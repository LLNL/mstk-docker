(function() {
var toc =  [{"type":"item","name":"BrowseService","url":"services/BrowseService.html"},{"type":"item","name":"SearchService","url":"services/SearchService.html"},{"type":"item","name":"DataExportService","url":"services/DataExportService.html"},{"type":"item","name":"DataImportService","url":"services/DataImportService.html"},{"type":"item","name":"EngineeringDataService","url":"services/EngineeringDataService.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
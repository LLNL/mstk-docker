(function() {
var toc =  [{"type":"item","name":"Welcome","url":"Welcome.html"},{"type":"book","name":"Services","key":"toc1","url":"Services.html"},{"type":"book","name":"Modules","key":"toc2","url":"Modules.html"},{"type":"book","name":"Example Python notebooks","key":"toc3","url":"Example_Code.htm"},{"type":"item","name":"Access the log files","url":"Logging.htm"},{"type":"item","name":"Copyright and trademarks","url":"Copyright.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();
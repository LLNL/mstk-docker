(function() {
var index =  {"type":"index"};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
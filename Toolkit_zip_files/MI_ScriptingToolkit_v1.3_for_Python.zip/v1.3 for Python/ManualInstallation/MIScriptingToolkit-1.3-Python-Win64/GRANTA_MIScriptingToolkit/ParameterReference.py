# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class ParameterReference(object):
    """ParameterReference. Identification of a particular parameter in a GRANTA MI database .
For requests a DBKey is required, and either the parameter ID  or the parameter name. 
    
        Arguments:
                * name - type str
                * DBKey - type str
                * ID - type int


    """
    
    def __init__(self, name=None, DBKey=None, ID=None, isOwner=True):
        """

        Arguments:
                * name - type str
                * DBKey - type str
                * ID - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ParameterReference_Create = self.lib.ParameterReference_Create
            ParameterReference_Create.restype = POINTER(c_void_p)
            self.c_obj = ParameterReference_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if name is not None:
            self.name = name
        if DBKey is not None:
            self.DBKey = DBKey
        if ID is not None:
            self.ID = ID


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ParameterReference_Destroy = self.lib.ParameterReference_Destroy
            ParameterReference_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ParameterReference_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    @property
    def ID(self):
        """Property ID is of type int. """ 
        self._ID = self.__GetID()
        return self._ID

    @ID.setter
    def ID(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('ID','ID: Invalid type ID must be of type int')
        self.__SetID(value)
        self._ID = value

    def __GetName(self):
        ParameterReference_GetName = self.lib.ParameterReference_GetName
        ParameterReference_GetName.argtypes = [POINTER(c_void_p)]
        ParameterReference_GetName.restype = POINTER(c_void_p)
        value = ParameterReference_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        ParameterReference_SetName = self.lib.ParameterReference_SetName 
        ParameterReference_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        ParameterReference_SetName(self._c_obj, EnsureEncoded(value))

    def __GetID(self):
        ParameterReference_GetID = self.lib.ParameterReference_GetID
        ParameterReference_GetID.argtypes = [POINTER(c_void_p)]
        ParameterReference_GetID.restype = c_int
        value = ParameterReference_GetID(self._c_obj)
        return value
    
    def __SetID(self, value):

        ParameterReference_SetID = self.lib.ParameterReference_SetID 
        ParameterReference_SetID.argtypes = [POINTER(c_void_p), c_int]
        ParameterReference_SetID(self._c_obj, value)

    def __SetDBKey(self, value):

        ParameterReference_SetDBKey = self.lib.ParameterReference_SetDBKey 
        ParameterReference_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        ParameterReference_SetDBKey(self._c_obj, EnsureEncoded(value))

    def __GetDBKey(self):
        ParameterReference_GetDBKey = self.lib.ParameterReference_GetDBKey
        ParameterReference_GetDBKey.argtypes = [POINTER(c_void_p)]
        ParameterReference_GetDBKey.restype = POINTER(c_void_p)
        value = ParameterReference_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


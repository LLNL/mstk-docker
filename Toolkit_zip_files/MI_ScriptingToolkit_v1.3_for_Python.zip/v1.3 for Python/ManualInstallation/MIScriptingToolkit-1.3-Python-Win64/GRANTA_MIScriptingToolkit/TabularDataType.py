# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.TabularColumn import TabularColumn
from GRANTA_MIScriptingToolkit.TabularDataRow import TabularDataRow

from .IDataValue import IDataValue


class TabularDataType(IDataValue):
    """TabularDataType. Type representing an item of exported Tabular Data, including metadata 
such as Column definitions. This type can also be used for import, although 
the usage pattern is different. See the :py:mod:`TabularDataRow <GRANTA_MIScriptingToolkit.TabularDataRow>` type for more information.
    
        Arguments:
                * columns - type list of str objects
                * tabularDataRows - type list of :py:mod:`TabularDataRow <GRANTA_MIScriptingToolkit.TabularDataRow>` objects


    """
    class ChangeType:
        InsertBefore = 0
        Append = 1
        Update = 2
        Delete = 3
    
    def __init__(self, columns=None, tabularDataRows=None, isOwner=True):
        """

        Arguments:
                * columns - type list of str objects
                * tabularDataRows - type list of :py:mod:`TabularDataRow <GRANTA_MIScriptingToolkit.TabularDataRow>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            TabularDataType_Create = self.lib.TabularDataType_Create
            TabularDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = TabularDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if columns is not None:
            self.columns = columns
        if tabularDataRows is not None:
            self.tabularDataRows = tabularDataRows


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            TabularDataType_Destroy = self.lib.TabularDataType_Destroy
            TabularDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            TabularDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    def CreateRow(self):
        """Create and return a row for a tabular data import operation."""

        value = TabularDataRow(isOwner=False)
        func = self.lib.TabularDataType_CreateRowRef
        func.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p))]
        func(self._c_obj, byref(value._c_obj))
        value._parent = self
        return value
    
    def CreateUpdateRow(self, type, identity):
        """
        Create and return a row for a tabular data import update operation.
        
        Arguments:
                * type - See :py:class:`TabularDataType.ChangeType <TabularDataType.ChangeType>` for supported values. This specifies the operation to perform on this tabular datum.
                * identity - The ID of the row to update. You should retrieve this from a data export operation (GetRecordAttributesByRef). If type is Append, pass this argument in as 0.

        """
        value = TabularDataRow(isOwner=False)
        func = self.lib.TabularDataType_CreateUpdateRowRef
        func.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p)), c_int, c_int]
        func(self._c_obj, byref(value._c_obj),type,identity)
        value._parent = self
        return value
    
    @property
    def columns(self):
        """Property columns is a list of str objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._columns = self.__GetColumnRefs()
        except:
            pass
        return self._columns

    @columns.setter
    def columns(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('columns','columns: Invalid type columns must be a list of str')
                
        try:
            self.__updatecolumns = True
            self.__ClearColumns()
            for v in value:
                self.AddColumn(v)
        except:
            pass


    @property
    def tabularDataRows(self):
        """Property tabularDataRows is a list of :py:mod:`TabularDataRow <GRANTA_MIScriptingToolkit.TabularDataRow>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._tabularDataRows = self.__GetTabularDataRowRefs()
        except:
            pass
        return self._tabularDataRows

    @tabularDataRows.setter
    def tabularDataRows(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('tabularDataRows','tabularDataRows: Invalid type tabularDataRows must be a list of TabularDataRow')
        
        self._tabularDataRows = value

    def __GetNumberOfColumnRefs(self):
        TabularDataType_GetNumberOfColumnRefs = self.lib.TabularDataType_GetNumberOfColumnRefs
        TabularDataType_GetNumberOfColumnRefs.argtypes = [POINTER(c_void_p)]
        TabularDataType_GetNumberOfColumnRefs.restype = c_int
        value = TabularDataType_GetNumberOfColumnRefs(self._c_obj)
        return value
    
    def __GetColumnRefsElement(self,i):
        value = TabularColumn(isOwner=False)
        TabularDataType_GetColumnRefs = self.lib.TabularDataType_GetColumnRefs
        TabularDataType_GetColumnRefs.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p)), c_int]
        TabularDataType_GetColumnRefs(self._c_obj, value.c_obj, i)
        value._parent = self
        return value
    
    def __GetColumnRefs(self):
         n = self.__GetNumberOfColumnRefs();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetColumnRefsElement(i))
         return temp
    
    def AddColumn(self, value):
        """Appends value to columns property on TabularDataType C-object.

           Arguments:
                value - object of type Defs.string_types.
        """

        TabularDataType_AddColumn = self.lib.TabularDataType_AddColumn
        TabularDataType_AddColumn.argtypes = [POINTER(c_void_p), c_char_p]
        TabularDataType_AddColumn(self._c_obj, value.encode('utf-8'))
        return self

    def __GetNumberOfTabularDataRowRefs(self):
        TabularDataType_GetNumberOfTabularDataRowRefs = self.lib.TabularDataType_GetNumberOfTabularDataRowRefs
        TabularDataType_GetNumberOfTabularDataRowRefs.argtypes = [POINTER(c_void_p)]
        TabularDataType_GetNumberOfTabularDataRowRefs.restype = c_int
        value = TabularDataType_GetNumberOfTabularDataRowRefs(self._c_obj)
        return value
    
    def __GetTabularDataRowRefsElement(self,i):
        value = TabularDataRow(isOwner=False)
        TabularDataType_GetTabularDataRowRefs = self.lib.TabularDataType_GetTabularDataRowRefs
        TabularDataType_GetTabularDataRowRefs.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p)), c_int]
        TabularDataType_GetTabularDataRowRefs(self._c_obj, value.c_obj, i)
        value._parent = self
        return value
    
    def __GetTabularDataRowRefs(self):
         n = self.__GetNumberOfTabularDataRowRefs();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetTabularDataRowRefsElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


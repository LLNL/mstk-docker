# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference
from GRANTA_MIScriptingToolkit.UnitConversionContext import UnitConversionContext
from GRANTA_MIScriptingToolkit.RecordFilter import RecordFilter
from GRANTA_MIScriptingToolkit.UnittedParameterValue import UnittedParameterValue


class ExportRecordDataRequest(object):
    """ExportRecordDataRequest. Input for the ExportRecordData operation. For this request to be valid, 
you must set the references and the exporter key. StopBeforeIndex is 0-indexed
    
        Arguments:
                * sigFigs - type int
                * exporterKey - type str
                * stopBeforeId - type str
                * parameterValues - type list of :py:mod:`UnittedParameterValue <GRANTA_MIScriptingToolkit.UnittedParameterValue>` objects
                * stopBeforeIndex - type int
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects
                * filter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * records - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * unitConversionContext - type :py:mod:`UnitConversionContext <GRANTA_MIScriptingToolkit.UnitConversionContext>`


    """
    
    def __init__(self, sigFigs=None, exporterKey=None, stopBeforeId=None, parameterValues=None, stopBeforeIndex=None, attributeReferences=None, filter=None, records=None, unitConversionContext=None, isOwner=True):
        """

        Arguments:
                * sigFigs - type int
                * exporterKey - type str
                * stopBeforeId - type str
                * parameterValues - type list of :py:mod:`UnittedParameterValue <GRANTA_MIScriptingToolkit.UnittedParameterValue>` objects
                * stopBeforeIndex - type int
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects
                * filter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * records - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * unitConversionContext - type :py:mod:`UnitConversionContext <GRANTA_MIScriptingToolkit.UnitConversionContext>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ExportRecordDataRequest_Create = self.lib.ExportRecordDataRequest_Create
            ExportRecordDataRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = ExportRecordDataRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if sigFigs is not None:
            self.sigFigs = sigFigs
        if exporterKey is not None:
            self.exporterKey = exporterKey
        if stopBeforeId is not None:
            self.stopBeforeId = stopBeforeId
        if parameterValues is not None:
            self.parameterValues = parameterValues
        if stopBeforeIndex is not None:
            self.stopBeforeIndex = stopBeforeIndex
        if attributeReferences is not None:
            self.attributeReferences = attributeReferences
        if filter is not None:
            self.filter = filter
        if records is not None:
            self.records = records
        if unitConversionContext is not None:
            self.unitConversionContext = unitConversionContext


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ExportRecordDataRequest_Destroy = self.lib.ExportRecordDataRequest_Destroy
            ExportRecordDataRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ExportRecordDataRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def sigFigs(self):
        """Property sigFigs is of type int. """ 
        self._sigFigs = self.__GetSigFigs()
        return self._sigFigs

    @sigFigs.setter
    def sigFigs(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('sigFigs','sigFigs: Invalid type sigFigs must be of type int')
        self.__SetSigFigs(value)
        self._sigFigs = value

    @property
    def exporterKey(self):
        """Property exporterKey is of type str. """ 
        self._exporterKey = self.__GetExporterKey()
        return self._exporterKey

    @exporterKey.setter
    def exporterKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('exporterKey','exporterKey: Invalid type exporterKey must be of type str')
        self.__SetExporterKey(value)
        self._exporterKey = value

    @property
    def stopBeforeId(self):
        """Property stopBeforeId is of type str. """ 
        self._stopBeforeId = self.__GetStopBeforeId()
        return self._stopBeforeId

    @stopBeforeId.setter
    def stopBeforeId(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('stopBeforeId','stopBeforeId: Invalid type stopBeforeId must be of type str')
        self.__SetStopBeforeId(value)
        self._stopBeforeId = value

    @property
    def parameterValues(self):
        """Property parameterValues is a list of :py:mod:`UnittedParameterValue <GRANTA_MIScriptingToolkit.UnittedParameterValue>` objects. Parameter values to use for any parameterised Data in the export. Each Parameter can only have one value for all parameterised Attributes in an export. Note that the true Parameter names (or Standard Names) in the MI Database must be used; aliases defined in the exporter configuration will not be understood. 
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._parameterValues = self.__GetParameterValues()
        except:
            pass
        return self._parameterValues

    @parameterValues.setter
    def parameterValues(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('parameterValues','parameterValues: Invalid type parameterValues must be a list of UnittedParameterValue')
                
        try:
            self.__updateparameterValues = True
            self.__ClearParameterValues()
            for v in value:
                self.AddParameterValues(v)
        except:
            pass


    @property
    def stopBeforeIndex(self):
        """Property stopBeforeIndex is of type int. """ 
        self._stopBeforeIndex = self.__GetStopBeforeIndex()
        return self._stopBeforeIndex

    @stopBeforeIndex.setter
    def stopBeforeIndex(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('stopBeforeIndex','stopBeforeIndex: Invalid type stopBeforeIndex must be of type int')
        self.__SetStopBeforeIndex(value)
        self._stopBeforeIndex = value

    @property
    def attributeReferences(self):
        """Property attributeReferences is a list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects. If this property is not specified, the attributes from the exporter configuration are used. If this element is included and non-empty, the attributes specified are used. 
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeReferences = self.__GetAttributeReferences()
        except:
            pass
        return self._attributeReferences

    @attributeReferences.setter
    def attributeReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeReferences','attributeReferences: Invalid type attributeReferences must be a list of AttributeReference')
                
        try:
            self.__updateattributeReferences = True
            self.__ClearAttributeReferences()
            for v in value:
                self.AddAttributeReference(v)
        except:
            pass


    @property
    def filter(self):
        """Property filter is of type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`. If specified, this filters the records that can be included when traversing record links within Tabular Data. This filter is NOT applied to the explicit list of records passed to this operation.""" 
        self._filter = self.__GetFilter()
        return self._filter

    @filter.setter
    def filter(self, value):
        if not isinstance(value, RecordFilter):
            raise GRANTA_Exception('filter','filter: Invalid type filter must be of type RecordFilter')
        self.__SetFilter(value)
        self._filter = value

    @property
    def records(self):
        """Property records is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._records = self.__GetRecords()
        except:
            pass
        return self._records

    @records.setter
    def records(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('records','records: Invalid type records must be a list of RecordReference')
                
        try:
            self.__updaterecords = True
            self.__ClearRecords()
            for v in value:
                self.AddRecord(v)
        except:
            pass


    @property
    def unitConversionContext(self):
        """Property unitConversionContext is of type :py:mod:`UnitConversionContext <GRANTA_MIScriptingToolkit.UnitConversionContext>`. """ 
        self._unitConversionContext = self.__GetUnitConversionContext()
        return self._unitConversionContext

    @unitConversionContext.setter
    def unitConversionContext(self, value):
        if not isinstance(value, UnitConversionContext):
            raise GRANTA_Exception('unitConversionContext','unitConversionContext: Invalid type unitConversionContext must be of type UnitConversionContext')
        self.__SetUnitConversionContext(value)
        self._unitConversionContext = value

    def AddRecord(self, _recordReference):
        """Appends _recordReference to records property on ExportRecordDataRequest C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('ExportRecordDataRequest.AddRecord','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        ExportRecordDataRequest_AddRecord = self.lib.ExportRecordDataRequest_AddRecord
        ExportRecordDataRequest_AddRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ExportRecordDataRequest_AddRecord(self._c_obj, _recordReference.c_obj)
        return self

    def __ClearRecords(self):
        ExportRecordDataRequest_ClearRecords = self.lib.ExportRecordDataRequest_ClearRecords
        ExportRecordDataRequest_ClearRecords.argtypes = [POINTER(c_void_p)]
        ExportRecordDataRequest_ClearRecords(self._c_obj)
        return self

    def __GetNumberOfRecords(self):
        ExportRecordDataRequest_GetNumberOfRecords = self.lib.ExportRecordDataRequest_GetNumberOfRecords
        ExportRecordDataRequest_GetNumberOfRecords.argtypes = [POINTER(c_void_p)]
        ExportRecordDataRequest_GetNumberOfRecords.restype = c_int
        value = ExportRecordDataRequest_GetNumberOfRecords(self._c_obj)
        return value
    
    def __GetRecordElement(self,i):
        value = RecordReference()
        ExportRecordDataRequest_GetRecord = self.lib.ExportRecordDataRequest_GetRecord
        ExportRecordDataRequest_GetRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        ExportRecordDataRequest_GetRecord(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecords(self):
         n = self.__GetNumberOfRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordElement(i))
         return temp
    
    def __GetNumberOfAttributeReferences(self):
        ExportRecordDataRequest_GetNumberOfAttributeReferences = self.lib.ExportRecordDataRequest_GetNumberOfAttributeReferences
        ExportRecordDataRequest_GetNumberOfAttributeReferences.argtypes = [POINTER(c_void_p)]
        ExportRecordDataRequest_GetNumberOfAttributeReferences.restype = c_int
        value = ExportRecordDataRequest_GetNumberOfAttributeReferences(self._c_obj)
        return value
    
    def __GetAttributeReferenceElement(self,i):
        value = AttributeReference()
        ExportRecordDataRequest_GetAttributeReference = self.lib.ExportRecordDataRequest_GetAttributeReference
        ExportRecordDataRequest_GetAttributeReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        ExportRecordDataRequest_GetAttributeReference(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributeReferences(self):
         n = self.__GetNumberOfAttributeReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeReferenceElement(i))
         return temp
    
    def AddAttributeReference(self, _attributeReference):
        """Appends _attributeReference to attributeReferences property on ExportRecordDataRequest C-object.

           Arguments:
                _attributeReference - object of type AttributeReference.
        """

        if not isinstance(_attributeReference, AttributeReference):
            raise GRANTA_Exception('ExportRecordDataRequest.AddAttributeReference','_attributeReference: Invalid argument type _attributeReference must be of type AttributeReference')
        ExportRecordDataRequest_AddAttributeReference = self.lib.ExportRecordDataRequest_AddAttributeReference
        ExportRecordDataRequest_AddAttributeReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ExportRecordDataRequest_AddAttributeReference(self._c_obj, _attributeReference.c_obj)
        return self

    def __ClearAttributeReferences(self):
        ExportRecordDataRequest_ClearAttributeReferences = self.lib.ExportRecordDataRequest_ClearAttributeReferences
        ExportRecordDataRequest_ClearAttributeReferences.argtypes = [POINTER(c_void_p)]
        ExportRecordDataRequest_ClearAttributeReferences(self._c_obj)
        return self

    def __SetExporterKey(self, value):

        ExportRecordDataRequest_SetExporterKey = self.lib.ExportRecordDataRequest_SetExporterKey 
        ExportRecordDataRequest_SetExporterKey.argtypes = [POINTER(c_void_p), c_char_p]
        ExportRecordDataRequest_SetExporterKey(self._c_obj, EnsureEncoded(value))

    def __GetExporterKey(self):
        ExportRecordDataRequest_GetExporterKey = self.lib.ExportRecordDataRequest_GetExporterKey
        ExportRecordDataRequest_GetExporterKey.argtypes = [POINTER(c_void_p)]
        ExportRecordDataRequest_GetExporterKey.restype = POINTER(c_void_p)
        value = ExportRecordDataRequest_GetExporterKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetUnitConversionContext(self):
        _unitConversionContext = UnitConversionContext()
        ExportRecordDataRequest_GetUnitConversionContext = self.lib.ExportRecordDataRequest_GetUnitConversionContext
        ExportRecordDataRequest_GetUnitConversionContext.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ExportRecordDataRequest_GetUnitConversionContext(self._c_obj, (_unitConversionContext.c_obj))
        
        return _unitConversionContext
        
    def __SetUnitConversionContext(self, value):

        ExportRecordDataRequest_SetUnitConversionContext = self.lib.ExportRecordDataRequest_SetUnitConversionContext 
        ExportRecordDataRequest_SetUnitConversionContext.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ExportRecordDataRequest_SetUnitConversionContext(self._c_obj, value.c_obj)

    def __GetFilter(self):
        _recordFilter = RecordFilter()
        ExportRecordDataRequest_GetFilter = self.lib.ExportRecordDataRequest_GetFilter
        ExportRecordDataRequest_GetFilter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ExportRecordDataRequest_GetFilter(self._c_obj, (_recordFilter.c_obj))
        
        return _recordFilter
        
    def __SetFilter(self, value):

        ExportRecordDataRequest_SetFilter = self.lib.ExportRecordDataRequest_SetFilter 
        ExportRecordDataRequest_SetFilter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ExportRecordDataRequest_SetFilter(self._c_obj, value.c_obj)

    def __GetNumberOfParameterValues(self):
        ExportRecordDataRequest_GetNumberOfParameterValues = self.lib.ExportRecordDataRequest_GetNumberOfParameterValues
        ExportRecordDataRequest_GetNumberOfParameterValues.argtypes = [POINTER(c_void_p)]
        ExportRecordDataRequest_GetNumberOfParameterValues.restype = c_int
        value = ExportRecordDataRequest_GetNumberOfParameterValues(self._c_obj)
        return value
    
    def __GetParameterValueElement(self,i):
        value = UnittedParameterValue()
        ExportRecordDataRequest_GetParameterValue = self.lib.ExportRecordDataRequest_GetParameterValue
        ExportRecordDataRequest_GetParameterValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        ExportRecordDataRequest_GetParameterValue(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetParameterValues(self):
         n = self.__GetNumberOfParameterValues();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetParameterValueElement(i))
         return temp
    
    def AddParameterValues(self, _unittedParameterValue):
        """Appends _unittedParameterValue to parameterValues property on ExportRecordDataRequest C-object.

           Arguments:
                _unittedParameterValue - object of type UnittedParameterValue.
        """

        if not isinstance(_unittedParameterValue, UnittedParameterValue):
            raise GRANTA_Exception('ExportRecordDataRequest.AddParameterValues','_unittedParameterValue: Invalid argument type _unittedParameterValue must be of type UnittedParameterValue')
        ExportRecordDataRequest_AddParameterValues = self.lib.ExportRecordDataRequest_AddParameterValues
        ExportRecordDataRequest_AddParameterValues.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ExportRecordDataRequest_AddParameterValues(self._c_obj, _unittedParameterValue.c_obj)
        return self

    def __ClearParameterValues(self):
        ExportRecordDataRequest_ClearParameterValues = self.lib.ExportRecordDataRequest_ClearParameterValues
        ExportRecordDataRequest_ClearParameterValues.argtypes = [POINTER(c_void_p)]
        ExportRecordDataRequest_ClearParameterValues(self._c_obj)
        return self

    def __GetSigFigs(self):
        ExportRecordDataRequest_GetSigFigs = self.lib.ExportRecordDataRequest_GetSigFigs
        ExportRecordDataRequest_GetSigFigs.argtypes = [POINTER(c_void_p)]
        ExportRecordDataRequest_GetSigFigs.restype = c_int
        value = ExportRecordDataRequest_GetSigFigs(self._c_obj)
        return value
    
    def __SetSigFigs(self, value):

        ExportRecordDataRequest_SetSigFigs = self.lib.ExportRecordDataRequest_SetSigFigs 
        ExportRecordDataRequest_SetSigFigs.argtypes = [POINTER(c_void_p), c_int]
        ExportRecordDataRequest_SetSigFigs(self._c_obj, value)

    def __GetStopBeforeIndex(self):
        ExportRecordDataRequest_GetStopBeforeIndex = self.lib.ExportRecordDataRequest_GetStopBeforeIndex
        ExportRecordDataRequest_GetStopBeforeIndex.argtypes = [POINTER(c_void_p)]
        ExportRecordDataRequest_GetStopBeforeIndex.restype = c_int
        value = ExportRecordDataRequest_GetStopBeforeIndex(self._c_obj)
        return value
    
    def __SetStopBeforeIndex(self, value):

        ExportRecordDataRequest_SetStopBeforeIndex = self.lib.ExportRecordDataRequest_SetStopBeforeIndex 
        ExportRecordDataRequest_SetStopBeforeIndex.argtypes = [POINTER(c_void_p), c_int]
        ExportRecordDataRequest_SetStopBeforeIndex(self._c_obj, value)

    def __GetStopBeforeId(self):
        ExportRecordDataRequest_GetStopBeforeId = self.lib.ExportRecordDataRequest_GetStopBeforeId
        ExportRecordDataRequest_GetStopBeforeId.argtypes = [POINTER(c_void_p)]
        ExportRecordDataRequest_GetStopBeforeId.restype = POINTER(c_void_p)
        value = ExportRecordDataRequest_GetStopBeforeId(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetStopBeforeId(self, value):

        ExportRecordDataRequest_SetStopBeforeId = self.lib.ExportRecordDataRequest_SetStopBeforeId 
        ExportRecordDataRequest_SetStopBeforeId.argtypes = [POINTER(c_void_p), c_char_p]
        ExportRecordDataRequest_SetStopBeforeId(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse
from GRANTA_MIScriptingToolkit.RecordExporterParameters import RecordExporterParameters


class GetExporterParametersResponse(object):
    """GetExporterParametersResponse. Output from the GetExporterParameters operation. Contains a list of records and details for exporting their attributes.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetExporterParametersResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetExporterParametersResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetExporterParametersResponse_Destroy = self.lib.GetExporterParametersResponse_Destroy
            GetExporterParametersResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetExporterParametersResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def records(self):
        """Property records is a list of :py:mod:`RecordExporterParameters <GRANTA_MIScriptingToolkit.RecordExporterParameters>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._records = self.__GetRecords()
        except:
            pass
        return self._records

    @records.setter
    def records(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('records','records: Invalid type records must be a list of RecordExporterParameters')
        
        self._records = value

    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        self.__SetServiceLayerResponse(value)
        self._serviceLayerResponse = value

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetExporterParametersResponse_GetServiceLayerResponse = self.lib.GetExporterParametersResponse_GetServiceLayerResponse
        GetExporterParametersResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetExporterParametersResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __SetServiceLayerResponse(self, value):

        GetExporterParametersResponse_SetServiceLayerResponse = self.lib.GetExporterParametersResponse_SetServiceLayerResponse 
        GetExporterParametersResponse_SetServiceLayerResponse.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetExporterParametersResponse_SetServiceLayerResponse(self._c_obj, value.c_obj)

    def __GetNumberOfRecords(self):
        GetExporterParametersResponse_GetNumberOfRecords = self.lib.GetExporterParametersResponse_GetNumberOfRecords
        GetExporterParametersResponse_GetNumberOfRecords.argtypes = [POINTER(c_void_p)]
        GetExporterParametersResponse_GetNumberOfRecords.restype = c_int
        value = GetExporterParametersResponse_GetNumberOfRecords(self._c_obj)
        return value
    
    def __GetRecordElement(self,i):
        value = RecordExporterParameters()
        GetExporterParametersResponse_GetRecord = self.lib.GetExporterParametersResponse_GetRecord
        GetExporterParametersResponse_GetRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetExporterParametersResponse_GetRecord(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecords(self):
         n = self.__GetNumberOfRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


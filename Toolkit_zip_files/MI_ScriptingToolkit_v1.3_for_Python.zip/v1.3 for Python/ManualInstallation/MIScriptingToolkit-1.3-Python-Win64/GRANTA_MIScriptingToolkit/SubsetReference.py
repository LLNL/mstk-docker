# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.PartialTableReference import PartialTableReference


class SubsetReference(object):
    """SubsetReference. A type that identifies a particular subset in a GRANTA MI database. This 
may be done by specifying the identity of the subset, or by specifying a 
name that will match (only) the subset along with the table to which the subset belongs.
    
        Arguments:
                * subsetIdentity - type int
                * name - type str
                * DBKey - type str
                * partialTableReference - type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`


    """
    
    def __init__(self, subsetIdentity=None, name=None, DBKey=None, partialTableReference=None, isOwner=True):
        """

        Arguments:
                * subsetIdentity - type int
                * name - type str
                * DBKey - type str
                * partialTableReference - type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            SubsetReference_Create = self.lib.SubsetReference_Create
            SubsetReference_Create.restype = POINTER(c_void_p)
            self.c_obj = SubsetReference_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if subsetIdentity is not None:
            self.subsetIdentity = subsetIdentity
        if name is not None:
            self.name = name
        if DBKey is not None:
            self.DBKey = DBKey
        if partialTableReference is not None:
            self.partialTableReference = partialTableReference


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            SubsetReference_Destroy = self.lib.SubsetReference_Destroy
            SubsetReference_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            SubsetReference_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def subsetIdentity(self):
        """Property subsetIdentity is of type int. """ 
        self._subsetIdentity = self.__GetSubsetIdentity()
        return self._subsetIdentity

    @subsetIdentity.setter
    def subsetIdentity(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('subsetIdentity','subsetIdentity: Invalid type subsetIdentity must be of type int')
        self.__SetSubsetIdentity(value)
        self._subsetIdentity = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    @property
    def partialTableReference(self):
        """Property partialTableReference is of type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`. When used for input, this only needs to be specified if you are specifying a name rather than an id.""" 
        self._partialTableReference = self.__GetPartialTableReference()
        return self._partialTableReference

    @partialTableReference.setter
    def partialTableReference(self, value):
        """When used for input, this only needs to be specified if you are specifying a name rather than an id."""
        if not isinstance(value, PartialTableReference):
            raise GRANTA_Exception('partialTableReference','partialTableReference: Invalid type partialTableReference must be of type PartialTableReference')
        self.__SetPartialTableReference(value)
        self._partialTableReference = value

    def __GetName(self):
        SubsetReference_GetName = self.lib.SubsetReference_GetName
        SubsetReference_GetName.argtypes = [POINTER(c_void_p)]
        SubsetReference_GetName.restype = POINTER(c_void_p)
        value = SubsetReference_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        SubsetReference_SetName = self.lib.SubsetReference_SetName 
        SubsetReference_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        SubsetReference_SetName(self._c_obj, EnsureEncoded(value))

    def __SetDBKey(self, value):

        SubsetReference_SetDBKey = self.lib.SubsetReference_SetDBKey 
        SubsetReference_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        SubsetReference_SetDBKey(self._c_obj, EnsureEncoded(value))

    def __GetDBKey(self):
        SubsetReference_GetDBKey = self.lib.SubsetReference_GetDBKey
        SubsetReference_GetDBKey.argtypes = [POINTER(c_void_p)]
        SubsetReference_GetDBKey.restype = POINTER(c_void_p)
        value = SubsetReference_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetPartialTableReference(self, value):
        """When used for input, this only needs to be specified if you are specifying a name rather than an id."""

        SubsetReference_SetPartialTableReference = self.lib.SubsetReference_SetPartialTableReference 
        SubsetReference_SetPartialTableReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        SubsetReference_SetPartialTableReference(self._c_obj, value.c_obj)

    def __GetPartialTableReference(self):
        _partialTableReference = PartialTableReference()
        SubsetReference_GetPartialTableReference = self.lib.SubsetReference_GetPartialTableReference
        SubsetReference_GetPartialTableReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        SubsetReference_GetPartialTableReference(self._c_obj, (_partialTableReference.c_obj))
        
        return _partialTableReference
        
    def __GetSubsetIdentity(self):
        SubsetReference_GetSubsetIdentity = self.lib.SubsetReference_GetSubsetIdentity
        SubsetReference_GetSubsetIdentity.argtypes = [POINTER(c_void_p)]
        SubsetReference_GetSubsetIdentity.restype = c_int
        value = SubsetReference_GetSubsetIdentity(self._c_obj)
        return value
    
    def __SetSubsetIdentity(self, value):

        SubsetReference_SetSubsetIdentity = self.lib.SubsetReference_SetSubsetIdentity 
        SubsetReference_SetSubsetIdentity.argtypes = [POINTER(c_void_p), c_int]
        SubsetReference_SetSubsetIdentity(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


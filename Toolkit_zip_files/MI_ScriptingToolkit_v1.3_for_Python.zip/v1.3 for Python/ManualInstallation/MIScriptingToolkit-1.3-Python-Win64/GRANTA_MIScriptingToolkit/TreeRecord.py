# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class TreeRecord(object):
    """TreeRecord. Type representing a single record in a GRANTA MI database, along with information about its position in the node-tree.
    
        Arguments:
                * parentRecordHistoryIdentity - type int
                * color - type str
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * longName - type str
                * shortName - type str
                * type - type str
                * children - type list of :py:mod:`TreeRecord <GRANTA_MIScriptingToolkit.TreeRecord>` objects


    """
    
    def __init__(self, parentRecordHistoryIdentity=None, color=None, recordReference=None, longName=None, shortName=None, type=None, children=None, isOwner=True):
        """

        Arguments:
                * parentRecordHistoryIdentity - type int
                * color - type str
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * longName - type str
                * shortName - type str
                * type - type str
                * children - type list of :py:mod:`TreeRecord <GRANTA_MIScriptingToolkit.TreeRecord>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            TreeRecord_Create = self.lib.TreeRecord_Create
            TreeRecord_Create.restype = POINTER(c_void_p)
            self.c_obj = TreeRecord_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if parentRecordHistoryIdentity is not None:
            self.parentRecordHistoryIdentity = parentRecordHistoryIdentity
        if color is not None:
            self.color = color
        if recordReference is not None:
            self.recordReference = recordReference
        if longName is not None:
            self.longName = longName
        if shortName is not None:
            self.shortName = shortName
        if type is not None:
            self.type = type
        if children is not None:
            self.children = children


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            TreeRecord_Destroy = self.lib.TreeRecord_Destroy
            TreeRecord_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            TreeRecord_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def parentRecordHistoryIdentity(self):
        """Property parentRecordHistoryIdentity is of type int. """ 
        self._parentRecordHistoryIdentity = self.__GetParentRecordHistoryIdentity()
        return self._parentRecordHistoryIdentity

    @parentRecordHistoryIdentity.setter
    def parentRecordHistoryIdentity(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('parentRecordHistoryIdentity','parentRecordHistoryIdentity: Invalid type parentRecordHistoryIdentity must be of type int')
        self.__SetParentRecordHistoryIdentity(value)
        self._parentRecordHistoryIdentity = value

    @property
    def color(self):
        """Property color is of type str. """ 
        self._color = self.__GetColor()
        return self._color

    @color.setter
    def color(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('color','color: Invalid type color must be of type str')
        
        self._color = value

    @property
    def recordReference(self):
        """Property recordReference is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._recordReference = self.__GetRecordReference()
        return self._recordReference

    @recordReference.setter
    def recordReference(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('recordReference','recordReference: Invalid type recordReference must be of type RecordReference')
        
        self._recordReference = value

    @property
    def longName(self):
        """Property longName is of type str. """ 
        self._longName = self.__GetLongName()
        return self._longName

    @longName.setter
    def longName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('longName','longName: Invalid type longName must be of type str')
        
        self._longName = value

    @property
    def shortName(self):
        """Property shortName is of type str. """ 
        self._shortName = self.__GetShortName()
        return self._shortName

    @shortName.setter
    def shortName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('shortName','shortName: Invalid type shortName must be of type str')
        
        self._shortName = value

    @property
    def type(self):
        """Property type is of type str. """ 
        self._type = self.__GetType()
        return self._type

    @type.setter
    def type(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('type','type: Invalid type type must be of type str')
        
        self._type = value

    @property
    def children(self):
        """Property children is a list of :py:mod:`TreeRecord <GRANTA_MIScriptingToolkit.TreeRecord>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._children = self.__GetChildren()
        except:
            pass
        return self._children

    @children.setter
    def children(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('children','children: Invalid type children must be a list of TreeRecord')
                
        try:
            self.__updatechildren = True
            self.__ClearChildren()
            for v in value:
                self.AddChildren(v)
        except:
            pass


    def AddChildren(self, _treeRecord):
        """Appends _treeRecord to children property on TreeRecord C-object.

           Arguments:
                _treeRecord - object of type TreeRecord.
        """

        if not isinstance(_treeRecord, TreeRecord):
            raise GRANTA_Exception('TreeRecord.AddChildren','_treeRecord: Invalid argument type _treeRecord must be of type TreeRecord')
        TreeRecord_AddChildren = self.lib.TreeRecord_AddChildren
        TreeRecord_AddChildren.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        TreeRecord_AddChildren(self._c_obj, _treeRecord.c_obj)
        return self

    def __ClearChildren(self):
        TreeRecord_ClearChildren = self.lib.TreeRecord_ClearChildren
        TreeRecord_ClearChildren.argtypes = [POINTER(c_void_p)]
        TreeRecord_ClearChildren(self._c_obj)
        return self

    def __GetNumberOfChildren(self):
        TreeRecord_GetNumberOfChildren = self.lib.TreeRecord_GetNumberOfChildren
        TreeRecord_GetNumberOfChildren.argtypes = [POINTER(c_void_p)]
        TreeRecord_GetNumberOfChildren.restype = c_int
        value = TreeRecord_GetNumberOfChildren(self._c_obj)
        return value
    
    def __GetChildrenElement(self,i):
        value = TreeRecord()
        TreeRecord_GetChildren = self.lib.TreeRecord_GetChildren
        TreeRecord_GetChildren.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        TreeRecord_GetChildren(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetChildren(self):
         n = self.__GetNumberOfChildren();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetChildrenElement(i))
         return temp
    
    def __GetParentRecordHistoryIdentity(self):
        TreeRecord_GetParentRecordHistoryIdentity = self.lib.TreeRecord_GetParentRecordHistoryIdentity
        TreeRecord_GetParentRecordHistoryIdentity.argtypes = [POINTER(c_void_p)]
        TreeRecord_GetParentRecordHistoryIdentity.restype = c_int
        value = TreeRecord_GetParentRecordHistoryIdentity(self._c_obj)
        return value
    
    def __SetParentRecordHistoryIdentity(self, value):

        TreeRecord_SetParentRecordHistoryIdentity = self.lib.TreeRecord_SetParentRecordHistoryIdentity 
        TreeRecord_SetParentRecordHistoryIdentity.argtypes = [POINTER(c_void_p), c_int]
        TreeRecord_SetParentRecordHistoryIdentity(self._c_obj, value)

    def __GetShortName(self):
        TreeRecord_GetShortName = self.lib.TreeRecord_GetShortName
        TreeRecord_GetShortName.argtypes = [POINTER(c_void_p)]
        TreeRecord_GetShortName.restype = POINTER(c_void_p)
        value = TreeRecord_GetShortName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetLongName(self):
        TreeRecord_GetLongName = self.lib.TreeRecord_GetLongName
        TreeRecord_GetLongName.argtypes = [POINTER(c_void_p)]
        TreeRecord_GetLongName.restype = POINTER(c_void_p)
        value = TreeRecord_GetLongName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetType(self):
        TreeRecord_GetType = self.lib.TreeRecord_GetType
        TreeRecord_GetType.argtypes = [POINTER(c_void_p)]
        TreeRecord_GetType.restype = POINTER(c_void_p)
        value = TreeRecord_GetType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetColor(self):
        TreeRecord_GetColor = self.lib.TreeRecord_GetColor
        TreeRecord_GetColor.argtypes = [POINTER(c_void_p)]
        TreeRecord_GetColor.restype = POINTER(c_void_p)
        value = TreeRecord_GetColor(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetRecordReference(self):
        _recordReference = RecordReference()
        TreeRecord_GetRecordReference = self.lib.TreeRecord_GetRecordReference
        TreeRecord_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TreeRecord_GetRecordReference(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


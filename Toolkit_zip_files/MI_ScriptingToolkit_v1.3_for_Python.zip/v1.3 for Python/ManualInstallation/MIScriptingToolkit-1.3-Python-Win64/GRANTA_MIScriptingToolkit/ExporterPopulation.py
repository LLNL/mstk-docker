# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ExporterTransform import ExporterTransform


class ExporterPopulation(object):
    """ExporterPopulation. Details of a particular FEA :py:mod:`Exporter <GRANTA_MIScriptingToolkit.Exporter>` configuration, typically obtained from an :py:mod:`Exporter <GRANTA_MIScriptingToolkit.Exporter>` Configuration File (EXP file) on the MI Server.
    
        Arguments:
                * description - type str
                * package - type str
                * validatedOk - type bool
                * name - type str
                * version - type int
                * transforms - type list of :py:mod:`ExporterTransform <GRANTA_MIScriptingToolkit.ExporterTransform>` objects
                * key - type str
                * model - type str
                * populationState - type int


    """
    class PopulationState:
        Unknown = 0
        FullyPopulated = 1
        PartiallyPopulated = 2
    
    def __init__(self, description=None, package=None, validatedOk=None, name=None, version=None, transforms=None, key=None, model=None, populationState=None, isOwner=True):
        """

        Arguments:
                * description - type str
                * package - type str
                * validatedOk - type bool
                * name - type str
                * version - type int
                * transforms - type list of :py:mod:`ExporterTransform <GRANTA_MIScriptingToolkit.ExporterTransform>` objects
                * key - type str
                * model - type str
                * populationState - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ExporterPopulation_Create = self.lib.ExporterPopulation_Create
            ExporterPopulation_Create.restype = POINTER(c_void_p)
            self.c_obj = ExporterPopulation_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if description is not None:
            self.description = description
        if package is not None:
            self.package = package
        if validatedOk is not None:
            self.validatedOk = validatedOk
        if name is not None:
            self.name = name
        if version is not None:
            self.version = version
        if transforms is not None:
            self.transforms = transforms
        if key is not None:
            self.key = key
        if model is not None:
            self.model = model
        if populationState is not None:
            self.populationState = populationState


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ExporterPopulation_Destroy = self.lib.ExporterPopulation_Destroy
            ExporterPopulation_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ExporterPopulation_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def description(self):
        """Property description is of type str. """ 
        self._description = self.__GetDescription()
        return self._description

    @description.setter
    def description(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('description','description: Invalid type description must be of type str')
        
        self._description = value

    @property
    def package(self):
        """Property package is of type str. """ 
        self._package = self.__GetPackage()
        return self._package

    @package.setter
    def package(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('package','package: Invalid type package must be of type str')
        
        self._package = value

    @property
    def validatedOk(self):
        """Property validatedOk is of type bool. """ 
        self._validatedOk = self.__GetValidatedOk()
        return self._validatedOk

    @validatedOk.setter
    def validatedOk(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('validatedOk','validatedOk: Invalid type validatedOk must be of type bool')
        
        self._validatedOk = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        
        self._name = value

    @property
    def version(self):
        """Property version is of type int. """ 
        self._version = self.__GetVersion()
        return self._version

    @version.setter
    def version(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('version','version: Invalid type version must be of type int')
        
        self._version = value

    @property
    def transforms(self):
        """Property transforms is a list of :py:mod:`ExporterTransform <GRANTA_MIScriptingToolkit.ExporterTransform>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._transforms = self.__GetTransforms()
        except:
            pass
        return self._transforms

    @transforms.setter
    def transforms(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('transforms','transforms: Invalid type transforms must be a list of ExporterTransform')
        
        self._transforms = value

    @property
    def key(self):
        """Property key is of type str. """ 
        self._key = self.__GetKey()
        return self._key

    @key.setter
    def key(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('key','key: Invalid type key must be of type str')
        
        self._key = value

    @property
    def model(self):
        """Property model is of type str. """ 
        self._model = self.__GetModel()
        return self._model

    @model.setter
    def model(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('model','model: Invalid type model must be of type str')
        
        self._model = value

    @property
    def populationState(self):
        """Property populationState is of type int. See :py:class:`ExporterPopulation.PopulationState <ExporterPopulation.PopulationState>` for supported values.""" 
        self._populationState = self.__GetPopulationState()
        return self._populationState

    @populationState.setter
    def populationState(self, value):
        """See :py:class:`ExporterPopulation.PopulationState <ExporterPopulation.PopulationState>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('populationState','populationState: Invalid type populationState must be of type int')
        self.__SetPopulationState(value)
        self._populationState = value

    def __GetPopulationState(self):
        ExporterPopulation_GetPopulationState = self.lib.ExporterPopulation_GetPopulationState
        ExporterPopulation_GetPopulationState.argtypes = [POINTER(c_void_p)]
        ExporterPopulation_GetPopulationState.restype = c_int
        value = ExporterPopulation_GetPopulationState(self._c_obj)
        return value
    
    def __SetPopulationState(self, value):
        """See :py:class:`ExporterPopulation.PopulationState <ExporterPopulation.PopulationState>` for supported values."""

        ExporterPopulation_SetPopulationState = self.lib.ExporterPopulation_SetPopulationState 
        ExporterPopulation_SetPopulationState.argtypes = [POINTER(c_void_p), c_int]
        ExporterPopulation_SetPopulationState(self._c_obj, value)

    def __GetKey(self):
        ExporterPopulation_GetKey = self.lib.ExporterPopulation_GetKey
        ExporterPopulation_GetKey.argtypes = [POINTER(c_void_p)]
        ExporterPopulation_GetKey.restype = POINTER(c_void_p)
        value = ExporterPopulation_GetKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetPackage(self):
        ExporterPopulation_GetPackage = self.lib.ExporterPopulation_GetPackage
        ExporterPopulation_GetPackage.argtypes = [POINTER(c_void_p)]
        ExporterPopulation_GetPackage.restype = POINTER(c_void_p)
        value = ExporterPopulation_GetPackage(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetModel(self):
        ExporterPopulation_GetModel = self.lib.ExporterPopulation_GetModel
        ExporterPopulation_GetModel.argtypes = [POINTER(c_void_p)]
        ExporterPopulation_GetModel.restype = POINTER(c_void_p)
        value = ExporterPopulation_GetModel(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetDescription(self):
        ExporterPopulation_GetDescription = self.lib.ExporterPopulation_GetDescription
        ExporterPopulation_GetDescription.argtypes = [POINTER(c_void_p)]
        ExporterPopulation_GetDescription.restype = POINTER(c_void_p)
        value = ExporterPopulation_GetDescription(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetNumberOfTransforms(self):
        ExporterPopulation_GetNumberOfTransforms = self.lib.ExporterPopulation_GetNumberOfTransforms
        ExporterPopulation_GetNumberOfTransforms.argtypes = [POINTER(c_void_p)]
        ExporterPopulation_GetNumberOfTransforms.restype = c_int
        value = ExporterPopulation_GetNumberOfTransforms(self._c_obj)
        return value
    
    def __GetTransformElement(self,i):
        value = ExporterTransform()
        ExporterPopulation_GetTransform = self.lib.ExporterPopulation_GetTransform
        ExporterPopulation_GetTransform.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        ExporterPopulation_GetTransform(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetTransforms(self):
         n = self.__GetNumberOfTransforms();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetTransformElement(i))
         return temp
    
    def __GetName(self):
        ExporterPopulation_GetName = self.lib.ExporterPopulation_GetName
        ExporterPopulation_GetName.argtypes = [POINTER(c_void_p)]
        ExporterPopulation_GetName.restype = POINTER(c_void_p)
        value = ExporterPopulation_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetVersion(self):
        ExporterPopulation_GetVersion = self.lib.ExporterPopulation_GetVersion
        ExporterPopulation_GetVersion.argtypes = [POINTER(c_void_p)]
        ExporterPopulation_GetVersion.restype = c_int
        value = ExporterPopulation_GetVersion(self._c_obj)
        return value
    
    def __GetValidatedOk(self):
        ExporterPopulation_GetValidatedOk = self.lib.ExporterPopulation_GetValidatedOk
        ExporterPopulation_GetValidatedOk.argtypes = [POINTER(c_void_p)]
        ExporterPopulation_GetValidatedOk.restype = c_bool
        value = ExporterPopulation_GetValidatedOk(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs


from .IDataValue import IDataValue


class LogicalDataType(IDataValue):
    """LogicalDataType. A type to contain a logical data type.
    
        Arguments:
                * value - type bool


    """
    
    def __init__(self, value=None, isOwner=True):
        """

        Arguments:
                * value - type bool

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            LogicalDataType_Create = self.lib.LogicalDataType_Create
            LogicalDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = LogicalDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if value is not None:
            self.value = value


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            LogicalDataType_Destroy = self.lib.LogicalDataType_Destroy
            LogicalDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            LogicalDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def value(self):
        """Property value is of type bool. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('value','value: Invalid type value must be of type bool')
        self.__SetValue(value)
        self._value = value

    def __SetValue(self, value):

        LogicalDataType_SetValue = self.lib.LogicalDataType_SetValue 
        LogicalDataType_SetValue.argtypes = [POINTER(c_void_p), c_bool]
        LogicalDataType_SetValue(self._c_obj, value)

    def __GetValue(self):
        LogicalDataType_GetValue = self.lib.LogicalDataType_GetValue
        LogicalDataType_GetValue.argtypes = [POINTER(c_void_p)]
        LogicalDataType_GetValue.restype = c_bool
        value = LogicalDataType_GetValue(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.TargetedSourceRecord import TargetedSourceRecord


class UnlinkRecords(object):
    """UnlinkRecords. For each given source record, remove links to the target records specified for that source record. Silently skip any links that do not exist.
    
        Arguments:
                * sourceRecords - type list of :py:mod:`TargetedSourceRecord <GRANTA_MIScriptingToolkit.TargetedSourceRecord>` objects
                * nodeName - type str


    """
    
    def __init__(self, sourceRecords=None, nodeName=None, isOwner=True):
        """

        Arguments:
                * sourceRecords - type list of :py:mod:`TargetedSourceRecord <GRANTA_MIScriptingToolkit.TargetedSourceRecord>` objects
                * nodeName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            UnlinkRecords_Create = self.lib.UnlinkRecords_Create
            UnlinkRecords_Create.restype = POINTER(c_void_p)
            self.c_obj = UnlinkRecords_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if sourceRecords is not None:
            self.sourceRecords = sourceRecords
        if nodeName is not None:
            self.nodeName = nodeName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            UnlinkRecords_Destroy = self.lib.UnlinkRecords_Destroy
            UnlinkRecords_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            UnlinkRecords_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def sourceRecords(self):
        """Property sourceRecords is of type list of :py:mod:`TargetedSourceRecord <GRANTA_MIScriptingToolkit.TargetedSourceRecord>`. """ 
        try:
            return self._sourceRecords
        except:
            return None

    @sourceRecords.setter
    def sourceRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('sourceRecords','sourceRecords: Invalid type sourceRecords must be a list of TargetedSourceRecord')
                
        try:
            self.__updatesourceRecords = True
            self.__ClearSourceRecords()
            for v in value:
                self.AddSourceRecord(v)
        except:
            pass


    @property
    def nodeName(self):
        """Property nodeName is of type str. """ 
        self._nodeName = self.__GetNodeName()
        return self._nodeName

    @nodeName.setter
    def nodeName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('nodeName','nodeName: Invalid type nodeName must be of type str')
        
        self._nodeName = value

    def AddSourceRecord(self, _targetedSourceRecord):
        """Appends _targetedSourceRecord to sourceRecords property on UnlinkRecords C-object.

           Arguments:
                _targetedSourceRecord - object of type TargetedSourceRecord.
        """

        if not isinstance(_targetedSourceRecord, TargetedSourceRecord):
            raise GRANTA_Exception('UnlinkRecords.AddSourceRecord','_targetedSourceRecord: Invalid argument type _targetedSourceRecord must be of type TargetedSourceRecord')
        UnlinkRecords_AddSourceRecord = self.lib.UnlinkRecords_AddSourceRecord
        UnlinkRecords_AddSourceRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        UnlinkRecords_AddSourceRecord(self._c_obj, _targetedSourceRecord.c_obj)
        return self

    def __ClearSourceRecords(self):
        UnlinkRecords_ClearSourceRecords = self.lib.UnlinkRecords_ClearSourceRecords
        UnlinkRecords_ClearSourceRecords.argtypes = [POINTER(c_void_p)]
        UnlinkRecords_ClearSourceRecords(self._c_obj)
        return self

    def __GetNodeName(self):
        UnlinkRecords_GetNodeName = self.lib.UnlinkRecords_GetNodeName
        UnlinkRecords_GetNodeName.argtypes = [POINTER(c_void_p)]
        UnlinkRecords_GetNodeName.restype = POINTER(c_void_p)
        value = UnlinkRecords_GetNodeName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


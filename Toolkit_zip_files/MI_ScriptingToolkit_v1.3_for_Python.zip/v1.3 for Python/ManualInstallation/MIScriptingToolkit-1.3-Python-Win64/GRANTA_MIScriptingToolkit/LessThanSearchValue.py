# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class LessThanSearchValue(object):
    """LessThanSearchValue. Search criterion to search for data less than a specified value.
Criterion passes if data value is less than a given value. Point, range, and integer attributes are supported.
    
        Arguments:
                * unit - type str
                * value - type float


    """
    
    def __init__(self, unit=None, value=None, isOwner=True):
        """

        Arguments:
                * unit - type str
                * value - type float

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            LessThanSearchValue_Create = self.lib.LessThanSearchValue_Create
            LessThanSearchValue_Create.restype = POINTER(c_void_p)
            self.c_obj = LessThanSearchValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if unit is not None:
            self.unit = unit
        if value is not None:
            self.value = value


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            LessThanSearchValue_Destroy = self.lib.LessThanSearchValue_Destroy
            LessThanSearchValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            LessThanSearchValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def unit(self):
        """Property unit is of type str. """ 
        self._unit = self.__GetUnit()
        return self._unit

    @unit.setter
    def unit(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('unit','unit: Invalid type unit must be of type str')
        self.__SetUnit(value)
        self._unit = value

    @property
    def value(self):
        """Property value is of type float. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('value','value: Invalid type value must be of type float')
        self.__SetValue(value)
        self._value = value

    def __GetValue(self):
        LessThanSearchValue_GetValue = self.lib.LessThanSearchValue_GetValue
        LessThanSearchValue_GetValue.argtypes = [POINTER(c_void_p)]
        LessThanSearchValue_GetValue.restype = c_double
        value = LessThanSearchValue_GetValue(self._c_obj)
        return value
    
    def __SetValue(self, value):

        LessThanSearchValue_SetValue = self.lib.LessThanSearchValue_SetValue 
        LessThanSearchValue_SetValue.argtypes = [POINTER(c_void_p), c_double]
        LessThanSearchValue_SetValue(self._c_obj, value)

    def __GetUnit(self):
        LessThanSearchValue_GetUnit = self.lib.LessThanSearchValue_GetUnit
        LessThanSearchValue_GetUnit.argtypes = [POINTER(c_void_p)]
        LessThanSearchValue_GetUnit.restype = POINTER(c_void_p)
        value = LessThanSearchValue_GetUnit(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetUnit(self, value):

        LessThanSearchValue_SetUnit = self.lib.LessThanSearchValue_SetUnit 
        LessThanSearchValue_SetUnit.argtypes = [POINTER(c_void_p), c_char_p]
        LessThanSearchValue_SetUnit(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


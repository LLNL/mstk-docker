# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse
from GRANTA_MIScriptingToolkit.RecordLinkChanges import RecordLinkChanges


class ModifyRecordLinksResponse(object):
    """ModifyRecordLinksResponse. The response from a ModifyRecordLinks request.
    
        Arguments:
            c_obj - ctypes.POINTER to a ModifyRecordLinksResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a ModifyRecordLinksResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ModifyRecordLinksResponse_Destroy = self.lib.ModifyRecordLinksResponse_Destroy
            ModifyRecordLinksResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ModifyRecordLinksResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordLinkChanges(self):
        """Property recordLinkChanges is of type :py:mod:`RecordLinkChanges <GRANTA_MIScriptingToolkit.RecordLinkChanges>`. """ 
        self._recordLinkChanges = self.__GetRecordLinkChanges()
        return self._recordLinkChanges

    @recordLinkChanges.setter
    def recordLinkChanges(self, value):
        if not isinstance(value, RecordLinkChanges):
            raise GRANTA_Exception('recordLinkChanges','recordLinkChanges: Invalid type recordLinkChanges must be of type RecordLinkChanges')
        self.__SetRecordLinkChanges(value)
        self._recordLinkChanges = value

    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        self.__SetServiceLayerResponse(value)
        self._serviceLayerResponse = value

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        ModifyRecordLinksResponse_GetServiceLayerResponse = self.lib.ModifyRecordLinksResponse_GetServiceLayerResponse
        ModifyRecordLinksResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ModifyRecordLinksResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __SetServiceLayerResponse(self, value):

        ModifyRecordLinksResponse_SetServiceLayerResponse = self.lib.ModifyRecordLinksResponse_SetServiceLayerResponse 
        ModifyRecordLinksResponse_SetServiceLayerResponse.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ModifyRecordLinksResponse_SetServiceLayerResponse(self._c_obj, value.c_obj)

    def __GetRecordLinkChanges(self):
        _recordLinkChanges = RecordLinkChanges()
        ModifyRecordLinksResponse_GetRecordLinkChanges = self.lib.ModifyRecordLinksResponse_GetRecordLinkChanges
        ModifyRecordLinksResponse_GetRecordLinkChanges.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ModifyRecordLinksResponse_GetRecordLinkChanges(self._c_obj, (_recordLinkChanges.c_obj))
        
        return _recordLinkChanges
        
    def __SetRecordLinkChanges(self, value):

        ModifyRecordLinksResponse_SetRecordLinkChanges = self.lib.ModifyRecordLinksResponse_SetRecordLinkChanges 
        ModifyRecordLinksResponse_SetRecordLinkChanges.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ModifyRecordLinksResponse_SetRecordLinkChanges(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


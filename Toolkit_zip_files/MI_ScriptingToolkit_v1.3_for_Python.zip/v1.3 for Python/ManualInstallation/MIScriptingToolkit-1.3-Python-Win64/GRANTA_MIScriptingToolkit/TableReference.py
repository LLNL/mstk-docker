# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class TableReference(object):
    """TableReference. A type that allows identification of a particular table in a particular GRANTA MI database.
The DBKey is required in addition to at least one of either: ID, GUID, or Name.
    
        Arguments:
                * GUID - type str
                * name - type str
                * DBKey - type str
                * ID - type int


    """
    
    def __init__(self, GUID=None, name=None, DBKey=None, ID=None, isOwner=True):
        """

        Arguments:
                * GUID - type str
                * name - type str
                * DBKey - type str
                * ID - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            TableReference_Create = self.lib.TableReference_Create
            TableReference_Create.restype = POINTER(c_void_p)
            self.c_obj = TableReference_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if GUID is not None:
            self.GUID = GUID
        if name is not None:
            self.name = name
        if DBKey is not None:
            self.DBKey = DBKey
        if ID is not None:
            self.ID = ID


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            TableReference_Destroy = self.lib.TableReference_Destroy
            TableReference_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            TableReference_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def GUID(self):
        """Property GUID is of type str. """ 
        self._GUID = self.__GetGUID()
        return self._GUID

    @GUID.setter
    def GUID(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('GUID','GUID: Invalid type GUID must be of type str')
        self.__SetGUID(value)
        self._GUID = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    @property
    def ID(self):
        """Property ID is of type int. """ 
        self._ID = self.__GetID()
        return self._ID

    @ID.setter
    def ID(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('ID','ID: Invalid type ID must be of type int')
        self.__SetID(value)
        self._ID = value

    def __GetDBKey(self):
        TableReference_GetDBKey = self.lib.TableReference_GetDBKey
        TableReference_GetDBKey.argtypes = [POINTER(c_void_p)]
        TableReference_GetDBKey.restype = POINTER(c_void_p)
        value = TableReference_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetDBKey(self, value):

        TableReference_SetDBKey = self.lib.TableReference_SetDBKey 
        TableReference_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        TableReference_SetDBKey(self._c_obj, EnsureEncoded(value))

    def __GetName(self):
        TableReference_GetName = self.lib.TableReference_GetName
        TableReference_GetName.argtypes = [POINTER(c_void_p)]
        TableReference_GetName.restype = POINTER(c_void_p)
        value = TableReference_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        TableReference_SetName = self.lib.TableReference_SetName 
        TableReference_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        TableReference_SetName(self._c_obj, EnsureEncoded(value))

    def __GetGUID(self):
        TableReference_GetGUID = self.lib.TableReference_GetGUID
        TableReference_GetGUID.argtypes = [POINTER(c_void_p)]
        TableReference_GetGUID.restype = POINTER(c_void_p)
        value = TableReference_GetGUID(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetGUID(self, value):

        TableReference_SetGUID = self.lib.TableReference_SetGUID 
        TableReference_SetGUID.argtypes = [POINTER(c_void_p), c_char_p]
        TableReference_SetGUID(self._c_obj, EnsureEncoded(value))

    def __GetID(self):
        TableReference_GetID = self.lib.TableReference_GetID
        TableReference_GetID.argtypes = [POINTER(c_void_p)]
        TableReference_GetID.restype = c_int
        value = TableReference_GetID(self._c_obj)
        return value
    
    def __SetID(self, value):

        TableReference_SetID = self.lib.TableReference_SetID 
        TableReference_SetID.argtypes = [POINTER(c_void_p), c_int]
        TableReference_SetID(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


import time
import GRANTA_MIScriptingToolkit.GRANTA_libs as GRANTA_libs
from ctypes import c_char_p, POINTER, c_bool, c_double, c_void_p, c_int
from GRANTA_MIScriptingToolkit.GRANTA_Logging import GRANTA_Logging
from GRANTA_MIScriptingToolkit.Service import Service
from GRANTA_MIScriptingToolkit.GRANTA_Exceptions import GRANTA_Exception
from GRANTA_MIScriptingToolkit.GetUploadAddressesRequest import GetUploadAddressesRequest
from GRANTA_MIScriptingToolkit.GetUploadAddressesResponse import GetUploadAddressesResponse
from GRANTA_MIScriptingToolkit.ModifyRecordLinksRequest import ModifyRecordLinksRequest
from GRANTA_MIScriptingToolkit.ModifyRecordLinksResponse import ModifyRecordLinksResponse
from GRANTA_MIScriptingToolkit.SetRecordAttributesRequest import SetRecordAttributesRequest
from GRANTA_MIScriptingToolkit.SetRecordAttributesResponse import SetRecordAttributesResponse

# This file was automatically generated
class DataImportService(Service):
    """The DataImport service writes data to attributes of records in GRANTA MI Databases."""

    def __init__(self, mi_session):
        """Initialize a DataImportService object
                Arguments:
                    mi_session - MI_Session object
        """
        self.mi_session = mi_session
        self.lib = GRANTA_libs.MIServiceLayerCAPILib

    def GetUploadAddresses(self, _req):
        """Returns an address to which a datum can be uploaded, for each combination of given sets of records and attributes in a GRANTA MI database. Each address will be an HTTP or HTTPS URL. The upload service only supports a subset of all available GRANTA MI attribute types, but this operation will give an address for an attribute of any type.

        Arguments:
            _req - :py:mod:`GetUploadAddressesRequest <GRANTA_MIScriptingToolkit.GetUploadAddressesRequest>` object
        Returns:
            :py:mod:`GetUploadAddressesResponse <GRANTA_MIScriptingToolkit.GetUploadAddressesResponse>` object
        
        """
        if not isinstance(_req, GetUploadAddressesRequest):
            raise GRANTA_Exception('DataImport.GetUploadAddresses','DataImport.GetUploadAddresses(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetUploadAddressesRequest')

        startTime = time.clock()
        func = self.lib.DataImport_GetUploadAddresses
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetUploadAddressesResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran DataImport.GetUploadAddresses() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'DataImport.GetUploadAddresses')
        return response

    def ModifyRecordLinks(self, _req):
        """Adds or removes static Links between record(s) in a GRANTA MI Database.

        Arguments:
            _req - :py:mod:`ModifyRecordLinksRequest <GRANTA_MIScriptingToolkit.ModifyRecordLinksRequest>` object
        Returns:
            :py:mod:`ModifyRecordLinksResponse <GRANTA_MIScriptingToolkit.ModifyRecordLinksResponse>` object
        
        """
        if not isinstance(_req, ModifyRecordLinksRequest):
            raise GRANTA_Exception('DataImport.ModifyRecordLinks','DataImport.ModifyRecordLinks(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.ModifyRecordLinksRequest')

        startTime = time.clock()
        func = self.lib.DataImport_ModifyRecordLinks
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = ModifyRecordLinksResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran DataImport.ModifyRecordLinks() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'DataImport.ModifyRecordLinks')
        return response

    def SetRecordAttributes(self, _req):
        """Sets the data values for the given attribute(s) and record(s) in a GRANTA MI Database. Note: this operation can accept an arbitrary number of attributes and records to be imported, but in practice there is a fairly low limit to the amount of data that can be imported in a single operation. Client code should perform large imports in small chunks.

        Arguments:
            _req - :py:mod:`SetRecordAttributesRequest <GRANTA_MIScriptingToolkit.SetRecordAttributesRequest>` object
        Returns:
            :py:mod:`SetRecordAttributesResponse <GRANTA_MIScriptingToolkit.SetRecordAttributesResponse>` object
        
        """
        if not isinstance(_req, SetRecordAttributesRequest):
            raise GRANTA_Exception('DataImport.SetRecordAttributes','DataImport.SetRecordAttributes(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.SetRecordAttributesRequest')

        startTime = time.clock()
        func = self.lib.DataImport_SetRecordAttributes
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = SetRecordAttributesResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran DataImport.SetRecordAttributes() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'DataImport.SetRecordAttributes')
        return response


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class HighEndSearchValue(object):
    """HighEndSearchValue. Upper limit for the :py:mod:`BetweenSearchValue <GRANTA_MIScriptingToolkit.BetweenSearchValue>` search criterion.
Requires a double value and an optional unit.
    
        Arguments:
                * unit - type str
                * value - type float


    """
    
    def __init__(self, unit=None, value=None, isOwner=True):
        """

        Arguments:
                * unit - type str
                * value - type float

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            HighEndSearchValue_Create = self.lib.HighEndSearchValue_Create
            HighEndSearchValue_Create.restype = POINTER(c_void_p)
            self.c_obj = HighEndSearchValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if unit is not None:
            self.unit = unit
        if value is not None:
            self.value = value


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            HighEndSearchValue_Destroy = self.lib.HighEndSearchValue_Destroy
            HighEndSearchValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            HighEndSearchValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def unit(self):
        """Property unit is of type str. """ 
        self._unit = self.__GetUnit()
        return self._unit

    @unit.setter
    def unit(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('unit','unit: Invalid type unit must be of type str')
        self.__SetUnit(value)
        self._unit = value

    @property
    def value(self):
        """Property value is of type float. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('value','value: Invalid type value must be of type float')
        self.__SetValue(value)
        self._value = value

    def __GetValue(self):
        HighEndSearchValue_GetValue = self.lib.HighEndSearchValue_GetValue
        HighEndSearchValue_GetValue.argtypes = [POINTER(c_void_p)]
        HighEndSearchValue_GetValue.restype = c_double
        value = HighEndSearchValue_GetValue(self._c_obj)
        return value
    
    def __SetValue(self, value):

        HighEndSearchValue_SetValue = self.lib.HighEndSearchValue_SetValue 
        HighEndSearchValue_SetValue.argtypes = [POINTER(c_void_p), c_double]
        HighEndSearchValue_SetValue(self._c_obj, value)

    def __GetUnit(self):
        HighEndSearchValue_GetUnit = self.lib.HighEndSearchValue_GetUnit
        HighEndSearchValue_GetUnit.argtypes = [POINTER(c_void_p)]
        HighEndSearchValue_GetUnit.restype = POINTER(c_void_p)
        value = HighEndSearchValue_GetUnit(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetUnit(self, value):

        HighEndSearchValue_SetUnit = self.lib.HighEndSearchValue_SetUnit 
        HighEndSearchValue_SetUnit.argtypes = [POINTER(c_void_p), c_char_p]
        HighEndSearchValue_SetUnit(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


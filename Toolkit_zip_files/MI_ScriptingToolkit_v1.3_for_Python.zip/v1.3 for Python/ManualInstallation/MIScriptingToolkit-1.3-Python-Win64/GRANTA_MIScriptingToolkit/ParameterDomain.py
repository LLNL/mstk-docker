# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterValue import ParameterValue


class ParameterDomain(object):
    """ParameterDomain. A type to contain a list of parameter values.
    
        Arguments:
                * exporterParameterId - type str
                * interpolable - type bool
                * values - type list of :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>` objects


    """
    
    def __init__(self, exporterParameterId=None, interpolable=None, values=None, isOwner=True):
        """

        Arguments:
                * exporterParameterId - type str
                * interpolable - type bool
                * values - type list of :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ParameterDomain_Create = self.lib.ParameterDomain_Create
            ParameterDomain_Create.restype = POINTER(c_void_p)
            self.c_obj = ParameterDomain_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if exporterParameterId is not None:
            self.exporterParameterId = exporterParameterId
        if interpolable is not None:
            self.interpolable = interpolable
        if values is not None:
            self.values = values


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ParameterDomain_Destroy = self.lib.ParameterDomain_Destroy
            ParameterDomain_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ParameterDomain_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def exporterParameterId(self):
        """Property exporterParameterId is of type str. """ 
        self._exporterParameterId = self.__GetExporterParameterId()
        return self._exporterParameterId

    @exporterParameterId.setter
    def exporterParameterId(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('exporterParameterId','exporterParameterId: Invalid type exporterParameterId must be of type str')
        
        self._exporterParameterId = value

    @property
    def interpolable(self):
        """Property interpolable is of type bool. """ 
        self._interpolable = self.__GetInterpolable()
        return self._interpolable

    @interpolable.setter
    def interpolable(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('interpolable','interpolable: Invalid type interpolable must be of type bool')
        
        self._interpolable = value

    @property
    def values(self):
        """Property values is a list of :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._values = self.__GetValues()
        except:
            pass
        return self._values

    @values.setter
    def values(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('values','values: Invalid type values must be a list of ParameterValue')
        
        self._values = value

    def __GetNumberOfValues(self):
        ParameterDomain_GetNumberOfValues = self.lib.ParameterDomain_GetNumberOfValues
        ParameterDomain_GetNumberOfValues.argtypes = [POINTER(c_void_p)]
        ParameterDomain_GetNumberOfValues.restype = c_int
        value = ParameterDomain_GetNumberOfValues(self._c_obj)
        return value
    
    def __GetValueElement(self,i):
        value = ParameterValue()
        ParameterDomain_GetValue = self.lib.ParameterDomain_GetValue
        ParameterDomain_GetValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        ParameterDomain_GetValue(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetValues(self):
         n = self.__GetNumberOfValues();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetValueElement(i))
         return temp
    
    def __GetInterpolable(self):
        ParameterDomain_GetInterpolable = self.lib.ParameterDomain_GetInterpolable
        ParameterDomain_GetInterpolable.argtypes = [POINTER(c_void_p)]
        ParameterDomain_GetInterpolable.restype = c_bool
        value = ParameterDomain_GetInterpolable(self._c_obj)
        return value
    
    def __GetExporterParameterId(self):
        ParameterDomain_GetExporterParameterId = self.lib.ParameterDomain_GetExporterParameterId
        ParameterDomain_GetExporterParameterId.argtypes = [POINTER(c_void_p)]
        ParameterDomain_GetExporterParameterId.restype = POINTER(c_void_p)
        value = ParameterDomain_GetExporterParameterId(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


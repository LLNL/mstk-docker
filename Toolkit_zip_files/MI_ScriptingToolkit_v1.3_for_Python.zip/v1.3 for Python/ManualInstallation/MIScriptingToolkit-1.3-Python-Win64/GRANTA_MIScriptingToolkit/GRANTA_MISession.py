
from ctypes import *

from GRANTA_MIScriptingToolkit import GRANTA_libs
import os
from GRANTA_MIScriptingToolkit.BrowseService import BrowseService
from GRANTA_MIScriptingToolkit.DataExportService import DataExportService
from GRANTA_MIScriptingToolkit.SearchService import SearchService
from GRANTA_MIScriptingToolkit.DataImportService import DataImportService
from GRANTA_MIScriptingToolkit.EngineeringDataService import EngineeringDataService
from GRANTA_MIScriptingToolkit.MISession import MISession
from GRANTA_MIScriptingToolkit.GRANTA_Exceptions import GRANTA_Exception
dir = os.path.dirname(__file__)
##


StaticInit = GRANTA_libs.MIServiceLayerCAPILib.MIServiceLayerCAPI_StaticInit
StaticInit()

class GRANTA_MISession(object):
    """The base object for the GRANTA_MIScripting toolkit. This creates a connection to a 
GRANTA MI Server via a GRANTA MI:ServiceLayer.
    
        Arguments:
           * url - url of your GRANTA MI:ServiceLayer installation
           * username - your GRANTA MI username (for Basic authentication)
           * password - your GRANTA MI password (for Basic authentication)
           * domain - your GRANTA MI user domain (for Basic authentication)
           * verbosity - logging verbosity accepted values "ERROR", "WARNING", or "DEBUG"
           * autoLogon - if set to True, this object will authenticate as the current Windows user
		   
		username, password, domain, and autoLogon are optional - use either SetCredentials or UseAutoLogon to specify the desired authentication method if these are omitted
    """
    
    def __init__(self, url, username=None, password=None, domain=None, verbosity="ERROR", autoLogon=False):
        """GRANTA_MISession - Create a connection to a GRANTA MI server
        This will create an Granta_MISession. 
        Omitting parameters username, password, domain, and autoLogon will cause the session to authenticate anonymously.
        Use these constructor parameters, or the functions SetCredentials or UseAutoLogon to specify the desired authentication method.
        
        Arguments:
           * url - url of your GRANTA MI:ServiceLayer installation
           * username - your GRANTA MI username (for Basic authentication)
           * password - your GRANTA MI password (for Basic authentication)
           * domain - your GRANTA MI user domain (for Basic authentication)
           * verbosity - logging verbosity accepted values "ERROR", "WARNING", or "DEBUG"
           * autoLogon - if set to True, this object will authenticate as the current Windows user

        """
        _verbosity = 0
        if verbosity == "ERROR":
            _verbosity = 1
        elif verbosity == "WARNING":
            _verbosity = 2
        elif verbosity == "DEBUG":
            _verbosity = 3

        self.name = "GRANTA_MISession"        
        self.__CreateSession(url, _verbosity)

        if username and password and autoLogon:
            raise GRANTA_Exception("autoLogon", "Calling code should specify either autoLogon, or both username and password (and possibly domain)")

        if username and password:
            self.mi_session.SetCredentials(domain, username, password)

        if autoLogon:
            self.mi_session.UseAutoLogon()

    def __CreateSession(self, url, verbosity):
        self.mi_session = MISession(url, verbosity)

    def TestConnection(self):
        """ Raises a GRANTA_Exception if connection cannot be made - eg bad credentials or unreachable GRANTA MI Service Layer URL"""
        self.mi_session.TestConnection()

    def __CheckValidSession(self):
        dbResponse = self.browseService.GetDatabases()
        slResponse = dbResponse.serviceLayerResponse
        responseCode = slResponse.responseCode
        responseMessage = slResponse.responseMessage
        if not (responseCode == 200):
            print ('ERROR: Invalid MI session. Operation failed with code: {0} and messsage: {1}'.format(responseCode, responseMessage))
    

    @property
    def browseService(self):
        """Property browseService is of type :py:mod:`BrowseService <GRANTA_MIScriptingToolkit.BrowseService>`""" 
        return BrowseService(self.mi_session)
        
    @property
    def searchService(self):
        """Property searchService is of type :py:mod:`SearchService <GRANTA_MIScriptingToolkit.SearchService>`""" 
        return SearchService(self.mi_session)

    @property
    def dataExportService(self):
        """Property dataExportService is of type :py:mod:`DataExportService <GRANTA_MIScriptingToolkit.DataExportService>`""" 
        return DataExportService(self.mi_session)

    @property
    def dataImportService(self):
        """Property dataImportService is of type :py:mod:`DataImportService <GRANTA_MIScriptingToolkit.DataImportService>`"""
        return DataImportService(self.mi_session)

    @property
    def engineeringDataService(self):
        """Property engineeringDataServiceis of type :py:mod:`EngineeringDataService <GRANTA_MIScriptingToolkit.EngineeringDataService>`"""
        return EngineeringDataService(self.mi_session)

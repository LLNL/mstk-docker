from GRANTA_MIScriptingToolkit.GRANTA_Logging import GRANTA_Logging

from xml.dom import minidom
import sys
try:
    from HTMLParser import HTMLParser # py2
    import httplib
except:
    from html import unescape #py3
    import http.client as httplib

class GRANTA_Exception(Exception):
    """Exception raised when there are errors in input. 

    Attributes:
        expr -- input expression in which the error occurred
        msg  -- explanation of the error
    """
    def __init__(self, expr, msg):
        super(GRANTA_Exception, self).__init__(msg)
        if not hasattr(self, "message"):
            self.message = msg
        self.expr = expr
        self.msg = msg
        GRANTA_Logging().error(msg)

def IndentXML(text):
    try:
        return minidom.parseString(text).toprettyxml(indent = "   ")
    except:
        return text
    
class GRANTA_ServiceLayerError(Exception):
    """Exception raised when the GRANTA MI ServiceLayer returns an error.

    attributes:
        responseXML - the XML from the response from GRANTA MI
        message - error string extracted from responseXML
        responseCode - HTTP response code associated with this error
        operation - a string that identifies the operation from which this exception originated
        data - type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`, request data causing this error
    """
    def __init__(self, slResponse, operation):
        self.responseXML = IndentXML(slResponse.responseMessage)
        self.requestXML = IndentXML(slResponse.requestMessage)

        self.responseCode = slResponse.responseCode

        if slResponse.errorMessage:
            if sys.version_info[0] == 3:
                self.message = unescape(slResponse.errorMessage)
            else:
                self.message = HTMLParser().unescape(slResponse.errorMessage)

            super(GRANTA_ServiceLayerError, self).__init__(self.message)
        elif self.responseCode in httplib.responses:
            self.message = httplib.responses[self.responseCode]
        
        self.operation = operation
        self.data = slResponse
        GRANTA_Logging().error(slResponse.errorMessage)
# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.TableReference import TableReference
from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference


class TableDetail(object):
    """TableDetail. Detailed meta-information about a table in a GRANTA MI database.
    
        Arguments:
                * tableFilters - type list of int objects
                * standardAttributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects
                * tableReference - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects


    """
    
    def __init__(self, tableFilters=None, standardAttributeReferences=None, tableReference=None, attributeReferences=None, isOwner=True):
        """

        Arguments:
                * tableFilters - type list of int objects
                * standardAttributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects
                * tableReference - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            TableDetail_Create = self.lib.TableDetail_Create
            TableDetail_Create.restype = POINTER(c_void_p)
            self.c_obj = TableDetail_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if tableFilters is not None:
            self.tableFilters = tableFilters
        if standardAttributeReferences is not None:
            self.standardAttributeReferences = standardAttributeReferences
        if tableReference is not None:
            self.tableReference = tableReference
        if attributeReferences is not None:
            self.attributeReferences = attributeReferences


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            TableDetail_Destroy = self.lib.TableDetail_Destroy
            TableDetail_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            TableDetail_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def tableFilters(self):
        """Property tableFilters is a list of int objects. See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values. 
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._tableFilters = self.__GetTableFilters()
        except:
            pass
        return self._tableFilters

    @tableFilters.setter
    def tableFilters(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('tableFilters','tableFilters: Invalid type tableFilters must be a list of int')
        
        self._tableFilters = value

    @property
    def standardAttributeReferences(self):
        """Property standardAttributeReferences is a list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._standardAttributeReferences = self.__GetStandardAttributeReferences()
        except:
            pass
        return self._standardAttributeReferences

    @standardAttributeReferences.setter
    def standardAttributeReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('standardAttributeReferences','standardAttributeReferences: Invalid type standardAttributeReferences must be a list of AttributeReference')
        
        self._standardAttributeReferences = value

    @property
    def tableReference(self):
        """Property tableReference is of type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`. """ 
        self._tableReference = self.__GetTableReference()
        return self._tableReference

    @tableReference.setter
    def tableReference(self, value):
        if not isinstance(value, TableReference):
            raise GRANTA_Exception('tableReference','tableReference: Invalid type tableReference must be of type TableReference')
        self.__SetTableReference(value)
        self._tableReference = value

    @property
    def attributeReferences(self):
        """Property attributeReferences is a list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeReferences = self.__GetAttributeReferences()
        except:
            pass
        return self._attributeReferences

    @attributeReferences.setter
    def attributeReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeReferences','attributeReferences: Invalid type attributeReferences must be a list of AttributeReference')
                
        try:
            self.__updateattributeReferences = True
            self.__ClearAttributeReferences()
            for v in value:
                self.AddAttributeReferences(v)
        except:
            pass


    def __GetTableReference(self):
        _tableReference = TableReference()
        TableDetail_GetTableReference = self.lib.TableDetail_GetTableReference
        TableDetail_GetTableReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TableDetail_GetTableReference(self._c_obj, (_tableReference.c_obj))
        
        return _tableReference
        
    def __SetTableReference(self, value):

        TableDetail_SetTableReference = self.lib.TableDetail_SetTableReference 
        TableDetail_SetTableReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        TableDetail_SetTableReference(self._c_obj, value.c_obj)

    def __GetNumberOfAttributeReferences(self):
        TableDetail_GetNumberOfAttributeReferences = self.lib.TableDetail_GetNumberOfAttributeReferences
        TableDetail_GetNumberOfAttributeReferences.argtypes = [POINTER(c_void_p)]
        TableDetail_GetNumberOfAttributeReferences.restype = c_int
        value = TableDetail_GetNumberOfAttributeReferences(self._c_obj)
        return value
    
    def __GetAttributeReferenceElement(self,i):
        value = AttributeReference()
        TableDetail_GetAttributeReference = self.lib.TableDetail_GetAttributeReference
        TableDetail_GetAttributeReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        TableDetail_GetAttributeReference(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributeReferences(self):
         n = self.__GetNumberOfAttributeReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeReferenceElement(i))
         return temp
    
    def AddAttributeReferences(self, _attributeReference):
        """Appends _attributeReference to attributeReferences property on TableDetail C-object.

           Arguments:
                _attributeReference - object of type AttributeReference.
        """

        if not isinstance(_attributeReference, AttributeReference):
            raise GRANTA_Exception('TableDetail.AddAttributeReferences','_attributeReference: Invalid argument type _attributeReference must be of type AttributeReference')
        TableDetail_AddAttributeReferences = self.lib.TableDetail_AddAttributeReferences
        TableDetail_AddAttributeReferences.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        TableDetail_AddAttributeReferences(self._c_obj, _attributeReference.c_obj)
        return self

    def __ClearAttributeReferences(self):
        TableDetail_ClearAttributeReferences = self.lib.TableDetail_ClearAttributeReferences
        TableDetail_ClearAttributeReferences.argtypes = [POINTER(c_void_p)]
        TableDetail_ClearAttributeReferences(self._c_obj)
        return self

    def __GetNumberOfStandardAttributeReferences(self):
        TableDetail_GetNumberOfStandardAttributeReferences = self.lib.TableDetail_GetNumberOfStandardAttributeReferences
        TableDetail_GetNumberOfStandardAttributeReferences.argtypes = [POINTER(c_void_p)]
        TableDetail_GetNumberOfStandardAttributeReferences.restype = c_int
        value = TableDetail_GetNumberOfStandardAttributeReferences(self._c_obj)
        return value
    
    def __GetStandardAttributeReferenceElement(self,i):
        value = AttributeReference()
        TableDetail_GetStandardAttributeReference = self.lib.TableDetail_GetStandardAttributeReference
        TableDetail_GetStandardAttributeReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        TableDetail_GetStandardAttributeReference(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetStandardAttributeReferences(self):
         n = self.__GetNumberOfStandardAttributeReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetStandardAttributeReferenceElement(i))
         return temp
    
    def __GetNumberOfTableFilters(self):
        TableDetail_GetNumberOfTableFilters = self.lib.TableDetail_GetNumberOfTableFilters
        TableDetail_GetNumberOfTableFilters.argtypes = [POINTER(c_void_p)]
        TableDetail_GetNumberOfTableFilters.restype = c_int
        value = TableDetail_GetNumberOfTableFilters(self._c_obj)
        return value
    
    def __GetTableFilterElement(self,i):
        TableDetail_GetTableFilter = self.lib.TableDetail_GetTableFilter
        TableDetail_GetTableFilter.argtypes = [POINTER(c_void_p), c_int]
        TableDetail_GetTableFilter.restype = c_int
        value = TableDetail_GetTableFilter(self._c_obj, i)
        return value
    
    def __GetTableFilters(self):
         n = self.__GetNumberOfTableFilters();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetTableFilterElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterDomain import ParameterDomain


class GraphDomain(object):
    """GraphDomain. A type to contain choices of fixed parameter values.
A value must be chosen for each parameter, within the given constraints.
    
        Arguments:
                * parameterDomains - type list of :py:mod:`ParameterDomain <GRANTA_MIScriptingToolkit.ParameterDomain>` objects


    """
    
    def __init__(self, parameterDomains=None, isOwner=True):
        """

        Arguments:
                * parameterDomains - type list of :py:mod:`ParameterDomain <GRANTA_MIScriptingToolkit.ParameterDomain>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GraphDomain_Create = self.lib.GraphDomain_Create
            GraphDomain_Create.restype = POINTER(c_void_p)
            self.c_obj = GraphDomain_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if parameterDomains is not None:
            self.parameterDomains = parameterDomains


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GraphDomain_Destroy = self.lib.GraphDomain_Destroy
            GraphDomain_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GraphDomain_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def parameterDomains(self):
        """Property parameterDomains is a list of :py:mod:`ParameterDomain <GRANTA_MIScriptingToolkit.ParameterDomain>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._parameterDomains = self.__GetParameterDomains()
        except:
            pass
        return self._parameterDomains

    @parameterDomains.setter
    def parameterDomains(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('parameterDomains','parameterDomains: Invalid type parameterDomains must be a list of ParameterDomain')
        
        self._parameterDomains = value

    def __GetNumberOfParameterDomains(self):
        GraphDomain_GetNumberOfParameterDomains = self.lib.GraphDomain_GetNumberOfParameterDomains
        GraphDomain_GetNumberOfParameterDomains.argtypes = [POINTER(c_void_p)]
        GraphDomain_GetNumberOfParameterDomains.restype = c_int
        value = GraphDomain_GetNumberOfParameterDomains(self._c_obj)
        return value
    
    def __GetParameterDomainElement(self,i):
        value = ParameterDomain()
        GraphDomain_GetParameterDomain = self.lib.GraphDomain_GetParameterDomain
        GraphDomain_GetParameterDomain.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GraphDomain_GetParameterDomain(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetParameterDomains(self):
         n = self.__GetNumberOfParameterDomains();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetParameterDomainElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


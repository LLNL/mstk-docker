# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.NamedAttribute import NamedAttribute
from GRANTA_MIScriptingToolkit.ExporterParameter import ExporterParameter
from GRANTA_MIScriptingToolkit.GraphDomain import GraphDomain


class AttributeExporterParameters(object):
    """AttributeExporterParameters. A type to contain an attribute along with associated parameters and domains. 
All :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>` are declared on the MI parameterised Attribute, even if not 
used in some combination of :py:mod:`Exporter <GRANTA_MIScriptingToolkit.Exporter>` and Record. It also contains the possible domains in which the fixed Parameter values must be chosen.
    
        Arguments:
                * attribute - type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`
                * dataPresence - type int
                * parameters - type list of :py:mod:`ExporterParameter <GRANTA_MIScriptingToolkit.ExporterParameter>` objects
                * graphDomains - type list of :py:mod:`GraphDomain <GRANTA_MIScriptingToolkit.GraphDomain>` objects


    """
    class DataPresence:
        Unknown = 0
        Present = 1
        NotApplicable = 2
        Missing = 3
        DataIncompatibleWithConfiguration = 4
    
    def __init__(self, attribute=None, dataPresence=None, parameters=None, graphDomains=None, isOwner=True):
        """

        Arguments:
                * attribute - type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`
                * dataPresence - type int
                * parameters - type list of :py:mod:`ExporterParameter <GRANTA_MIScriptingToolkit.ExporterParameter>` objects
                * graphDomains - type list of :py:mod:`GraphDomain <GRANTA_MIScriptingToolkit.GraphDomain>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            AttributeExporterParameters_Create = self.lib.AttributeExporterParameters_Create
            AttributeExporterParameters_Create.restype = POINTER(c_void_p)
            self.c_obj = AttributeExporterParameters_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if attribute is not None:
            self.attribute = attribute
        if dataPresence is not None:
            self.dataPresence = dataPresence
        if parameters is not None:
            self.parameters = parameters
        if graphDomains is not None:
            self.graphDomains = graphDomains


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            AttributeExporterParameters_Destroy = self.lib.AttributeExporterParameters_Destroy
            AttributeExporterParameters_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            AttributeExporterParameters_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def attribute(self):
        """Property attribute is of type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`. """ 
        self._attribute = self.__GetAttribute()
        return self._attribute

    @attribute.setter
    def attribute(self, value):
        if not isinstance(value, NamedAttribute):
            raise GRANTA_Exception('attribute','attribute: Invalid type attribute must be of type NamedAttribute')
        self.__SetAttribute(value)
        self._attribute = value

    @property
    def dataPresence(self):
        """Property dataPresence is of type int. See :py:class:`AttributeExporterParameters.DataPresence <AttributeExporterParameters.DataPresence>` for supported values.""" 
        self._dataPresence = self.__GetDataPresence()
        return self._dataPresence

    @dataPresence.setter
    def dataPresence(self, value):
        """See :py:class:`AttributeExporterParameters.DataPresence <AttributeExporterParameters.DataPresence>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('dataPresence','dataPresence: Invalid type dataPresence must be of type int')
        self.__SetDataPresence(value)
        self._dataPresence = value

    @property
    def parameters(self):
        """Property parameters is a list of :py:mod:`ExporterParameter <GRANTA_MIScriptingToolkit.ExporterParameter>` objects. This is a list of parameters that parameterize the attribute in question. 
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._parameters = self.__GetParameters()
        except:
            pass
        return self._parameters

    @parameters.setter
    def parameters(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('parameters','parameters: Invalid type parameters must be a list of ExporterParameter')
                
        try:
            self.__updateparameters = True
            self.__ClearParameters()
            for v in value:
                self.AddParameter(v)
        except:
            pass


    @property
    def graphDomains(self):
        """Property graphDomains is a list of :py:mod:`GraphDomain <GRANTA_MIScriptingToolkit.GraphDomain>` objects. Each graph domain contains information on the possible values that the corresponding parameter (by list index) can take. 
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._graphDomains = self.__GetGraphDomains()
        except:
            pass
        return self._graphDomains

    @graphDomains.setter
    def graphDomains(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('graphDomains','graphDomains: Invalid type graphDomains must be a list of GraphDomain')
                
        try:
            self.__updategraphDomains = True
            self.__ClearGraphDomains()
            for v in value:
                self.AddGraphDomain(v)
        except:
            pass


    def __GetAttribute(self):
        _namedAttribute = NamedAttribute()
        AttributeExporterParameters_GetAttribute = self.lib.AttributeExporterParameters_GetAttribute
        AttributeExporterParameters_GetAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeExporterParameters_GetAttribute(self._c_obj, (_namedAttribute.c_obj))
        
        return _namedAttribute
        
    def __SetAttribute(self, value):

        AttributeExporterParameters_SetAttribute = self.lib.AttributeExporterParameters_SetAttribute 
        AttributeExporterParameters_SetAttribute.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        AttributeExporterParameters_SetAttribute(self._c_obj, value.c_obj)

    def __GetNumberOfParameters(self):
        AttributeExporterParameters_GetNumberOfParameters = self.lib.AttributeExporterParameters_GetNumberOfParameters
        AttributeExporterParameters_GetNumberOfParameters.argtypes = [POINTER(c_void_p)]
        AttributeExporterParameters_GetNumberOfParameters.restype = c_int
        value = AttributeExporterParameters_GetNumberOfParameters(self._c_obj)
        return value
    
    def __GetParameterElement(self,i):
        value = ExporterParameter()
        AttributeExporterParameters_GetParameter = self.lib.AttributeExporterParameters_GetParameter
        AttributeExporterParameters_GetParameter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        AttributeExporterParameters_GetParameter(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetParameters(self):
         n = self.__GetNumberOfParameters();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetParameterElement(i))
         return temp
    
    def __ClearParameters(self):
        AttributeExporterParameters_ClearParameters = self.lib.AttributeExporterParameters_ClearParameters
        AttributeExporterParameters_ClearParameters.argtypes = [POINTER(c_void_p)]
        AttributeExporterParameters_ClearParameters(self._c_obj)
        return self

    def AddParameter(self, _exporterParameter):
        """Appends _exporterParameter to parameters property on AttributeExporterParameters C-object.

           Arguments:
                _exporterParameter - object of type ExporterParameter.
        """

        if not isinstance(_exporterParameter, ExporterParameter):
            raise GRANTA_Exception('AttributeExporterParameters.AddParameter','_exporterParameter: Invalid argument type _exporterParameter must be of type ExporterParameter')
        AttributeExporterParameters_AddParameter = self.lib.AttributeExporterParameters_AddParameter
        AttributeExporterParameters_AddParameter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        AttributeExporterParameters_AddParameter(self._c_obj, _exporterParameter.c_obj)
        return self

    def __GetNumberOfGraphDomains(self):
        AttributeExporterParameters_GetNumberOfGraphDomains = self.lib.AttributeExporterParameters_GetNumberOfGraphDomains
        AttributeExporterParameters_GetNumberOfGraphDomains.argtypes = [POINTER(c_void_p)]
        AttributeExporterParameters_GetNumberOfGraphDomains.restype = c_int
        value = AttributeExporterParameters_GetNumberOfGraphDomains(self._c_obj)
        return value
    
    def __GetGraphDomainElement(self,i):
        value = GraphDomain()
        AttributeExporterParameters_GetGraphDomain = self.lib.AttributeExporterParameters_GetGraphDomain
        AttributeExporterParameters_GetGraphDomain.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        AttributeExporterParameters_GetGraphDomain(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetGraphDomains(self):
         n = self.__GetNumberOfGraphDomains();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetGraphDomainElement(i))
         return temp
    
    def __ClearGraphDomains(self):
        AttributeExporterParameters_ClearGraphDomains = self.lib.AttributeExporterParameters_ClearGraphDomains
        AttributeExporterParameters_ClearGraphDomains.argtypes = [POINTER(c_void_p)]
        AttributeExporterParameters_ClearGraphDomains(self._c_obj)
        return self

    def AddGraphDomain(self, _graphDomain):
        """Appends _graphDomain to graphDomains property on AttributeExporterParameters C-object.

           Arguments:
                _graphDomain - object of type GraphDomain.
        """

        if not isinstance(_graphDomain, GraphDomain):
            raise GRANTA_Exception('AttributeExporterParameters.AddGraphDomain','_graphDomain: Invalid argument type _graphDomain must be of type GraphDomain')
        AttributeExporterParameters_AddGraphDomain = self.lib.AttributeExporterParameters_AddGraphDomain
        AttributeExporterParameters_AddGraphDomain.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        AttributeExporterParameters_AddGraphDomain(self._c_obj, _graphDomain.c_obj)
        return self

    def __GetDataPresence(self):
        AttributeExporterParameters_GetDataPresence = self.lib.AttributeExporterParameters_GetDataPresence
        AttributeExporterParameters_GetDataPresence.argtypes = [POINTER(c_void_p)]
        AttributeExporterParameters_GetDataPresence.restype = c_int
        value = AttributeExporterParameters_GetDataPresence(self._c_obj)
        return value
    
    def __SetDataPresence(self, value):
        """See :py:class:`AttributeExporterParameters.DataPresence <AttributeExporterParameters.DataPresence>` for supported values."""

        AttributeExporterParameters_SetDataPresence = self.lib.AttributeExporterParameters_SetDataPresence 
        AttributeExporterParameters_SetDataPresence.argtypes = [POINTER(c_void_p), c_int]
        AttributeExporterParameters_SetDataPresence(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


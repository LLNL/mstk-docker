# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterInformation import ParameterInformation


class Parameters(object):
    """Parameters. A collection of :py:mod:`ParameterInformation <GRANTA_MIScriptingToolkit.ParameterInformation>` objects.
    
        Arguments:
                * parameters - type list of :py:mod:`ParameterInformation <GRANTA_MIScriptingToolkit.ParameterInformation>` objects


    """
    
    def __init__(self, parameters=None, isOwner=True):
        """

        Arguments:
                * parameters - type list of :py:mod:`ParameterInformation <GRANTA_MIScriptingToolkit.ParameterInformation>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            Parameters_Create = self.lib.Parameters_Create
            Parameters_Create.restype = POINTER(c_void_p)
            self.c_obj = Parameters_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if parameters is not None:
            self.parameters = parameters


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            Parameters_Destroy = self.lib.Parameters_Destroy
            Parameters_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            Parameters_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def parameters(self):
        """Property parameters is a list of :py:mod:`ParameterInformation <GRANTA_MIScriptingToolkit.ParameterInformation>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._parameters = self.__GetParameters()
        except:
            pass
        return self._parameters

    @parameters.setter
    def parameters(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('parameters','parameters: Invalid type parameters must be a list of ParameterInformation')
                
        try:
            self.__updateparameters = True
            self.__ClearParameters()
            for v in value:
                self.AddParameter(v)
        except:
            pass


    def AddParameter(self, _parameterInformation):
        """Appends _parameterInformation to parameters property on Parameters C-object.

           Arguments:
                _parameterInformation - object of type ParameterInformation.
        """

        if not isinstance(_parameterInformation, ParameterInformation):
            raise GRANTA_Exception('Parameters.AddParameter','_parameterInformation: Invalid argument type _parameterInformation must be of type ParameterInformation')
        Parameters_AddParameter = self.lib.Parameters_AddParameter
        Parameters_AddParameter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        Parameters_AddParameter(self._c_obj, _parameterInformation.c_obj)
        return self

    def __ClearParameters(self):
        Parameters_ClearParameters = self.lib.Parameters_ClearParameters
        Parameters_ClearParameters.argtypes = [POINTER(c_void_p)]
        Parameters_ClearParameters(self._c_obj)
        return self

    def __GetNumberOfParameters(self):
        Parameters_GetNumberOfParameters = self.lib.Parameters_GetNumberOfParameters
        Parameters_GetNumberOfParameters.argtypes = [POINTER(c_void_p)]
        Parameters_GetNumberOfParameters.restype = c_int
        value = Parameters_GetNumberOfParameters(self._c_obj)
        return value
    
    def __GetParameterElement(self,i):
        value = ParameterInformation()
        Parameters_GetParameter = self.lib.Parameters_GetParameter
        Parameters_GetParameter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        Parameters_GetParameter(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetParameters(self):
         n = self.__GetNumberOfParameters();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetParameterElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


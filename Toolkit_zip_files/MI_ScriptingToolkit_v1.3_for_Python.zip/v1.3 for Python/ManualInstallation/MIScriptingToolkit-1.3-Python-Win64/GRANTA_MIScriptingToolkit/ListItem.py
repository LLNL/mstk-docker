# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.LogicalDataType import LogicalDataType
from GRANTA_MIScriptingToolkit.ShortTextDataType import ShortTextDataType
from GRANTA_MIScriptingToolkit.LongTextDataType import LongTextDataType
from GRANTA_MIScriptingToolkit.IntegerDataType import IntegerDataType
from GRANTA_MIScriptingToolkit.RangeDataType import RangeDataType
from GRANTA_MIScriptingToolkit.PointDataType import PointDataType
from GRANTA_MIScriptingToolkit.HyperlinkDataType import HyperlinkDataType
from GRANTA_MIScriptingToolkit.DiscreteDataType import DiscreteDataType
from GRANTA_MIScriptingToolkit.DateDataType import DateDataType
from GRANTA_MIScriptingToolkit.FileDataType import FileDataType


class ListItem(object):
    """ListItem. An item in a List data value.
    
        Arguments:
                * rangeDataValue - type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`
                * shortTextDataValue - type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`
                * hyperlinkDataValue - type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`
                * fileDataValue - type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`
                * discreteDataValue - type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`
                * dataType - type str
                * logicalDataValue - type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`
                * integerDataValue - type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`
                * pointDataValue - type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`
                * longTextDataValue - type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`
                * dateDataValue - type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`


    """
    
    def __init__(self, rangeDataValue=None, shortTextDataValue=None, hyperlinkDataValue=None, fileDataValue=None, discreteDataValue=None, dataType=None, logicalDataValue=None, integerDataValue=None, pointDataValue=None, longTextDataValue=None, dateDataValue=None, isOwner=True):
        """

        Arguments:
                * rangeDataValue - type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`
                * shortTextDataValue - type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`
                * hyperlinkDataValue - type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`
                * fileDataValue - type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`
                * discreteDataValue - type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`
                * dataType - type str
                * logicalDataValue - type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`
                * integerDataValue - type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`
                * pointDataValue - type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`
                * longTextDataValue - type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`
                * dateDataValue - type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ListItem_Create = self.lib.ListItem_Create
            ListItem_Create.restype = POINTER(c_void_p)
            self.c_obj = ListItem_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if rangeDataValue is not None:
            self.rangeDataValue = rangeDataValue
        if shortTextDataValue is not None:
            self.shortTextDataValue = shortTextDataValue
        if hyperlinkDataValue is not None:
            self.hyperlinkDataValue = hyperlinkDataValue
        if fileDataValue is not None:
            self.fileDataValue = fileDataValue
        if discreteDataValue is not None:
            self.discreteDataValue = discreteDataValue
        if dataType is not None:
            self.dataType = dataType
        if logicalDataValue is not None:
            self.logicalDataValue = logicalDataValue
        if integerDataValue is not None:
            self.integerDataValue = integerDataValue
        if pointDataValue is not None:
            self.pointDataValue = pointDataValue
        if longTextDataValue is not None:
            self.longTextDataValue = longTextDataValue
        if dateDataValue is not None:
            self.dateDataValue = dateDataValue


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ListItem_Destroy = self.lib.ListItem_Destroy
            ListItem_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ListItem_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def rangeDataValue(self):
        """Property rangeDataValue is of type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`. """ 
        self._rangeDataValue = self.__GetRangeDataValue()
        return self._rangeDataValue

    @rangeDataValue.setter
    def rangeDataValue(self, value):
        if not isinstance(value, RangeDataType):
            raise GRANTA_Exception('rangeDataValue','rangeDataValue: Invalid type rangeDataValue must be of type RangeDataType')
        
        self._rangeDataValue = value

    @property
    def shortTextDataValue(self):
        """Property shortTextDataValue is of type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`. """ 
        self._shortTextDataValue = self.__GetShortTextDataValue()
        return self._shortTextDataValue

    @shortTextDataValue.setter
    def shortTextDataValue(self, value):
        if not isinstance(value, ShortTextDataType):
            raise GRANTA_Exception('shortTextDataValue','shortTextDataValue: Invalid type shortTextDataValue must be of type ShortTextDataType')
        
        self._shortTextDataValue = value

    @property
    def hyperlinkDataValue(self):
        """Property hyperlinkDataValue is of type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`. """ 
        self._hyperlinkDataValue = self.__GetHyperlinkDataValue()
        return self._hyperlinkDataValue

    @hyperlinkDataValue.setter
    def hyperlinkDataValue(self, value):
        if not isinstance(value, HyperlinkDataType):
            raise GRANTA_Exception('hyperlinkDataValue','hyperlinkDataValue: Invalid type hyperlinkDataValue must be of type HyperlinkDataType')
        
        self._hyperlinkDataValue = value

    @property
    def fileDataValue(self):
        """Property fileDataValue is of type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`. """ 
        self._fileDataValue = self.__GetFileDataValue()
        return self._fileDataValue

    @fileDataValue.setter
    def fileDataValue(self, value):
        if not isinstance(value, FileDataType):
            raise GRANTA_Exception('fileDataValue','fileDataValue: Invalid type fileDataValue must be of type FileDataType')
        
        self._fileDataValue = value

    @property
    def discreteDataValue(self):
        """Property discreteDataValue is of type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`. """ 
        self._discreteDataValue = self.__GetDiscreteDataValue()
        return self._discreteDataValue

    @discreteDataValue.setter
    def discreteDataValue(self, value):
        if not isinstance(value, DiscreteDataType):
            raise GRANTA_Exception('discreteDataValue','discreteDataValue: Invalid type discreteDataValue must be of type DiscreteDataType')
        
        self._discreteDataValue = value

    @property
    def dataType(self):
        """Property dataType is of type str. """ 
        self._dataType = self.__GetDataType()
        return self._dataType

    @dataType.setter
    def dataType(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('dataType','dataType: Invalid type dataType must be of type str')
        
        self._dataType = value

    @property
    def logicalDataValue(self):
        """Property logicalDataValue is of type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`. """ 
        self._logicalDataValue = self.__GetLogicalDataValue()
        return self._logicalDataValue

    @logicalDataValue.setter
    def logicalDataValue(self, value):
        if not isinstance(value, LogicalDataType):
            raise GRANTA_Exception('logicalDataValue','logicalDataValue: Invalid type logicalDataValue must be of type LogicalDataType')
        
        self._logicalDataValue = value

    @property
    def integerDataValue(self):
        """Property integerDataValue is of type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`. """ 
        self._integerDataValue = self.__GetIntegerDataValue()
        return self._integerDataValue

    @integerDataValue.setter
    def integerDataValue(self, value):
        if not isinstance(value, IntegerDataType):
            raise GRANTA_Exception('integerDataValue','integerDataValue: Invalid type integerDataValue must be of type IntegerDataType')
        
        self._integerDataValue = value

    @property
    def pointDataValue(self):
        """Property pointDataValue is of type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`. """ 
        self._pointDataValue = self.__GetPointDataValue()
        return self._pointDataValue

    @pointDataValue.setter
    def pointDataValue(self, value):
        if not isinstance(value, PointDataType):
            raise GRANTA_Exception('pointDataValue','pointDataValue: Invalid type pointDataValue must be of type PointDataType')
        
        self._pointDataValue = value

    @property
    def longTextDataValue(self):
        """Property longTextDataValue is of type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`. """ 
        self._longTextDataValue = self.__GetLongTextDataValue()
        return self._longTextDataValue

    @longTextDataValue.setter
    def longTextDataValue(self, value):
        if not isinstance(value, LongTextDataType):
            raise GRANTA_Exception('longTextDataValue','longTextDataValue: Invalid type longTextDataValue must be of type LongTextDataType')
        
        self._longTextDataValue = value

    @property
    def dateDataValue(self):
        """Property dateDataValue is of type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`. """ 
        self._dateDataValue = self.__GetDateDataValue()
        return self._dateDataValue

    @dateDataValue.setter
    def dateDataValue(self, value):
        if not isinstance(value, DateDataType):
            raise GRANTA_Exception('dateDataValue','dateDataValue: Invalid type dateDataValue must be of type DateDataType')
        
        self._dateDataValue = value

    def __GetDataType(self):
        ListItem_GetDataType = self.lib.ListItem_GetDataType
        ListItem_GetDataType.argtypes = [POINTER(c_void_p)]
        ListItem_GetDataType.restype = POINTER(c_void_p)
        value = ListItem_GetDataType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetLogicalDataValue(self):
        _logicalDataType = LogicalDataType()
        ListItem_GetLogicalDataValue = self.lib.ListItem_GetLogicalDataValue
        ListItem_GetLogicalDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ListItem_GetLogicalDataValue(self._c_obj, (_logicalDataType.c_obj))
        
        return _logicalDataType
        
    def __GetShortTextDataValue(self):
        _shortTextDataType = ShortTextDataType()
        ListItem_GetShortTextDataValue = self.lib.ListItem_GetShortTextDataValue
        ListItem_GetShortTextDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ListItem_GetShortTextDataValue(self._c_obj, (_shortTextDataType.c_obj))
        
        return _shortTextDataType
        
    def __GetLongTextDataValue(self):
        _longTextDataType = LongTextDataType()
        ListItem_GetLongTextDataValue = self.lib.ListItem_GetLongTextDataValue
        ListItem_GetLongTextDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ListItem_GetLongTextDataValue(self._c_obj, (_longTextDataType.c_obj))
        
        return _longTextDataType
        
    def __GetIntegerDataValue(self):
        _integerDataType = IntegerDataType()
        ListItem_GetIntegerDataValue = self.lib.ListItem_GetIntegerDataValue
        ListItem_GetIntegerDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ListItem_GetIntegerDataValue(self._c_obj, (_integerDataType.c_obj))
        
        return _integerDataType
        
    def __GetRangeDataValue(self):
        _rangeDataType = RangeDataType()
        ListItem_GetRangeDataValue = self.lib.ListItem_GetRangeDataValue
        ListItem_GetRangeDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ListItem_GetRangeDataValue(self._c_obj, (_rangeDataType.c_obj))
        
        return _rangeDataType
        
    def __GetPointDataValue(self):
        _pointDataType = PointDataType()
        ListItem_GetPointDataValue = self.lib.ListItem_GetPointDataValue
        ListItem_GetPointDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ListItem_GetPointDataValue(self._c_obj, (_pointDataType.c_obj))
        
        return _pointDataType
        
    def __GetHyperlinkDataValue(self):
        _hyperlinkDataType = HyperlinkDataType()
        ListItem_GetHyperlinkDataValue = self.lib.ListItem_GetHyperlinkDataValue
        ListItem_GetHyperlinkDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ListItem_GetHyperlinkDataValue(self._c_obj, (_hyperlinkDataType.c_obj))
        
        return _hyperlinkDataType
        
    def __GetDiscreteDataValue(self):
        _discreteDataType = DiscreteDataType()
        ListItem_GetDiscreteDataValue = self.lib.ListItem_GetDiscreteDataValue
        ListItem_GetDiscreteDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ListItem_GetDiscreteDataValue(self._c_obj, (_discreteDataType.c_obj))
        
        return _discreteDataType
        
    def __GetDateDataValue(self):
        _dateDataType = DateDataType()
        ListItem_GetDateDataValue = self.lib.ListItem_GetDateDataValue
        ListItem_GetDateDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ListItem_GetDateDataValue(self._c_obj, (_dateDataType.c_obj))
        
        return _dateDataType
        
    def __GetFileDataValue(self):
        _fileDataType = FileDataType()
        ListItem_GetFileDataValue = self.lib.ListItem_GetFileDataValue
        ListItem_GetFileDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ListItem_GetFileDataValue(self._c_obj, (_fileDataType.c_obj))
        
        return _fileDataType
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


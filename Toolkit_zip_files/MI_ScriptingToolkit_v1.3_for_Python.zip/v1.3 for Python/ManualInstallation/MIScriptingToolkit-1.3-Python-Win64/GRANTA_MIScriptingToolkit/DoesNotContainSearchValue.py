# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class DoesNotContainSearchValue(object):
    """DoesNotContainSearchValue. Search criterion to search for discrete data types that contain none of the specified search values. 
This criterion type is specific to discrete attributes.
    
        Arguments:
                * value - type str


    """
    
    def __init__(self, value=None, isOwner=True):
        """

        Arguments:
                * value - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            DoesNotContainSearchValue_Create = self.lib.DoesNotContainSearchValue_Create
            DoesNotContainSearchValue_Create.restype = POINTER(c_void_p)
            self.c_obj = DoesNotContainSearchValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if value is not None:
            self.value = value


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            DoesNotContainSearchValue_Destroy = self.lib.DoesNotContainSearchValue_Destroy
            DoesNotContainSearchValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            DoesNotContainSearchValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def value(self):
        """Property value is of type str. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('value','value: Invalid type value must be of type str')
        self.__SetValue(value)
        self._value = value

    def __GetValue(self):
        DoesNotContainSearchValue_GetValue = self.lib.DoesNotContainSearchValue_GetValue
        DoesNotContainSearchValue_GetValue.argtypes = [POINTER(c_void_p)]
        DoesNotContainSearchValue_GetValue.restype = POINTER(c_void_p)
        value = DoesNotContainSearchValue_GetValue(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetValue(self, value):

        DoesNotContainSearchValue_SetValue = self.lib.DoesNotContainSearchValue_SetValue 
        DoesNotContainSearchValue_SetValue.argtypes = [POINTER(c_void_p), c_char_p]
        DoesNotContainSearchValue_SetValue(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


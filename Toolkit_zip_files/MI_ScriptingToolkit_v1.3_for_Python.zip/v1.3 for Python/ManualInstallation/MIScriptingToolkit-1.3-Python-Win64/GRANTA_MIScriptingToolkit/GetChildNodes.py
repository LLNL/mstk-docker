# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.RecordFilter import RecordFilter


class GetChildNodes(object):
    """GetChildNodes. Input for the GetChildNodes operation.
A :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` for the record you wish to find the children of is required.
    
        Arguments:
                * recordFilter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * recurse - type bool
                * populateGUIDs - type bool
                * parent - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * recurseMaxDepth - type int


    """
    
    def __init__(self, recordFilter=None, recurse=None, populateGUIDs=None, parent=None, recurseMaxDepth=None, isOwner=True):
        """

        Arguments:
                * recordFilter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * recurse - type bool
                * populateGUIDs - type bool
                * parent - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * recurseMaxDepth - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetChildNodes_Create = self.lib.GetChildNodes_Create
            GetChildNodes_Create.restype = POINTER(c_void_p)
            self.c_obj = GetChildNodes_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordFilter is not None:
            self.recordFilter = recordFilter
        if recurse is not None:
            self.recurse = recurse
        if populateGUIDs is not None:
            self.populateGUIDs = populateGUIDs
        if parent is not None:
            self.parent = parent
        if recurseMaxDepth is not None:
            self.recurseMaxDepth = recurseMaxDepth


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetChildNodes_Destroy = self.lib.GetChildNodes_Destroy
            GetChildNodes_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetChildNodes_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordFilter(self):
        """Property recordFilter is of type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`. """ 
        self._recordFilter = self.__GetRecordFilter()
        return self._recordFilter

    @recordFilter.setter
    def recordFilter(self, value):
        if not isinstance(value, RecordFilter):
            raise GRANTA_Exception('recordFilter','recordFilter: Invalid type recordFilter must be of type RecordFilter')
        self.__SetRecordFilter(value)
        self._recordFilter = value

    @property
    def recurse(self):
        """Property recurse is of type bool. """ 
        self._recurse = self.__GetRecurse()
        return self._recurse

    @recurse.setter
    def recurse(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('recurse','recurse: Invalid type recurse must be of type bool')
        self.__SetRecurse(value)
        self._recurse = value

    @property
    def populateGUIDs(self):
        """Property populateGUIDs is of type bool. """ 
        self._populateGUIDs = self.__GetPopulateGUIDs()
        return self._populateGUIDs

    @populateGUIDs.setter
    def populateGUIDs(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('populateGUIDs','populateGUIDs: Invalid type populateGUIDs must be of type bool')
        self.__SetPopulateGUIDs(value)
        self._populateGUIDs = value

    @property
    def parent(self):
        """Property parent is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._parent = self.__GetParent()
        return self._parent

    @parent.setter
    def parent(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('parent','parent: Invalid type parent must be of type RecordReference')
        self.__SetParent(value)
        self._parent = value

    @property
    def recurseMaxDepth(self):
        """Property recurseMaxDepth is of type int. """ 
        self._recurseMaxDepth = self.__GetRecurseMaxDepth()
        return self._recurseMaxDepth

    @recurseMaxDepth.setter
    def recurseMaxDepth(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('recurseMaxDepth','recurseMaxDepth: Invalid type recurseMaxDepth must be of type int')
        self.__SetRecurseMaxDepth(value)
        self._recurseMaxDepth = value

    def __SetParent(self, value):

        GetChildNodes_SetParent = self.lib.GetChildNodes_SetParent 
        GetChildNodes_SetParent.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetChildNodes_SetParent(self._c_obj, value.c_obj)

    def __SetPopulateGUIDs(self, value):

        GetChildNodes_SetPopulateGUIDs = self.lib.GetChildNodes_SetPopulateGUIDs 
        GetChildNodes_SetPopulateGUIDs.argtypes = [POINTER(c_void_p), c_bool]
        GetChildNodes_SetPopulateGUIDs(self._c_obj, value)

    def __SetRecurse(self, value):

        GetChildNodes_SetRecurse = self.lib.GetChildNodes_SetRecurse 
        GetChildNodes_SetRecurse.argtypes = [POINTER(c_void_p), c_bool]
        GetChildNodes_SetRecurse(self._c_obj, value)

    def __GetParent(self):
        _recordReference = RecordReference()
        GetChildNodes_GetParent = self.lib.GetChildNodes_GetParent
        GetChildNodes_GetParent.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetChildNodes_GetParent(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __GetPopulateGUIDs(self):
        GetChildNodes_GetPopulateGUIDs = self.lib.GetChildNodes_GetPopulateGUIDs
        GetChildNodes_GetPopulateGUIDs.argtypes = [POINTER(c_void_p)]
        GetChildNodes_GetPopulateGUIDs.restype = c_bool
        value = GetChildNodes_GetPopulateGUIDs(self._c_obj)
        return value
    
    def __GetRecurse(self):
        GetChildNodes_GetRecurse = self.lib.GetChildNodes_GetRecurse
        GetChildNodes_GetRecurse.argtypes = [POINTER(c_void_p)]
        GetChildNodes_GetRecurse.restype = c_bool
        value = GetChildNodes_GetRecurse(self._c_obj)
        return value
    
    def __GetRecordFilter(self):
        _recordFilter = RecordFilter()
        GetChildNodes_GetRecordFilter = self.lib.GetChildNodes_GetRecordFilter
        GetChildNodes_GetRecordFilter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetChildNodes_GetRecordFilter(self._c_obj, (_recordFilter.c_obj))
        
        return _recordFilter
        
    def __SetRecordFilter(self, value):

        GetChildNodes_SetRecordFilter = self.lib.GetChildNodes_SetRecordFilter 
        GetChildNodes_SetRecordFilter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetChildNodes_SetRecordFilter(self._c_obj, value.c_obj)

    def __GetRecurseMaxDepth(self):
        GetChildNodes_GetRecurseMaxDepth = self.lib.GetChildNodes_GetRecurseMaxDepth
        GetChildNodes_GetRecurseMaxDepth.argtypes = [POINTER(c_void_p)]
        GetChildNodes_GetRecurseMaxDepth.restype = c_int
        value = GetChildNodes_GetRecurseMaxDepth(self._c_obj)
        return value
    
    def __SetRecurseMaxDepth(self, value):

        GetChildNodes_SetRecurseMaxDepth = self.lib.GetChildNodes_SetRecurseMaxDepth 
        GetChildNodes_SetRecurseMaxDepth.argtypes = [POINTER(c_void_p), c_int]
        GetChildNodes_SetRecurseMaxDepth(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


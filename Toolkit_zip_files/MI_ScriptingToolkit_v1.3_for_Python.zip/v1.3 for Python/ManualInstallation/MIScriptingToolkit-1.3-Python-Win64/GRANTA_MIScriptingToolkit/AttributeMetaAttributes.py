# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference
from GRANTA_MIScriptingToolkit.NamedAttribute import NamedAttribute


class AttributeMetaAttributes(object):
    """AttributeMetaAttributes. Lists the Meta-Attributes of a particular Attribute in a GRANTA MI Database Table.
    
        Arguments:
                * metaAttributes - type list of :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>` objects
                * parentAttribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`


    """
    
    def __init__(self, metaAttributes=None, parentAttribute=None, isOwner=True):
        """

        Arguments:
                * metaAttributes - type list of :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>` objects
                * parentAttribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            AttributeMetaAttributes_Create = self.lib.AttributeMetaAttributes_Create
            AttributeMetaAttributes_Create.restype = POINTER(c_void_p)
            self.c_obj = AttributeMetaAttributes_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if metaAttributes is not None:
            self.metaAttributes = metaAttributes
        if parentAttribute is not None:
            self.parentAttribute = parentAttribute


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            AttributeMetaAttributes_Destroy = self.lib.AttributeMetaAttributes_Destroy
            AttributeMetaAttributes_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            AttributeMetaAttributes_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def metaAttributes(self):
        """Property metaAttributes is a list of :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._metaAttributes = self.__GetMetaAttributes()
        except:
            pass
        return self._metaAttributes

    @metaAttributes.setter
    def metaAttributes(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('metaAttributes','metaAttributes: Invalid type metaAttributes must be a list of NamedAttribute')
        
        self._metaAttributes = value

    @property
    def parentAttribute(self):
        """Property parentAttribute is of type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`. """ 
        self._parentAttribute = self.__GetParentAttribute()
        return self._parentAttribute

    @parentAttribute.setter
    def parentAttribute(self, value):
        if not isinstance(value, AttributeReference):
            raise GRANTA_Exception('parentAttribute','parentAttribute: Invalid type parentAttribute must be of type AttributeReference')
        
        self._parentAttribute = value

    def __GetParentAttribute(self):
        _attributeReference = AttributeReference()
        AttributeMetaAttributes_GetParentAttribute = self.lib.AttributeMetaAttributes_GetParentAttribute
        AttributeMetaAttributes_GetParentAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeMetaAttributes_GetParentAttribute(self._c_obj, (_attributeReference.c_obj))
        
        return _attributeReference
        
    def __GetNumberOfMetaAttributes(self):
        AttributeMetaAttributes_GetNumberOfMetaAttributes = self.lib.AttributeMetaAttributes_GetNumberOfMetaAttributes
        AttributeMetaAttributes_GetNumberOfMetaAttributes.argtypes = [POINTER(c_void_p)]
        AttributeMetaAttributes_GetNumberOfMetaAttributes.restype = c_int
        value = AttributeMetaAttributes_GetNumberOfMetaAttributes(self._c_obj)
        return value
    
    def __GetMetaAttributeElement(self,i):
        value = NamedAttribute()
        AttributeMetaAttributes_GetMetaAttribute = self.lib.AttributeMetaAttributes_GetMetaAttribute
        AttributeMetaAttributes_GetMetaAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        AttributeMetaAttributes_GetMetaAttribute(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetMetaAttributes(self):
         n = self.__GetNumberOfMetaAttributes();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetMetaAttributeElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


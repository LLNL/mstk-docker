

from ctypes import POINTER, pointer
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from GRANTA_MIScriptingToolkit import GRANTA_libs

class Defs:
    unicode_type = type(u"x")
    bytes_type = type(b"x")
    string_types = (unicode_type, bytes_type)
    
def EnsureEncoded(param):
    if type(param) == Defs.unicode_type:
        return param.encode("utf-8")
    return param

class StringUtils(object):
    """StringUtils. Class for dealing with memory of C character data. For internal usage only. """
    
    def __init__(self):
        self.lib = GRANTA_libs.MIServiceLayerCAPILib

    
    def delete(self, obj):
         try:
            Char_Destroy = self.lib.Char_Destroy
            Char_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            Char_Destroy(pointer(obj))
         except:
             print ("ERROR: deleting string {0} {1}".format(obj, pointer(obj)))
        

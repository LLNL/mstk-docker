# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordLinkGroupDetail import RecordLinkGroupDetail
from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse


class GetRecordLinkGroupsResponse(object):
    """GetRecordLinkGroupsResponse. Output from the :py:mod:`GetRecordLinkGroups <GRANTA_MIScriptingToolkit.GetRecordLinkGroups>` operation.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetRecordLinkGroupsResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetRecordLinkGroupsResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetRecordLinkGroupsResponse_Destroy = self.lib.GetRecordLinkGroupsResponse_Destroy
            GetRecordLinkGroupsResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetRecordLinkGroupsResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordLinkGroups(self):
        """Property recordLinkGroups is a list of :py:mod:`RecordLinkGroupDetail <GRANTA_MIScriptingToolkit.RecordLinkGroupDetail>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordLinkGroups = self.__GetRecordLinkGroups()
        except:
            pass
        return self._recordLinkGroups

    @recordLinkGroups.setter
    def recordLinkGroups(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordLinkGroups','recordLinkGroups: Invalid type recordLinkGroups must be a list of RecordLinkGroupDetail')
        
        self._recordLinkGroups = value

    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        self.__SetServiceLayerResponse(value)
        self._serviceLayerResponse = value

    def __GetNumberOfRecordLinkGroups(self):
        GetRecordLinkGroupsResponse_GetNumberOfRecordLinkGroups = self.lib.GetRecordLinkGroupsResponse_GetNumberOfRecordLinkGroups
        GetRecordLinkGroupsResponse_GetNumberOfRecordLinkGroups.argtypes = [POINTER(c_void_p)]
        GetRecordLinkGroupsResponse_GetNumberOfRecordLinkGroups.restype = c_int
        value = GetRecordLinkGroupsResponse_GetNumberOfRecordLinkGroups(self._c_obj)
        return value
    
    def __GetRecordLinkGroupElement(self,i):
        value = RecordLinkGroupDetail()
        GetRecordLinkGroupsResponse_GetRecordLinkGroup = self.lib.GetRecordLinkGroupsResponse_GetRecordLinkGroup
        GetRecordLinkGroupsResponse_GetRecordLinkGroup.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetRecordLinkGroupsResponse_GetRecordLinkGroup(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordLinkGroups(self):
         n = self.__GetNumberOfRecordLinkGroups();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordLinkGroupElement(i))
         return temp
    
    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetRecordLinkGroupsResponse_GetServiceLayerResponse = self.lib.GetRecordLinkGroupsResponse_GetServiceLayerResponse
        GetRecordLinkGroupsResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetRecordLinkGroupsResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __SetServiceLayerResponse(self, value):

        GetRecordLinkGroupsResponse_SetServiceLayerResponse = self.lib.GetRecordLinkGroupsResponse_SetServiceLayerResponse 
        GetRecordLinkGroupsResponse_SetServiceLayerResponse.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRecordLinkGroupsResponse_SetServiceLayerResponse(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


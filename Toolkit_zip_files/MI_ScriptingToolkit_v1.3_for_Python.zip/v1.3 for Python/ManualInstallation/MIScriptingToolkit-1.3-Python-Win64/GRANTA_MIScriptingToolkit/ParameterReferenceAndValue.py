# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterReference import ParameterReference
from GRANTA_MIScriptingToolkit.ParameterValue import ParameterValue


class ParameterReferenceAndValue(object):
    """ParameterReferenceAndValue. Contains a :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>` and a :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`.
    
        Arguments:
                * parameterValue - type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`
                * parameter - type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`


    """
    
    def __init__(self, parameterValue=None, parameter=None, isOwner=True):
        """

        Arguments:
                * parameterValue - type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`
                * parameter - type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ParameterReferenceAndValue_Create = self.lib.ParameterReferenceAndValue_Create
            ParameterReferenceAndValue_Create.restype = POINTER(c_void_p)
            self.c_obj = ParameterReferenceAndValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if parameterValue is not None:
            self.parameterValue = parameterValue
        if parameter is not None:
            self.parameter = parameter


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ParameterReferenceAndValue_Destroy = self.lib.ParameterReferenceAndValue_Destroy
            ParameterReferenceAndValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ParameterReferenceAndValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def parameterValue(self):
        """Property parameterValue is of type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`. """ 
        self._parameterValue = self.__GetParameterValue()
        return self._parameterValue

    @parameterValue.setter
    def parameterValue(self, value):
        if not isinstance(value, ParameterValue):
            raise GRANTA_Exception('parameterValue','parameterValue: Invalid type parameterValue must be of type ParameterValue')
        self.__SetParameterValue(value)
        self._parameterValue = value

    @property
    def parameter(self):
        """Property parameter is of type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`. """ 
        self._parameter = self.__GetParameter()
        return self._parameter

    @parameter.setter
    def parameter(self, value):
        if not isinstance(value, ParameterReference):
            raise GRANTA_Exception('parameter','parameter: Invalid type parameter must be of type ParameterReference')
        self.__SetParameter(value)
        self._parameter = value

    def __SetParameter(self, value):

        ParameterReferenceAndValue_SetParameter = self.lib.ParameterReferenceAndValue_SetParameter 
        ParameterReferenceAndValue_SetParameter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ParameterReferenceAndValue_SetParameter(self._c_obj, value.c_obj)

    def __GetParameter(self):
        _parameterReference = ParameterReference()
        ParameterReferenceAndValue_GetParameter = self.lib.ParameterReferenceAndValue_GetParameter
        ParameterReferenceAndValue_GetParameter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ParameterReferenceAndValue_GetParameter(self._c_obj, (_parameterReference.c_obj))
        
        return _parameterReference
        
    def __SetParameterValue(self, value):

        ParameterReferenceAndValue_SetParameterValue = self.lib.ParameterReferenceAndValue_SetParameterValue 
        ParameterReferenceAndValue_SetParameterValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ParameterReferenceAndValue_SetParameterValue(self._c_obj, value.c_obj)

    def __GetParameterValue(self):
        _parameterValue = ParameterValue()
        ParameterReferenceAndValue_GetParameterValue = self.lib.ParameterReferenceAndValue_GetParameterValue
        ParameterReferenceAndValue_GetParameterValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ParameterReferenceAndValue_GetParameterValue(self._c_obj, (_parameterValue.c_obj))
        
        return _parameterValue
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


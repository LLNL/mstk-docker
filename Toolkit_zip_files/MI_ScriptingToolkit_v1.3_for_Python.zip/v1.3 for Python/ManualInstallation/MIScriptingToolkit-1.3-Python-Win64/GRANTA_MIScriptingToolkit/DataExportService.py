import time
import GRANTA_MIScriptingToolkit.GRANTA_libs as GRANTA_libs
from ctypes import c_char_p, POINTER, c_bool, c_double, c_void_p, c_int
from GRANTA_MIScriptingToolkit.GRANTA_Logging import GRANTA_Logging
from GRANTA_MIScriptingToolkit.Service import Service
from GRANTA_MIScriptingToolkit.GRANTA_Exceptions import GRANTA_Exception
from GRANTA_MIScriptingToolkit.GetRecordAttributesByRefRequest import GetRecordAttributesByRefRequest
from GRANTA_MIScriptingToolkit.GetRecordAttributesByRefResponse import GetRecordAttributesByRefResponse

# This file was automatically generated
class DataExportService(Service):
    """The DataExport service retrieves and returns data from attributes of records in GRANTA MI Databases."""

    def __init__(self, mi_session):
        """Initialize a DataExportService object
                Arguments:
                    mi_session - MI_Session object
        """
        self.mi_session = mi_session
        self.lib = GRANTA_libs.MIServiceLayerCAPILib

    def GetRecordAttributesByRef(self, _req):
        """Retrieves the data values for the given attribute(s) and record(s) in a GRANTA MI Database.

        Arguments:
            _req - :py:mod:`GetRecordAttributesByRefRequest <GRANTA_MIScriptingToolkit.GetRecordAttributesByRefRequest>` object
        Returns:
            :py:mod:`GetRecordAttributesByRefResponse <GRANTA_MIScriptingToolkit.GetRecordAttributesByRefResponse>` object
        
        """
        if not isinstance(_req, GetRecordAttributesByRefRequest):
            raise GRANTA_Exception('DataExport.GetRecordAttributesByRef','DataExport.GetRecordAttributesByRef(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetRecordAttributesByRefRequest')

        startTime = time.clock()
        func = self.lib.DataExport_GetRecordAttributesByRef
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetRecordAttributesByRefResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran DataExport.GetRecordAttributesByRef() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'DataExport.GetRecordAttributesByRef')
        return response


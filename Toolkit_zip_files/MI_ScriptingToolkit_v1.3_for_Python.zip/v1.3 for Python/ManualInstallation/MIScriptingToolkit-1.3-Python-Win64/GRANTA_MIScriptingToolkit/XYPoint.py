# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterValue import ParameterValue


class XYPoint(object):
    """XYPoint. An x-y datum where the y-axis value is a point.
    
        Arguments:
                * Y - type float
                * isEstimated - type bool
                * parameterValue - type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`


    """
    
    def __init__(self, Y=None, isEstimated=None, parameterValue=None, isOwner=True):
        """

        Arguments:
                * Y - type float
                * isEstimated - type bool
                * parameterValue - type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            XYPoint_Create = self.lib.XYPoint_Create
            XYPoint_Create.restype = POINTER(c_void_p)
            self.c_obj = XYPoint_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if Y is not None:
            self.Y = Y
        if isEstimated is not None:
            self.isEstimated = isEstimated
        if parameterValue is not None:
            self.parameterValue = parameterValue


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            XYPoint_Destroy = self.lib.XYPoint_Destroy
            XYPoint_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            XYPoint_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def Y(self):
        """Property Y is of type float. """ 
        self._Y = self.__GetY()
        return self._Y

    @Y.setter
    def Y(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('Y','Y: Invalid type Y must be of type float')
        self.__SetY(value)
        self._Y = value

    @property
    def isEstimated(self):
        """Property isEstimated is of type bool. """ 
        self._isEstimated = self.__GetIsEstimated()
        return self._isEstimated

    @isEstimated.setter
    def isEstimated(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('isEstimated','isEstimated: Invalid type isEstimated must be of type bool')
        
        self._isEstimated = value

    @property
    def parameterValue(self):
        """Property parameterValue is of type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`. """ 
        self._parameterValue = self.__GetParameterValue()
        return self._parameterValue

    @parameterValue.setter
    def parameterValue(self, value):
        if not isinstance(value, ParameterValue):
            raise GRANTA_Exception('parameterValue','parameterValue: Invalid type parameterValue must be of type ParameterValue')
        self.__SetParameterValue(value)
        self._parameterValue = value

    def __GetY(self):
        XYPoint_GetY = self.lib.XYPoint_GetY
        XYPoint_GetY.argtypes = [POINTER(c_void_p)]
        XYPoint_GetY.restype = c_double
        value = XYPoint_GetY(self._c_obj)
        return value
    
    def __SetY(self, value):

        XYPoint_SetY = self.lib.XYPoint_SetY 
        XYPoint_SetY.argtypes = [POINTER(c_void_p), c_double]
        XYPoint_SetY(self._c_obj, value)

    def __GetParameterValue(self):
        _parameterValue = ParameterValue()
        XYPoint_GetParameterValue = self.lib.XYPoint_GetParameterValue
        XYPoint_GetParameterValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        XYPoint_GetParameterValue(self._c_obj, (_parameterValue.c_obj))
        
        return _parameterValue
        
    def __SetParameterValue(self, value):

        XYPoint_SetParameterValue = self.lib.XYPoint_SetParameterValue 
        XYPoint_SetParameterValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        XYPoint_SetParameterValue(self._c_obj, value.c_obj)

    def __GetIsEstimated(self):
        XYPoint_GetIsEstimated = self.lib.XYPoint_GetIsEstimated
        XYPoint_GetIsEstimated.argtypes = [POINTER(c_void_p)]
        XYPoint_GetIsEstimated.restype = c_bool
        value = XYPoint_GetIsEstimated(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


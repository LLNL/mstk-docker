# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RevisionInfo import RevisionInfo


class TabularColumnDetail(object):
    """TabularColumnDetail. Describes a Tabular Column, defined in a Tabular Attribute. 
This details how the schema describes the Column, and does not provide information about the contents of the Column in any particular Datum.
    
        Arguments:
                * name - type str
                * dataType - type str
                * databaseUnit - type str
                * revisionInfo - type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`
                * discreteValues - type list of str objects
                * type - type int


    """
    
    def __init__(self, name=None, dataType=None, databaseUnit=None, revisionInfo=None, discreteValues=None, type=None, isOwner=True):
        """

        Arguments:
                * name - type str
                * dataType - type str
                * databaseUnit - type str
                * revisionInfo - type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`
                * discreteValues - type list of str objects
                * type - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            TabularColumnDetail_Create = self.lib.TabularColumnDetail_Create
            TabularColumnDetail_Create.restype = POINTER(c_void_p)
            self.c_obj = TabularColumnDetail_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if name is not None:
            self.name = name
        if dataType is not None:
            self.dataType = dataType
        if databaseUnit is not None:
            self.databaseUnit = databaseUnit
        if revisionInfo is not None:
            self.revisionInfo = revisionInfo
        if discreteValues is not None:
            self.discreteValues = discreteValues
        if type is not None:
            self.type = type


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            TabularColumnDetail_Destroy = self.lib.TabularColumnDetail_Destroy
            TabularColumnDetail_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            TabularColumnDetail_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        
        self._name = value

    @property
    def dataType(self):
        """Property dataType is of type str. """ 
        self._dataType = self.__GetDataType()
        return self._dataType

    @dataType.setter
    def dataType(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('dataType','dataType: Invalid type dataType must be of type str')
        
        self._dataType = value

    @property
    def databaseUnit(self):
        """Property databaseUnit is of type str. """ 
        self._databaseUnit = self.__GetDatabaseUnit()
        return self._databaseUnit

    @databaseUnit.setter
    def databaseUnit(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('databaseUnit','databaseUnit: Invalid type databaseUnit must be of type str')
        
        self._databaseUnit = value

    @property
    def revisionInfo(self):
        """Property revisionInfo is of type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`. """ 
        self._revisionInfo = self.__GetRevisionInfo()
        return self._revisionInfo

    @revisionInfo.setter
    def revisionInfo(self, value):
        if not isinstance(value, RevisionInfo):
            raise GRANTA_Exception('revisionInfo','revisionInfo: Invalid type revisionInfo must be of type RevisionInfo')
        
        self._revisionInfo = value

    @property
    def discreteValues(self):
        """Property discreteValues is a list of str objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._discreteValues = self.__GetDiscreteValues()
        except:
            pass
        return self._discreteValues

    @discreteValues.setter
    def discreteValues(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('discreteValues','discreteValues: Invalid type discreteValues must be a list of str')
        
        self._discreteValues = value

    @property
    def type(self):
        """Property type is of type int. See :py:class:`TabularColumn.ColType <GRANTA_MIScriptingToolkit.TabularColumn>` for supported values.""" 
        self._type = self.__GetType()
        return self._type

    @type.setter
    def type(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('type','type: Invalid type type must be of type int')
        
        self._type = value

    def __GetName(self):
        TabularColumnDetail_GetName = self.lib.TabularColumnDetail_GetName
        TabularColumnDetail_GetName.argtypes = [POINTER(c_void_p)]
        TabularColumnDetail_GetName.restype = POINTER(c_void_p)
        value = TabularColumnDetail_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetType(self):
        TabularColumnDetail_GetType = self.lib.TabularColumnDetail_GetType
        TabularColumnDetail_GetType.argtypes = [POINTER(c_void_p)]
        TabularColumnDetail_GetType.restype = c_int
        value = TabularColumnDetail_GetType(self._c_obj)
        return value
    
    def __GetRevisionInfo(self):
        _revisionInfo = RevisionInfo()
        TabularColumnDetail_GetRevisionInfo = self.lib.TabularColumnDetail_GetRevisionInfo
        TabularColumnDetail_GetRevisionInfo.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularColumnDetail_GetRevisionInfo(self._c_obj, (_revisionInfo.c_obj))
        
        return _revisionInfo
        
    def __GetDataType(self):
        TabularColumnDetail_GetDataType = self.lib.TabularColumnDetail_GetDataType
        TabularColumnDetail_GetDataType.argtypes = [POINTER(c_void_p)]
        TabularColumnDetail_GetDataType.restype = POINTER(c_void_p)
        value = TabularColumnDetail_GetDataType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetDatabaseUnit(self):
        TabularColumnDetail_GetDatabaseUnit = self.lib.TabularColumnDetail_GetDatabaseUnit
        TabularColumnDetail_GetDatabaseUnit.argtypes = [POINTER(c_void_p)]
        TabularColumnDetail_GetDatabaseUnit.restype = POINTER(c_void_p)
        value = TabularColumnDetail_GetDatabaseUnit(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetNumberOfDiscreteValues(self):
        TabularColumnDetail_GetNumberOfDiscreteValues = self.lib.TabularColumnDetail_GetNumberOfDiscreteValues
        TabularColumnDetail_GetNumberOfDiscreteValues.argtypes = [POINTER(c_void_p)]
        TabularColumnDetail_GetNumberOfDiscreteValues.restype = c_int
        value = TabularColumnDetail_GetNumberOfDiscreteValues(self._c_obj)
        return value
    
    def __GetDiscreteValueElement(self,i):
        TabularColumnDetail_GetDiscreteValue = self.lib.TabularColumnDetail_GetDiscreteValue
        TabularColumnDetail_GetDiscreteValue.argtypes = [POINTER(c_void_p), c_int]
        TabularColumnDetail_GetDiscreteValue.restype = POINTER(c_void_p)
        value = TabularColumnDetail_GetDiscreteValue(self._c_obj, i)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
    
    def __GetDiscreteValues(self):
         n = self.__GetNumberOfDiscreteValues();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetDiscreteValueElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


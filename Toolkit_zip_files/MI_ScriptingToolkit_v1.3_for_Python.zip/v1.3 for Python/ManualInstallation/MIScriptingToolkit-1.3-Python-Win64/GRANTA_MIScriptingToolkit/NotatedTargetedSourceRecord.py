# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.NotatedTargetRecord import NotatedTargetRecord
from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class NotatedTargetedSourceRecord(object):
    """NotatedTargetedSourceRecord. A :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` to link from and container of :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` of the records to link to.
Requires a source :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>`. Can set zero to many target :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` objects you wish to link to.
    
        Arguments:
                * sourceRecord - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * targetRecords - type list of :py:mod:`NotatedTargetRecord <GRANTA_MIScriptingToolkit.NotatedTargetRecord>` objects


    """
    
    def __init__(self, sourceRecord=None, targetRecords=None, isOwner=True):
        """

        Arguments:
                * sourceRecord - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * targetRecords - type list of :py:mod:`NotatedTargetRecord <GRANTA_MIScriptingToolkit.NotatedTargetRecord>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            NotatedTargetedSourceRecord_Create = self.lib.NotatedTargetedSourceRecord_Create
            NotatedTargetedSourceRecord_Create.restype = POINTER(c_void_p)
            self.c_obj = NotatedTargetedSourceRecord_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if sourceRecord is not None:
            self.sourceRecord = sourceRecord
        if targetRecords is not None:
            self.targetRecords = targetRecords


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            NotatedTargetedSourceRecord_Destroy = self.lib.NotatedTargetedSourceRecord_Destroy
            NotatedTargetedSourceRecord_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            NotatedTargetedSourceRecord_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def sourceRecord(self):
        """Property sourceRecord is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._sourceRecord = self.__GetSourceRecord()
        return self._sourceRecord

    @sourceRecord.setter
    def sourceRecord(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('sourceRecord','sourceRecord: Invalid type sourceRecord must be of type RecordReference')
        self.__SetSourceRecord(value)
        self._sourceRecord = value

    @property
    def targetRecords(self):
        """Property targetRecords is a list of :py:mod:`NotatedTargetRecord <GRANTA_MIScriptingToolkit.NotatedTargetRecord>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._targetRecords = self.__GetTargetRecords()
        except:
            pass
        return self._targetRecords

    @targetRecords.setter
    def targetRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('targetRecords','targetRecords: Invalid type targetRecords must be a list of NotatedTargetRecord')
                
        try:
            self.__updatetargetRecords = True
            self.__ClearTargetRecords()
            for v in value:
                self.AddTargetRecord(v)
        except:
            pass


    def AddTargetRecord(self, _notatedTargetRecord):
        """Appends _notatedTargetRecord to targetRecords property on NotatedTargetedSourceRecord C-object.

           Arguments:
                _notatedTargetRecord - object of type NotatedTargetRecord.
        """

        if not isinstance(_notatedTargetRecord, NotatedTargetRecord):
            raise GRANTA_Exception('NotatedTargetedSourceRecord.AddTargetRecord','_notatedTargetRecord: Invalid argument type _notatedTargetRecord must be of type NotatedTargetRecord')
        NotatedTargetedSourceRecord_AddTargetRecord = self.lib.NotatedTargetedSourceRecord_AddTargetRecord
        NotatedTargetedSourceRecord_AddTargetRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        NotatedTargetedSourceRecord_AddTargetRecord(self._c_obj, _notatedTargetRecord.c_obj)
        return self

    def __ClearTargetRecords(self):
        NotatedTargetedSourceRecord_ClearTargetRecords = self.lib.NotatedTargetedSourceRecord_ClearTargetRecords
        NotatedTargetedSourceRecord_ClearTargetRecords.argtypes = [POINTER(c_void_p)]
        NotatedTargetedSourceRecord_ClearTargetRecords(self._c_obj)
        return self

    def __GetNumberOfTargetRecords(self):
        NotatedTargetedSourceRecord_GetNumberOfTargetRecords = self.lib.NotatedTargetedSourceRecord_GetNumberOfTargetRecords
        NotatedTargetedSourceRecord_GetNumberOfTargetRecords.argtypes = [POINTER(c_void_p)]
        NotatedTargetedSourceRecord_GetNumberOfTargetRecords.restype = c_int
        value = NotatedTargetedSourceRecord_GetNumberOfTargetRecords(self._c_obj)
        return value
    
    def __GetTargetRecordsElement(self,i):
        value = NotatedTargetRecord()
        NotatedTargetedSourceRecord_GetTargetRecords = self.lib.NotatedTargetedSourceRecord_GetTargetRecords
        NotatedTargetedSourceRecord_GetTargetRecords.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        NotatedTargetedSourceRecord_GetTargetRecords(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetTargetRecords(self):
         n = self.__GetNumberOfTargetRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetTargetRecordsElement(i))
         return temp
    
    def __GetSourceRecord(self):
        _recordReference = RecordReference()
        NotatedTargetedSourceRecord_GetSourceRecord = self.lib.NotatedTargetedSourceRecord_GetSourceRecord
        NotatedTargetedSourceRecord_GetSourceRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        NotatedTargetedSourceRecord_GetSourceRecord(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __SetSourceRecord(self, value):

        NotatedTargetedSourceRecord_SetSourceRecord = self.lib.NotatedTargetedSourceRecord_SetSourceRecord 
        NotatedTargetedSourceRecord_SetSourceRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        NotatedTargetedSourceRecord_SetSourceRecord(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


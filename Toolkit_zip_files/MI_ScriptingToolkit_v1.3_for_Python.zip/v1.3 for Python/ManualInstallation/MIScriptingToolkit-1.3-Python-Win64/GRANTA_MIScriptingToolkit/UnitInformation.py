# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class UnitInformation(object):
    """UnitInformation. A type used to give details of units for quantities. 
When this type is output by the Service Layer, both name and symbol will 
be populated. When passed as input to the Service Layer, only name or symbol need to be populated; if both are populated, only the symbol is used.
    
        Arguments:
                * unitSymbol - type str
                * unitName - type str


    """
    
    def __init__(self, unitSymbol=None, unitName=None, isOwner=True):
        """

        Arguments:
                * unitSymbol - type str
                * unitName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            UnitInformation_Create = self.lib.UnitInformation_Create
            UnitInformation_Create.restype = POINTER(c_void_p)
            self.c_obj = UnitInformation_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if unitSymbol is not None:
            self.unitSymbol = unitSymbol
        if unitName is not None:
            self.unitName = unitName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            UnitInformation_Destroy = self.lib.UnitInformation_Destroy
            UnitInformation_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            UnitInformation_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def unitSymbol(self):
        """Property unitSymbol is of type str. """ 
        self._unitSymbol = self.__GetUnitSymbol()
        return self._unitSymbol

    @unitSymbol.setter
    def unitSymbol(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('unitSymbol','unitSymbol: Invalid type unitSymbol must be of type str')
        self.__SetUnitSymbol(value)
        self._unitSymbol = value

    @property
    def unitName(self):
        """Property unitName is of type str. """ 
        self._unitName = self.__GetUnitName()
        return self._unitName

    @unitName.setter
    def unitName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('unitName','unitName: Invalid type unitName must be of type str')
        self.__SetUnitName(value)
        self._unitName = value

    def __GetUnitSymbol(self):
        UnitInformation_GetUnitSymbol = self.lib.UnitInformation_GetUnitSymbol
        UnitInformation_GetUnitSymbol.argtypes = [POINTER(c_void_p)]
        UnitInformation_GetUnitSymbol.restype = POINTER(c_void_p)
        value = UnitInformation_GetUnitSymbol(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetUnitSymbol(self, value):

        UnitInformation_SetUnitSymbol = self.lib.UnitInformation_SetUnitSymbol 
        UnitInformation_SetUnitSymbol.argtypes = [POINTER(c_void_p), c_char_p]
        UnitInformation_SetUnitSymbol(self._c_obj, EnsureEncoded(value))

    def __GetUnitName(self):
        UnitInformation_GetUnitName = self.lib.UnitInformation_GetUnitName
        UnitInformation_GetUnitName.argtypes = [POINTER(c_void_p)]
        UnitInformation_GetUnitName.restype = POINTER(c_void_p)
        value = UnitInformation_GetUnitName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetUnitName(self, value):

        UnitInformation_SetUnitName = self.lib.UnitInformation_SetUnitName 
        UnitInformation_SetUnitName.argtypes = [POINTER(c_void_p), c_char_p]
        UnitInformation_SetUnitName(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse
from GRANTA_MIScriptingToolkit.Exporter import Exporter


class GetAvailableExportersResponse(object):
    """GetAvailableExportersResponse. Output from the GetAvailableExporters operation. Contains a list of exporters.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetAvailableExportersResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetAvailableExportersResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetAvailableExportersResponse_Destroy = self.lib.GetAvailableExportersResponse_Destroy
            GetAvailableExportersResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetAvailableExportersResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def exporters(self):
        """Property exporters is a list of :py:mod:`Exporter <GRANTA_MIScriptingToolkit.Exporter>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._exporters = self.__GetExporters()
        except:
            pass
        return self._exporters

    @exporters.setter
    def exporters(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('exporters','exporters: Invalid type exporters must be a list of Exporter')
        
        self._exporters = value

    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetAvailableExportersResponse_GetServiceLayerResponse = self.lib.GetAvailableExportersResponse_GetServiceLayerResponse
        GetAvailableExportersResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetAvailableExportersResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __GetNumberOfExporters(self):
        GetAvailableExportersResponse_GetNumberOfExporters = self.lib.GetAvailableExportersResponse_GetNumberOfExporters
        GetAvailableExportersResponse_GetNumberOfExporters.argtypes = [POINTER(c_void_p)]
        GetAvailableExportersResponse_GetNumberOfExporters.restype = c_int
        value = GetAvailableExportersResponse_GetNumberOfExporters(self._c_obj)
        return value
    
    def __GetExporterElement(self,i):
        value = Exporter()
        GetAvailableExportersResponse_GetExporter = self.lib.GetAvailableExportersResponse_GetExporter
        GetAvailableExportersResponse_GetExporter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetAvailableExportersResponse_GetExporter(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetExporters(self):
         n = self.__GetNumberOfExporters();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetExporterElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


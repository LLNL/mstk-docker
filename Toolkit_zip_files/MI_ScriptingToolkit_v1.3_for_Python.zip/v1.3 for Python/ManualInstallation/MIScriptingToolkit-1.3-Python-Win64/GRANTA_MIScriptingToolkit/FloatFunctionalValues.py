# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.FloatFunctionalPointValue import FloatFunctionalPointValue
from GRANTA_MIScriptingToolkit.FloatFunctionalRangeValue import FloatFunctionalRangeValue


class FloatFunctionalValues(object):
    """FloatFunctionalValues. A collection of :py:mod:`FloatFunctionalPointValue <GRANTA_MIScriptingToolkit.FloatFunctionalPointValue>` and :py:mod:`FloatFunctionalRangeValue <GRANTA_MIScriptingToolkit.FloatFunctionalRangeValue>` objects.
    
        Arguments:
                * valueType - type str
                * rangeValues - type list of :py:mod:`FloatFunctionalRangeValue <GRANTA_MIScriptingToolkit.FloatFunctionalRangeValue>` objects
                * pointValues - type list of :py:mod:`FloatFunctionalPointValue <GRANTA_MIScriptingToolkit.FloatFunctionalPointValue>` objects


    """
    
    def __init__(self, valueType=None, rangeValues=None, pointValues=None, isOwner=True):
        """

        Arguments:
                * valueType - type str
                * rangeValues - type list of :py:mod:`FloatFunctionalRangeValue <GRANTA_MIScriptingToolkit.FloatFunctionalRangeValue>` objects
                * pointValues - type list of :py:mod:`FloatFunctionalPointValue <GRANTA_MIScriptingToolkit.FloatFunctionalPointValue>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            FloatFunctionalValues_Create = self.lib.FloatFunctionalValues_Create
            FloatFunctionalValues_Create.restype = POINTER(c_void_p)
            self.c_obj = FloatFunctionalValues_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if valueType is not None:
            self.valueType = valueType
        if rangeValues is not None:
            self.rangeValues = rangeValues
        if pointValues is not None:
            self.pointValues = pointValues


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            FloatFunctionalValues_Destroy = self.lib.FloatFunctionalValues_Destroy
            FloatFunctionalValues_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            FloatFunctionalValues_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def valueType(self):
        """Property valueType is of type str. """ 
        self._valueType = self.__GetValueType()
        return self._valueType

    @valueType.setter
    def valueType(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('valueType','valueType: Invalid type valueType must be of type str')
        
        self._valueType = value

    @property
    def rangeValues(self):
        """Property rangeValues is a :py:mod:`FloatFunctionalRangeValue <GRANTA_MIScriptingToolkit.FloatFunctionalRangeValue>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._rangeValues = self.__GetRangeValues()
        except:
            pass
        return self._rangeValues

    @rangeValues.setter
    def rangeValues(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('rangeValues','rangeValues: Invalid type rangeValues must be a list of FloatFunctionalRangeValue')
                
        try:
            self.__updaterangeValues = True
            self.__ClearRangeValues()
            for v in value:
                self.AddRangeValue(v)
        except:
            pass


    @property
    def pointValues(self):
        """Property pointValues is a :py:mod:`FloatFunctionalPointValue <GRANTA_MIScriptingToolkit.FloatFunctionalPointValue>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._pointValues = self.__GetPointValues()
        except:
            pass
        return self._pointValues

    @pointValues.setter
    def pointValues(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('pointValues','pointValues: Invalid type pointValues must be a list of FloatFunctionalPointValue')
                
        try:
            self.__updatepointValues = True
            self.__ClearPointValues()
            for v in value:
                self.AddPointValue(v)
        except:
            pass


    def __GetValueType(self):
        FloatFunctionalValues_GetValueType = self.lib.FloatFunctionalValues_GetValueType
        FloatFunctionalValues_GetValueType.argtypes = [POINTER(c_void_p)]
        FloatFunctionalValues_GetValueType.restype = POINTER(c_void_p)
        value = FloatFunctionalValues_GetValueType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetPointValueElement(self,i):
        value = FloatFunctionalPointValue()
        FloatFunctionalValues_GetPointValue = self.lib.FloatFunctionalValues_GetPointValue
        FloatFunctionalValues_GetPointValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        FloatFunctionalValues_GetPointValue(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetPointValues(self):
         n = self.__GetNumberOfPointValues();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetPointValueElement(i))
         return temp
    
    def __GetRangeValueElement(self,i):
        value = FloatFunctionalRangeValue()
        FloatFunctionalValues_GetRangeValue = self.lib.FloatFunctionalValues_GetRangeValue
        FloatFunctionalValues_GetRangeValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        FloatFunctionalValues_GetRangeValue(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRangeValues(self):
         n = self.__GetNumberOfRangeValues();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRangeValueElement(i))
         return temp
    
    def AddPointValue(self, _floatFunctionalPointValue):
        """Appends _floatFunctionalPointValue to pointValues property on FloatFunctionalValues C-object.

           Arguments:
                _floatFunctionalPointValue - object of type FloatFunctionalPointValue.
        """

        if not isinstance(_floatFunctionalPointValue, FloatFunctionalPointValue):
            raise GRANTA_Exception('FloatFunctionalValues.AddPointValue','_floatFunctionalPointValue: Invalid argument type _floatFunctionalPointValue must be of type FloatFunctionalPointValue')
        FloatFunctionalValues_AddPointValue = self.lib.FloatFunctionalValues_AddPointValue
        FloatFunctionalValues_AddPointValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalValues_AddPointValue(self._c_obj, _floatFunctionalPointValue.c_obj)
        return self

    def AddRangeValue(self, _floatFunctionalRangeValue):
        """Appends _floatFunctionalRangeValue to rangeValues property on FloatFunctionalValues C-object.

           Arguments:
                _floatFunctionalRangeValue - object of type FloatFunctionalRangeValue.
        """

        if not isinstance(_floatFunctionalRangeValue, FloatFunctionalRangeValue):
            raise GRANTA_Exception('FloatFunctionalValues.AddRangeValue','_floatFunctionalRangeValue: Invalid argument type _floatFunctionalRangeValue must be of type FloatFunctionalRangeValue')
        FloatFunctionalValues_AddRangeValue = self.lib.FloatFunctionalValues_AddRangeValue
        FloatFunctionalValues_AddRangeValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalValues_AddRangeValue(self._c_obj, _floatFunctionalRangeValue.c_obj)
        return self

    def __ClearPointValues(self):
        FloatFunctionalValues_ClearPointValues = self.lib.FloatFunctionalValues_ClearPointValues
        FloatFunctionalValues_ClearPointValues.argtypes = [POINTER(c_void_p)]
        FloatFunctionalValues_ClearPointValues(self._c_obj)
        return self

    def __ClearRangeValues(self):
        FloatFunctionalValues_ClearRangeValues = self.lib.FloatFunctionalValues_ClearRangeValues
        FloatFunctionalValues_ClearRangeValues.argtypes = [POINTER(c_void_p)]
        FloatFunctionalValues_ClearRangeValues(self._c_obj)
        return self

    def __GetNumberOfPointValues(self):
        FloatFunctionalValues_GetNumberOfPointValues = self.lib.FloatFunctionalValues_GetNumberOfPointValues
        FloatFunctionalValues_GetNumberOfPointValues.argtypes = [POINTER(c_void_p)]
        FloatFunctionalValues_GetNumberOfPointValues.restype = c_int
        value = FloatFunctionalValues_GetNumberOfPointValues(self._c_obj)
        return value
    
    def __GetNumberOfRangeValues(self):
        FloatFunctionalValues_GetNumberOfRangeValues = self.lib.FloatFunctionalValues_GetNumberOfRangeValues
        FloatFunctionalValues_GetNumberOfRangeValues.argtypes = [POINTER(c_void_p)]
        FloatFunctionalValues_GetNumberOfRangeValues.restype = c_int
        value = FloatFunctionalValues_GetNumberOfRangeValues(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


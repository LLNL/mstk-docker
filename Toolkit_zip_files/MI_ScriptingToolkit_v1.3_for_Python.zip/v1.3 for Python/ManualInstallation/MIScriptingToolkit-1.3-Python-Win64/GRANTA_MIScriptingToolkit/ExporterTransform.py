# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class ExporterTransform(object):
    """ExporterTransform. Contains a type and an ID for an :py:mod:`Exporter <GRANTA_MIScriptingToolkit.Exporter>` Transform
    
        Arguments:
                * type - type int
                * Id - type str


    """
    class Type:
        Unknown = 0
        XSLT = 1
    
    def __init__(self, type=None, Id=None, isOwner=True):
        """

        Arguments:
                * type - type int
                * Id - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ExporterTransform_Create = self.lib.ExporterTransform_Create
            ExporterTransform_Create.restype = POINTER(c_void_p)
            self.c_obj = ExporterTransform_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if type is not None:
            self.type = type
        if Id is not None:
            self.Id = Id


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ExporterTransform_Destroy = self.lib.ExporterTransform_Destroy
            ExporterTransform_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ExporterTransform_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def type(self):
        """Property type is of type int. See :py:class:`ExporterTransform.Type <ExporterTransform.Type>` for supported values.""" 
        self._type = self.__GetType()
        return self._type

    @type.setter
    def type(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('type','type: Invalid type type must be of type int')
        
        self._type = value

    @property
    def Id(self):
        """Property Id is of type str. """ 
        self._Id = self.__GetId()
        return self._Id

    @Id.setter
    def Id(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('Id','Id: Invalid type Id must be of type str')
        
        self._Id = value

    def __GetType(self):
        ExporterTransform_GetType = self.lib.ExporterTransform_GetType
        ExporterTransform_GetType.argtypes = [POINTER(c_void_p)]
        ExporterTransform_GetType.restype = c_int
        value = ExporterTransform_GetType(self._c_obj)
        return value
    
    def __GetId(self):
        ExporterTransform_GetId = self.lib.ExporterTransform_GetId
        ExporterTransform_GetId.argtypes = [POINTER(c_void_p)]
        ExporterTransform_GetId.restype = POINTER(c_void_p)
        value = ExporterTransform_GetId(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


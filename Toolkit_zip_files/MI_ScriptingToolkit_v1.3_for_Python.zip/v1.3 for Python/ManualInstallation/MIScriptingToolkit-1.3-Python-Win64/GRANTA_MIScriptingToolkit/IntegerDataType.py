# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs


from .IDataValue import IDataValue


class IntegerDataType(IDataValue):
    """IntegerDataType. A type to contain an integer data type.
    
        Arguments:
                * value - type int


    """
    
    def __init__(self, value=None, isOwner=True):
        """

        Arguments:
                * value - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            IntegerDataType_Create = self.lib.IntegerDataType_Create
            IntegerDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = IntegerDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if value is not None:
            self.value = value


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            IntegerDataType_Destroy = self.lib.IntegerDataType_Destroy
            IntegerDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            IntegerDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def value(self):
        """Property value is of type int. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('value','value: Invalid type value must be of type int')
        self.__SetValue(value)
        self._value = value

    def __SetValue(self, value):

        IntegerDataType_SetValue = self.lib.IntegerDataType_SetValue 
        IntegerDataType_SetValue.argtypes = [POINTER(c_void_p), c_int]
        IntegerDataType_SetValue(self._c_obj, value)

    def __GetValue(self):
        IntegerDataType_GetValue = self.lib.IntegerDataType_GetValue
        IntegerDataType_GetValue.argtypes = [POINTER(c_void_p)]
        IntegerDataType_GetValue.restype = c_int
        value = IntegerDataType_GetValue(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


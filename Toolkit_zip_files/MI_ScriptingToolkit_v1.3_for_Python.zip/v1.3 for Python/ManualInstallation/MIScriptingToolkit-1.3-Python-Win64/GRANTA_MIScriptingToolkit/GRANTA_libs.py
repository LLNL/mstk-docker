from ctypes import *
import os
dir = os.path.dirname(__file__)
gdlCoreLib = cdll.LoadLibrary(dir+'\\CLibs\\gdlCore.dll')
gdlCryptoLib = cdll.LoadLibrary(dir+'\\CLibs\\gdlCrypto.dll')
gdlHttpLib = cdll.LoadLibrary(dir+'\\CLibs\\gdlHttp.dll')
gdlHttpLibClient = cdll.LoadLibrary(dir+'\\CLibs\\gdlHttpClient.dll')
gdlXMLLib = cdll.LoadLibrary(dir+'\\CLibs\\gdlXML.dll')
MIServiceLayerWrapperLib = cdll.LoadLibrary(dir+'\\CLibs\\gdltkMIServiceLayer.dll')
MIServiceLayerCAPILib = cdll.LoadLibrary(dir+'\\CLibs\\MIServiceLayerCAPI.dll')
# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.NamedTargetedSourceRecord import NamedTargetedSourceRecord


class RecordLinkChanges(object):
    """RecordLinkChanges. A set of changes to be made to record link groups
    
        Arguments:
                * unlinked - type list of :py:mod:`NamedTargetedSourceRecord <GRANTA_MIScriptingToolkit.NamedTargetedSourceRecord>` objects
                * linked - type list of :py:mod:`NamedTargetedSourceRecord <GRANTA_MIScriptingToolkit.NamedTargetedSourceRecord>` objects


    """
    
    def __init__(self, unlinked=None, linked=None, isOwner=True):
        """

        Arguments:
                * unlinked - type list of :py:mod:`NamedTargetedSourceRecord <GRANTA_MIScriptingToolkit.NamedTargetedSourceRecord>` objects
                * linked - type list of :py:mod:`NamedTargetedSourceRecord <GRANTA_MIScriptingToolkit.NamedTargetedSourceRecord>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordLinkChanges_Create = self.lib.RecordLinkChanges_Create
            RecordLinkChanges_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordLinkChanges_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if unlinked is not None:
            self.unlinked = unlinked
        if linked is not None:
            self.linked = linked


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordLinkChanges_Destroy = self.lib.RecordLinkChanges_Destroy
            RecordLinkChanges_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordLinkChanges_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def unlinked(self):
        """Property unlinked is a list of :py:mod:`NamedTargetedSourceRecord <GRANTA_MIScriptingToolkit.NamedTargetedSourceRecord>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._unlinked = self.__GetUnlinked()
        except:
            pass
        return self._unlinked

    @unlinked.setter
    def unlinked(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('unlinked','unlinked: Invalid type unlinked must be a list of NamedTargetedSourceRecord')
        
        self._unlinked = value

    @property
    def linked(self):
        """Property linked is a list of :py:mod:`NamedTargetedSourceRecord <GRANTA_MIScriptingToolkit.NamedTargetedSourceRecord>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._linked = self.__GetLinked()
        except:
            pass
        return self._linked

    @linked.setter
    def linked(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('linked','linked: Invalid type linked must be a list of NamedTargetedSourceRecord')
        
        self._linked = value

    def __GetNumberOfLinked(self):
        RecordLinkChanges_GetNumberOfLinked = self.lib.RecordLinkChanges_GetNumberOfLinked
        RecordLinkChanges_GetNumberOfLinked.argtypes = [POINTER(c_void_p)]
        RecordLinkChanges_GetNumberOfLinked.restype = c_int
        value = RecordLinkChanges_GetNumberOfLinked(self._c_obj)
        return value
    
    def __GetLinkedElement(self,i):
        value = NamedTargetedSourceRecord()
        RecordLinkChanges_GetLinked = self.lib.RecordLinkChanges_GetLinked
        RecordLinkChanges_GetLinked.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordLinkChanges_GetLinked(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetLinked(self):
         n = self.__GetNumberOfLinked();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetLinkedElement(i))
         return temp
    
    def __GetNumberOfUnlinked(self):
        RecordLinkChanges_GetNumberOfUnlinked = self.lib.RecordLinkChanges_GetNumberOfUnlinked
        RecordLinkChanges_GetNumberOfUnlinked.argtypes = [POINTER(c_void_p)]
        RecordLinkChanges_GetNumberOfUnlinked.restype = c_int
        value = RecordLinkChanges_GetNumberOfUnlinked(self._c_obj)
        return value
    
    def __GetUnlinkedElement(self,i):
        value = NamedTargetedSourceRecord()
        RecordLinkChanges_GetUnlinked = self.lib.RecordLinkChanges_GetUnlinked
        RecordLinkChanges_GetUnlinked.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordLinkChanges_GetUnlinked(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetUnlinked(self):
         n = self.__GetNumberOfUnlinked();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetUnlinkedElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


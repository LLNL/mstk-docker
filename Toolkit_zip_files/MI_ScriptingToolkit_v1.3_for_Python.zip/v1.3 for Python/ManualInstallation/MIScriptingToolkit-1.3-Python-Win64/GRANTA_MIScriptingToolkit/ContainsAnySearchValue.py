# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class ContainsAnySearchValue(object):
    """ContainsAnySearchValue. Search criterion to search for discrete data types that contain any of the specified search values. 
This criterion type is specific to discrete attributes.
    
        Arguments:
                * values - type list of str objects


    """
    
    def __init__(self, values=None, isOwner=True):
        """

        Arguments:
                * values - type list of str objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ContainsAnySearchValue_Create = self.lib.ContainsAnySearchValue_Create
            ContainsAnySearchValue_Create.restype = POINTER(c_void_p)
            self.c_obj = ContainsAnySearchValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if values is not None:
            self.values = values


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ContainsAnySearchValue_Destroy = self.lib.ContainsAnySearchValue_Destroy
            ContainsAnySearchValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ContainsAnySearchValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def values(self):
        """Property values is of type list of str. """ 
        try:
            return self._values
        except:
            return None

    @values.setter
    def values(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('values','values: Invalid type values must be a list of str')
                
        try:
            self.__updatevalues = True
            self.__ClearValues()
            for v in value:
                self.AddValue(v)
        except:
            pass


    def AddValue(self, value):
        """Appends value to values property on ContainsAnySearchValue C-object.

           Arguments:
                value - object of type Defs.string_types.
        """

        ContainsAnySearchValue_AddValue = self.lib.ContainsAnySearchValue_AddValue
        ContainsAnySearchValue_AddValue.argtypes = [POINTER(c_void_p), c_char_p]
        ContainsAnySearchValue_AddValue(self._c_obj, value.encode('utf-8'))
        return self

    def __ClearValues(self):
        ContainsAnySearchValue_ClearValues = self.lib.ContainsAnySearchValue_ClearValues
        ContainsAnySearchValue_ClearValues.argtypes = [POINTER(c_void_p)]
        ContainsAnySearchValue_ClearValues(self._c_obj)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.MIDatabase import MIDatabase
from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse


class GetDatabasesResponse(object):
    """GetDatabasesResponse. Output from the GetDatabases operation.
Includes an array of :py:mod:`MIDatabase <GRANTA_MIScriptingToolkit.MIDatabase>` objects and a :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>` object.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetDatabasesResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetDatabasesResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetDatabasesResponse_Destroy = self.lib.GetDatabasesResponse_Destroy
            GetDatabasesResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetDatabasesResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    @property
    def databases(self):
        """Property databases is a list of :py:mod:`MIDatabase <GRANTA_MIScriptingToolkit.MIDatabase>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._databases = self.__GetDatabases()
        except:
            pass
        return self._databases

    @databases.setter
    def databases(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('databases','databases: Invalid type databases must be a list of MIDatabase')
                
        try:
            self.__updatedatabases = True
            self.__ClearDatabases()
            for v in value:
                self.AddDatabase(v)
        except:
            pass


    def AddDatabase(self, _MIDatabase):
        """Appends _MIDatabase to databases property on GetDatabasesResponse C-object.

           Arguments:
                _MIDatabase - object of type MIDatabase.
        """

        if not isinstance(_MIDatabase, MIDatabase):
            raise GRANTA_Exception('GetDatabasesResponse.AddDatabase','_MIDatabase: Invalid argument type _MIDatabase must be of type MIDatabase')
        GetDatabasesResponse_AddDatabase = self.lib.GetDatabasesResponse_AddDatabase
        GetDatabasesResponse_AddDatabase.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetDatabasesResponse_AddDatabase(self._c_obj, _MIDatabase.c_obj)
        return self

    def __ClearDatabases(self):
        GetDatabasesResponse_ClearDatabases = self.lib.GetDatabasesResponse_ClearDatabases
        GetDatabasesResponse_ClearDatabases.argtypes = [POINTER(c_void_p)]
        GetDatabasesResponse_ClearDatabases(self._c_obj)
        return self

    def __GetNumberOfDatabases(self):
        GetDatabasesResponse_GetNumberOfDatabases = self.lib.GetDatabasesResponse_GetNumberOfDatabases
        GetDatabasesResponse_GetNumberOfDatabases.argtypes = [POINTER(c_void_p)]
        GetDatabasesResponse_GetNumberOfDatabases.restype = c_int
        value = GetDatabasesResponse_GetNumberOfDatabases(self._c_obj)
        return value
    
    def __GetDatabaseElement(self,i):
        value = MIDatabase()
        GetDatabasesResponse_GetDatabase = self.lib.GetDatabasesResponse_GetDatabase
        GetDatabasesResponse_GetDatabase.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetDatabasesResponse_GetDatabase(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetDatabases(self):
         n = self.__GetNumberOfDatabases();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetDatabaseElement(i))
         return temp
    
    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetDatabasesResponse_GetServiceLayerResponse = self.lib.GetDatabasesResponse_GetServiceLayerResponse
        GetDatabasesResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetDatabasesResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ExporterTransform import ExporterTransform


class Exporter(object):
    """Exporter. Details of a particular FEA Exporter configuration, typically obtained from an Exporter Configuration File (EXP file) on the MI Server.
    
        Arguments:
                * name - type str
                * package - type str
                * validatedOk - type bool
                * version - type int
                * transforms - type list of :py:mod:`ExporterTransform <GRANTA_MIScriptingToolkit.ExporterTransform>` objects
                * key - type str
                * model - type str
                * description - type str


    """
    
    def __init__(self, name=None, package=None, validatedOk=None, version=None, transforms=None, key=None, model=None, description=None, isOwner=True):
        """

        Arguments:
                * name - type str
                * package - type str
                * validatedOk - type bool
                * version - type int
                * transforms - type list of :py:mod:`ExporterTransform <GRANTA_MIScriptingToolkit.ExporterTransform>` objects
                * key - type str
                * model - type str
                * description - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            Exporter_Create = self.lib.Exporter_Create
            Exporter_Create.restype = POINTER(c_void_p)
            self.c_obj = Exporter_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if name is not None:
            self.name = name
        if package is not None:
            self.package = package
        if validatedOk is not None:
            self.validatedOk = validatedOk
        if version is not None:
            self.version = version
        if transforms is not None:
            self.transforms = transforms
        if key is not None:
            self.key = key
        if model is not None:
            self.model = model
        if description is not None:
            self.description = description


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            Exporter_Destroy = self.lib.Exporter_Destroy
            Exporter_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            Exporter_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        
        self._name = value

    @property
    def package(self):
        """Property package is of type str. """ 
        self._package = self.__GetPackage()
        return self._package

    @package.setter
    def package(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('package','package: Invalid type package must be of type str')
        
        self._package = value

    @property
    def validatedOk(self):
        """Property validatedOk is of type bool. """ 
        self._validatedOk = self.__GetValidatedOk()
        return self._validatedOk

    @validatedOk.setter
    def validatedOk(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('validatedOk','validatedOk: Invalid type validatedOk must be of type bool')
        
        self._validatedOk = value

    @property
    def version(self):
        """Property version is of type int. """ 
        self._version = self.__GetVersion()
        return self._version

    @version.setter
    def version(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('version','version: Invalid type version must be of type int')
        
        self._version = value

    @property
    def transforms(self):
        """Property transforms is a list of :py:mod:`ExporterTransform <GRANTA_MIScriptingToolkit.ExporterTransform>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._transforms = self.__GetTransforms()
        except:
            pass
        return self._transforms

    @transforms.setter
    def transforms(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('transforms','transforms: Invalid type transforms must be a list of ExporterTransform')
        
        self._transforms = value

    @property
    def key(self):
        """Property key is of type str. The key that uniquely identifies this Exporter. This value is generated by the MI Server at runtime and may change between runs.""" 
        self._key = self.__GetKey()
        return self._key

    @key.setter
    def key(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('key','key: Invalid type key must be of type str')
        
        self._key = value

    @property
    def model(self):
        """Property model is of type str. """ 
        self._model = self.__GetModel()
        return self._model

    @model.setter
    def model(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('model','model: Invalid type model must be of type str')
        
        self._model = value

    @property
    def description(self):
        """Property description is of type str. """ 
        self._description = self.__GetDescription()
        return self._description

    @description.setter
    def description(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('description','description: Invalid type description must be of type str')
        
        self._description = value

    def __GetKey(self):
        Exporter_GetKey = self.lib.Exporter_GetKey
        Exporter_GetKey.argtypes = [POINTER(c_void_p)]
        Exporter_GetKey.restype = POINTER(c_void_p)
        value = Exporter_GetKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetPackage(self):
        Exporter_GetPackage = self.lib.Exporter_GetPackage
        Exporter_GetPackage.argtypes = [POINTER(c_void_p)]
        Exporter_GetPackage.restype = POINTER(c_void_p)
        value = Exporter_GetPackage(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetModel(self):
        Exporter_GetModel = self.lib.Exporter_GetModel
        Exporter_GetModel.argtypes = [POINTER(c_void_p)]
        Exporter_GetModel.restype = POINTER(c_void_p)
        value = Exporter_GetModel(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetDescription(self):
        Exporter_GetDescription = self.lib.Exporter_GetDescription
        Exporter_GetDescription.argtypes = [POINTER(c_void_p)]
        Exporter_GetDescription.restype = POINTER(c_void_p)
        value = Exporter_GetDescription(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetName(self):
        Exporter_GetName = self.lib.Exporter_GetName
        Exporter_GetName.argtypes = [POINTER(c_void_p)]
        Exporter_GetName.restype = POINTER(c_void_p)
        value = Exporter_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetVersion(self):
        Exporter_GetVersion = self.lib.Exporter_GetVersion
        Exporter_GetVersion.argtypes = [POINTER(c_void_p)]
        Exporter_GetVersion.restype = c_int
        value = Exporter_GetVersion(self._c_obj)
        return value
    
    def __GetValidatedOk(self):
        Exporter_GetValidatedOk = self.lib.Exporter_GetValidatedOk
        Exporter_GetValidatedOk.argtypes = [POINTER(c_void_p)]
        Exporter_GetValidatedOk.restype = c_bool
        value = Exporter_GetValidatedOk(self._c_obj)
        return value
    
    def __GetNumberOfTransforms(self):
        Exporter_GetNumberOfTransforms = self.lib.Exporter_GetNumberOfTransforms
        Exporter_GetNumberOfTransforms.argtypes = [POINTER(c_void_p)]
        Exporter_GetNumberOfTransforms.restype = c_int
        value = Exporter_GetNumberOfTransforms(self._c_obj)
        return value
    
    def __GetTransformElement(self,i):
        value = ExporterTransform()
        Exporter_GetTransform = self.lib.Exporter_GetTransform
        Exporter_GetTransform.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        Exporter_GetTransform(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetTransforms(self):
         n = self.__GetNumberOfTransforms();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetTransformElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


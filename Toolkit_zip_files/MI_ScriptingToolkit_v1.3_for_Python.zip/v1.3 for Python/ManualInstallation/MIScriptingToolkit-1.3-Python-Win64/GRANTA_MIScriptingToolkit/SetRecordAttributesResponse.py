# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse
from GRANTA_MIScriptingToolkit.NamedRecord import NamedRecord


class SetRecordAttributesResponse(object):
    """SetRecordAttributesResponse. Response for set record attributes operation. Includes an array of import records.
    
        Arguments:
            c_obj - ctypes.POINTER to a SetRecordAttributesResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a SetRecordAttributesResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            SetRecordAttributesResponse_Destroy = self.lib.SetRecordAttributesResponse_Destroy
            SetRecordAttributesResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            SetRecordAttributesResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    @property
    def recordsImported(self):
        """Property recordsImported is a list of :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordsImported = self.__GetRecordsImported()
        except:
            pass
        return self._recordsImported

    @recordsImported.setter
    def recordsImported(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordsImported','recordsImported: Invalid type recordsImported must be a list of NamedRecord')
        
        self._recordsImported = value

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        SetRecordAttributesResponse_GetServiceLayerResponse = self.lib.SetRecordAttributesResponse_GetServiceLayerResponse
        SetRecordAttributesResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        SetRecordAttributesResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __GetNumberOfRecordsImported(self):
        SetRecordAttributesResponse_GetNumberOfRecordsImported = self.lib.SetRecordAttributesResponse_GetNumberOfRecordsImported
        SetRecordAttributesResponse_GetNumberOfRecordsImported.argtypes = [POINTER(c_void_p)]
        SetRecordAttributesResponse_GetNumberOfRecordsImported.restype = c_int
        value = SetRecordAttributesResponse_GetNumberOfRecordsImported(self._c_obj)
        return value
    
    def __GetRecordsImportedElement(self,i):
        value = NamedRecord()
        SetRecordAttributesResponse_GetRecordsImported = self.lib.SetRecordAttributesResponse_GetRecordsImported
        SetRecordAttributesResponse_GetRecordsImported.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        SetRecordAttributesResponse_GetRecordsImported(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordsImported(self):
         n = self.__GetNumberOfRecordsImported();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordsImportedElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


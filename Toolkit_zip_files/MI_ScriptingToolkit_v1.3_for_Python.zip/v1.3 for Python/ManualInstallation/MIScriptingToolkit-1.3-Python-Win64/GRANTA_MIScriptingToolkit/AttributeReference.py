# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.PartialTableReference import PartialTableReference


class AttributeReference(object):
    """AttributeReference. Identification of a particular attribute in a GRANTA MI database. 
For requests, a DBKey is required and either the attribute ID or the 
attribute name. If the name is not a standard name, then a :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>` is also required.
    
        Arguments:
                * pseudoAttribute - type int
                * isStandardName - type bool
                * name - type str
                * partialTableReference - type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`
                * DBKey - type str
                * attributeID - type int


    """
    class MIPseudoAttributeReference:
        name = 0
        shortName = 1
        releasedDate = 3
        modifiedDate = 4
        recordType = 5
        recordHistoryIdentity = 6
        recordColor = 7
        recordVersionNumber = 12
        tableName = 13
        writable = 16
        parentName = 17
        parentShortName = 18
        parentRecordHistoryIdentity = 19
    
    def __init__(self, pseudoAttribute=None, isStandardName=None, name=None, partialTableReference=None, DBKey=None, attributeID=None, isOwner=True):
        """

        Arguments:
                * pseudoAttribute - type int
                * isStandardName - type bool
                * name - type str
                * partialTableReference - type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`
                * DBKey - type str
                * attributeID - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            AttributeReference_Create = self.lib.AttributeReference_Create
            AttributeReference_Create.restype = POINTER(c_void_p)
            self.c_obj = AttributeReference_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if pseudoAttribute is not None:
            self.pseudoAttribute = pseudoAttribute
        if isStandardName is not None:
            self.isStandardName = isStandardName
        if name is not None:
            self.name = name
        if partialTableReference is not None:
            self.partialTableReference = partialTableReference
        if DBKey is not None:
            self.DBKey = DBKey
        if attributeID is not None:
            self.attributeID = attributeID


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            AttributeReference_Destroy = self.lib.AttributeReference_Destroy
            AttributeReference_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            AttributeReference_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def pseudoAttribute(self):
        """Property pseudoAttribute is of type int. See :py:class:`AttributeReference.MIPseudoAttributeReference <AttributeReference.MIPseudoAttributeReference>` for supported values.""" 
        try:
            return self._pseudoAttribute
        except:
            return None

    @pseudoAttribute.setter
    def pseudoAttribute(self, value):
        """See :py:class:`AttributeReference.MIPseudoAttributeReference <AttributeReference.MIPseudoAttributeReference>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('pseudoAttribute','pseudoAttribute: Invalid type pseudoAttribute must be of type int')
        self.__SetPseudoAttribute(value)
        self._pseudoAttribute = value

    @property
    def isStandardName(self):
        """Property isStandardName is of type bool. """ 
        self._isStandardName = self.__GetIsStandardName()
        return self._isStandardName

    @isStandardName.setter
    def isStandardName(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('isStandardName','isStandardName: Invalid type isStandardName must be of type bool')
        self.__SetIsStandardName(value)
        self._isStandardName = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    @property
    def partialTableReference(self):
        """Property partialTableReference is of type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`. """ 
        self._partialTableReference = self.__GetPartialTableReference()
        return self._partialTableReference

    @partialTableReference.setter
    def partialTableReference(self, value):
        if not isinstance(value, PartialTableReference):
            raise GRANTA_Exception('partialTableReference','partialTableReference: Invalid type partialTableReference must be of type PartialTableReference')
        self.__SetPartialTableReference(value)
        self._partialTableReference = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    @property
    def attributeID(self):
        """Property attributeID is of type int. """ 
        self._attributeID = self.__GetAttributeID()
        return self._attributeID

    @attributeID.setter
    def attributeID(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('attributeID','attributeID: Invalid type attributeID must be of type int')
        self.__SetAttributeID(value)
        self._attributeID = value

    def __GetAttributeID(self):
        AttributeReference_GetAttributeID = self.lib.AttributeReference_GetAttributeID
        AttributeReference_GetAttributeID.argtypes = [POINTER(c_void_p)]
        AttributeReference_GetAttributeID.restype = c_int
        value = AttributeReference_GetAttributeID(self._c_obj)
        return value
    
    def __SetAttributeID(self, value):

        AttributeReference_SetAttributeID = self.lib.AttributeReference_SetAttributeID 
        AttributeReference_SetAttributeID.argtypes = [POINTER(c_void_p), c_int]
        AttributeReference_SetAttributeID(self._c_obj, value)

    def __GetName(self):
        AttributeReference_GetName = self.lib.AttributeReference_GetName
        AttributeReference_GetName.argtypes = [POINTER(c_void_p)]
        AttributeReference_GetName.restype = POINTER(c_void_p)
        value = AttributeReference_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        AttributeReference_SetName = self.lib.AttributeReference_SetName 
        AttributeReference_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        AttributeReference_SetName(self._c_obj, EnsureEncoded(value))

    def __SetPartialTableReference(self, value):

        AttributeReference_SetPartialTableReference = self.lib.AttributeReference_SetPartialTableReference 
        AttributeReference_SetPartialTableReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        AttributeReference_SetPartialTableReference(self._c_obj, value.c_obj)

    def __GetPartialTableReference(self):
        _partialTableReference = PartialTableReference()
        AttributeReference_GetPartialTableReference = self.lib.AttributeReference_GetPartialTableReference
        AttributeReference_GetPartialTableReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeReference_GetPartialTableReference(self._c_obj, (_partialTableReference.c_obj))
        
        return _partialTableReference
        
    def __GetDBKey(self):
        AttributeReference_GetDBKey = self.lib.AttributeReference_GetDBKey
        AttributeReference_GetDBKey.argtypes = [POINTER(c_void_p)]
        AttributeReference_GetDBKey.restype = POINTER(c_void_p)
        value = AttributeReference_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetDBKey(self, value):

        AttributeReference_SetDBKey = self.lib.AttributeReference_SetDBKey 
        AttributeReference_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        AttributeReference_SetDBKey(self._c_obj, EnsureEncoded(value))

    def __SetIsStandardName(self, value):

        AttributeReference_SetIsStandardName = self.lib.AttributeReference_SetIsStandardName 
        AttributeReference_SetIsStandardName.argtypes = [POINTER(c_void_p), c_bool]
        AttributeReference_SetIsStandardName(self._c_obj, value)

    def __SetPseudoAttribute(self, value):
        """See :py:class:`AttributeReference.MIPseudoAttributeReference <AttributeReference.MIPseudoAttributeReference>` for supported values."""

        AttributeReference_SetPseudoAttribute = self.lib.AttributeReference_SetPseudoAttribute 
        AttributeReference_SetPseudoAttribute.argtypes = [POINTER(c_void_p), c_int]
        AttributeReference_SetPseudoAttribute(self._c_obj, value)

    def __GetIsStandardName(self):
        AttributeReference_GetIsStandardName = self.lib.AttributeReference_GetIsStandardName
        AttributeReference_GetIsStandardName.argtypes = [POINTER(c_void_p)]
        AttributeReference_GetIsStandardName.restype = c_bool
        value = AttributeReference_GetIsStandardName(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


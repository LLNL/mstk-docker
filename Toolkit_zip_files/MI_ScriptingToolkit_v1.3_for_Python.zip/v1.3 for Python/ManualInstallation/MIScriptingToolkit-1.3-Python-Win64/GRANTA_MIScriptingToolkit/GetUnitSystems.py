# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class GetUnitSystems(object):
    """GetUnitSystems. A type for requesting the unit systems on a particular GRANTA MI database.
A DBKey must be specified. 
    
        Arguments:
                * excludeCurrencies - type bool
                * DBKey - type str


    """
    
    def __init__(self, excludeCurrencies=None, DBKey=None, isOwner=True):
        """

        Arguments:
                * excludeCurrencies - type bool
                * DBKey - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetUnitSystems_Create = self.lib.GetUnitSystems_Create
            GetUnitSystems_Create.restype = POINTER(c_void_p)
            self.c_obj = GetUnitSystems_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if excludeCurrencies is not None:
            self.excludeCurrencies = excludeCurrencies
        if DBKey is not None:
            self.DBKey = DBKey


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetUnitSystems_Destroy = self.lib.GetUnitSystems_Destroy
            GetUnitSystems_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetUnitSystems_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def excludeCurrencies(self):
        """Property excludeCurrencies is of type bool. """ 
        self._excludeCurrencies = self.__GetExcludeCurrencies()
        return self._excludeCurrencies

    @excludeCurrencies.setter
    def excludeCurrencies(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('excludeCurrencies','excludeCurrencies: Invalid type excludeCurrencies must be of type bool')
        self.__SetExcludeCurrencies(value)
        self._excludeCurrencies = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    def __SetDBKey(self, value):

        GetUnitSystems_SetDBKey = self.lib.GetUnitSystems_SetDBKey 
        GetUnitSystems_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        GetUnitSystems_SetDBKey(self._c_obj, EnsureEncoded(value))

    def __GetDBKey(self):
        GetUnitSystems_GetDBKey = self.lib.GetUnitSystems_GetDBKey
        GetUnitSystems_GetDBKey.argtypes = [POINTER(c_void_p)]
        GetUnitSystems_GetDBKey.restype = POINTER(c_void_p)
        value = GetUnitSystems_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetExcludeCurrencies(self):
        GetUnitSystems_GetExcludeCurrencies = self.lib.GetUnitSystems_GetExcludeCurrencies
        GetUnitSystems_GetExcludeCurrencies.argtypes = [POINTER(c_void_p)]
        GetUnitSystems_GetExcludeCurrencies.restype = c_bool
        value = GetUnitSystems_GetExcludeCurrencies(self._c_obj)
        return value
    
    def __SetExcludeCurrencies(self, value):

        GetUnitSystems_SetExcludeCurrencies = self.lib.GetUnitSystems_SetExcludeCurrencies 
        GetUnitSystems_SetExcludeCurrencies.argtypes = [POINTER(c_void_p), c_bool]
        GetUnitSystems_SetExcludeCurrencies(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


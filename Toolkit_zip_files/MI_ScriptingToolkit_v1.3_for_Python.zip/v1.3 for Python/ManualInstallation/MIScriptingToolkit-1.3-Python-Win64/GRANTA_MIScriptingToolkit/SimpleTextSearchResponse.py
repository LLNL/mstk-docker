# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.SearchResult import SearchResult
from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse


class SimpleTextSearchResponse(object):
    """SimpleTextSearchResponse. The output to the simple text search operation.
Contains a list of records returned by the search and a :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>` object.
    
        Arguments:
            c_obj - ctypes.POINTER to a SimpleTextSearchResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a SimpleTextSearchResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            SimpleTextSearchResponse_Destroy = self.lib.SimpleTextSearchResponse_Destroy
            SimpleTextSearchResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            SimpleTextSearchResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def searchResults(self):
        """Property searchResults is a list of :py:mod:`SearchResult <GRANTA_MIScriptingToolkit.SearchResult>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._searchResults = self.__GetSearchResults()
        except:
            pass
        return self._searchResults

    @searchResults.setter
    def searchResults(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('searchResults','searchResults: Invalid type searchResults must be a list of SearchResult')
                
        try:
            self.__updatesearchResults = True
            self.__ClearSearchResults()
            for v in value:
                self.AddSearchResult(v)
        except:
            pass


    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    def AddSearchResult(self, _searchResult):
        """Appends _searchResult to searchResults property on SimpleTextSearchResponse C-object.

           Arguments:
                _searchResult - object of type SearchResult.
        """

        if not isinstance(_searchResult, SearchResult):
            raise GRANTA_Exception('SimpleTextSearchResponse.AddSearchResult','_searchResult: Invalid argument type _searchResult must be of type SearchResult')
        SimpleTextSearchResponse_AddSearchResult = self.lib.SimpleTextSearchResponse_AddSearchResult
        SimpleTextSearchResponse_AddSearchResult.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        SimpleTextSearchResponse_AddSearchResult(self._c_obj, _searchResult.c_obj)
        return self

    def __ClearSearchResults(self):
        SimpleTextSearchResponse_ClearSearchResults = self.lib.SimpleTextSearchResponse_ClearSearchResults
        SimpleTextSearchResponse_ClearSearchResults.argtypes = [POINTER(c_void_p)]
        SimpleTextSearchResponse_ClearSearchResults(self._c_obj)
        return self

    def __GetNumberOfSearchResults(self):
        SimpleTextSearchResponse_GetNumberOfSearchResults = self.lib.SimpleTextSearchResponse_GetNumberOfSearchResults
        SimpleTextSearchResponse_GetNumberOfSearchResults.argtypes = [POINTER(c_void_p)]
        SimpleTextSearchResponse_GetNumberOfSearchResults.restype = c_int
        value = SimpleTextSearchResponse_GetNumberOfSearchResults(self._c_obj)
        return value
    
    def __GetSearchResultsElement(self,i):
        value = SearchResult()
        SimpleTextSearchResponse_GetSearchResults = self.lib.SimpleTextSearchResponse_GetSearchResults
        SimpleTextSearchResponse_GetSearchResults.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        SimpleTextSearchResponse_GetSearchResults(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetSearchResults(self):
         n = self.__GetNumberOfSearchResults();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetSearchResultsElement(i))
         return temp
    
    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        SimpleTextSearchResponse_GetServiceLayerResponse = self.lib.SimpleTextSearchResponse_GetServiceLayerResponse
        SimpleTextSearchResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        SimpleTextSearchResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


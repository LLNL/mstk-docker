# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class BetweenDateTimesSearchValue(object):
    """BetweenDateTimesSearchValue. Search criterion to search for data between two times. 
This criterion type is specific to DateTime Attributes. Both a LowEnd and 
a HighEnd value are required. The date format is in XSD's dateTime data type (YYYY-MM-DDThh:mm:ss).
    
        Arguments:
                * lowEnd - type str
                * highEnd - type str


    """
    
    def __init__(self, lowEnd=None, highEnd=None, isOwner=True):
        """

        Arguments:
                * lowEnd - type str
                * highEnd - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            BetweenDateTimesSearchValue_Create = self.lib.BetweenDateTimesSearchValue_Create
            BetweenDateTimesSearchValue_Create.restype = POINTER(c_void_p)
            self.c_obj = BetweenDateTimesSearchValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if lowEnd is not None:
            self.lowEnd = lowEnd
        if highEnd is not None:
            self.highEnd = highEnd


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            BetweenDateTimesSearchValue_Destroy = self.lib.BetweenDateTimesSearchValue_Destroy
            BetweenDateTimesSearchValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            BetweenDateTimesSearchValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def lowEnd(self):
        """Property lowEnd is of type str. """ 
        self._lowEnd = self.__GetLowEnd()
        return self._lowEnd

    @lowEnd.setter
    def lowEnd(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('lowEnd','lowEnd: Invalid type lowEnd must be of type str')
        self.__SetLowEnd(value)
        self._lowEnd = value

    @property
    def highEnd(self):
        """Property highEnd is of type str. """ 
        self._highEnd = self.__GetHighEnd()
        return self._highEnd

    @highEnd.setter
    def highEnd(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('highEnd','highEnd: Invalid type highEnd must be of type str')
        self.__SetHighEnd(value)
        self._highEnd = value

    def __GetLowEnd(self):
        BetweenDateTimesSearchValue_GetLowEnd = self.lib.BetweenDateTimesSearchValue_GetLowEnd
        BetweenDateTimesSearchValue_GetLowEnd.argtypes = [POINTER(c_void_p)]
        BetweenDateTimesSearchValue_GetLowEnd.restype = POINTER(c_void_p)
        value = BetweenDateTimesSearchValue_GetLowEnd(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetLowEnd(self, value):

        BetweenDateTimesSearchValue_SetLowEnd = self.lib.BetweenDateTimesSearchValue_SetLowEnd 
        BetweenDateTimesSearchValue_SetLowEnd.argtypes = [POINTER(c_void_p), c_char_p]
        BetweenDateTimesSearchValue_SetLowEnd(self._c_obj, EnsureEncoded(value))

    def __GetHighEnd(self):
        BetweenDateTimesSearchValue_GetHighEnd = self.lib.BetweenDateTimesSearchValue_GetHighEnd
        BetweenDateTimesSearchValue_GetHighEnd.argtypes = [POINTER(c_void_p)]
        BetweenDateTimesSearchValue_GetHighEnd.restype = POINTER(c_void_p)
        value = BetweenDateTimesSearchValue_GetHighEnd(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetHighEnd(self, value):

        BetweenDateTimesSearchValue_SetHighEnd = self.lib.BetweenDateTimesSearchValue_SetHighEnd 
        BetweenDateTimesSearchValue_SetHighEnd.argtypes = [POINTER(c_void_p), c_char_p]
        BetweenDateTimesSearchValue_SetHighEnd(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value



from ctypes import POINTER
from ctypes import c_void_p
from ctypes import c_int
from ctypes import c_char_p
from ctypes import c_bool
from ctypes import c_double
from GRANTA_MIScriptingToolkit import GRANTA_libs


class MIEntityReference(object):
    """ A base type for types that identify entities in a GRANTA MI Database. The details of how entities are identified differ between concrete sub-types. 

You should not interact directly with this class. """
    def __init__(self):
        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        MIEntityReference_Create = self.lib.MIEntityReference_Create
        MIEntityReference_Create.restype = POINTER(c_void_p)
        self.c_obj = MIEntityReference_Create()

    
    def __del__(self):
        MIEntityReference_Destroy = self.lib.MIEntityReference_Destroy
        MIEntityReference_Destroy.argtypes = [POINTER(c_void_p)]
        MIEntityReference_Destroy(self.c_obj)
    
    
    def GetDBKey(self):
        MIEntityReference_GetDBKey = self.lib.MIEntityReference_GetDBKey
        MIEntityReference_GetDBKey.argtypes = [POINTER(c_void_p)]
        MIEntityReference_GetDBKey.restype = c_char_p
        value = MIEntityReference_GetDBKey(self.c_obj)
        return value;
    
    def WithDBKey(self, value):
        MIEntityReference_SetDBKey = self.lib.MIEntityReference_SetDBKey 
        MIEntityReference_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        MIEntityReference_SetDBKey(self.c_obj, value)
        return self


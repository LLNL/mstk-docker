# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordLinkGroupReference import RecordLinkGroupReference


class GetRecordLinkGroups(object):
    """GetRecordLinkGroups. Returns details of Record Link Groups in a GRANTA MI Database.
    
        Arguments:
                * standardNamesOnly - type bool
                * recordLinkGroups - type list of :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>` objects
                * DBKey - type str


    """
    
    def __init__(self, standardNamesOnly=None, recordLinkGroups=None, DBKey=None, isOwner=True):
        """

        Arguments:
                * standardNamesOnly - type bool
                * recordLinkGroups - type list of :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>` objects
                * DBKey - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetRecordLinkGroups_Create = self.lib.GetRecordLinkGroups_Create
            GetRecordLinkGroups_Create.restype = POINTER(c_void_p)
            self.c_obj = GetRecordLinkGroups_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if standardNamesOnly is not None:
            self.standardNamesOnly = standardNamesOnly
        if recordLinkGroups is not None:
            self.recordLinkGroups = recordLinkGroups
        if DBKey is not None:
            self.DBKey = DBKey


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetRecordLinkGroups_Destroy = self.lib.GetRecordLinkGroups_Destroy
            GetRecordLinkGroups_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetRecordLinkGroups_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def standardNamesOnly(self):
        """Property standardNamesOnly is of type bool. """ 
        self._standardNamesOnly = self.__GetStandardNamesOnly()
        return self._standardNamesOnly

    @standardNamesOnly.setter
    def standardNamesOnly(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('standardNamesOnly','standardNamesOnly: Invalid type standardNamesOnly must be of type bool')
        self.__SetStandardNamesOnly(value)
        self._standardNamesOnly = value

    @property
    def recordLinkGroups(self):
        """Property recordLinkGroups is a list of :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordLinkGroups = self.__GetRecordLinkGroups()
        except:
            pass
        return self._recordLinkGroups

    @recordLinkGroups.setter
    def recordLinkGroups(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordLinkGroups','recordLinkGroups: Invalid type recordLinkGroups must be a list of RecordLinkGroupReference')
                
        try:
            self.__updaterecordLinkGroups = True
            self.__ClearRecordLinkGroups()
            for v in value:
                self.AddRecordLinkGroup(v)
        except:
            pass


    @property
    def DBKey(self):
        """Property DBKey is of type str. When this is provided, details of all Record Link Groups in the specified GRANTA MI Database will be returned.""" 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        """When this is provided, details of all Record Link Groups in the specified GRANTA MI Database will be returned."""
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    def __GetDBKey(self):
        GetRecordLinkGroups_GetDBKey = self.lib.GetRecordLinkGroups_GetDBKey
        GetRecordLinkGroups_GetDBKey.argtypes = [POINTER(c_void_p)]
        GetRecordLinkGroups_GetDBKey.restype = POINTER(c_void_p)
        value = GetRecordLinkGroups_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetDBKey(self, value):
        """When this is provided, details of all Record Link Groups in the specified GRANTA MI Database will be returned."""

        GetRecordLinkGroups_SetDBKey = self.lib.GetRecordLinkGroups_SetDBKey 
        GetRecordLinkGroups_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        GetRecordLinkGroups_SetDBKey(self._c_obj, EnsureEncoded(value))

    def __GetStandardNamesOnly(self):
        GetRecordLinkGroups_GetStandardNamesOnly = self.lib.GetRecordLinkGroups_GetStandardNamesOnly
        GetRecordLinkGroups_GetStandardNamesOnly.argtypes = [POINTER(c_void_p)]
        GetRecordLinkGroups_GetStandardNamesOnly.restype = c_bool
        value = GetRecordLinkGroups_GetStandardNamesOnly(self._c_obj)
        return value
    
    def __SetStandardNamesOnly(self, value):

        GetRecordLinkGroups_SetStandardNamesOnly = self.lib.GetRecordLinkGroups_SetStandardNamesOnly 
        GetRecordLinkGroups_SetStandardNamesOnly.argtypes = [POINTER(c_void_p), c_bool]
        GetRecordLinkGroups_SetStandardNamesOnly(self._c_obj, value)

    def __GetNumberOfRecordLinkGroups(self):
        GetRecordLinkGroups_GetNumberOfRecordLinkGroups = self.lib.GetRecordLinkGroups_GetNumberOfRecordLinkGroups
        GetRecordLinkGroups_GetNumberOfRecordLinkGroups.argtypes = [POINTER(c_void_p)]
        GetRecordLinkGroups_GetNumberOfRecordLinkGroups.restype = c_int
        value = GetRecordLinkGroups_GetNumberOfRecordLinkGroups(self._c_obj)
        return value
    
    def __GetRecordLinkGroupElement(self,i):
        value = RecordLinkGroupReference()
        GetRecordLinkGroups_GetRecordLinkGroup = self.lib.GetRecordLinkGroups_GetRecordLinkGroup
        GetRecordLinkGroups_GetRecordLinkGroup.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetRecordLinkGroups_GetRecordLinkGroup(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordLinkGroups(self):
         n = self.__GetNumberOfRecordLinkGroups();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordLinkGroupElement(i))
         return temp
    
    def __ClearRecordLinkGroups(self):
        GetRecordLinkGroups_ClearRecordLinkGroups = self.lib.GetRecordLinkGroups_ClearRecordLinkGroups
        GetRecordLinkGroups_ClearRecordLinkGroups.argtypes = [POINTER(c_void_p)]
        GetRecordLinkGroups_ClearRecordLinkGroups(self._c_obj)
        return self

    def AddRecordLinkGroup(self, _recordLinkGroupReference):
        """Appends _recordLinkGroupReference to recordLinkGroups property on GetRecordLinkGroups C-object.

           Arguments:
                _recordLinkGroupReference - object of type RecordLinkGroupReference.
        """

        if not isinstance(_recordLinkGroupReference, RecordLinkGroupReference):
            raise GRANTA_Exception('GetRecordLinkGroups.AddRecordLinkGroup','_recordLinkGroupReference: Invalid argument type _recordLinkGroupReference must be of type RecordLinkGroupReference')
        GetRecordLinkGroups_AddRecordLinkGroup = self.lib.GetRecordLinkGroups_AddRecordLinkGroup
        GetRecordLinkGroups_AddRecordLinkGroup.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRecordLinkGroups_AddRecordLinkGroup(self._c_obj, _recordLinkGroupReference.c_obj)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


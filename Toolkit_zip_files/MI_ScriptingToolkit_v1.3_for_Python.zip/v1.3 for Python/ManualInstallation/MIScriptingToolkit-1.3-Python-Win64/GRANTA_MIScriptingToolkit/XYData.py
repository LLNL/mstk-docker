# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.XYPoint import XYPoint
from GRANTA_MIScriptingToolkit.XYRange import XYRange


class XYData(object):
    """XYData. A collection of y-axis values for a graph where the y-axis values are either point or range values.
    
        Arguments:
                * XYPoints - type list of :py:mod:`XYPoint <GRANTA_MIScriptingToolkit.XYPoint>` objects
                * XYRanges - type list of :py:mod:`XYRange <GRANTA_MIScriptingToolkit.XYRange>` objects
                * type - type str


    """
    
    def __init__(self, XYPoints=None, XYRanges=None, type=None, isOwner=True):
        """

        Arguments:
                * XYPoints - type list of :py:mod:`XYPoint <GRANTA_MIScriptingToolkit.XYPoint>` objects
                * XYRanges - type list of :py:mod:`XYRange <GRANTA_MIScriptingToolkit.XYRange>` objects
                * type - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            XYData_Create = self.lib.XYData_Create
            XYData_Create.restype = POINTER(c_void_p)
            self.c_obj = XYData_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if XYPoints is not None:
            self.XYPoints = XYPoints
        if XYRanges is not None:
            self.XYRanges = XYRanges
        if type is not None:
            self.type = type


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            XYData_Destroy = self.lib.XYData_Destroy
            XYData_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            XYData_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def XYPoints(self):
        """Property XYPoints is a :py:mod:`XYPoint <GRANTA_MIScriptingToolkit.XYPoint>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._XYPoints = self.__GetXYPoints()
        except:
            pass
        return self._XYPoints

    @XYPoints.setter
    def XYPoints(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('XYPoints','XYPoints: Invalid type XYPoints must be a list of XYPoint')
                
        try:
            self.__updateXYPoints = True
            self.__ClearXYPoints()
            for v in value:
                self.AddXYPoint(v)
        except:
            pass


    @property
    def XYRanges(self):
        """Property XYRanges is a :py:mod:`XYRange <GRANTA_MIScriptingToolkit.XYRange>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._XYRanges = self.__GetXYRanges()
        except:
            pass
        return self._XYRanges

    @XYRanges.setter
    def XYRanges(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('XYRanges','XYRanges: Invalid type XYRanges must be a list of XYRange')
                
        try:
            self.__updateXYRanges = True
            self.__ClearXYRanges()
            for v in value:
                self.AddXYRange(v)
        except:
            pass


    @property
    def type(self):
        """Property type is of type str. """ 
        self._type = self.__GetType()
        return self._type

    @type.setter
    def type(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('type','type: Invalid type type must be of type str')
        
        self._type = value

    def __GetType(self):
        XYData_GetType = self.lib.XYData_GetType
        XYData_GetType.argtypes = [POINTER(c_void_p)]
        XYData_GetType.restype = POINTER(c_void_p)
        value = XYData_GetType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetXYPointElement(self,i):
        value = XYPoint()
        XYData_GetXYPoint = self.lib.XYData_GetXYPoint
        XYData_GetXYPoint.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        XYData_GetXYPoint(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetXYPoints(self):
         n = self.__GetNumberOfXYPoints();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetXYPointElement(i))
         return temp
    
    def __GetXYRangeElement(self,i):
        value = XYRange()
        XYData_GetXYRange = self.lib.XYData_GetXYRange
        XYData_GetXYRange.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        XYData_GetXYRange(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetXYRanges(self):
         n = self.__GetNumberOfXYRanges();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetXYRangeElement(i))
         return temp
    
    def AddXYPoint(self, _XYPoint):
        """Appends _XYPoint to XYPoints property on XYData C-object.

           Arguments:
                _XYPoint - object of type XYPoint.
        """

        if not isinstance(_XYPoint, XYPoint):
            raise GRANTA_Exception('XYData.AddXYPoint','_XYPoint: Invalid argument type _XYPoint must be of type XYPoint')
        XYData_AddXYPoint = self.lib.XYData_AddXYPoint
        XYData_AddXYPoint.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        XYData_AddXYPoint(self._c_obj, _XYPoint.c_obj)
        return self

    def AddXYRange(self, _XYRange):
        """Appends _XYRange to XYRanges property on XYData C-object.

           Arguments:
                _XYRange - object of type XYRange.
        """

        if not isinstance(_XYRange, XYRange):
            raise GRANTA_Exception('XYData.AddXYRange','_XYRange: Invalid argument type _XYRange must be of type XYRange')
        XYData_AddXYRange = self.lib.XYData_AddXYRange
        XYData_AddXYRange.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        XYData_AddXYRange(self._c_obj, _XYRange.c_obj)
        return self

    def __ClearXYPoints(self):
        XYData_ClearXYPoints = self.lib.XYData_ClearXYPoints
        XYData_ClearXYPoints.argtypes = [POINTER(c_void_p)]
        XYData_ClearXYPoints(self._c_obj)
        return self

    def __ClearXYRanges(self):
        XYData_ClearXYRanges = self.lib.XYData_ClearXYRanges
        XYData_ClearXYRanges.argtypes = [POINTER(c_void_p)]
        XYData_ClearXYRanges(self._c_obj)
        return self

    def __GetNumberOfXYPoints(self):
        XYData_GetNumberOfXYPoints = self.lib.XYData_GetNumberOfXYPoints
        XYData_GetNumberOfXYPoints.argtypes = [POINTER(c_void_p)]
        XYData_GetNumberOfXYPoints.restype = c_int
        value = XYData_GetNumberOfXYPoints(self._c_obj)
        return value
    
    def __GetNumberOfXYRanges(self):
        XYData_GetNumberOfXYRanges = self.lib.XYData_GetNumberOfXYRanges
        XYData_GetNumberOfXYRanges.argtypes = [POINTER(c_void_p)]
        XYData_GetNumberOfXYRanges.restype = c_int
        value = XYData_GetNumberOfXYRanges(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterValue import ParameterValue


class XYRange(object):
    """XYRange. An x-y datum where the y-axis value is a range.
    
        Arguments:
                * isEstimated - type bool
                * lowerY - type float
                * upperY - type float
                * parameterValue - type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`


    """
    
    def __init__(self, isEstimated=None, lowerY=None, upperY=None, parameterValue=None, isOwner=True):
        """

        Arguments:
                * isEstimated - type bool
                * lowerY - type float
                * upperY - type float
                * parameterValue - type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            XYRange_Create = self.lib.XYRange_Create
            XYRange_Create.restype = POINTER(c_void_p)
            self.c_obj = XYRange_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if isEstimated is not None:
            self.isEstimated = isEstimated
        if lowerY is not None:
            self.lowerY = lowerY
        if upperY is not None:
            self.upperY = upperY
        if parameterValue is not None:
            self.parameterValue = parameterValue


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            XYRange_Destroy = self.lib.XYRange_Destroy
            XYRange_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            XYRange_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def isEstimated(self):
        """Property isEstimated is of type bool. """ 
        self._isEstimated = self.__GetIsEstimated()
        return self._isEstimated

    @isEstimated.setter
    def isEstimated(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('isEstimated','isEstimated: Invalid type isEstimated must be of type bool')
        
        self._isEstimated = value

    @property
    def lowerY(self):
        """Property lowerY is of type float. """ 
        self._lowerY = self.__GetLowerY()
        return self._lowerY

    @lowerY.setter
    def lowerY(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('lowerY','lowerY: Invalid type lowerY must be of type float')
        self.__SetLowerY(value)
        self._lowerY = value

    @property
    def upperY(self):
        """Property upperY is of type float. """ 
        self._upperY = self.__GetUpperY()
        return self._upperY

    @upperY.setter
    def upperY(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('upperY','upperY: Invalid type upperY must be of type float')
        self.__SetUpperY(value)
        self._upperY = value

    @property
    def parameterValue(self):
        """Property parameterValue is of type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`. """ 
        self._parameterValue = self.__GetParameterValue()
        return self._parameterValue

    @parameterValue.setter
    def parameterValue(self, value):
        if not isinstance(value, ParameterValue):
            raise GRANTA_Exception('parameterValue','parameterValue: Invalid type parameterValue must be of type ParameterValue')
        self.__SetParameterValue(value)
        self._parameterValue = value

    def __GetLowerY(self):
        XYRange_GetLowerY = self.lib.XYRange_GetLowerY
        XYRange_GetLowerY.argtypes = [POINTER(c_void_p)]
        XYRange_GetLowerY.restype = c_double
        value = XYRange_GetLowerY(self._c_obj)
        return value
    
    def __SetLowerY(self, value):

        XYRange_SetLowerY = self.lib.XYRange_SetLowerY 
        XYRange_SetLowerY.argtypes = [POINTER(c_void_p), c_double]
        XYRange_SetLowerY(self._c_obj, value)

    def __GetUpperY(self):
        XYRange_GetUpperY = self.lib.XYRange_GetUpperY
        XYRange_GetUpperY.argtypes = [POINTER(c_void_p)]
        XYRange_GetUpperY.restype = c_double
        value = XYRange_GetUpperY(self._c_obj)
        return value
    
    def __SetUpperY(self, value):

        XYRange_SetUpperY = self.lib.XYRange_SetUpperY 
        XYRange_SetUpperY.argtypes = [POINTER(c_void_p), c_double]
        XYRange_SetUpperY(self._c_obj, value)

    def __GetParameterValue(self):
        _parameterValue = ParameterValue()
        XYRange_GetParameterValue = self.lib.XYRange_GetParameterValue
        XYRange_GetParameterValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        XYRange_GetParameterValue(self._c_obj, (_parameterValue.c_obj))
        
        return _parameterValue
        
    def __SetParameterValue(self, value):

        XYRange_SetParameterValue = self.lib.XYRange_SetParameterValue 
        XYRange_SetParameterValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        XYRange_SetParameterValue(self._c_obj, value.c_obj)

    def __GetIsEstimated(self):
        XYRange_GetIsEstimated = self.lib.XYRange_GetIsEstimated
        XYRange_GetIsEstimated.argtypes = [POINTER(c_void_p)]
        XYRange_GetIsEstimated.restype = c_bool
        value = XYRange_GetIsEstimated(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


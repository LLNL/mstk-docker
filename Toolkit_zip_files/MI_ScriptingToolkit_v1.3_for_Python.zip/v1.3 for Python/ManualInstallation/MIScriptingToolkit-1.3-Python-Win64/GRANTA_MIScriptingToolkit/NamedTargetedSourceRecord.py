# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.NamedRecord import NamedRecord


class NamedTargetedSourceRecord(object):
    """NamedTargetedSourceRecord. A named record used for modifying record links.
    
        Arguments:
                * record - type :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>`
                * targetRecords - type list of :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` objects


    """
    
    def __init__(self, record=None, targetRecords=None, isOwner=True):
        """

        Arguments:
                * record - type :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>`
                * targetRecords - type list of :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            NamedTargetedSourceRecord_Create = self.lib.NamedTargetedSourceRecord_Create
            NamedTargetedSourceRecord_Create.restype = POINTER(c_void_p)
            self.c_obj = NamedTargetedSourceRecord_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if record is not None:
            self.record = record
        if targetRecords is not None:
            self.targetRecords = targetRecords


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            NamedTargetedSourceRecord_Destroy = self.lib.NamedTargetedSourceRecord_Destroy
            NamedTargetedSourceRecord_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            NamedTargetedSourceRecord_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def record(self):
        """Property record is of type :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>`. """ 
        self._record = self.__GetRecord()
        return self._record

    @record.setter
    def record(self, value):
        if not isinstance(value, NamedRecord):
            raise GRANTA_Exception('record','record: Invalid type record must be of type NamedRecord')
        self.__SetRecord(value)
        self._record = value

    @property
    def targetRecords(self):
        """Property targetRecords is a list of :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._targetRecords = self.__GetTargetRecords()
        except:
            pass
        return self._targetRecords

    @targetRecords.setter
    def targetRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('targetRecords','targetRecords: Invalid type targetRecords must be a list of NamedRecord')
                
        try:
            self.__updatetargetRecords = True
            self.__ClearTargetRecords()
            for v in value:
                self.AddTargetRecords(v)
        except:
            pass


    def __GetNumberOfTargetRecords(self):
        NamedTargetedSourceRecord_GetNumberOfTargetRecords = self.lib.NamedTargetedSourceRecord_GetNumberOfTargetRecords
        NamedTargetedSourceRecord_GetNumberOfTargetRecords.argtypes = [POINTER(c_void_p)]
        NamedTargetedSourceRecord_GetNumberOfTargetRecords.restype = c_int
        value = NamedTargetedSourceRecord_GetNumberOfTargetRecords(self._c_obj)
        return value
    
    def __GetTargetRecordsElement(self,i):
        value = NamedRecord()
        NamedTargetedSourceRecord_GetTargetRecords = self.lib.NamedTargetedSourceRecord_GetTargetRecords
        NamedTargetedSourceRecord_GetTargetRecords.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        NamedTargetedSourceRecord_GetTargetRecords(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetTargetRecords(self):
         n = self.__GetNumberOfTargetRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetTargetRecordsElement(i))
         return temp
    
    def AddTargetRecords(self, _namedRecord):
        """Appends _namedRecord to targetRecords property on NamedTargetedSourceRecord C-object.

           Arguments:
                _namedRecord - object of type NamedRecord.
        """

        if not isinstance(_namedRecord, NamedRecord):
            raise GRANTA_Exception('NamedTargetedSourceRecord.AddTargetRecords','_namedRecord: Invalid argument type _namedRecord must be of type NamedRecord')
        NamedTargetedSourceRecord_AddTargetRecords = self.lib.NamedTargetedSourceRecord_AddTargetRecords
        NamedTargetedSourceRecord_AddTargetRecords.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        NamedTargetedSourceRecord_AddTargetRecords(self._c_obj, _namedRecord.c_obj)
        return self

    def __ClearTargetRecords(self):
        NamedTargetedSourceRecord_ClearTargetRecords = self.lib.NamedTargetedSourceRecord_ClearTargetRecords
        NamedTargetedSourceRecord_ClearTargetRecords.argtypes = [POINTER(c_void_p)]
        NamedTargetedSourceRecord_ClearTargetRecords(self._c_obj)
        return self

    def __GetRecord(self):
        _namedRecord = NamedRecord()
        NamedTargetedSourceRecord_GetRecord = self.lib.NamedTargetedSourceRecord_GetRecord
        NamedTargetedSourceRecord_GetRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        NamedTargetedSourceRecord_GetRecord(self._c_obj, (_namedRecord.c_obj))
        
        return _namedRecord
        
    def __SetRecord(self, value):

        NamedTargetedSourceRecord_SetRecord = self.lib.NamedTargetedSourceRecord_SetRecord 
        NamedTargetedSourceRecord_SetRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        NamedTargetedSourceRecord_SetRecord(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.AttributeDetail import AttributeDetail
from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse


class GetAttributeDetailsResponse(object):
    """GetAttributeDetailsResponse. Output from the GetAttributeDetails operation.
Includes an array of :py:mod:`AttributeDetail <GRANTA_MIScriptingToolkit.AttributeDetail>` objects and a :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>` object.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetAttributeDetailsResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetAttributeDetailsResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetAttributeDetailsResponse_Destroy = self.lib.GetAttributeDetailsResponse_Destroy
            GetAttributeDetailsResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetAttributeDetailsResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def attributeDetails(self):
        """Property attributeDetails is a list of :py:mod:`AttributeDetail <GRANTA_MIScriptingToolkit.AttributeDetail>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeDetails = self.__GetAttributeDetails()
        except:
            pass
        return self._attributeDetails

    @attributeDetails.setter
    def attributeDetails(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeDetails','attributeDetails: Invalid type attributeDetails must be a list of AttributeDetail')
                
        try:
            self.__updateattributeDetails = True
            self.__ClearAttributeDetails()
            for v in value:
                self.AddAttributeDetails(v)
        except:
            pass


    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    def __GetNumberOfAttributeDetails(self):
        GetAttributeDetailsResponse_GetNumberOfAttributeDetails = self.lib.GetAttributeDetailsResponse_GetNumberOfAttributeDetails
        GetAttributeDetailsResponse_GetNumberOfAttributeDetails.argtypes = [POINTER(c_void_p)]
        GetAttributeDetailsResponse_GetNumberOfAttributeDetails.restype = c_int
        value = GetAttributeDetailsResponse_GetNumberOfAttributeDetails(self._c_obj)
        return value
    
    def __GetAttributeDetailsElement(self,i):
        value = AttributeDetail()
        GetAttributeDetailsResponse_GetAttributeDetails = self.lib.GetAttributeDetailsResponse_GetAttributeDetails
        GetAttributeDetailsResponse_GetAttributeDetails.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetAttributeDetailsResponse_GetAttributeDetails(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributeDetails(self):
         n = self.__GetNumberOfAttributeDetails();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeDetailsElement(i))
         return temp
    
    def AddAttributeDetails(self, _attributeDetail):
        """Appends _attributeDetail to attributeDetails property on GetAttributeDetailsResponse C-object.

           Arguments:
                _attributeDetail - object of type AttributeDetail.
        """

        if not isinstance(_attributeDetail, AttributeDetail):
            raise GRANTA_Exception('GetAttributeDetailsResponse.AddAttributeDetails','_attributeDetail: Invalid argument type _attributeDetail must be of type AttributeDetail')
        GetAttributeDetailsResponse_AddAttributeDetails = self.lib.GetAttributeDetailsResponse_AddAttributeDetails
        GetAttributeDetailsResponse_AddAttributeDetails.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetAttributeDetailsResponse_AddAttributeDetails(self._c_obj, _attributeDetail.c_obj)
        return self

    def __ClearAttributeDetails(self):
        GetAttributeDetailsResponse_ClearAttributeDetails = self.lib.GetAttributeDetailsResponse_ClearAttributeDetails
        GetAttributeDetailsResponse_ClearAttributeDetails.argtypes = [POINTER(c_void_p)]
        GetAttributeDetailsResponse_ClearAttributeDetails(self._c_obj)
        return self

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetAttributeDetailsResponse_GetServiceLayerResponse = self.lib.GetAttributeDetailsResponse_GetServiceLayerResponse
        GetAttributeDetailsResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetAttributeDetailsResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


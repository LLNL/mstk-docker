# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference
from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.UnitConversionContext import UnitConversionContext
from GRANTA_MIScriptingToolkit.RecordFilter import RecordFilter


class GetRecordAttributesByRefRequest(object):
    """GetRecordAttributesByRefRequest. Input for the GetRecordAttributesByRef operation.
For requests, at least one :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` and at least one :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` is required.
    
        Arguments:
                * recordFilter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * useFallback - type bool
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects
                * populateGUIDs - type bool
                * unitConversionContext - type :py:mod:`UnitConversionContext <GRANTA_MIScriptingToolkit.UnitConversionContext>`
                * binaryDataRepresentation - type int
                * recordReferences - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects


    """
    
    def __init__(self, recordFilter=None, useFallback=None, attributeReferences=None, populateGUIDs=None, unitConversionContext=None, binaryDataRepresentation=None, recordReferences=None, isOwner=True):
        """

        Arguments:
                * recordFilter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * useFallback - type bool
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects
                * populateGUIDs - type bool
                * unitConversionContext - type :py:mod:`UnitConversionContext <GRANTA_MIScriptingToolkit.UnitConversionContext>`
                * binaryDataRepresentation - type int
                * recordReferences - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetRecordAttributesByRefRequest_Create = self.lib.GetRecordAttributesByRefRequest_Create
            GetRecordAttributesByRefRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetRecordAttributesByRefRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordFilter is not None:
            self.recordFilter = recordFilter
        if useFallback is not None:
            self.useFallback = useFallback
        if attributeReferences is not None:
            self.attributeReferences = attributeReferences
        if populateGUIDs is not None:
            self.populateGUIDs = populateGUIDs
        if unitConversionContext is not None:
            self.unitConversionContext = unitConversionContext
        if binaryDataRepresentation is not None:
            self.binaryDataRepresentation = binaryDataRepresentation
        if recordReferences is not None:
            self.recordReferences = recordReferences


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetRecordAttributesByRefRequest_Destroy = self.lib.GetRecordAttributesByRefRequest_Destroy
            GetRecordAttributesByRefRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetRecordAttributesByRefRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordFilter(self):
        """Property recordFilter is of type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`. """ 
        self._recordFilter = self.__GetRecordFilter()
        return self._recordFilter

    @recordFilter.setter
    def recordFilter(self, value):
        if not isinstance(value, RecordFilter):
            raise GRANTA_Exception('recordFilter','recordFilter: Invalid type recordFilter must be of type RecordFilter')
        self.__SetRecordFilter(value)
        self._recordFilter = value

    @property
    def useFallback(self):
        """Property useFallback is of type bool. """ 
        self._useFallback = self.__GetUseFallback()
        return self._useFallback

    @useFallback.setter
    def useFallback(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('useFallback','useFallback: Invalid type useFallback must be of type bool')
        self.__SetUseFallback(value)
        self._useFallback = value

    @property
    def attributeReferences(self):
        """Property attributeReferences is a list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeReferences = self.__GetAttributeReferences()
        except:
            pass
        return self._attributeReferences

    @attributeReferences.setter
    def attributeReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeReferences','attributeReferences: Invalid type attributeReferences must be a list of AttributeReference')
                
        try:
            self.__updateattributeReferences = True
            self.__ClearAttributeReferences()
            for v in value:
                self.AddAttributeReference(v)
        except:
            pass


    @property
    def populateGUIDs(self):
        """Property populateGUIDs is of type bool. """ 
        self._populateGUIDs = self.__GetPopulateGUIDs()
        return self._populateGUIDs

    @populateGUIDs.setter
    def populateGUIDs(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('populateGUIDs','populateGUIDs: Invalid type populateGUIDs must be of type bool')
        self.__SetPopulateGUIDs(value)
        self._populateGUIDs = value

    @property
    def unitConversionContext(self):
        """Property unitConversionContext is of type :py:mod:`UnitConversionContext <GRANTA_MIScriptingToolkit.UnitConversionContext>`. """ 
        self._unitConversionContext = self.__GetUnitConversionContext()
        return self._unitConversionContext

    @unitConversionContext.setter
    def unitConversionContext(self, value):
        if not isinstance(value, UnitConversionContext):
            raise GRANTA_Exception('unitConversionContext','unitConversionContext: Invalid type unitConversionContext must be of type UnitConversionContext')
        self.__SetUnitConversionContext(value)
        self._unitConversionContext = value

    @property
    def binaryDataRepresentation(self):
        """Property binaryDataRepresentation is of type int. See :py:class:`GRANTA_Constants.BinaryDataRepresentation <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        try:
            return self._binaryDataRepresentation
        except:
            return None

    @binaryDataRepresentation.setter
    def binaryDataRepresentation(self, value):
        """See :py:class:`GRANTA_Constants.BinaryDataRepresentation <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('binaryDataRepresentation','binaryDataRepresentation: Invalid type binaryDataRepresentation must be of type int')
        self.__SetBinaryDataRepresentation(value)
        self._binaryDataRepresentation = value

    @property
    def recordReferences(self):
        """Property recordReferences is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordReferences = self.__GetRecordReferences()
        except:
            pass
        return self._recordReferences

    @recordReferences.setter
    def recordReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordReferences','recordReferences: Invalid type recordReferences must be a list of RecordReference')
                
        try:
            self.__updaterecordReferences = True
            self.__ClearRecordReferences()
            for v in value:
                self.AddRecordReference(v)
        except:
            pass


    def AddAttributeReference(self, _attributeReference):
        """Appends _attributeReference to attributeReferences property on GetRecordAttributesByRefRequest C-object.

           Arguments:
                _attributeReference - object of type AttributeReference.
        """

        if not isinstance(_attributeReference, AttributeReference):
            raise GRANTA_Exception('GetRecordAttributesByRefRequest.AddAttributeReference','_attributeReference: Invalid argument type _attributeReference must be of type AttributeReference')
        GetRecordAttributesByRefRequest_AddAttributeReference = self.lib.GetRecordAttributesByRefRequest_AddAttributeReference
        GetRecordAttributesByRefRequest_AddAttributeReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRecordAttributesByRefRequest_AddAttributeReference(self._c_obj, _attributeReference.c_obj)
        return self

    def __ClearAttributeReferences(self):
        GetRecordAttributesByRefRequest_ClearAttributeReferences = self.lib.GetRecordAttributesByRefRequest_ClearAttributeReferences
        GetRecordAttributesByRefRequest_ClearAttributeReferences.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesByRefRequest_ClearAttributeReferences(self._c_obj)
        return self

    def AddRecordReference(self, _recordReference):
        """Appends _recordReference to recordReferences property on GetRecordAttributesByRefRequest C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('GetRecordAttributesByRefRequest.AddRecordReference','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        GetRecordAttributesByRefRequest_AddRecordReference = self.lib.GetRecordAttributesByRefRequest_AddRecordReference
        GetRecordAttributesByRefRequest_AddRecordReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRecordAttributesByRefRequest_AddRecordReference(self._c_obj, _recordReference.c_obj)
        return self

    def __ClearRecordReferences(self):
        GetRecordAttributesByRefRequest_ClearRecordReferences = self.lib.GetRecordAttributesByRefRequest_ClearRecordReferences
        GetRecordAttributesByRefRequest_ClearRecordReferences.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesByRefRequest_ClearRecordReferences(self._c_obj)
        return self

    def __GetNumberOfAttributeReferences(self):
        GetRecordAttributesByRefRequest_GetNumberOfAttributeReferences = self.lib.GetRecordAttributesByRefRequest_GetNumberOfAttributeReferences
        GetRecordAttributesByRefRequest_GetNumberOfAttributeReferences.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesByRefRequest_GetNumberOfAttributeReferences.restype = c_int
        value = GetRecordAttributesByRefRequest_GetNumberOfAttributeReferences(self._c_obj)
        return value
    
    def __GetAttributeReferencesElement(self,i):
        value = AttributeReference()
        GetRecordAttributesByRefRequest_GetAttributeReferences = self.lib.GetRecordAttributesByRefRequest_GetAttributeReferences
        GetRecordAttributesByRefRequest_GetAttributeReferences.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetRecordAttributesByRefRequest_GetAttributeReferences(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributeReferences(self):
         n = self.__GetNumberOfAttributeReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeReferencesElement(i))
         return temp
    
    def __GetNumberOfRecordReferences(self):
        GetRecordAttributesByRefRequest_GetNumberOfRecordReferences = self.lib.GetRecordAttributesByRefRequest_GetNumberOfRecordReferences
        GetRecordAttributesByRefRequest_GetNumberOfRecordReferences.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesByRefRequest_GetNumberOfRecordReferences.restype = c_int
        value = GetRecordAttributesByRefRequest_GetNumberOfRecordReferences(self._c_obj)
        return value
    
    def __GetRecordReferencesElement(self,i):
        value = RecordReference()
        GetRecordAttributesByRefRequest_GetRecordReferences = self.lib.GetRecordAttributesByRefRequest_GetRecordReferences
        GetRecordAttributesByRefRequest_GetRecordReferences.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetRecordAttributesByRefRequest_GetRecordReferences(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordReferences(self):
         n = self.__GetNumberOfRecordReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordReferencesElement(i))
         return temp
    
    def __SetPopulateGUIDs(self, value):

        GetRecordAttributesByRefRequest_SetPopulateGUIDs = self.lib.GetRecordAttributesByRefRequest_SetPopulateGUIDs 
        GetRecordAttributesByRefRequest_SetPopulateGUIDs.argtypes = [POINTER(c_void_p), c_bool]
        GetRecordAttributesByRefRequest_SetPopulateGUIDs(self._c_obj, value)

    def __GetPopulateGUIDs(self):
        GetRecordAttributesByRefRequest_GetPopulateGUIDs = self.lib.GetRecordAttributesByRefRequest_GetPopulateGUIDs
        GetRecordAttributesByRefRequest_GetPopulateGUIDs.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesByRefRequest_GetPopulateGUIDs.restype = c_bool
        value = GetRecordAttributesByRefRequest_GetPopulateGUIDs(self._c_obj)
        return value
    
    def __GetUnitConversionContext(self):
        _unitConversionContext = UnitConversionContext()
        GetRecordAttributesByRefRequest_GetUnitConversionContext = self.lib.GetRecordAttributesByRefRequest_GetUnitConversionContext
        GetRecordAttributesByRefRequest_GetUnitConversionContext.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetRecordAttributesByRefRequest_GetUnitConversionContext(self._c_obj, (_unitConversionContext.c_obj))
        
        return _unitConversionContext
        
    def __SetUnitConversionContext(self, value):

        GetRecordAttributesByRefRequest_SetUnitConversionContext = self.lib.GetRecordAttributesByRefRequest_SetUnitConversionContext 
        GetRecordAttributesByRefRequest_SetUnitConversionContext.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRecordAttributesByRefRequest_SetUnitConversionContext(self._c_obj, value.c_obj)

    def __SetRecordFilter(self, value):

        GetRecordAttributesByRefRequest_SetRecordFilter = self.lib.GetRecordAttributesByRefRequest_SetRecordFilter 
        GetRecordAttributesByRefRequest_SetRecordFilter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRecordAttributesByRefRequest_SetRecordFilter(self._c_obj, value.c_obj)

    def __GetRecordFilter(self):
        _recordFilter = RecordFilter()
        GetRecordAttributesByRefRequest_GetRecordFilter = self.lib.GetRecordAttributesByRefRequest_GetRecordFilter
        GetRecordAttributesByRefRequest_GetRecordFilter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetRecordAttributesByRefRequest_GetRecordFilter(self._c_obj, (_recordFilter.c_obj))
        
        return _recordFilter
        
    def __GetUseFallback(self):
        GetRecordAttributesByRefRequest_GetUseFallback = self.lib.GetRecordAttributesByRefRequest_GetUseFallback
        GetRecordAttributesByRefRequest_GetUseFallback.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesByRefRequest_GetUseFallback.restype = c_bool
        value = GetRecordAttributesByRefRequest_GetUseFallback(self._c_obj)
        return value
    
    def __SetUseFallback(self, value):

        GetRecordAttributesByRefRequest_SetUseFallback = self.lib.GetRecordAttributesByRefRequest_SetUseFallback 
        GetRecordAttributesByRefRequest_SetUseFallback.argtypes = [POINTER(c_void_p), c_bool]
        GetRecordAttributesByRefRequest_SetUseFallback(self._c_obj, value)

    def __SetBinaryDataRepresentation(self, value):
        """See :py:class:`GRANTA_Constants.BinaryDataRepresentation <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        GetRecordAttributesByRefRequest_SetBinaryDataRepresentation = self.lib.GetRecordAttributesByRefRequest_SetBinaryDataRepresentation 
        GetRecordAttributesByRefRequest_SetBinaryDataRepresentation.argtypes = [POINTER(c_void_p), c_int]
        GetRecordAttributesByRefRequest_SetBinaryDataRepresentation(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class GetTables(object):
    """GetTables. Input to the GetTables operation.
Requires a DBKey to be set.
    
        Arguments:
                * tableFilter - type int
                * attributeSelectors - type list of int objects
                * DBKey - type str


    """
    class AttributeSelector:
        NONE = 0
        NonMetaAttributes = 1
        MetaAttributes = 2
        StandardAttributes = 3
    
    def __init__(self, tableFilter=None, attributeSelectors=None, DBKey=None, isOwner=True):
        """

        Arguments:
                * tableFilter - type int
                * attributeSelectors - type list of int objects
                * DBKey - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetTables_Create = self.lib.GetTables_Create
            GetTables_Create.restype = POINTER(c_void_p)
            self.c_obj = GetTables_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if tableFilter is not None:
            self.tableFilter = tableFilter
        if attributeSelectors is not None:
            self.attributeSelectors = attributeSelectors
        if DBKey is not None:
            self.DBKey = DBKey


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetTables_Destroy = self.lib.GetTables_Destroy
            GetTables_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetTables_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def tableFilter(self):
        """Property tableFilter is of type int. See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._tableFilter = self.__GetTableFilter()
        return self._tableFilter

    @tableFilter.setter
    def tableFilter(self, value):
        """See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('tableFilter','tableFilter: Invalid type tableFilter must be of type int')
        self.__SetTableFilter(value)
        self._tableFilter = value

    @property
    def attributeSelectors(self):
        """Property attributeSelectors is a list of int objects. See :py:class:`GetTables.AttributeSelector <GetTables.AttributeSelector>` for supported values. 
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeSelectors = self.__GetAttributeSelectors()
        except:
            pass
        return self._attributeSelectors

    @attributeSelectors.setter
    def attributeSelectors(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeSelectors','attributeSelectors: Invalid type attributeSelectors must be a list of int')
                
        try:
            self.__updateattributeSelectors = True
            self.__ClearAttributeSelectors()
            for v in value:
                self.AddAttributeSelector(v)
        except:
            pass


    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    def __SetDBKey(self, value):

        GetTables_SetDBKey = self.lib.GetTables_SetDBKey 
        GetTables_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        GetTables_SetDBKey(self._c_obj, EnsureEncoded(value))

    def __GetDBKey(self):
        GetTables_GetDBKey = self.lib.GetTables_GetDBKey
        GetTables_GetDBKey.argtypes = [POINTER(c_void_p)]
        GetTables_GetDBKey.restype = POINTER(c_void_p)
        value = GetTables_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetTableFilter(self):
        GetTables_GetTableFilter = self.lib.GetTables_GetTableFilter
        GetTables_GetTableFilter.argtypes = [POINTER(c_void_p)]
        GetTables_GetTableFilter.restype = c_int
        value = GetTables_GetTableFilter(self._c_obj)
        return value
    
    def __SetTableFilter(self, value):
        """See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        GetTables_SetTableFilter = self.lib.GetTables_SetTableFilter 
        GetTables_SetTableFilter.argtypes = [POINTER(c_void_p), c_int]
        GetTables_SetTableFilter(self._c_obj, value)

    def __GetNumberOfAttributeSelectors(self):
        GetTables_GetNumberOfAttributeSelectors = self.lib.GetTables_GetNumberOfAttributeSelectors
        GetTables_GetNumberOfAttributeSelectors.argtypes = [POINTER(c_void_p)]
        GetTables_GetNumberOfAttributeSelectors.restype = c_int
        value = GetTables_GetNumberOfAttributeSelectors(self._c_obj)
        return value
    
    def __GetAttributeSelectorElement(self,i):
        GetTables_GetAttributeSelector = self.lib.GetTables_GetAttributeSelector
        GetTables_GetAttributeSelector.argtypes = [POINTER(c_void_p), c_int]
        GetTables_GetAttributeSelector.restype = c_int
        value = GetTables_GetAttributeSelector(self._c_obj, i)
        return value
    
    def __GetAttributeSelectors(self):
         n = self.__GetNumberOfAttributeSelectors();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeSelectorElement(i))
         return temp
    
    def __ClearAttributeSelectors(self):
        GetTables_ClearAttributeSelectors = self.lib.GetTables_ClearAttributeSelectors
        GetTables_ClearAttributeSelectors.argtypes = [POINTER(c_void_p)]
        GetTables_ClearAttributeSelectors(self._c_obj)
        return self

    def AddAttributeSelector(self, value):
        """Appends value to attributeSelectors property on GetTables C-object.

           Arguments:
                value - object of type int.
        """

        GetTables_AddAttributeSelector = self.lib.GetTables_AddAttributeSelector
        GetTables_AddAttributeSelector.argtypes = [POINTER(c_void_p), c_int]
        GetTables_AddAttributeSelector(self._c_obj, value)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


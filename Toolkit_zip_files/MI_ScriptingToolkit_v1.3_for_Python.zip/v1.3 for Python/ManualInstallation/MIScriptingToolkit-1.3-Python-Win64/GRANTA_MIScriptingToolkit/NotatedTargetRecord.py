# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class NotatedTargetRecord(object):
    """NotatedTargetRecord. A :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` of the record you wish to link to and notes on the record link.
Requires a :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. Notes on the link and the reverse link are optional.
    
        Arguments:
                * record - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * notes - type str
                * reverseNotes - type str


    """
    
    def __init__(self, record=None, notes=None, reverseNotes=None, isOwner=True):
        """

        Arguments:
                * record - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * notes - type str
                * reverseNotes - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            NotatedTargetRecord_Create = self.lib.NotatedTargetRecord_Create
            NotatedTargetRecord_Create.restype = POINTER(c_void_p)
            self.c_obj = NotatedTargetRecord_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if record is not None:
            self.record = record
        if notes is not None:
            self.notes = notes
        if reverseNotes is not None:
            self.reverseNotes = reverseNotes


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            NotatedTargetRecord_Destroy = self.lib.NotatedTargetRecord_Destroy
            NotatedTargetRecord_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            NotatedTargetRecord_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def record(self):
        """Property record is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._record = self.__GetRecord()
        return self._record

    @record.setter
    def record(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('record','record: Invalid type record must be of type RecordReference')
        self.__SetRecord(value)
        self._record = value

    @property
    def notes(self):
        """Property notes is of type str. """ 
        self._notes = self.__GetNotes()
        return self._notes

    @notes.setter
    def notes(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('notes','notes: Invalid type notes must be of type str')
        self.__SetNotes(value)
        self._notes = value

    @property
    def reverseNotes(self):
        """Property reverseNotes is of type str. """ 
        self._reverseNotes = self.__GetReverseNotes()
        return self._reverseNotes

    @reverseNotes.setter
    def reverseNotes(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('reverseNotes','reverseNotes: Invalid type reverseNotes must be of type str')
        self.__SetReverseNotes(value)
        self._reverseNotes = value

    def __GetNotes(self):
        NotatedTargetRecord_GetNotes = self.lib.NotatedTargetRecord_GetNotes
        NotatedTargetRecord_GetNotes.argtypes = [POINTER(c_void_p)]
        NotatedTargetRecord_GetNotes.restype = POINTER(c_void_p)
        value = NotatedTargetRecord_GetNotes(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetNotes(self, value):

        NotatedTargetRecord_SetNotes = self.lib.NotatedTargetRecord_SetNotes 
        NotatedTargetRecord_SetNotes.argtypes = [POINTER(c_void_p), c_char_p]
        NotatedTargetRecord_SetNotes(self._c_obj, EnsureEncoded(value))

    def __GetReverseNotes(self):
        NotatedTargetRecord_GetReverseNotes = self.lib.NotatedTargetRecord_GetReverseNotes
        NotatedTargetRecord_GetReverseNotes.argtypes = [POINTER(c_void_p)]
        NotatedTargetRecord_GetReverseNotes.restype = POINTER(c_void_p)
        value = NotatedTargetRecord_GetReverseNotes(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetReverseNotes(self, value):

        NotatedTargetRecord_SetReverseNotes = self.lib.NotatedTargetRecord_SetReverseNotes 
        NotatedTargetRecord_SetReverseNotes.argtypes = [POINTER(c_void_p), c_char_p]
        NotatedTargetRecord_SetReverseNotes(self._c_obj, EnsureEncoded(value))

    def __GetRecord(self):
        _recordReference = RecordReference()
        NotatedTargetRecord_GetRecord = self.lib.NotatedTargetRecord_GetRecord
        NotatedTargetRecord_GetRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        NotatedTargetRecord_GetRecord(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __SetRecord(self, value):

        NotatedTargetRecord_SetRecord = self.lib.NotatedTargetRecord_SetRecord 
        NotatedTargetRecord_SetRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        NotatedTargetRecord_SetRecord(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


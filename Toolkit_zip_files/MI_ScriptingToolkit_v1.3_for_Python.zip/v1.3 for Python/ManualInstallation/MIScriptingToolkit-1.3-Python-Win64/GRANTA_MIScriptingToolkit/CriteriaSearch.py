# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordSearchCriterion import RecordSearchCriterion
from GRANTA_MIScriptingToolkit.RecordFilter import RecordFilter


class CriteriaSearch(object):
    """CriteriaSearch. The input for the CriteriaSearch operation.
Both the DBKey and recordSearchCriterion are required.
    
        Arguments:
                * recordFilter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * searchFilter - type int
                * DBKey - type str
                * searchMode - type int
                * populateGUIDs - type bool
                * searchCriteria - type list of :py:mod:`RecordSearchCriterion <GRANTA_MIScriptingToolkit.RecordSearchCriterion>` objects


    """
    
    def __init__(self, recordFilter=None, searchFilter=None, DBKey=None, searchMode=None, populateGUIDs=None, searchCriteria=None, isOwner=True):
        """

        Arguments:
                * recordFilter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * searchFilter - type int
                * DBKey - type str
                * searchMode - type int
                * populateGUIDs - type bool
                * searchCriteria - type list of :py:mod:`RecordSearchCriterion <GRANTA_MIScriptingToolkit.RecordSearchCriterion>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            CriteriaSearch_Create = self.lib.CriteriaSearch_Create
            CriteriaSearch_Create.restype = POINTER(c_void_p)
            self.c_obj = CriteriaSearch_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordFilter is not None:
            self.recordFilter = recordFilter
        if searchFilter is not None:
            self.searchFilter = searchFilter
        if DBKey is not None:
            self.DBKey = DBKey
        if searchMode is not None:
            self.searchMode = searchMode
        if populateGUIDs is not None:
            self.populateGUIDs = populateGUIDs
        if searchCriteria is not None:
            self.searchCriteria = searchCriteria


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            CriteriaSearch_Destroy = self.lib.CriteriaSearch_Destroy
            CriteriaSearch_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            CriteriaSearch_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordFilter(self):
        """Property recordFilter is of type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`. """ 
        self._recordFilter = self.__GetRecordFilter()
        return self._recordFilter

    @recordFilter.setter
    def recordFilter(self, value):
        if not isinstance(value, RecordFilter):
            raise GRANTA_Exception('recordFilter','recordFilter: Invalid type recordFilter must be of type RecordFilter')
        self.__SetRecordFilter(value)
        self._recordFilter = value

    @property
    def searchFilter(self):
        """Property searchFilter is of type int. See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._searchFilter = self.__GetSearchFilter()
        return self._searchFilter

    @searchFilter.setter
    def searchFilter(self, value):
        """See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('searchFilter','searchFilter: Invalid type searchFilter must be of type int')
        self.__SetSearchFilter(value)
        self._searchFilter = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    @property
    def searchMode(self):
        """Property searchMode is of type int. See :py:class:`GRANTA_Constants.SearchMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._searchMode = self.__GetSearchMode()
        return self._searchMode

    @searchMode.setter
    def searchMode(self, value):
        """See :py:class:`GRANTA_Constants.SearchMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('searchMode','searchMode: Invalid type searchMode must be of type int')
        self.__SetSearchMode(value)
        self._searchMode = value

    @property
    def populateGUIDs(self):
        """Property populateGUIDs is of type bool. """ 
        self._populateGUIDs = self.__GetPopulateGUIDs()
        return self._populateGUIDs

    @populateGUIDs.setter
    def populateGUIDs(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('populateGUIDs','populateGUIDs: Invalid type populateGUIDs must be of type bool')
        self.__SetPopulateGUIDs(value)
        self._populateGUIDs = value

    @property
    def searchCriteria(self):
        """Property searchCriteria is a list of :py:mod:`RecordSearchCriterion <GRANTA_MIScriptingToolkit.RecordSearchCriterion>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._searchCriteria = self.__GetSearchCriteria()
        except:
            pass
        return self._searchCriteria

    @searchCriteria.setter
    def searchCriteria(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('searchCriteria','searchCriteria: Invalid type searchCriteria must be a list of RecordSearchCriterion')
                
        try:
            self.__updatesearchCriteria = True
            self.__ClearSearchCriteria()
            for v in value:
                self.AddSearchCriteria(v)
        except:
            pass


    def __GetDBKey(self):
        CriteriaSearch_GetDBKey = self.lib.CriteriaSearch_GetDBKey
        CriteriaSearch_GetDBKey.argtypes = [POINTER(c_void_p)]
        CriteriaSearch_GetDBKey.restype = POINTER(c_void_p)
        value = CriteriaSearch_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetDBKey(self, value):

        CriteriaSearch_SetDBKey = self.lib.CriteriaSearch_SetDBKey 
        CriteriaSearch_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        CriteriaSearch_SetDBKey(self._c_obj, EnsureEncoded(value))

    def __GetNumberOfSearchCriteria(self):
        CriteriaSearch_GetNumberOfSearchCriteria = self.lib.CriteriaSearch_GetNumberOfSearchCriteria
        CriteriaSearch_GetNumberOfSearchCriteria.argtypes = [POINTER(c_void_p)]
        CriteriaSearch_GetNumberOfSearchCriteria.restype = c_int
        value = CriteriaSearch_GetNumberOfSearchCriteria(self._c_obj)
        return value
    
    def __GetSearchCriteriaElement(self,i):
        value = RecordSearchCriterion()
        CriteriaSearch_GetSearchCriteria = self.lib.CriteriaSearch_GetSearchCriteria
        CriteriaSearch_GetSearchCriteria.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        CriteriaSearch_GetSearchCriteria(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetSearchCriteria(self):
         n = self.__GetNumberOfSearchCriteria();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetSearchCriteriaElement(i))
         return temp
    
    def AddSearchCriteria(self, _recordSearchCriterion):
        """Appends _recordSearchCriterion to searchCriteria property on CriteriaSearch C-object.

           Arguments:
                _recordSearchCriterion - object of type RecordSearchCriterion.
        """

        if not isinstance(_recordSearchCriterion, RecordSearchCriterion):
            raise GRANTA_Exception('CriteriaSearch.AddSearchCriteria','_recordSearchCriterion: Invalid argument type _recordSearchCriterion must be of type RecordSearchCriterion')
        CriteriaSearch_AddSearchCriteria = self.lib.CriteriaSearch_AddSearchCriteria
        CriteriaSearch_AddSearchCriteria.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        CriteriaSearch_AddSearchCriteria(self._c_obj, _recordSearchCriterion.c_obj)
        return self

    def __ClearSearchCriteria(self):
        CriteriaSearch_ClearSearchCriteria = self.lib.CriteriaSearch_ClearSearchCriteria
        CriteriaSearch_ClearSearchCriteria.argtypes = [POINTER(c_void_p)]
        CriteriaSearch_ClearSearchCriteria(self._c_obj)
        return self

    def __SetPopulateGUIDs(self, value):

        CriteriaSearch_SetPopulateGUIDs = self.lib.CriteriaSearch_SetPopulateGUIDs 
        CriteriaSearch_SetPopulateGUIDs.argtypes = [POINTER(c_void_p), c_bool]
        CriteriaSearch_SetPopulateGUIDs(self._c_obj, value)

    def __GetPopulateGUIDs(self):
        CriteriaSearch_GetPopulateGUIDs = self.lib.CriteriaSearch_GetPopulateGUIDs
        CriteriaSearch_GetPopulateGUIDs.argtypes = [POINTER(c_void_p)]
        CriteriaSearch_GetPopulateGUIDs.restype = c_bool
        value = CriteriaSearch_GetPopulateGUIDs(self._c_obj)
        return value
    
    def __GetSearchFilter(self):
        CriteriaSearch_GetSearchFilter = self.lib.CriteriaSearch_GetSearchFilter
        CriteriaSearch_GetSearchFilter.argtypes = [POINTER(c_void_p)]
        CriteriaSearch_GetSearchFilter.restype = c_int
        value = CriteriaSearch_GetSearchFilter(self._c_obj)
        return value
    
    def __SetSearchFilter(self, value):
        """See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        CriteriaSearch_SetSearchFilter = self.lib.CriteriaSearch_SetSearchFilter 
        CriteriaSearch_SetSearchFilter.argtypes = [POINTER(c_void_p), c_int]
        CriteriaSearch_SetSearchFilter(self._c_obj, value)

    def __GetSearchMode(self):
        CriteriaSearch_GetSearchMode = self.lib.CriteriaSearch_GetSearchMode
        CriteriaSearch_GetSearchMode.argtypes = [POINTER(c_void_p)]
        CriteriaSearch_GetSearchMode.restype = c_int
        value = CriteriaSearch_GetSearchMode(self._c_obj)
        return value
    
    def __SetSearchMode(self, value):
        """See :py:class:`GRANTA_Constants.SearchMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        CriteriaSearch_SetSearchMode = self.lib.CriteriaSearch_SetSearchMode 
        CriteriaSearch_SetSearchMode.argtypes = [POINTER(c_void_p), c_int]
        CriteriaSearch_SetSearchMode(self._c_obj, value)

    def __GetRecordFilter(self):
        _recordFilter = RecordFilter()
        CriteriaSearch_GetRecordFilter = self.lib.CriteriaSearch_GetRecordFilter
        CriteriaSearch_GetRecordFilter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        CriteriaSearch_GetRecordFilter(self._c_obj, (_recordFilter.c_obj))
        
        return _recordFilter
        
    def __SetRecordFilter(self, value):

        CriteriaSearch_SetRecordFilter = self.lib.CriteriaSearch_SetRecordFilter 
        CriteriaSearch_SetRecordFilter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        CriteriaSearch_SetRecordFilter(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


import time
import GRANTA_MIScriptingToolkit.GRANTA_libs as GRANTA_libs
from ctypes import c_char_p, POINTER, c_bool, c_double, c_void_p, c_int
from GRANTA_MIScriptingToolkit.GRANTA_Logging import GRANTA_Logging
from GRANTA_MIScriptingToolkit.Service import Service
from GRANTA_MIScriptingToolkit.GRANTA_Exceptions import GRANTA_Exception
from GRANTA_MIScriptingToolkit.GetMetaAttributesRequest import GetMetaAttributesRequest
from GRANTA_MIScriptingToolkit.GetMetaAttributesResponse import GetMetaAttributesResponse
from GRANTA_MIScriptingToolkit.GetAttributeParametersRequest import GetAttributeParametersRequest
from GRANTA_MIScriptingToolkit.GetAttributeParametersResponse import GetAttributeParametersResponse
from GRANTA_MIScriptingToolkit.GetUnitSystems import GetUnitSystems
from GRANTA_MIScriptingToolkit.GetUnitSystemsResponse import GetUnitSystemsResponse
from GRANTA_MIScriptingToolkit.GetLinkedRecordsRequest import GetLinkedRecordsRequest
from GRANTA_MIScriptingToolkit.GetLinkedRecordsResponse import GetLinkedRecordsResponse
from GRANTA_MIScriptingToolkit.GetChildNodes import GetChildNodes
from GRANTA_MIScriptingToolkit.GetChildNodesResponse import GetChildNodesResponse
from GRANTA_MIScriptingToolkit.GetTables import GetTables
from GRANTA_MIScriptingToolkit.GetTablesResponse import GetTablesResponse
from GRANTA_MIScriptingToolkit.GetRecordVersionsRequest import GetRecordVersionsRequest
from GRANTA_MIScriptingToolkit.GetRecordVersionsResponse import GetRecordVersionsResponse
from GRANTA_MIScriptingToolkit.GetParameterDetailsRequest import GetParameterDetailsRequest
from GRANTA_MIScriptingToolkit.GetParameterDetailsResponse import GetParameterDetailsResponse
from GRANTA_MIScriptingToolkit.GetRootNode import GetRootNode
from GRANTA_MIScriptingToolkit.GetRootNodeResponse import GetRootNodeResponse
from GRANTA_MIScriptingToolkit.GetTreeRecordsRequest import GetTreeRecordsRequest
from GRANTA_MIScriptingToolkit.GetTreeRecordsResponse import GetTreeRecordsResponse
from GRANTA_MIScriptingToolkit.GetRecordLinkGroups import GetRecordLinkGroups
from GRANTA_MIScriptingToolkit.GetRecordLinkGroupsResponse import GetRecordLinkGroupsResponse
from GRANTA_MIScriptingToolkit.GetRecordAttributesRequest import GetRecordAttributesRequest
from GRANTA_MIScriptingToolkit.GetRecordAttributesResponse import GetRecordAttributesResponse
from GRANTA_MIScriptingToolkit.GetAttributeDetailsRequest import GetAttributeDetailsRequest
from GRANTA_MIScriptingToolkit.GetAttributeDetailsResponse import GetAttributeDetailsResponse
from GRANTA_MIScriptingToolkit.GetDatabasesResponse import GetDatabasesResponse
from GRANTA_MIScriptingToolkit.GetSubsetsRequest import GetSubsetsRequest
from GRANTA_MIScriptingToolkit.GetSubsetsResponse import GetSubsetsResponse

# This file was automatically generated
class BrowseService(Service):
    """The Browse service provides read-only operation for a GRANTA MI Server."""

    def __init__(self, mi_session):
        """Initialize a BrowseService object
                Arguments:
                    mi_session - MI_Session object
        """
        self.mi_session = mi_session
        self.lib = GRANTA_libs.MIServiceLayerCAPILib

    def GetMetaAttributes(self, _req):
        """Returns the Meta-Attributes of one or more parent Attributes in a Table of a GRANTA MI Database.

        Arguments:
            _req - :py:mod:`GetMetaAttributesRequest <GRANTA_MIScriptingToolkit.GetMetaAttributesRequest>` object
        Returns:
            :py:mod:`GetMetaAttributesResponse <GRANTA_MIScriptingToolkit.GetMetaAttributesResponse>` object
        
        """
        if not isinstance(_req, GetMetaAttributesRequest):
            raise GRANTA_Exception('Browse.GetMetaAttributes','Browse.GetMetaAttributes(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetMetaAttributesRequest')

        startTime = time.clock()
        func = self.lib.Browse_GetMetaAttributes
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetMetaAttributesResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetMetaAttributes() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetMetaAttributes')
        return response

    def GetAttributeParameters(self, _req):
        """Gets detailed information about the Parameters that are declared to be usable with given Attribute(s) in a GRANTA MI Database. Can only be used with Functional Attributes or Multi-Valued Attributes.

        Arguments:
            _req - :py:mod:`GetAttributeParametersRequest <GRANTA_MIScriptingToolkit.GetAttributeParametersRequest>` object
        Returns:
            :py:mod:`GetAttributeParametersResponse <GRANTA_MIScriptingToolkit.GetAttributeParametersResponse>` object
        
        """
        if not isinstance(_req, GetAttributeParametersRequest):
            raise GRANTA_Exception('Browse.GetAttributeParameters','Browse.GetAttributeParameters(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetAttributeParametersRequest')

        startTime = time.clock()
        func = self.lib.Browse_GetAttributeParameters
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetAttributeParametersResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetAttributeParameters() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetAttributeParameters')
        return response

    def GetUnitSystems(self, _req):
        """Returns information about the unit systems known to a GRANTA MI Database

        Arguments:
            _req - :py:mod:`GetUnitSystems <GRANTA_MIScriptingToolkit.GetUnitSystems>` object
        Returns:
            :py:mod:`GetUnitSystemsResponse <GRANTA_MIScriptingToolkit.GetUnitSystemsResponse>` object
        
        """
        if not isinstance(_req, GetUnitSystems):
            raise GRANTA_Exception('Browse.GetUnitSystems','Browse.GetUnitSystems(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetUnitSystems')

        startTime = time.clock()
        func = self.lib.Browse_GetUnitSystems
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetUnitSystemsResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetUnitSystems() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetUnitSystems')
        return response

    def GetLinkedRecords(self, _req):
        """Returns the linked records for specified records, for one or more record link groups.

        Arguments:
            _req - :py:mod:`GetLinkedRecordsRequest <GRANTA_MIScriptingToolkit.GetLinkedRecordsRequest>` object
        Returns:
            :py:mod:`GetLinkedRecordsResponse <GRANTA_MIScriptingToolkit.GetLinkedRecordsResponse>` object
        
        """
        if not isinstance(_req, GetLinkedRecordsRequest):
            raise GRANTA_Exception('Browse.GetLinkedRecords','Browse.GetLinkedRecords(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetLinkedRecordsRequest')

        startTime = time.clock()
        func = self.lib.Browse_GetLinkedRecords
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetLinkedRecordsResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetLinkedRecords() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetLinkedRecords')
        return response

    def GetChildNodes(self, _req):
        """Returns information about the child nodes of the given node in the node-tree of a GRANTA MI Table.

        Arguments:
            _req - :py:mod:`GetChildNodes <GRANTA_MIScriptingToolkit.GetChildNodes>` object
        Returns:
            :py:mod:`GetChildNodesResponse <GRANTA_MIScriptingToolkit.GetChildNodesResponse>` object
        
        """
        if not isinstance(_req, GetChildNodes):
            raise GRANTA_Exception('Browse.GetChildNodes','Browse.GetChildNodes(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetChildNodes')

        startTime = time.clock()
        func = self.lib.Browse_GetChildNodes
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetChildNodesResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetChildNodes() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetChildNodes')
        return response

    def GetTables(self, _req):
        """List the tables contained in a particular GRANTA MI Database.

        Arguments:
            _req - :py:mod:`GetTables <GRANTA_MIScriptingToolkit.GetTables>` object
        Returns:
            :py:mod:`GetTablesResponse <GRANTA_MIScriptingToolkit.GetTablesResponse>` object
        
        """
        if not isinstance(_req, GetTables):
            raise GRANTA_Exception('Browse.GetTables','Browse.GetTables(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetTables')

        startTime = time.clock()
        func = self.lib.Browse_GetTables
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetTablesResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetTables() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetTables')
        return response

    def GetRecordVersions(self, _req):
        """Returns version information about the records specified in the request object.

        Arguments:
            _req - :py:mod:`GetRecordVersionsRequest <GRANTA_MIScriptingToolkit.GetRecordVersionsRequest>` object
        Returns:
            :py:mod:`GetRecordVersionsResponse <GRANTA_MIScriptingToolkit.GetRecordVersionsResponse>` object
        
        """
        if not isinstance(_req, GetRecordVersionsRequest):
            raise GRANTA_Exception('Browse.GetRecordVersions','Browse.GetRecordVersions(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetRecordVersionsRequest')

        startTime = time.clock()
        func = self.lib.Browse_GetRecordVersions
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetRecordVersionsResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetRecordVersions() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetRecordVersions')
        return response

    def GetParameterDetails(self, _req):
        """Returns detailed information about the given Parameter(s) in a GRANTA MI Database.

        Arguments:
            _req - :py:mod:`GetParameterDetailsRequest <GRANTA_MIScriptingToolkit.GetParameterDetailsRequest>` object
        Returns:
            :py:mod:`GetParameterDetailsResponse <GRANTA_MIScriptingToolkit.GetParameterDetailsResponse>` object
        
        """
        if not isinstance(_req, GetParameterDetailsRequest):
            raise GRANTA_Exception('Browse.GetParameterDetails','Browse.GetParameterDetails(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetParameterDetailsRequest')

        startTime = time.clock()
        func = self.lib.Browse_GetParameterDetails
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetParameterDetailsResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetParameterDetails() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetParameterDetails')
        return response

    def GetRootNode(self, _req):
        """Returns information about the root node of a particular Table in a GRANTA MI Database. This can be passed to GetChildNodes operation to find the contents of the rest of the node-tree of the Table.

        Arguments:
            _req - :py:mod:`GetRootNode <GRANTA_MIScriptingToolkit.GetRootNode>` object
        Returns:
            :py:mod:`GetRootNodeResponse <GRANTA_MIScriptingToolkit.GetRootNodeResponse>` object
        
        """
        if not isinstance(_req, GetRootNode):
            raise GRANTA_Exception('Browse.GetRootNode','Browse.GetRootNode(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetRootNode')

        startTime = time.clock()
        func = self.lib.Browse_GetRootNode
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetRootNodeResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetRootNode() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetRootNode')
        return response

    def GetTreeRecords(self, _req):
        """Returns name, record type, and some tree information for the given record(s). Does not retrieve the tree children; for that, use the GetChildRecords operation.

        Arguments:
            _req - :py:mod:`GetTreeRecordsRequest <GRANTA_MIScriptingToolkit.GetTreeRecordsRequest>` object
        Returns:
            :py:mod:`GetTreeRecordsResponse <GRANTA_MIScriptingToolkit.GetTreeRecordsResponse>` object
        
        """
        if not isinstance(_req, GetTreeRecordsRequest):
            raise GRANTA_Exception('Browse.GetTreeRecords','Browse.GetTreeRecords(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetTreeRecordsRequest')

        startTime = time.clock()
        func = self.lib.Browse_GetTreeRecords
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetTreeRecordsResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetTreeRecords() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetTreeRecords')
        return response

    def GetRecordLinkGroups(self, _req):
        """Gets details of Record Link Groups in a Granta MI Database.

        Arguments:
            _req - :py:mod:`GetRecordLinkGroups <GRANTA_MIScriptingToolkit.GetRecordLinkGroups>` object
        Returns:
            :py:mod:`GetRecordLinkGroupsResponse <GRANTA_MIScriptingToolkit.GetRecordLinkGroupsResponse>` object
        
        """
        if not isinstance(_req, GetRecordLinkGroups):
            raise GRANTA_Exception('Browse.GetRecordLinkGroups','Browse.GetRecordLinkGroups(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetRecordLinkGroups')

        startTime = time.clock()
        func = self.lib.Browse_GetRecordLinkGroups
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetRecordLinkGroupsResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetRecordLinkGroups() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetRecordLinkGroups')
        return response

    def GetRecordAttributes(self, _req):
        """Returns information about which Attributes have Data, for given Record(s). Includes information about when Data was created and retired, in a Version-Controlled Table. Does not retrieve values of the Data; for that, use the DataExport or EngineeringData services.

        Arguments:
            _req - :py:mod:`GetRecordAttributesRequest <GRANTA_MIScriptingToolkit.GetRecordAttributesRequest>` object
        Returns:
            :py:mod:`GetRecordAttributesResponse <GRANTA_MIScriptingToolkit.GetRecordAttributesResponse>` object
        
        """
        if not isinstance(_req, GetRecordAttributesRequest):
            raise GRANTA_Exception('Browse.GetRecordAttributes','Browse.GetRecordAttributes(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetRecordAttributesRequest')

        startTime = time.clock()
        func = self.lib.Browse_GetRecordAttributes
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetRecordAttributesResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetRecordAttributes() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetRecordAttributes')
        return response

    def GetAttributeDetails(self, _req):
        """Returns detailed meta-information about given Attribute(s) in a GRANTA MI Database. Does not retrieve values of the Data; for that, use the DataExport service.

        Arguments:
            _req - :py:mod:`GetAttributeDetailsRequest <GRANTA_MIScriptingToolkit.GetAttributeDetailsRequest>` object
        Returns:
            :py:mod:`GetAttributeDetailsResponse <GRANTA_MIScriptingToolkit.GetAttributeDetailsResponse>` object
        
        """
        if not isinstance(_req, GetAttributeDetailsRequest):
            raise GRANTA_Exception('Browse.GetAttributeDetails','Browse.GetAttributeDetails(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetAttributeDetailsRequest')

        startTime = time.clock()
        func = self.lib.Browse_GetAttributeDetails
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetAttributeDetailsResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetAttributeDetails() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetAttributeDetails')
        return response

    def GetDatabases(self):
        """List the databases available on the GRANTA MI Server.

        Arguments:
        Returns:
            :py:mod:`GetDatabasesResponse <GRANTA_MIScriptingToolkit.GetDatabasesResponse>` object
        
        """

        startTime = time.clock()
        func = self.lib.Browse_GetDatabases
        func.argtypes = [POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj)
        response = GetDatabasesResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetDatabases() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetDatabases')
        return response


    def GetSubsets(self, _req):
        """List the Subsets for a GRANTA MI Database or for one Table in a Database.

        Arguments:
            _req - :py:mod:`GetSubsetsRequest <GRANTA_MIScriptingToolkit.GetSubsetsRequest>` object
        Returns:
            :py:mod:`GetSubsetsResponse <GRANTA_MIScriptingToolkit.GetSubsetsResponse>` object
        
        """
        if not isinstance(_req, GetSubsetsRequest):
            raise GRANTA_Exception('Browse.GetSubsets','Browse.GetSubsets(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetSubsetsRequest')

        startTime = time.clock()
        func = self.lib.Browse_GetSubsets
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetSubsetsResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Browse.GetSubsets() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Browse.GetSubsets')
        return response


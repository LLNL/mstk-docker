# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.MIParameterValue import MIParameterValue
from GRANTA_MIScriptingToolkit.RevisionInfo import RevisionInfo
from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference
from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.UnitInformation import UnitInformation
from GRANTA_MIScriptingToolkit.ParameterReference import ParameterReference


class ParameterDetail(object):
    """ParameterDetail. Detailed information about a Parameter in a GRANTA MI Database.
    
        Arguments:
                * parameterType - type int
                * appliesToAttribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * name - type str
                * appliesToRecord - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * parameterValues - type list of :py:mod:`MIParameterValue <GRANTA_MIScriptingToolkit.MIParameterValue>` objects
                * defaultValue - type :py:mod:`MIParameterValue <GRANTA_MIScriptingToolkit.MIParameterValue>`
                * revisionInfo - type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`
                * interpolationType - type int
                * parameterReference - type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`
                * order - type int
                * unit - type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`
                * scaleType - type int


    """
    class ParameterType:
        NumericUnrestricted = 0
        NumericRestricted = 1
        Discrete = 2
    class ScaleType:
        NotSet = 0
        Linear = 1
        Log = 2
    class Interpolation:
        NONE = 0
        Linear = 1
        CubicSpline = 2
    
    def __init__(self, parameterType=None, appliesToAttribute=None, name=None, appliesToRecord=None, parameterValues=None, defaultValue=None, revisionInfo=None, interpolationType=None, parameterReference=None, order=None, unit=None, scaleType=None, isOwner=True):
        """

        Arguments:
                * parameterType - type int
                * appliesToAttribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * name - type str
                * appliesToRecord - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * parameterValues - type list of :py:mod:`MIParameterValue <GRANTA_MIScriptingToolkit.MIParameterValue>` objects
                * defaultValue - type :py:mod:`MIParameterValue <GRANTA_MIScriptingToolkit.MIParameterValue>`
                * revisionInfo - type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`
                * interpolationType - type int
                * parameterReference - type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`
                * order - type int
                * unit - type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`
                * scaleType - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ParameterDetail_Create = self.lib.ParameterDetail_Create
            ParameterDetail_Create.restype = POINTER(c_void_p)
            self.c_obj = ParameterDetail_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if parameterType is not None:
            self.parameterType = parameterType
        if appliesToAttribute is not None:
            self.appliesToAttribute = appliesToAttribute
        if name is not None:
            self.name = name
        if appliesToRecord is not None:
            self.appliesToRecord = appliesToRecord
        if parameterValues is not None:
            self.parameterValues = parameterValues
        if defaultValue is not None:
            self.defaultValue = defaultValue
        if revisionInfo is not None:
            self.revisionInfo = revisionInfo
        if interpolationType is not None:
            self.interpolationType = interpolationType
        if parameterReference is not None:
            self.parameterReference = parameterReference
        if order is not None:
            self.order = order
        if unit is not None:
            self.unit = unit
        if scaleType is not None:
            self.scaleType = scaleType


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ParameterDetail_Destroy = self.lib.ParameterDetail_Destroy
            ParameterDetail_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ParameterDetail_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def parameterType(self):
        """Property parameterType is of type int. See :py:class:`ParameterDetail.ParameterType <ParameterDetail.ParameterType>` for supported values.""" 
        self._parameterType = self.__GetParameterType()
        return self._parameterType

    @parameterType.setter
    def parameterType(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('parameterType','parameterType: Invalid type parameterType must be of type int')
        
        self._parameterType = value

    @property
    def appliesToAttribute(self):
        """Property appliesToAttribute is of type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`. """ 
        self._appliesToAttribute = self.__GetAppliesToAttribute()
        return self._appliesToAttribute

    @appliesToAttribute.setter
    def appliesToAttribute(self, value):
        if not isinstance(value, AttributeReference):
            raise GRANTA_Exception('appliesToAttribute','appliesToAttribute: Invalid type appliesToAttribute must be of type AttributeReference')
        
        self._appliesToAttribute = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    @property
    def appliesToRecord(self):
        """Property appliesToRecord is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._appliesToRecord = self.__GetAppliesToRecord()
        return self._appliesToRecord

    @appliesToRecord.setter
    def appliesToRecord(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('appliesToRecord','appliesToRecord: Invalid type appliesToRecord must be of type RecordReference')
        
        self._appliesToRecord = value

    @property
    def parameterValues(self):
        """Property parameterValues is a list of :py:mod:`MIParameterValue <GRANTA_MIScriptingToolkit.MIParameterValue>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._parameterValues = self.__GetParameterValues()
        except:
            pass
        return self._parameterValues

    @parameterValues.setter
    def parameterValues(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('parameterValues','parameterValues: Invalid type parameterValues must be a list of MIParameterValue')
        
        self._parameterValues = value

    @property
    def defaultValue(self):
        """Property defaultValue is of type :py:mod:`MIParameterValue <GRANTA_MIScriptingToolkit.MIParameterValue>`. """ 
        self._defaultValue = self.__GetDefaultValue()
        return self._defaultValue

    @defaultValue.setter
    def defaultValue(self, value):
        if not isinstance(value, MIParameterValue):
            raise GRANTA_Exception('defaultValue','defaultValue: Invalid type defaultValue must be of type MIParameterValue')
        
        self._defaultValue = value

    @property
    def revisionInfo(self):
        """Property revisionInfo is of type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`. """ 
        self._revisionInfo = self.__GetRevisionInfo()
        return self._revisionInfo

    @revisionInfo.setter
    def revisionInfo(self, value):
        if not isinstance(value, RevisionInfo):
            raise GRANTA_Exception('revisionInfo','revisionInfo: Invalid type revisionInfo must be of type RevisionInfo')
        
        self._revisionInfo = value

    @property
    def interpolationType(self):
        """Property interpolationType is of type int. See :py:class:`ParameterDetail.Interpolation <ParameterDetail.Interpolation>` for supported values.""" 
        self._interpolationType = self.__GetInterpolationType()
        return self._interpolationType

    @interpolationType.setter
    def interpolationType(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('interpolationType','interpolationType: Invalid type interpolationType must be of type int')
        
        self._interpolationType = value

    @property
    def parameterReference(self):
        """Property parameterReference is of type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`. """ 
        self._parameterReference = self.__GetParameterReference()
        return self._parameterReference

    @parameterReference.setter
    def parameterReference(self, value):
        if not isinstance(value, ParameterReference):
            raise GRANTA_Exception('parameterReference','parameterReference: Invalid type parameterReference must be of type ParameterReference')
        self.__SetParameterReference(value)
        self._parameterReference = value

    @property
    def order(self):
        """Property order is of type int. """ 
        self._order = self.__GetOrder()
        return self._order

    @order.setter
    def order(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('order','order: Invalid type order must be of type int')
        
        self._order = value

    @property
    def unit(self):
        """Property unit is of type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`. """ 
        self._unit = self.__GetUnit()
        return self._unit

    @unit.setter
    def unit(self, value):
        if not isinstance(value, UnitInformation):
            raise GRANTA_Exception('unit','unit: Invalid type unit must be of type UnitInformation')
        self.__SetUnit(value)
        self._unit = value

    @property
    def scaleType(self):
        """Property scaleType is of type int. See :py:class:`ParameterDetail.ScaleType <ParameterDetail.ScaleType>` for supported values.""" 
        self._scaleType = self.__GetScaleType()
        return self._scaleType

    @scaleType.setter
    def scaleType(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('scaleType','scaleType: Invalid type scaleType must be of type int')
        
        self._scaleType = value

    def __GetDefaultValue(self):
        _MIParameterValue = MIParameterValue()
        ParameterDetail_GetDefaultValue = self.lib.ParameterDetail_GetDefaultValue
        ParameterDetail_GetDefaultValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ParameterDetail_GetDefaultValue(self._c_obj, (_MIParameterValue.c_obj))
        
        return _MIParameterValue
        
    def __GetScaleType(self):
        ParameterDetail_GetScaleType = self.lib.ParameterDetail_GetScaleType
        ParameterDetail_GetScaleType.argtypes = [POINTER(c_void_p)]
        ParameterDetail_GetScaleType.restype = c_int
        value = ParameterDetail_GetScaleType(self._c_obj)
        return value
    
    def __GetInterpolationType(self):
        ParameterDetail_GetInterpolationType = self.lib.ParameterDetail_GetInterpolationType
        ParameterDetail_GetInterpolationType.argtypes = [POINTER(c_void_p)]
        ParameterDetail_GetInterpolationType.restype = c_int
        value = ParameterDetail_GetInterpolationType(self._c_obj)
        return value
    
    def __GetParameterType(self):
        ParameterDetail_GetParameterType = self.lib.ParameterDetail_GetParameterType
        ParameterDetail_GetParameterType.argtypes = [POINTER(c_void_p)]
        ParameterDetail_GetParameterType.restype = c_int
        value = ParameterDetail_GetParameterType(self._c_obj)
        return value
    
    def __GetRevisionInfo(self):
        _revisionInfo = RevisionInfo()
        ParameterDetail_GetRevisionInfo = self.lib.ParameterDetail_GetRevisionInfo
        ParameterDetail_GetRevisionInfo.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ParameterDetail_GetRevisionInfo(self._c_obj, (_revisionInfo.c_obj))
        
        return _revisionInfo
        
    def __GetNumberOfParameterValues(self):
        ParameterDetail_GetNumberOfParameterValues = self.lib.ParameterDetail_GetNumberOfParameterValues
        ParameterDetail_GetNumberOfParameterValues.argtypes = [POINTER(c_void_p)]
        ParameterDetail_GetNumberOfParameterValues.restype = c_int
        value = ParameterDetail_GetNumberOfParameterValues(self._c_obj)
        return value
    
    def __GetParameterValueElement(self,i):
        value = MIParameterValue()
        ParameterDetail_GetParameterValue = self.lib.ParameterDetail_GetParameterValue
        ParameterDetail_GetParameterValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        ParameterDetail_GetParameterValue(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetParameterValues(self):
         n = self.__GetNumberOfParameterValues();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetParameterValueElement(i))
         return temp
    
    def __GetAppliesToAttribute(self):
        _attributeReference = AttributeReference()
        ParameterDetail_GetAppliesToAttribute = self.lib.ParameterDetail_GetAppliesToAttribute
        ParameterDetail_GetAppliesToAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ParameterDetail_GetAppliesToAttribute(self._c_obj, (_attributeReference.c_obj))
        
        return _attributeReference
        
    def __GetAppliesToRecord(self):
        _recordReference = RecordReference()
        ParameterDetail_GetAppliesToRecord = self.lib.ParameterDetail_GetAppliesToRecord
        ParameterDetail_GetAppliesToRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ParameterDetail_GetAppliesToRecord(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __GetName(self):
        ParameterDetail_GetName = self.lib.ParameterDetail_GetName
        ParameterDetail_GetName.argtypes = [POINTER(c_void_p)]
        ParameterDetail_GetName.restype = POINTER(c_void_p)
        value = ParameterDetail_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        ParameterDetail_SetName = self.lib.ParameterDetail_SetName 
        ParameterDetail_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        ParameterDetail_SetName(self._c_obj, EnsureEncoded(value))

    def __GetUnit(self):
        _unitInformation = UnitInformation()
        ParameterDetail_GetUnit = self.lib.ParameterDetail_GetUnit
        ParameterDetail_GetUnit.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ParameterDetail_GetUnit(self._c_obj, (_unitInformation.c_obj))
        
        return _unitInformation
        
    def __SetUnit(self, value):

        ParameterDetail_SetUnit = self.lib.ParameterDetail_SetUnit 
        ParameterDetail_SetUnit.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ParameterDetail_SetUnit(self._c_obj, value.c_obj)

    def __GetParameterReference(self):
        _parameterReference = ParameterReference()
        ParameterDetail_GetParameterReference = self.lib.ParameterDetail_GetParameterReference
        ParameterDetail_GetParameterReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ParameterDetail_GetParameterReference(self._c_obj, (_parameterReference.c_obj))
        
        return _parameterReference
        
    def __SetParameterReference(self, value):

        ParameterDetail_SetParameterReference = self.lib.ParameterDetail_SetParameterReference 
        ParameterDetail_SetParameterReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ParameterDetail_SetParameterReference(self._c_obj, value.c_obj)

    def __GetOrder(self):
        ParameterDetail_GetOrder = self.lib.ParameterDetail_GetOrder
        ParameterDetail_GetOrder.argtypes = [POINTER(c_void_p)]
        ParameterDetail_GetOrder.restype = c_int
        value = ParameterDetail_GetOrder(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


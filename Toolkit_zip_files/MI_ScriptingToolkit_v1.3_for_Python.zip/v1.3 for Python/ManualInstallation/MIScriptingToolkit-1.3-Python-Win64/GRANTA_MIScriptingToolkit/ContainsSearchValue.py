# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class ContainsSearchValue(object):
    """ContainsSearchValue. Search criterion to search for data that contains the specified search text value. 
Search criterion applies to text, logical, and discrete attributes. For logicals, specify 'true' or 'false' as the text.
    
        Arguments:
                * value - type str


    """
    
    def __init__(self, value=None, isOwner=True):
        """

        Arguments:
                * value - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ContainsSearchValue_Create = self.lib.ContainsSearchValue_Create
            ContainsSearchValue_Create.restype = POINTER(c_void_p)
            self.c_obj = ContainsSearchValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if value is not None:
            self.value = value


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ContainsSearchValue_Destroy = self.lib.ContainsSearchValue_Destroy
            ContainsSearchValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ContainsSearchValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def value(self):
        """Property value is of type str. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('value','value: Invalid type value must be of type str')
        self.__SetValue(value)
        self._value = value

    def __GetValue(self):
        ContainsSearchValue_GetValue = self.lib.ContainsSearchValue_GetValue
        ContainsSearchValue_GetValue.argtypes = [POINTER(c_void_p)]
        ContainsSearchValue_GetValue.restype = POINTER(c_void_p)
        value = ContainsSearchValue_GetValue(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetValue(self, value):

        ContainsSearchValue_SetValue = self.lib.ContainsSearchValue_SetValue 
        ContainsSearchValue_SetValue.argtypes = [POINTER(c_void_p), c_char_p]
        ContainsSearchValue_SetValue(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


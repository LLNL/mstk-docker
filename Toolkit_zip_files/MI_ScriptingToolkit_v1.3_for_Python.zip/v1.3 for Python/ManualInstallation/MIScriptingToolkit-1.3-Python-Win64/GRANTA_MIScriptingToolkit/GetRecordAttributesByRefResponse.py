# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordData import RecordData
from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse


class GetRecordAttributesByRefResponse(object):
    """GetRecordAttributesByRefResponse. Output from the GetRecordAttributesByRef operation.
Includes an array of :py:mod:`RecordData <GRANTA_MIScriptingToolkit.RecordData>` objects and a :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>` object.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetRecordAttributesByRefResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetRecordAttributesByRefResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetRecordAttributesByRefResponse_Destroy = self.lib.GetRecordAttributesByRefResponse_Destroy
            GetRecordAttributesByRefResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetRecordAttributesByRefResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordData(self):
        """Property recordData is a list of :py:mod:`RecordData <GRANTA_MIScriptingToolkit.RecordData>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordData = self.__GetRecordData()
        except:
            pass
        return self._recordData

    @recordData.setter
    def recordData(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordData','recordData: Invalid type recordData must be a list of RecordData')
                
        try:
            self.__updaterecordData = True
            self.__ClearRecordData()
            for v in value:
                self.AddRecordData(v)
        except:
            pass


    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    def __GetNumberOfRecordData(self):
        GetRecordAttributesByRefResponse_GetNumberOfRecordData = self.lib.GetRecordAttributesByRefResponse_GetNumberOfRecordData
        GetRecordAttributesByRefResponse_GetNumberOfRecordData.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesByRefResponse_GetNumberOfRecordData.restype = c_int
        value = GetRecordAttributesByRefResponse_GetNumberOfRecordData(self._c_obj)
        return value
    
    def __GetRecordDataElement(self,i):
        value = RecordData()
        GetRecordAttributesByRefResponse_GetRecordData = self.lib.GetRecordAttributesByRefResponse_GetRecordData
        GetRecordAttributesByRefResponse_GetRecordData.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetRecordAttributesByRefResponse_GetRecordData(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordData(self):
         n = self.__GetNumberOfRecordData();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordDataElement(i))
         return temp
    
    def AddRecordData(self, _recordData):
        """Appends _recordData to recordData property on GetRecordAttributesByRefResponse C-object.

           Arguments:
                _recordData - object of type RecordData.
        """

        if not isinstance(_recordData, RecordData):
            raise GRANTA_Exception('GetRecordAttributesByRefResponse.AddRecordData','_recordData: Invalid argument type _recordData must be of type RecordData')
        GetRecordAttributesByRefResponse_AddRecordData = self.lib.GetRecordAttributesByRefResponse_AddRecordData
        GetRecordAttributesByRefResponse_AddRecordData.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRecordAttributesByRefResponse_AddRecordData(self._c_obj, _recordData.c_obj)
        return self

    def __ClearRecordData(self):
        GetRecordAttributesByRefResponse_ClearRecordData = self.lib.GetRecordAttributesByRefResponse_ClearRecordData
        GetRecordAttributesByRefResponse_ClearRecordData.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesByRefResponse_ClearRecordData(self._c_obj)
        return self

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetRecordAttributesByRefResponse_GetServiceLayerResponse = self.lib.GetRecordAttributesByRefResponse_GetServiceLayerResponse
        GetRecordAttributesByRefResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetRecordAttributesByRefResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


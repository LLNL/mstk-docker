# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.Constraints import Constraints


class FloatFunctionalRangeValue(object):
    """FloatFunctionalRangeValue. A single grid point in Gridded Float-Valued Functional Data, where the Y-axis value is a range.
    
        Arguments:
                * lowValue - type float
                * estimated - type bool
                * highValue - type float
                * constraints - type :py:mod:`Constraints <GRANTA_MIScriptingToolkit.Constraints>`


    """
    
    def __init__(self, lowValue=None, estimated=None, highValue=None, constraints=None, isOwner=True):
        """

        Arguments:
                * lowValue - type float
                * estimated - type bool
                * highValue - type float
                * constraints - type :py:mod:`Constraints <GRANTA_MIScriptingToolkit.Constraints>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            FloatFunctionalRangeValue_Create = self.lib.FloatFunctionalRangeValue_Create
            FloatFunctionalRangeValue_Create.restype = POINTER(c_void_p)
            self.c_obj = FloatFunctionalRangeValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if lowValue is not None:
            self.lowValue = lowValue
        if estimated is not None:
            self.estimated = estimated
        if highValue is not None:
            self.highValue = highValue
        if constraints is not None:
            self.constraints = constraints


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            FloatFunctionalRangeValue_Destroy = self.lib.FloatFunctionalRangeValue_Destroy
            FloatFunctionalRangeValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            FloatFunctionalRangeValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def lowValue(self):
        """Property lowValue is of type float. """ 
        self._lowValue = self.__GetLowValue()
        return self._lowValue

    @lowValue.setter
    def lowValue(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('lowValue','lowValue: Invalid type lowValue must be of type float')
        self.__SetLowValue(value)
        self._lowValue = value

    @property
    def estimated(self):
        """Property estimated is of type bool. """ 
        self._estimated = self.__GetEstimated()
        return self._estimated

    @estimated.setter
    def estimated(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('estimated','estimated: Invalid type estimated must be of type bool')
        self.__SetEstimated(value)
        self._estimated = value

    @property
    def highValue(self):
        """Property highValue is of type float. """ 
        self._highValue = self.__GetHighValue()
        return self._highValue

    @highValue.setter
    def highValue(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('highValue','highValue: Invalid type highValue must be of type float')
        self.__SetHighValue(value)
        self._highValue = value

    @property
    def constraints(self):
        """Property constraints is of type :py:mod:`Constraints <GRANTA_MIScriptingToolkit.Constraints>`. """ 
        self._constraints = self.__GetConstraints()
        return self._constraints

    @constraints.setter
    def constraints(self, value):
        if not isinstance(value, Constraints):
            raise GRANTA_Exception('constraints','constraints: Invalid type constraints must be of type Constraints')
        self.__SetConstraints(value)
        self._constraints = value

    def __GetConstraints(self):
        _constraints = Constraints()
        FloatFunctionalRangeValue_GetConstraints = self.lib.FloatFunctionalRangeValue_GetConstraints
        FloatFunctionalRangeValue_GetConstraints.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        FloatFunctionalRangeValue_GetConstraints(self._c_obj, (_constraints.c_obj))
        
        return _constraints
        
    def __SetConstraints(self, value):

        FloatFunctionalRangeValue_SetConstraints = self.lib.FloatFunctionalRangeValue_SetConstraints 
        FloatFunctionalRangeValue_SetConstraints.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalRangeValue_SetConstraints(self._c_obj, value.c_obj)

    def __SetEstimated(self, value):

        FloatFunctionalRangeValue_SetEstimated = self.lib.FloatFunctionalRangeValue_SetEstimated 
        FloatFunctionalRangeValue_SetEstimated.argtypes = [POINTER(c_void_p), c_bool]
        FloatFunctionalRangeValue_SetEstimated(self._c_obj, value)

    def __GetEstimated(self):
        FloatFunctionalRangeValue_GetEstimated = self.lib.FloatFunctionalRangeValue_GetEstimated
        FloatFunctionalRangeValue_GetEstimated.argtypes = [POINTER(c_void_p)]
        FloatFunctionalRangeValue_GetEstimated.restype = c_bool
        value = FloatFunctionalRangeValue_GetEstimated(self._c_obj)
        return value
    
    def __GetLowValue(self):
        FloatFunctionalRangeValue_GetLowValue = self.lib.FloatFunctionalRangeValue_GetLowValue
        FloatFunctionalRangeValue_GetLowValue.argtypes = [POINTER(c_void_p)]
        FloatFunctionalRangeValue_GetLowValue.restype = c_double
        value = FloatFunctionalRangeValue_GetLowValue(self._c_obj)
        return value
    
    def __SetLowValue(self, value):

        FloatFunctionalRangeValue_SetLowValue = self.lib.FloatFunctionalRangeValue_SetLowValue 
        FloatFunctionalRangeValue_SetLowValue.argtypes = [POINTER(c_void_p), c_double]
        FloatFunctionalRangeValue_SetLowValue(self._c_obj, value)

    def __GetHighValue(self):
        FloatFunctionalRangeValue_GetHighValue = self.lib.FloatFunctionalRangeValue_GetHighValue
        FloatFunctionalRangeValue_GetHighValue.argtypes = [POINTER(c_void_p)]
        FloatFunctionalRangeValue_GetHighValue.restype = c_double
        value = FloatFunctionalRangeValue_GetHighValue(self._c_obj)
        return value
    
    def __SetHighValue(self, value):

        FloatFunctionalRangeValue_SetHighValue = self.lib.FloatFunctionalRangeValue_SetHighValue 
        FloatFunctionalRangeValue_SetHighValue.argtypes = [POINTER(c_void_p), c_double]
        FloatFunctionalRangeValue_SetHighValue(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value



import logging
import os
import time
from datetime import date

class GRANTA_Logging(object):
    """ GRANTA_Logging. Class for logging to file.
        On Windows, logs are created in %LOCALAPPDATA%/Granta Design/MIScriptingToolkit/Python.
        On Linux operating systems, logs are created in ~/.appdata/Granta Design/MIScriptingToolkit/Python
    """
    # whether to print logs to console
    propagate = True
    
    def __init__(self):
        locAppData = os.getenv('LOCALAPPDATA')
        loggingFolder = os.path.join(locAppData, 'Granta Design/MIScriptingToolkit/Python')
        try:
            os.makedirs(loggingFolder)
        except:
            if not os.path.exists(loggingFolder):
                raise
    
        #create logger
        logger = logging.getLogger('GDL')
        today = date.today()
        logger.propagate = GRANTA_Logging.propagate
        if not len(logger.handlers):
            today = date.today()
            loggingFile = loggingFolder+'\MIScriptingToolkitForPython_'+str(today.year)+'.'+today.strftime('%m')+'.'+today.strftime('%d')+'.log'
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            fh = logging.FileHandler(filename=loggingFile)
            fh.setFormatter(formatter)
            fh.setLevel(logging.ERROR)
            logger.addHandler(fh)
            if GRANTA_Logging.propagate:
                ch = logging.StreamHandler()
                ch.setLevel(logging.ERROR)
                ch.setFormatter(formatter)
                logger.addHandler(ch)
        
        self.logger = logger
        
    
    def info(self, message):
        self.logger.info(message)
        
    def debug(self, message):
        self.logger.debug(message)
    
    def warning(self, message):
        self.logger.warning(message)
    
    def error(self, message):
        self.logger.error(message)
        

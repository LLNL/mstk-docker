# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse
from GRANTA_MIScriptingToolkit.ParameterDetail import ParameterDetail


class GetAttributeParametersResponse(object):
    """GetAttributeParametersResponse. Output from the GetAttributeParameters operation. 
Includes an array of :py:mod:`ParameterDetail <GRANTA_MIScriptingToolkit.ParameterDetail>` objects and a :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>` object.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetAttributeParametersResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetAttributeParametersResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetAttributeParametersResponse_Destroy = self.lib.GetAttributeParametersResponse_Destroy
            GetAttributeParametersResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetAttributeParametersResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        self.__SetServiceLayerResponse(value)
        self._serviceLayerResponse = value

    @property
    def attributeParameters(self):
        """Property attributeParameters is a list of :py:mod:`ParameterDetail <GRANTA_MIScriptingToolkit.ParameterDetail>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeParameters = self.__GetAttributeParameters()
        except:
            pass
        return self._attributeParameters

    @attributeParameters.setter
    def attributeParameters(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeParameters','attributeParameters: Invalid type attributeParameters must be a list of ParameterDetail')
        
        self._attributeParameters = value

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetAttributeParametersResponse_GetServiceLayerResponse = self.lib.GetAttributeParametersResponse_GetServiceLayerResponse
        GetAttributeParametersResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetAttributeParametersResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __SetServiceLayerResponse(self, value):

        GetAttributeParametersResponse_SetServiceLayerResponse = self.lib.GetAttributeParametersResponse_SetServiceLayerResponse 
        GetAttributeParametersResponse_SetServiceLayerResponse.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetAttributeParametersResponse_SetServiceLayerResponse(self._c_obj, value.c_obj)

    def __GetNumberOfAttributeParameters(self):
        GetAttributeParametersResponse_GetNumberOfAttributeParameters = self.lib.GetAttributeParametersResponse_GetNumberOfAttributeParameters
        GetAttributeParametersResponse_GetNumberOfAttributeParameters.argtypes = [POINTER(c_void_p)]
        GetAttributeParametersResponse_GetNumberOfAttributeParameters.restype = c_int
        value = GetAttributeParametersResponse_GetNumberOfAttributeParameters(self._c_obj)
        return value
    
    def __GetAttributeParameterElement(self,i):
        value = ParameterDetail()
        GetAttributeParametersResponse_GetAttributeParameter = self.lib.GetAttributeParametersResponse_GetAttributeParameter
        GetAttributeParametersResponse_GetAttributeParameter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetAttributeParametersResponse_GetAttributeParameter(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributeParameters(self):
         n = self.__GetNumberOfAttributeParameters();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeParameterElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


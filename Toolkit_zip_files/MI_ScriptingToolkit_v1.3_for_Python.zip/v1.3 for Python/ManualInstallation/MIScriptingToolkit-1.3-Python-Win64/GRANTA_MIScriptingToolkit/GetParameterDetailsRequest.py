# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterReference import ParameterReference
from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference
from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class GetParameterDetailsRequest(object):
    """GetParameterDetailsRequest. Input for the GetParameterDetails operation. 
    
        Arguments:
                * attribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * parameterReferences - type list of :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>` objects
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`


    """
    
    def __init__(self, attribute=None, parameterReferences=None, recordReference=None, isOwner=True):
        """

        Arguments:
                * attribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * parameterReferences - type list of :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>` objects
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetParameterDetailsRequest_Create = self.lib.GetParameterDetailsRequest_Create
            GetParameterDetailsRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetParameterDetailsRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if attribute is not None:
            self.attribute = attribute
        if parameterReferences is not None:
            self.parameterReferences = parameterReferences
        if recordReference is not None:
            self.recordReference = recordReference


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetParameterDetailsRequest_Destroy = self.lib.GetParameterDetailsRequest_Destroy
            GetParameterDetailsRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetParameterDetailsRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def attribute(self):
        """Property attribute is of type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`. """ 
        self._attribute = self.__GetAttribute()
        return self._attribute

    @attribute.setter
    def attribute(self, value):
        if not isinstance(value, AttributeReference):
            raise GRANTA_Exception('attribute','attribute: Invalid type attribute must be of type AttributeReference')
        self.__SetAttribute(value)
        self._attribute = value

    @property
    def parameterReferences(self):
        """Property parameterReferences is a list of :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._parameterReferences = self.__GetParameterReferences()
        except:
            pass
        return self._parameterReferences

    @parameterReferences.setter
    def parameterReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('parameterReferences','parameterReferences: Invalid type parameterReferences must be a list of ParameterReference')
                
        try:
            self.__updateparameterReferences = True
            self.__ClearParameterReferences()
            for v in value:
                self.AddParameterReference(v)
        except:
            pass


    @property
    def recordReference(self):
        """Property recordReference is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._recordReference = self.__GetRecordReference()
        return self._recordReference

    @recordReference.setter
    def recordReference(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('recordReference','recordReference: Invalid type recordReference must be of type RecordReference')
        self.__SetRecordReference(value)
        self._recordReference = value

    def __GetNumberOfParameterReferences(self):
        GetParameterDetailsRequest_GetNumberOfParameterReferences = self.lib.GetParameterDetailsRequest_GetNumberOfParameterReferences
        GetParameterDetailsRequest_GetNumberOfParameterReferences.argtypes = [POINTER(c_void_p)]
        GetParameterDetailsRequest_GetNumberOfParameterReferences.restype = c_int
        value = GetParameterDetailsRequest_GetNumberOfParameterReferences(self._c_obj)
        return value
    
    def __GetParameterReferenceElement(self,i):
        value = ParameterReference()
        GetParameterDetailsRequest_GetParameterReference = self.lib.GetParameterDetailsRequest_GetParameterReference
        GetParameterDetailsRequest_GetParameterReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetParameterDetailsRequest_GetParameterReference(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetParameterReferences(self):
         n = self.__GetNumberOfParameterReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetParameterReferenceElement(i))
         return temp
    
    def __ClearParameterReferences(self):
        GetParameterDetailsRequest_ClearParameterReferences = self.lib.GetParameterDetailsRequest_ClearParameterReferences
        GetParameterDetailsRequest_ClearParameterReferences.argtypes = [POINTER(c_void_p)]
        GetParameterDetailsRequest_ClearParameterReferences(self._c_obj)
        return self

    def AddParameterReference(self, _parameterReference):
        """Appends _parameterReference to parameterReferences property on GetParameterDetailsRequest C-object.

           Arguments:
                _parameterReference - object of type ParameterReference.
        """

        if not isinstance(_parameterReference, ParameterReference):
            raise GRANTA_Exception('GetParameterDetailsRequest.AddParameterReference','_parameterReference: Invalid argument type _parameterReference must be of type ParameterReference')
        GetParameterDetailsRequest_AddParameterReference = self.lib.GetParameterDetailsRequest_AddParameterReference
        GetParameterDetailsRequest_AddParameterReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetParameterDetailsRequest_AddParameterReference(self._c_obj, _parameterReference.c_obj)
        return self

    def __GetAttribute(self):
        _attributeReference = AttributeReference()
        GetParameterDetailsRequest_GetAttribute = self.lib.GetParameterDetailsRequest_GetAttribute
        GetParameterDetailsRequest_GetAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetParameterDetailsRequest_GetAttribute(self._c_obj, (_attributeReference.c_obj))
        
        return _attributeReference
        
    def __SetAttribute(self, value):

        GetParameterDetailsRequest_SetAttribute = self.lib.GetParameterDetailsRequest_SetAttribute 
        GetParameterDetailsRequest_SetAttribute.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetParameterDetailsRequest_SetAttribute(self._c_obj, value.c_obj)

    def __GetRecordReference(self):
        _recordReference = RecordReference()
        GetParameterDetailsRequest_GetRecordReference = self.lib.GetParameterDetailsRequest_GetRecordReference
        GetParameterDetailsRequest_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetParameterDetailsRequest_GetRecordReference(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __SetRecordReference(self, value):

        GetParameterDetailsRequest_SetRecordReference = self.lib.GetParameterDetailsRequest_SetRecordReference 
        GetParameterDetailsRequest_SetRecordReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetParameterDetailsRequest_SetRecordReference(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.TableReference import TableReference


class GetRootNode(object):
    """GetRootNode. Input to the GetRootNode operation.
Requires a :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>` .
    
        Arguments:
                * table - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`


    """
    
    def __init__(self, table=None, isOwner=True):
        """

        Arguments:
                * table - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetRootNode_Create = self.lib.GetRootNode_Create
            GetRootNode_Create.restype = POINTER(c_void_p)
            self.c_obj = GetRootNode_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if table is not None:
            self.table = table


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetRootNode_Destroy = self.lib.GetRootNode_Destroy
            GetRootNode_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetRootNode_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def table(self):
        """Property table is of type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`. """ 
        self._table = self.__GetTable()
        return self._table

    @table.setter
    def table(self, value):
        if not isinstance(value, TableReference):
            raise GRANTA_Exception('table','table: Invalid type table must be of type TableReference')
        self.__SetTable(value)
        self._table = value

    def __SetTable(self, value):

        GetRootNode_SetTable = self.lib.GetRootNode_SetTable 
        GetRootNode_SetTable.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRootNode_SetTable(self._c_obj, value.c_obj)

    def __GetTable(self):
        _tableReference = TableReference()
        GetRootNode_GetTable = self.lib.GetRootNode_GetTable
        GetRootNode_GetTable.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetRootNode_GetTable(self._c_obj, (_tableReference.c_obj))
        
        return _tableReference
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


import GRANTA_MIScriptingToolkit

class IDataValue(object):
    """ Base class for data values in GRANTA MI.

You should not interact directly with this class."""
    pass
# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class UnlinkAllRecords(object):
    """UnlinkAllRecords. For each given source record, remove all links in the Record Link Group.
    
        Arguments:
                * sourceRecords - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * nodeName - type str


    """
    
    def __init__(self, sourceRecords=None, nodeName=None, isOwner=True):
        """

        Arguments:
                * sourceRecords - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * nodeName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            UnlinkAllRecords_Create = self.lib.UnlinkAllRecords_Create
            UnlinkAllRecords_Create.restype = POINTER(c_void_p)
            self.c_obj = UnlinkAllRecords_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if sourceRecords is not None:
            self.sourceRecords = sourceRecords
        if nodeName is not None:
            self.nodeName = nodeName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            UnlinkAllRecords_Destroy = self.lib.UnlinkAllRecords_Destroy
            UnlinkAllRecords_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            UnlinkAllRecords_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def sourceRecords(self):
        """Property sourceRecords is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._sourceRecords = self.__GetSourceRecords()
        except:
            pass
        return self._sourceRecords

    @sourceRecords.setter
    def sourceRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('sourceRecords','sourceRecords: Invalid type sourceRecords must be a list of RecordReference')
                
        try:
            self.__updatesourceRecords = True
            self.__ClearSourceRecords()
            for v in value:
                self.AddSourceRecord(v)
        except:
            pass


    @property
    def nodeName(self):
        """Property nodeName is of type str. """ 
        self._nodeName = self.__GetNodeName()
        return self._nodeName

    @nodeName.setter
    def nodeName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('nodeName','nodeName: Invalid type nodeName must be of type str')
        
        self._nodeName = value

    def __GetNodeName(self):
        UnlinkAllRecords_GetNodeName = self.lib.UnlinkAllRecords_GetNodeName
        UnlinkAllRecords_GetNodeName.argtypes = [POINTER(c_void_p)]
        UnlinkAllRecords_GetNodeName.restype = POINTER(c_void_p)
        value = UnlinkAllRecords_GetNodeName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def AddSourceRecord(self, _recordReference):
        """Appends _recordReference to sourceRecords property on UnlinkAllRecords C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('UnlinkAllRecords.AddSourceRecord','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        UnlinkAllRecords_AddSourceRecord = self.lib.UnlinkAllRecords_AddSourceRecord
        UnlinkAllRecords_AddSourceRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        UnlinkAllRecords_AddSourceRecord(self._c_obj, _recordReference.c_obj)
        return self

    def __ClearSourceRecords(self):
        UnlinkAllRecords_ClearSourceRecords = self.lib.UnlinkAllRecords_ClearSourceRecords
        UnlinkAllRecords_ClearSourceRecords.argtypes = [POINTER(c_void_p)]
        UnlinkAllRecords_ClearSourceRecords(self._c_obj)
        return self

    def __GetNumberOfSourceRecords(self):
        UnlinkAllRecords_GetNumberOfSourceRecords = self.lib.UnlinkAllRecords_GetNumberOfSourceRecords
        UnlinkAllRecords_GetNumberOfSourceRecords.argtypes = [POINTER(c_void_p)]
        UnlinkAllRecords_GetNumberOfSourceRecords.restype = c_int
        value = UnlinkAllRecords_GetNumberOfSourceRecords(self._c_obj)
        return value
    
    def __GetSourceRecordsElement(self,i):
        value = RecordReference()
        UnlinkAllRecords_GetSourceRecords = self.lib.UnlinkAllRecords_GetSourceRecords
        UnlinkAllRecords_GetSourceRecords.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        UnlinkAllRecords_GetSourceRecords(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetSourceRecords(self):
         n = self.__GetNumberOfSourceRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetSourceRecordsElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


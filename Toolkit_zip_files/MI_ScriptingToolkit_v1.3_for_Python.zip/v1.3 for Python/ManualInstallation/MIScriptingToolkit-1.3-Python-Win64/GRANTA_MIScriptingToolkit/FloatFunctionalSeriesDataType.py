# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.FloatFunctionalSeriesGraph import FloatFunctionalSeriesGraph
from GRANTA_MIScriptingToolkit.UnitInformation import UnitInformation
from GRANTA_MIScriptingToolkit.Parameters import Parameters

from .IDataValue import IDataValue


class FloatFunctionalSeriesDataType(IDataValue):
    """FloatFunctionalSeriesDataType. A type to contain the values of float-valued functional series data.
For requests Graph, and :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>` are required.
    
        Arguments:
                * graph - type :py:mod:`FloatFunctionalSeriesGraph <GRANTA_MIScriptingToolkit.FloatFunctionalSeriesGraph>`
                * parameters - type :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>`
                * unitInformation - type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`


    """
    
    def __init__(self, graph=None, parameters=None, unitInformation=None, isOwner=True):
        """

        Arguments:
                * graph - type :py:mod:`FloatFunctionalSeriesGraph <GRANTA_MIScriptingToolkit.FloatFunctionalSeriesGraph>`
                * parameters - type :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>`
                * unitInformation - type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            FloatFunctionalSeriesDataType_Create = self.lib.FloatFunctionalSeriesDataType_Create
            FloatFunctionalSeriesDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = FloatFunctionalSeriesDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if graph is not None:
            self.graph = graph
        if parameters is not None:
            self.parameters = parameters
        if unitInformation is not None:
            self.unitInformation = unitInformation


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            FloatFunctionalSeriesDataType_Destroy = self.lib.FloatFunctionalSeriesDataType_Destroy
            FloatFunctionalSeriesDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            FloatFunctionalSeriesDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def graph(self):
        """Property graph is of type :py:mod:`FloatFunctionalSeriesGraph <GRANTA_MIScriptingToolkit.FloatFunctionalSeriesGraph>`. """ 
        self._graph = self.__GetGraph()
        return self._graph

    @graph.setter
    def graph(self, value):
        if not isinstance(value, FloatFunctionalSeriesGraph):
            raise GRANTA_Exception('graph','graph: Invalid type graph must be of type FloatFunctionalSeriesGraph')
        self.__SetGraph(value)
        self._graph = value

    @property
    def parameters(self):
        """Property parameters is of type :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>`. """ 
        self._parameters = self.__GetParameters()
        return self._parameters

    @parameters.setter
    def parameters(self, value):
        if not isinstance(value, Parameters):
            raise GRANTA_Exception('parameters','parameters: Invalid type parameters must be of type Parameters')
        self.__SetParameters(value)
        self._parameters = value

    @property
    def unitInformation(self):
        """Property unitInformation is of type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`. """ 
        self._unitInformation = self.__GetUnitInformation()
        return self._unitInformation

    @unitInformation.setter
    def unitInformation(self, value):
        if not isinstance(value, UnitInformation):
            raise GRANTA_Exception('unitInformation','unitInformation: Invalid type unitInformation must be of type UnitInformation')
        self.__SetUnitInformation(value)
        self._unitInformation = value

    def __GetGraph(self):
        _floatFunctionalSeriesGraph = FloatFunctionalSeriesGraph()
        FloatFunctionalSeriesDataType_GetGraph = self.lib.FloatFunctionalSeriesDataType_GetGraph
        FloatFunctionalSeriesDataType_GetGraph.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        FloatFunctionalSeriesDataType_GetGraph(self._c_obj, (_floatFunctionalSeriesGraph.c_obj))
        
        return _floatFunctionalSeriesGraph
        
    def __SetGraph(self, value):

        FloatFunctionalSeriesDataType_SetGraph = self.lib.FloatFunctionalSeriesDataType_SetGraph 
        FloatFunctionalSeriesDataType_SetGraph.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalSeriesDataType_SetGraph(self._c_obj, value.c_obj)

    def __SetUnitInformation(self, value):

        FloatFunctionalSeriesDataType_SetUnitInformation = self.lib.FloatFunctionalSeriesDataType_SetUnitInformation 
        FloatFunctionalSeriesDataType_SetUnitInformation.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalSeriesDataType_SetUnitInformation(self._c_obj, value.c_obj)

    def __SetParameters(self, value):

        FloatFunctionalSeriesDataType_SetParameters = self.lib.FloatFunctionalSeriesDataType_SetParameters 
        FloatFunctionalSeriesDataType_SetParameters.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalSeriesDataType_SetParameters(self._c_obj, value.c_obj)

    def __GetParameters(self):
        _parameters = Parameters()
        FloatFunctionalSeriesDataType_GetParameters = self.lib.FloatFunctionalSeriesDataType_GetParameters
        FloatFunctionalSeriesDataType_GetParameters.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        FloatFunctionalSeriesDataType_GetParameters(self._c_obj, (_parameters.c_obj))
        
        return _parameters
        
    def __GetUnitInformation(self):
        _unitInformation = UnitInformation()
        FloatFunctionalSeriesDataType_GetUnitInformation = self.lib.FloatFunctionalSeriesDataType_GetUnitInformation
        FloatFunctionalSeriesDataType_GetUnitInformation.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        FloatFunctionalSeriesDataType_GetUnitInformation(self._c_obj, (_unitInformation.c_obj))
        
        return _unitInformation
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse
from GRANTA_MIScriptingToolkit.RecordWithAttributeAddresses import RecordWithAttributeAddresses


class GetUploadAddressesResponse(object):
    """GetUploadAddressesResponse. Output from the GetUploadAddresses operation.
Contains a list of :py:mod:`RecordWithAttributeAddresses <GRANTA_MIScriptingToolkit.RecordWithAttributeAddresses>` objects for each record in the :py:mod:`GetUploadAddressesRequest <GRANTA_MIScriptingToolkit.GetUploadAddressesRequest>`.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetUploadAddressesResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetUploadAddressesResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetUploadAddressesResponse_Destroy = self.lib.GetUploadAddressesResponse_Destroy
            GetUploadAddressesResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetUploadAddressesResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordsWithAttributeAddresses(self):
        """Property recordsWithAttributeAddresses is a list of :py:mod:`RecordWithAttributeAddresses <GRANTA_MIScriptingToolkit.RecordWithAttributeAddresses>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordsWithAttributeAddresses = self.__GetRecordsWithAttributeAddresses()
        except:
            pass
        return self._recordsWithAttributeAddresses

    @recordsWithAttributeAddresses.setter
    def recordsWithAttributeAddresses(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordsWithAttributeAddresses','recordsWithAttributeAddresses: Invalid type recordsWithAttributeAddresses must be a list of RecordWithAttributeAddresses')
        
        self._recordsWithAttributeAddresses = value

    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetUploadAddressesResponse_GetServiceLayerResponse = self.lib.GetUploadAddressesResponse_GetServiceLayerResponse
        GetUploadAddressesResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetUploadAddressesResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __ClearRecordsWithAttributeAddresses(self):
        GetUploadAddressesResponse_ClearRecordsWithAttributeAddresses = self.lib.GetUploadAddressesResponse_ClearRecordsWithAttributeAddresses
        GetUploadAddressesResponse_ClearRecordsWithAttributeAddresses.argtypes = [POINTER(c_void_p)]
        GetUploadAddressesResponse_ClearRecordsWithAttributeAddresses(self._c_obj)
        return self

    def __GetNumberOfRecordsWithAttributeAddresses(self):
        GetUploadAddressesResponse_GetNumberOfRecordsWithAttributeAddresses = self.lib.GetUploadAddressesResponse_GetNumberOfRecordsWithAttributeAddresses
        GetUploadAddressesResponse_GetNumberOfRecordsWithAttributeAddresses.argtypes = [POINTER(c_void_p)]
        GetUploadAddressesResponse_GetNumberOfRecordsWithAttributeAddresses.restype = c_int
        value = GetUploadAddressesResponse_GetNumberOfRecordsWithAttributeAddresses(self._c_obj)
        return value
    
    def __GetRecordsWithAttributeAddressesElement(self,i):
        value = RecordWithAttributeAddresses()
        GetUploadAddressesResponse_GetRecordsWithAttributeAddresses = self.lib.GetUploadAddressesResponse_GetRecordsWithAttributeAddresses
        GetUploadAddressesResponse_GetRecordsWithAttributeAddresses.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetUploadAddressesResponse_GetRecordsWithAttributeAddresses(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordsWithAttributeAddresses(self):
         n = self.__GetNumberOfRecordsWithAttributeAddresses();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordsWithAttributeAddressesElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


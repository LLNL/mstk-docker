# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterReferenceAndValue import ParameterReferenceAndValue


class UnittedParameterValue(object):
    """UnittedParameterValue. A Parameter, along with a single value of that Parameter, optionally with units.
    
        Arguments:
                * unitSymbol - type str
                * parameterWithValues - type :py:mod:`ParameterReferenceAndValue <GRANTA_MIScriptingToolkit.ParameterReferenceAndValue>`


    """
    
    def __init__(self, unitSymbol=None, parameterWithValues=None, isOwner=True):
        """

        Arguments:
                * unitSymbol - type str
                * parameterWithValues - type :py:mod:`ParameterReferenceAndValue <GRANTA_MIScriptingToolkit.ParameterReferenceAndValue>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            UnittedParameterValue_Create = self.lib.UnittedParameterValue_Create
            UnittedParameterValue_Create.restype = POINTER(c_void_p)
            self.c_obj = UnittedParameterValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if unitSymbol is not None:
            self.unitSymbol = unitSymbol
        if parameterWithValues is not None:
            self.parameterWithValues = parameterWithValues


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            UnittedParameterValue_Destroy = self.lib.UnittedParameterValue_Destroy
            UnittedParameterValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            UnittedParameterValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def unitSymbol(self):
        """Property unitSymbol is of type str. """ 
        try:
            return self._unitSymbol
        except:
            return None

    @unitSymbol.setter
    def unitSymbol(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('unitSymbol','unitSymbol: Invalid type unitSymbol must be of type str')
        self.__SetUnitSymbol(value)
        self._unitSymbol = value

    @property
    def parameterWithValues(self):
        """Property parameterWithValues is of type :py:mod:`ParameterReferenceAndValue <GRANTA_MIScriptingToolkit.ParameterReferenceAndValue>`. """ 
        try:
            return self._parameterWithValues
        except:
            return None

    @parameterWithValues.setter
    def parameterWithValues(self, value):
        if not isinstance(value, ParameterReferenceAndValue):
            raise GRANTA_Exception('parameterWithValues','parameterWithValues: Invalid type parameterWithValues must be of type ParameterReferenceAndValue')
        self.__SetParameterWithValues(value)
        self._parameterWithValues = value

    def __SetParameterWithValues(self, value):

        UnittedParameterValue_SetParameterWithValues = self.lib.UnittedParameterValue_SetParameterWithValues 
        UnittedParameterValue_SetParameterWithValues.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        UnittedParameterValue_SetParameterWithValues(self._c_obj, value.c_obj)

    def __SetUnitSymbol(self, value):

        UnittedParameterValue_SetUnitSymbol = self.lib.UnittedParameterValue_SetUnitSymbol 
        UnittedParameterValue_SetUnitSymbol.argtypes = [POINTER(c_void_p), c_char_p]
        UnittedParameterValue_SetUnitSymbol(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


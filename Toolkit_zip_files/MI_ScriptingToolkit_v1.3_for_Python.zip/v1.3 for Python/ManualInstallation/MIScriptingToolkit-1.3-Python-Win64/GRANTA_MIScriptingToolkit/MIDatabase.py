# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class MIDatabase(object):
    """MIDatabase. Data regarding a GRANTA MI database.
Contains a DBKey and a volume name.
    
        Arguments:
                * name - type str
                * DBKey - type str


    """
    
    def __init__(self, name=None, DBKey=None, isOwner=True):
        """

        Arguments:
                * name - type str
                * DBKey - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            MIDatabase_Create = self.lib.MIDatabase_Create
            MIDatabase_Create.restype = POINTER(c_void_p)
            self.c_obj = MIDatabase_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if name is not None:
            self.name = name
        if DBKey is not None:
            self.DBKey = DBKey


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            MIDatabase_Destroy = self.lib.MIDatabase_Destroy
            MIDatabase_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            MIDatabase_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        
        self._name = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        
        self._DBKey = value

    def __GetName(self):
        MIDatabase_GetName = self.lib.MIDatabase_GetName
        MIDatabase_GetName.argtypes = [POINTER(c_void_p)]
        MIDatabase_GetName.restype = POINTER(c_void_p)
        value = MIDatabase_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetDBKey(self):
        MIDatabase_GetDBKey = self.lib.MIDatabase_GetDBKey
        MIDatabase_GetDBKey.argtypes = [POINTER(c_void_p)]
        MIDatabase_GetDBKey.restype = POINTER(c_void_p)
        value = MIDatabase_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.NamedRecord import NamedRecord


class RecordLinkGroup(object):
    """RecordLinkGroup. A type representing a group of linked records.
    
        Arguments:
                * standardNames - type list of str objects
                * tableFilters - type list of int objects
                * name - type str
                * linkedRecords - type list of :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` objects


    """
    
    def __init__(self, standardNames=None, tableFilters=None, name=None, linkedRecords=None, isOwner=True):
        """

        Arguments:
                * standardNames - type list of str objects
                * tableFilters - type list of int objects
                * name - type str
                * linkedRecords - type list of :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordLinkGroup_Create = self.lib.RecordLinkGroup_Create
            RecordLinkGroup_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordLinkGroup_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if standardNames is not None:
            self.standardNames = standardNames
        if tableFilters is not None:
            self.tableFilters = tableFilters
        if name is not None:
            self.name = name
        if linkedRecords is not None:
            self.linkedRecords = linkedRecords


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordLinkGroup_Destroy = self.lib.RecordLinkGroup_Destroy
            RecordLinkGroup_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordLinkGroup_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def standardNames(self):
        """Property standardNames is a list of str objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._standardNames = self.__GetStandardNames()
        except:
            pass
        return self._standardNames

    @standardNames.setter
    def standardNames(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('standardNames','standardNames: Invalid type standardNames must be a list of str')
        
        self._standardNames = value

    @property
    def tableFilters(self):
        """Property tableFilters is a list of int objects. See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values. 
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._tableFilters = self.__GetTableFilters()
        except:
            pass
        return self._tableFilters

    @tableFilters.setter
    def tableFilters(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('tableFilters','tableFilters: Invalid type tableFilters must be a list of int')
        
        self._tableFilters = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        
        self._name = value

    @property
    def linkedRecords(self):
        """Property linkedRecords is a list of :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._linkedRecords = self.__GetLinkedRecords()
        except:
            pass
        return self._linkedRecords

    @linkedRecords.setter
    def linkedRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('linkedRecords','linkedRecords: Invalid type linkedRecords must be a list of NamedRecord')
        
        self._linkedRecords = value

    def __GetName(self):
        RecordLinkGroup_GetName = self.lib.RecordLinkGroup_GetName
        RecordLinkGroup_GetName.argtypes = [POINTER(c_void_p)]
        RecordLinkGroup_GetName.restype = POINTER(c_void_p)
        value = RecordLinkGroup_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetNumberOfLinkedRecords(self):
        RecordLinkGroup_GetNumberOfLinkedRecords = self.lib.RecordLinkGroup_GetNumberOfLinkedRecords
        RecordLinkGroup_GetNumberOfLinkedRecords.argtypes = [POINTER(c_void_p)]
        RecordLinkGroup_GetNumberOfLinkedRecords.restype = c_int
        value = RecordLinkGroup_GetNumberOfLinkedRecords(self._c_obj)
        return value
    
    def __GetLinkedRecordElement(self,i):
        value = NamedRecord()
        RecordLinkGroup_GetLinkedRecord = self.lib.RecordLinkGroup_GetLinkedRecord
        RecordLinkGroup_GetLinkedRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordLinkGroup_GetLinkedRecord(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetLinkedRecords(self):
         n = self.__GetNumberOfLinkedRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetLinkedRecordElement(i))
         return temp
    
    def __GetNumberOfTableFilters(self):
        RecordLinkGroup_GetNumberOfTableFilters = self.lib.RecordLinkGroup_GetNumberOfTableFilters
        RecordLinkGroup_GetNumberOfTableFilters.argtypes = [POINTER(c_void_p)]
        RecordLinkGroup_GetNumberOfTableFilters.restype = c_int
        value = RecordLinkGroup_GetNumberOfTableFilters(self._c_obj)
        return value
    
    def __GetTableFilterElement(self,i):
        RecordLinkGroup_GetTableFilter = self.lib.RecordLinkGroup_GetTableFilter
        RecordLinkGroup_GetTableFilter.argtypes = [POINTER(c_void_p), c_int]
        RecordLinkGroup_GetTableFilter.restype = c_int
        value = RecordLinkGroup_GetTableFilter(self._c_obj, i)
        return value
    
    def __GetTableFilters(self):
         n = self.__GetNumberOfTableFilters();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetTableFilterElement(i))
         return temp
    
    def __GetNumberOfStandardNames(self):
        RecordLinkGroup_GetNumberOfStandardNames = self.lib.RecordLinkGroup_GetNumberOfStandardNames
        RecordLinkGroup_GetNumberOfStandardNames.argtypes = [POINTER(c_void_p)]
        RecordLinkGroup_GetNumberOfStandardNames.restype = c_int
        value = RecordLinkGroup_GetNumberOfStandardNames(self._c_obj)
        return value
    
    def __GetStandardNameElement(self,i):
        RecordLinkGroup_GetStandardName = self.lib.RecordLinkGroup_GetStandardName
        RecordLinkGroup_GetStandardName.argtypes = [POINTER(c_void_p), c_int]
        RecordLinkGroup_GetStandardName.restype = POINTER(c_void_p)
        value = RecordLinkGroup_GetStandardName(self._c_obj, i)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
    
    def __GetStandardNames(self):
         n = self.__GetNumberOfStandardNames();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetStandardNameElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


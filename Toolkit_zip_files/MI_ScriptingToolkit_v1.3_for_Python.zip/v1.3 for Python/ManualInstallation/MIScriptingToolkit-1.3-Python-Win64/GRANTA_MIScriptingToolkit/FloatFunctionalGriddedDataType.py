# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.FloatFunctionalValues import FloatFunctionalValues
from GRANTA_MIScriptingToolkit.UnitInformation import UnitInformation
from GRANTA_MIScriptingToolkit.Parameters import Parameters
from GRANTA_MIScriptingToolkit.ParameterInformation import ParameterInformation

from .IDataValue import IDataValue


class FloatFunctionalGriddedDataType(IDataValue):
    """FloatFunctionalGriddedDataType. A type to contain the values of float-valued functional gridded data.
For requests, Values and :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>` are required.
    
        Arguments:
                * decoration - type int
                * defaultXAxisParameter - type :py:mod:`ParameterInformation <GRANTA_MIScriptingToolkit.ParameterInformation>`
                * values - type :py:mod:`FloatFunctionalValues <GRANTA_MIScriptingToolkit.FloatFunctionalValues>`
                * parameters - type :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>`
                * unitInformation - type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`


    """
    
    def __init__(self, decoration=None, defaultXAxisParameter=None, values=None, parameters=None, unitInformation=None, isOwner=True):
        """

        Arguments:
                * decoration - type int
                * defaultXAxisParameter - type :py:mod:`ParameterInformation <GRANTA_MIScriptingToolkit.ParameterInformation>`
                * values - type :py:mod:`FloatFunctionalValues <GRANTA_MIScriptingToolkit.FloatFunctionalValues>`
                * parameters - type :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>`
                * unitInformation - type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            FloatFunctionalGriddedDataType_Create = self.lib.FloatFunctionalGriddedDataType_Create
            FloatFunctionalGriddedDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = FloatFunctionalGriddedDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if decoration is not None:
            self.decoration = decoration
        if defaultXAxisParameter is not None:
            self.defaultXAxisParameter = defaultXAxisParameter
        if values is not None:
            self.values = values
        if parameters is not None:
            self.parameters = parameters
        if unitInformation is not None:
            self.unitInformation = unitInformation


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            FloatFunctionalGriddedDataType_Destroy = self.lib.FloatFunctionalGriddedDataType_Destroy
            FloatFunctionalGriddedDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            FloatFunctionalGriddedDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def decoration(self):
        """Property decoration is of type int. See :py:class:`GRANTA_Constants.GraphDecoration <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._decoration = self.__GetDecoration()
        return self._decoration

    @decoration.setter
    def decoration(self, value):
        """See :py:class:`GRANTA_Constants.GraphDecoration <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('decoration','decoration: Invalid type decoration must be of type int')
        self.__SetDecoration(value)
        self._decoration = value

    @property
    def defaultXAxisParameter(self):
        """Property defaultXAxisParameter is of type :py:mod:`ParameterInformation <GRANTA_MIScriptingToolkit.ParameterInformation>`. """ 
        self._defaultXAxisParameter = self.__GetDefaultXAxisParameter()
        return self._defaultXAxisParameter

    @defaultXAxisParameter.setter
    def defaultXAxisParameter(self, value):
        if not isinstance(value, ParameterInformation):
            raise GRANTA_Exception('defaultXAxisParameter','defaultXAxisParameter: Invalid type defaultXAxisParameter must be of type ParameterInformation')
        self.__SetDefaultXAxisParameter(value)
        self._defaultXAxisParameter = value

    @property
    def values(self):
        """Property values is of type :py:mod:`FloatFunctionalValues <GRANTA_MIScriptingToolkit.FloatFunctionalValues>`. """ 
        self._values = self.__GetValues()
        return self._values

    @values.setter
    def values(self, value):
        if not isinstance(value, FloatFunctionalValues):
            raise GRANTA_Exception('values','values: Invalid type values must be of type FloatFunctionalValues')
        self.__SetValues(value)
        self._values = value

    @property
    def parameters(self):
        """Property parameters is of type :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>`. """ 
        self._parameters = self.__GetParameters()
        return self._parameters

    @parameters.setter
    def parameters(self, value):
        if not isinstance(value, Parameters):
            raise GRANTA_Exception('parameters','parameters: Invalid type parameters must be of type Parameters')
        self.__SetParameters(value)
        self._parameters = value

    @property
    def unitInformation(self):
        """Property unitInformation is of type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`. """ 
        self._unitInformation = self.__GetUnitInformation()
        return self._unitInformation

    @unitInformation.setter
    def unitInformation(self, value):
        if not isinstance(value, UnitInformation):
            raise GRANTA_Exception('unitInformation','unitInformation: Invalid type unitInformation must be of type UnitInformation')
        self.__SetUnitInformation(value)
        self._unitInformation = value

    def __GetValues(self):
        _floatFunctionalValues = FloatFunctionalValues()
        FloatFunctionalGriddedDataType_GetValues = self.lib.FloatFunctionalGriddedDataType_GetValues
        FloatFunctionalGriddedDataType_GetValues.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        FloatFunctionalGriddedDataType_GetValues(self._c_obj, (_floatFunctionalValues.c_obj))
        
        return _floatFunctionalValues
        
    def __SetValues(self, value):

        FloatFunctionalGriddedDataType_SetValues = self.lib.FloatFunctionalGriddedDataType_SetValues 
        FloatFunctionalGriddedDataType_SetValues.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalGriddedDataType_SetValues(self._c_obj, value.c_obj)

    def __SetUnitInformation(self, value):

        FloatFunctionalGriddedDataType_SetUnitInformation = self.lib.FloatFunctionalGriddedDataType_SetUnitInformation 
        FloatFunctionalGriddedDataType_SetUnitInformation.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalGriddedDataType_SetUnitInformation(self._c_obj, value.c_obj)

    def __SetParameters(self, value):

        FloatFunctionalGriddedDataType_SetParameters = self.lib.FloatFunctionalGriddedDataType_SetParameters 
        FloatFunctionalGriddedDataType_SetParameters.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalGriddedDataType_SetParameters(self._c_obj, value.c_obj)

    def __GetParameters(self):
        _parameters = Parameters()
        FloatFunctionalGriddedDataType_GetParameters = self.lib.FloatFunctionalGriddedDataType_GetParameters
        FloatFunctionalGriddedDataType_GetParameters.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        FloatFunctionalGriddedDataType_GetParameters(self._c_obj, (_parameters.c_obj))
        
        return _parameters
        
    def __GetUnitInformation(self):
        _unitInformation = UnitInformation()
        FloatFunctionalGriddedDataType_GetUnitInformation = self.lib.FloatFunctionalGriddedDataType_GetUnitInformation
        FloatFunctionalGriddedDataType_GetUnitInformation.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        FloatFunctionalGriddedDataType_GetUnitInformation(self._c_obj, (_unitInformation.c_obj))
        
        return _unitInformation
        
    def __GetDefaultXAxisParameter(self):
        _parameterInformation = ParameterInformation()
        FloatFunctionalGriddedDataType_GetDefaultXAxisParameter = self.lib.FloatFunctionalGriddedDataType_GetDefaultXAxisParameter
        FloatFunctionalGriddedDataType_GetDefaultXAxisParameter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        FloatFunctionalGriddedDataType_GetDefaultXAxisParameter(self._c_obj, (_parameterInformation.c_obj))
        
        return _parameterInformation
        
    def __SetDefaultXAxisParameter(self, value):

        FloatFunctionalGriddedDataType_SetDefaultXAxisParameter = self.lib.FloatFunctionalGriddedDataType_SetDefaultXAxisParameter 
        FloatFunctionalGriddedDataType_SetDefaultXAxisParameter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalGriddedDataType_SetDefaultXAxisParameter(self._c_obj, value.c_obj)

    def __GetDecoration(self):
        FloatFunctionalGriddedDataType_GetDecoration = self.lib.FloatFunctionalGriddedDataType_GetDecoration
        FloatFunctionalGriddedDataType_GetDecoration.argtypes = [POINTER(c_void_p)]
        FloatFunctionalGriddedDataType_GetDecoration.restype = c_int
        value = FloatFunctionalGriddedDataType_GetDecoration(self._c_obj)
        return value
    
    def __SetDecoration(self, value):
        """See :py:class:`GRANTA_Constants.GraphDecoration <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        FloatFunctionalGriddedDataType_SetDecoration = self.lib.FloatFunctionalGriddedDataType_SetDecoration 
        FloatFunctionalGriddedDataType_SetDecoration.argtypes = [POINTER(c_void_p), c_int]
        FloatFunctionalGriddedDataType_SetDecoration(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterReferenceAndValue import ParameterReferenceAndValue


class ParameterReferencesAndValues(object):
    """ParameterReferencesAndValues. A collection of :py:mod:`ParameterReferenceAndValue <GRANTA_MIScriptingToolkit.ParameterReferenceAndValue>` objects.
    
        Arguments:
                * parameterWithValues - type list of :py:mod:`ParameterReferenceAndValue <GRANTA_MIScriptingToolkit.ParameterReferenceAndValue>` objects


    """
    
    def __init__(self, parameterWithValues=None, isOwner=True):
        """

        Arguments:
                * parameterWithValues - type list of :py:mod:`ParameterReferenceAndValue <GRANTA_MIScriptingToolkit.ParameterReferenceAndValue>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ParameterReferencesAndValues_Create = self.lib.ParameterReferencesAndValues_Create
            ParameterReferencesAndValues_Create.restype = POINTER(c_void_p)
            self.c_obj = ParameterReferencesAndValues_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if parameterWithValues is not None:
            self.parameterWithValues = parameterWithValues


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ParameterReferencesAndValues_Destroy = self.lib.ParameterReferencesAndValues_Destroy
            ParameterReferencesAndValues_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ParameterReferencesAndValues_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def parameterWithValues(self):
        """Property parameterWithValues is a list of :py:mod:`ParameterReferenceAndValue <GRANTA_MIScriptingToolkit.ParameterReferenceAndValue>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._parameterWithValues = self.__GetParameterWithValues()
        except:
            pass
        return self._parameterWithValues

    @parameterWithValues.setter
    def parameterWithValues(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('parameterWithValues','parameterWithValues: Invalid type parameterWithValues must be a list of ParameterReferenceAndValue')
                
        try:
            self.__updateparameterWithValues = True
            self.__ClearParameterWithValues()
            for v in value:
                self.AddParameterWithValue(v)
        except:
            pass


    def AddParameterWithValue(self, _parameterReferenceAndValue):
        """Appends _parameterReferenceAndValue to parameterWithValues property on ParameterReferencesAndValues C-object.

           Arguments:
                _parameterReferenceAndValue - object of type ParameterReferenceAndValue.
        """

        if not isinstance(_parameterReferenceAndValue, ParameterReferenceAndValue):
            raise GRANTA_Exception('ParameterReferencesAndValues.AddParameterWithValue','_parameterReferenceAndValue: Invalid argument type _parameterReferenceAndValue must be of type ParameterReferenceAndValue')
        ParameterReferencesAndValues_AddParameterWithValue = self.lib.ParameterReferencesAndValues_AddParameterWithValue
        ParameterReferencesAndValues_AddParameterWithValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ParameterReferencesAndValues_AddParameterWithValue(self._c_obj, _parameterReferenceAndValue.c_obj)
        return self

    def __ClearParameterWithValues(self):
        ParameterReferencesAndValues_ClearParameterWithValues = self.lib.ParameterReferencesAndValues_ClearParameterWithValues
        ParameterReferencesAndValues_ClearParameterWithValues.argtypes = [POINTER(c_void_p)]
        ParameterReferencesAndValues_ClearParameterWithValues(self._c_obj)
        return self

    def __GetNumberOfParameterWithValues(self):
        ParameterReferencesAndValues_GetNumberOfParameterWithValues = self.lib.ParameterReferencesAndValues_GetNumberOfParameterWithValues
        ParameterReferencesAndValues_GetNumberOfParameterWithValues.argtypes = [POINTER(c_void_p)]
        ParameterReferencesAndValues_GetNumberOfParameterWithValues.restype = c_int
        value = ParameterReferencesAndValues_GetNumberOfParameterWithValues(self._c_obj)
        return value
    
    def __GetParameterWithValuesElement(self,i):
        value = ParameterReferenceAndValue()
        ParameterReferencesAndValues_GetParameterWithValues = self.lib.ParameterReferencesAndValues_GetParameterWithValues
        ParameterReferencesAndValues_GetParameterWithValues.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        ParameterReferencesAndValues_GetParameterWithValues(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetParameterWithValues(self):
         n = self.__GetNumberOfParameterWithValues();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetParameterWithValuesElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


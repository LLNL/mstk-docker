# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.NamedAttribute import NamedAttribute
from GRANTA_MIScriptingToolkit.RevisionInfo import RevisionInfo
from GRANTA_MIScriptingToolkit.ParameterDetail import ParameterDetail


class RecordAttribute(object):
    """RecordAttribute. Meta-information about the data of a particular attribute of a particular Record in a GRANTA MI database 
Does NOT include values of the data (see :py:mod:`AttributeValue <GRANTA_MIScriptingToolkit.AttributeValue>` type).
    
        Arguments:
                * dataVersionNumber - type int
                * attribute - type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`
                * dataCreatedRecordVersion - type int
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * hasData - type bool
                * dataRetiredRecordVersion - type int
                * parameterDetails - type list of :py:mod:`ParameterDetail <GRANTA_MIScriptingToolkit.ParameterDetail>` objects
                * dataRevisionInfo - type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`


    """
    
    def __init__(self, dataVersionNumber=None, attribute=None, dataCreatedRecordVersion=None, recordReference=None, hasData=None, dataRetiredRecordVersion=None, parameterDetails=None, dataRevisionInfo=None, isOwner=True):
        """

        Arguments:
                * dataVersionNumber - type int
                * attribute - type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`
                * dataCreatedRecordVersion - type int
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * hasData - type bool
                * dataRetiredRecordVersion - type int
                * parameterDetails - type list of :py:mod:`ParameterDetail <GRANTA_MIScriptingToolkit.ParameterDetail>` objects
                * dataRevisionInfo - type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordAttribute_Create = self.lib.RecordAttribute_Create
            RecordAttribute_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordAttribute_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if dataVersionNumber is not None:
            self.dataVersionNumber = dataVersionNumber
        if attribute is not None:
            self.attribute = attribute
        if dataCreatedRecordVersion is not None:
            self.dataCreatedRecordVersion = dataCreatedRecordVersion
        if recordReference is not None:
            self.recordReference = recordReference
        if hasData is not None:
            self.hasData = hasData
        if dataRetiredRecordVersion is not None:
            self.dataRetiredRecordVersion = dataRetiredRecordVersion
        if parameterDetails is not None:
            self.parameterDetails = parameterDetails
        if dataRevisionInfo is not None:
            self.dataRevisionInfo = dataRevisionInfo


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordAttribute_Destroy = self.lib.RecordAttribute_Destroy
            RecordAttribute_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordAttribute_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def dataVersionNumber(self):
        """Property dataVersionNumber is of type int. """ 
        self._dataVersionNumber = self.__GetDataVersionNumber()
        return self._dataVersionNumber

    @dataVersionNumber.setter
    def dataVersionNumber(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('dataVersionNumber','dataVersionNumber: Invalid type dataVersionNumber must be of type int')
        
        self._dataVersionNumber = value

    @property
    def attribute(self):
        """Property attribute is of type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`. """ 
        self._attribute = self.__GetAttribute()
        return self._attribute

    @attribute.setter
    def attribute(self, value):
        if not isinstance(value, NamedAttribute):
            raise GRANTA_Exception('attribute','attribute: Invalid type attribute must be of type NamedAttribute')
        self.__SetAttribute(value)
        self._attribute = value

    @property
    def dataCreatedRecordVersion(self):
        """Property dataCreatedRecordVersion is of type int. """ 
        self._dataCreatedRecordVersion = self.__GetDataCreatedRecordVersion()
        return self._dataCreatedRecordVersion

    @dataCreatedRecordVersion.setter
    def dataCreatedRecordVersion(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('dataCreatedRecordVersion','dataCreatedRecordVersion: Invalid type dataCreatedRecordVersion must be of type int')
        
        self._dataCreatedRecordVersion = value

    @property
    def recordReference(self):
        """Property recordReference is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._recordReference = self.__GetRecordReference()
        return self._recordReference

    @recordReference.setter
    def recordReference(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('recordReference','recordReference: Invalid type recordReference must be of type RecordReference')
        self.__SetRecordReference(value)
        self._recordReference = value

    @property
    def hasData(self):
        """Property hasData is of type bool. """ 
        self._hasData = self.__GetHasData()
        return self._hasData

    @hasData.setter
    def hasData(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('hasData','hasData: Invalid type hasData must be of type bool')
        self.__SetHasData(value)
        self._hasData = value

    @property
    def dataRetiredRecordVersion(self):
        """Property dataRetiredRecordVersion is of type int. """ 
        self._dataRetiredRecordVersion = self.__GetDataRetiredRecordVersion()
        return self._dataRetiredRecordVersion

    @dataRetiredRecordVersion.setter
    def dataRetiredRecordVersion(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('dataRetiredRecordVersion','dataRetiredRecordVersion: Invalid type dataRetiredRecordVersion must be of type int')
        
        self._dataRetiredRecordVersion = value

    @property
    def parameterDetails(self):
        """Property parameterDetails is a list of :py:mod:`ParameterDetail <GRANTA_MIScriptingToolkit.ParameterDetail>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._parameterDetails = self.__GetParameterDetails()
        except:
            pass
        return self._parameterDetails

    @parameterDetails.setter
    def parameterDetails(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('parameterDetails','parameterDetails: Invalid type parameterDetails must be a list of ParameterDetail')
        
        self._parameterDetails = value

    @property
    def dataRevisionInfo(self):
        """Property dataRevisionInfo is of type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`. """ 
        self._dataRevisionInfo = self.__GetDataRevisionInfo()
        return self._dataRevisionInfo

    @dataRevisionInfo.setter
    def dataRevisionInfo(self, value):
        if not isinstance(value, RevisionInfo):
            raise GRANTA_Exception('dataRevisionInfo','dataRevisionInfo: Invalid type dataRevisionInfo must be of type RevisionInfo')
        
        self._dataRevisionInfo = value

    def __GetRecordReference(self):
        _recordReference = RecordReference()
        RecordAttribute_GetRecordReference = self.lib.RecordAttribute_GetRecordReference
        RecordAttribute_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordAttribute_GetRecordReference(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __SetRecordReference(self, value):

        RecordAttribute_SetRecordReference = self.lib.RecordAttribute_SetRecordReference 
        RecordAttribute_SetRecordReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordAttribute_SetRecordReference(self._c_obj, value.c_obj)

    def __GetAttribute(self):
        _namedAttribute = NamedAttribute()
        RecordAttribute_GetAttribute = self.lib.RecordAttribute_GetAttribute
        RecordAttribute_GetAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordAttribute_GetAttribute(self._c_obj, (_namedAttribute.c_obj))
        
        return _namedAttribute
        
    def __SetAttribute(self, value):

        RecordAttribute_SetAttribute = self.lib.RecordAttribute_SetAttribute 
        RecordAttribute_SetAttribute.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordAttribute_SetAttribute(self._c_obj, value.c_obj)

    def __GetHasData(self):
        RecordAttribute_GetHasData = self.lib.RecordAttribute_GetHasData
        RecordAttribute_GetHasData.argtypes = [POINTER(c_void_p)]
        RecordAttribute_GetHasData.restype = c_bool
        value = RecordAttribute_GetHasData(self._c_obj)
        return value
    
    def __SetHasData(self, value):

        RecordAttribute_SetHasData = self.lib.RecordAttribute_SetHasData 
        RecordAttribute_SetHasData.argtypes = [POINTER(c_void_p), c_bool]
        RecordAttribute_SetHasData(self._c_obj, value)

    def __GetDataRevisionInfo(self):
        _revisionInfo = RevisionInfo()
        RecordAttribute_GetDataRevisionInfo = self.lib.RecordAttribute_GetDataRevisionInfo
        RecordAttribute_GetDataRevisionInfo.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordAttribute_GetDataRevisionInfo(self._c_obj, (_revisionInfo.c_obj))
        
        return _revisionInfo
        
    def __GetDataCreatedRecordVersion(self):
        RecordAttribute_GetDataCreatedRecordVersion = self.lib.RecordAttribute_GetDataCreatedRecordVersion
        RecordAttribute_GetDataCreatedRecordVersion.argtypes = [POINTER(c_void_p)]
        RecordAttribute_GetDataCreatedRecordVersion.restype = c_int
        value = RecordAttribute_GetDataCreatedRecordVersion(self._c_obj)
        return value
    
    def __GetDataRetiredRecordVersion(self):
        RecordAttribute_GetDataRetiredRecordVersion = self.lib.RecordAttribute_GetDataRetiredRecordVersion
        RecordAttribute_GetDataRetiredRecordVersion.argtypes = [POINTER(c_void_p)]
        RecordAttribute_GetDataRetiredRecordVersion.restype = c_int
        value = RecordAttribute_GetDataRetiredRecordVersion(self._c_obj)
        return value
    
    def __GetDataVersionNumber(self):
        RecordAttribute_GetDataVersionNumber = self.lib.RecordAttribute_GetDataVersionNumber
        RecordAttribute_GetDataVersionNumber.argtypes = [POINTER(c_void_p)]
        RecordAttribute_GetDataVersionNumber.restype = c_int
        value = RecordAttribute_GetDataVersionNumber(self._c_obj)
        return value
    
    def __GetNumberOfParameterDetails(self):
        RecordAttribute_GetNumberOfParameterDetails = self.lib.RecordAttribute_GetNumberOfParameterDetails
        RecordAttribute_GetNumberOfParameterDetails.argtypes = [POINTER(c_void_p)]
        RecordAttribute_GetNumberOfParameterDetails.restype = c_int
        value = RecordAttribute_GetNumberOfParameterDetails(self._c_obj)
        return value
    
    def __GetParameterDetailElement(self,i):
        value = ParameterDetail()
        RecordAttribute_GetParameterDetail = self.lib.RecordAttribute_GetParameterDetail
        RecordAttribute_GetParameterDetail.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordAttribute_GetParameterDetail(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetParameterDetails(self):
         n = self.__GetNumberOfParameterDetails();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetParameterDetailElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


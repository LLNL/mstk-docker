# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class GetTreeRecordsRequest(object):
    """GetTreeRecordsRequest. Input to the GetTreeRecords operation.
Requires at least one RecordReference
    
        Arguments:
                * records - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects


    """
    
    def __init__(self, records=None, isOwner=True):
        """

        Arguments:
                * records - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetTreeRecordsRequest_Create = self.lib.GetTreeRecordsRequest_Create
            GetTreeRecordsRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetTreeRecordsRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if records is not None:
            self.records = records


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetTreeRecordsRequest_Destroy = self.lib.GetTreeRecordsRequest_Destroy
            GetTreeRecordsRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetTreeRecordsRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def records(self):
        """Property records is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._records = self.__GetRecords()
        except:
            pass
        return self._records

    @records.setter
    def records(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('records','records: Invalid type records must be a list of RecordReference')
                
        try:
            self.__updaterecords = True
            self.__ClearRecords()
            for v in value:
                self.AddRecord(v)
        except:
            pass


    def AddRecord(self, _recordReference):
        """Appends _recordReference to records property on GetTreeRecordsRequest C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('GetTreeRecordsRequest.AddRecord','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        GetTreeRecordsRequest_AddRecord = self.lib.GetTreeRecordsRequest_AddRecord
        GetTreeRecordsRequest_AddRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetTreeRecordsRequest_AddRecord(self._c_obj, _recordReference.c_obj)
        return self

    def __ClearRecords(self):
        GetTreeRecordsRequest_ClearRecords = self.lib.GetTreeRecordsRequest_ClearRecords
        GetTreeRecordsRequest_ClearRecords.argtypes = [POINTER(c_void_p)]
        GetTreeRecordsRequest_ClearRecords(self._c_obj)
        return self

    def __GetNumberOfRecords(self):
        GetTreeRecordsRequest_GetNumberOfRecords = self.lib.GetTreeRecordsRequest_GetNumberOfRecords
        GetTreeRecordsRequest_GetNumberOfRecords.argtypes = [POINTER(c_void_p)]
        GetTreeRecordsRequest_GetNumberOfRecords.restype = c_int
        value = GetTreeRecordsRequest_GetNumberOfRecords(self._c_obj)
        return value
    
    def __GetRecordsElement(self,i):
        value = RecordReference()
        GetTreeRecordsRequest_GetRecords = self.lib.GetTreeRecordsRequest_GetRecords
        GetTreeRecordsRequest_GetRecords.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetTreeRecordsRequest_GetRecords(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecords(self):
         n = self.__GetNumberOfRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordsElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.SubsetReference import SubsetReference
from GRANTA_MIScriptingToolkit.TableReference import TableReference


class GetSubsetsRequest(object):
    """GetSubsetsRequest. Input to the GetSubsets operation.
Requires a :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>` .
    
        Arguments:
                * table - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`
                * subsetReferences - type list of :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>` objects


    """
    
    def __init__(self, table=None, subsetReferences=None, isOwner=True):
        """

        Arguments:
                * table - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`
                * subsetReferences - type list of :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetSubsetsRequest_Create = self.lib.GetSubsetsRequest_Create
            GetSubsetsRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetSubsetsRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if table is not None:
            self.table = table
        if subsetReferences is not None:
            self.subsetReferences = subsetReferences


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetSubsetsRequest_Destroy = self.lib.GetSubsetsRequest_Destroy
            GetSubsetsRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetSubsetsRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def table(self):
        """Property table is of type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`. """ 
        try:
            return self._table
        except:
            return None

    @table.setter
    def table(self, value):
        if not isinstance(value, TableReference):
            raise GRANTA_Exception('table','table: Invalid type table must be of type TableReference')
        self.__SetTable(value)
        self._table = value

    @property
    def subsetReferences(self):
        """Property subsetReferences is of type list of :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>`. """ 
        try:
            return self._subsetReferences
        except:
            return None

    @subsetReferences.setter
    def subsetReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('subsetReferences','subsetReferences: Invalid type subsetReferences must be a list of SubsetReference')
                
        try:
            self.__updatesubsetReferences = True
            self.__ClearSubsetReferences()
            for v in value:
                self.AddSubsetReference(v)
        except:
            pass


    def AddSubsetReference(self, _subsetReference):
        """Appends _subsetReference to subsetReferences property on GetSubsetsRequest C-object.

           Arguments:
                _subsetReference - object of type SubsetReference.
        """

        if not isinstance(_subsetReference, SubsetReference):
            raise GRANTA_Exception('GetSubsetsRequest.AddSubsetReference','_subsetReference: Invalid argument type _subsetReference must be of type SubsetReference')
        GetSubsetsRequest_AddSubsetReference = self.lib.GetSubsetsRequest_AddSubsetReference
        GetSubsetsRequest_AddSubsetReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetSubsetsRequest_AddSubsetReference(self._c_obj, _subsetReference.c_obj)
        return self

    def __ClearSubsetReferences(self):
        GetSubsetsRequest_ClearSubsetReferences = self.lib.GetSubsetsRequest_ClearSubsetReferences
        GetSubsetsRequest_ClearSubsetReferences.argtypes = [POINTER(c_void_p)]
        GetSubsetsRequest_ClearSubsetReferences(self._c_obj)
        return self

    def __SetTable(self, value):

        GetSubsetsRequest_SetTable = self.lib.GetSubsetsRequest_SetTable 
        GetSubsetsRequest_SetTable.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetSubsetsRequest_SetTable(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


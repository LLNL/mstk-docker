# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.PartialTableReference import PartialTableReference


class GetAvailableExportersRequest(object):
    """GetAvailableExportersRequest. Input for the GetAvailableExporters operation.
    
        Arguments:
                * package - type str
                * partialTableReference - type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`
                * DBKey - type str
                * versionPolicy - type int
                * applicabilityTag - type str
                * model - type str
                * matchDB - type bool


    """
    
    def __init__(self, package=None, partialTableReference=None, DBKey=None, versionPolicy=None, applicabilityTag=None, model=None, matchDB=None, isOwner=True):
        """

        Arguments:
                * package - type str
                * partialTableReference - type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`
                * DBKey - type str
                * versionPolicy - type int
                * applicabilityTag - type str
                * model - type str
                * matchDB - type bool

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetAvailableExportersRequest_Create = self.lib.GetAvailableExportersRequest_Create
            GetAvailableExportersRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetAvailableExportersRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if package is not None:
            self.package = package
        if partialTableReference is not None:
            self.partialTableReference = partialTableReference
        if DBKey is not None:
            self.DBKey = DBKey
        if versionPolicy is not None:
            self.versionPolicy = versionPolicy
        if applicabilityTag is not None:
            self.applicabilityTag = applicabilityTag
        if model is not None:
            self.model = model
        if matchDB is not None:
            self.matchDB = matchDB


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetAvailableExportersRequest_Destroy = self.lib.GetAvailableExportersRequest_Destroy
            GetAvailableExportersRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetAvailableExportersRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def package(self):
        """Property package is of type str. """ 
        self._package = self.__GetPackage()
        return self._package

    @package.setter
    def package(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('package','package: Invalid type package must be of type str')
        self.__SetPackage(value)
        self._package = value

    @property
    def partialTableReference(self):
        """Property partialTableReference is of type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`. """ 
        self._partialTableReference = self.__GetPartialTableReference()
        return self._partialTableReference

    @partialTableReference.setter
    def partialTableReference(self, value):
        if not isinstance(value, PartialTableReference):
            raise GRANTA_Exception('partialTableReference','partialTableReference: Invalid type partialTableReference must be of type PartialTableReference')
        self.__SetPartialTableReference(value)
        self._partialTableReference = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    @property
    def versionPolicy(self):
        """Property versionPolicy is of type int. See :py:class:`GRANTA_Constants.VersionPolicy <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._versionPolicy = self.__GetVersionPolicy()
        return self._versionPolicy

    @versionPolicy.setter
    def versionPolicy(self, value):
        """See :py:class:`GRANTA_Constants.VersionPolicy <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('versionPolicy','versionPolicy: Invalid type versionPolicy must be of type int')
        self.__SetVersionPolicy(value)
        self._versionPolicy = value

    @property
    def applicabilityTag(self):
        """Property applicabilityTag is of type str. """ 
        self._applicabilityTag = self.__GetApplicabilityTag()
        return self._applicabilityTag

    @applicabilityTag.setter
    def applicabilityTag(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('applicabilityTag','applicabilityTag: Invalid type applicabilityTag must be of type str')
        self.__SetApplicabilityTag(value)
        self._applicabilityTag = value

    @property
    def model(self):
        """Property model is of type str. """ 
        self._model = self.__GetModel()
        return self._model

    @model.setter
    def model(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('model','model: Invalid type model must be of type str')
        self.__SetModel(value)
        self._model = value

    @property
    def matchDB(self):
        """Property matchDB is of type bool. If true, we check that the exporter config Table element is in a Database element for the right dbKey.""" 
        self._matchDB = self.__GetMatchDB()
        return self._matchDB

    @matchDB.setter
    def matchDB(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('matchDB','matchDB: Invalid type matchDB must be of type bool')
        self.__SetMatchDB(value)
        self._matchDB = value

    def __SetPackage(self, value):

        GetAvailableExportersRequest_SetPackage = self.lib.GetAvailableExportersRequest_SetPackage 
        GetAvailableExportersRequest_SetPackage.argtypes = [POINTER(c_void_p), c_char_p]
        GetAvailableExportersRequest_SetPackage(self._c_obj, EnsureEncoded(value))

    def __GetPackage(self):
        GetAvailableExportersRequest_GetPackage = self.lib.GetAvailableExportersRequest_GetPackage
        GetAvailableExportersRequest_GetPackage.argtypes = [POINTER(c_void_p)]
        GetAvailableExportersRequest_GetPackage.restype = POINTER(c_void_p)
        value = GetAvailableExportersRequest_GetPackage(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetModel(self, value):

        GetAvailableExportersRequest_SetModel = self.lib.GetAvailableExportersRequest_SetModel 
        GetAvailableExportersRequest_SetModel.argtypes = [POINTER(c_void_p), c_char_p]
        GetAvailableExportersRequest_SetModel(self._c_obj, EnsureEncoded(value))

    def __GetModel(self):
        GetAvailableExportersRequest_GetModel = self.lib.GetAvailableExportersRequest_GetModel
        GetAvailableExportersRequest_GetModel.argtypes = [POINTER(c_void_p)]
        GetAvailableExportersRequest_GetModel.restype = POINTER(c_void_p)
        value = GetAvailableExportersRequest_GetModel(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetDBKey(self, value):

        GetAvailableExportersRequest_SetDBKey = self.lib.GetAvailableExportersRequest_SetDBKey 
        GetAvailableExportersRequest_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        GetAvailableExportersRequest_SetDBKey(self._c_obj, EnsureEncoded(value))

    def __GetDBKey(self):
        GetAvailableExportersRequest_GetDBKey = self.lib.GetAvailableExportersRequest_GetDBKey
        GetAvailableExportersRequest_GetDBKey.argtypes = [POINTER(c_void_p)]
        GetAvailableExportersRequest_GetDBKey.restype = POINTER(c_void_p)
        value = GetAvailableExportersRequest_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetMatchDB(self, value):

        GetAvailableExportersRequest_SetMatchDB = self.lib.GetAvailableExportersRequest_SetMatchDB 
        GetAvailableExportersRequest_SetMatchDB.argtypes = [POINTER(c_void_p), c_bool]
        GetAvailableExportersRequest_SetMatchDB(self._c_obj, value)

    def __GetMatchDB(self):
        GetAvailableExportersRequest_GetMatchDB = self.lib.GetAvailableExportersRequest_GetMatchDB
        GetAvailableExportersRequest_GetMatchDB.argtypes = [POINTER(c_void_p)]
        GetAvailableExportersRequest_GetMatchDB.restype = c_bool
        value = GetAvailableExportersRequest_GetMatchDB(self._c_obj)
        return value
    
    def __SetPartialTableReference(self, value):

        GetAvailableExportersRequest_SetPartialTableReference = self.lib.GetAvailableExportersRequest_SetPartialTableReference 
        GetAvailableExportersRequest_SetPartialTableReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetAvailableExportersRequest_SetPartialTableReference(self._c_obj, value.c_obj)

    def __GetPartialTableReference(self):
        _partialTableReference = PartialTableReference()
        GetAvailableExportersRequest_GetPartialTableReference = self.lib.GetAvailableExportersRequest_GetPartialTableReference
        GetAvailableExportersRequest_GetPartialTableReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetAvailableExportersRequest_GetPartialTableReference(self._c_obj, (_partialTableReference.c_obj))
        
        return _partialTableReference
        
    def __GetVersionPolicy(self):
        GetAvailableExportersRequest_GetVersionPolicy = self.lib.GetAvailableExportersRequest_GetVersionPolicy
        GetAvailableExportersRequest_GetVersionPolicy.argtypes = [POINTER(c_void_p)]
        GetAvailableExportersRequest_GetVersionPolicy.restype = c_int
        value = GetAvailableExportersRequest_GetVersionPolicy(self._c_obj)
        return value
    
    def __SetVersionPolicy(self, value):
        """See :py:class:`GRANTA_Constants.VersionPolicy <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        GetAvailableExportersRequest_SetVersionPolicy = self.lib.GetAvailableExportersRequest_SetVersionPolicy 
        GetAvailableExportersRequest_SetVersionPolicy.argtypes = [POINTER(c_void_p), c_int]
        GetAvailableExportersRequest_SetVersionPolicy(self._c_obj, value)

    def __SetApplicabilityTag(self, value):

        GetAvailableExportersRequest_SetApplicabilityTag = self.lib.GetAvailableExportersRequest_SetApplicabilityTag 
        GetAvailableExportersRequest_SetApplicabilityTag.argtypes = [POINTER(c_void_p), c_char_p]
        GetAvailableExportersRequest_SetApplicabilityTag(self._c_obj, EnsureEncoded(value))

    def __GetApplicabilityTag(self):
        GetAvailableExportersRequest_GetApplicabilityTag = self.lib.GetAvailableExportersRequest_GetApplicabilityTag
        GetAvailableExportersRequest_GetApplicabilityTag.argtypes = [POINTER(c_void_p)]
        GetAvailableExportersRequest_GetApplicabilityTag.restype = POINTER(c_void_p)
        value = GetAvailableExportersRequest_GetApplicabilityTag(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


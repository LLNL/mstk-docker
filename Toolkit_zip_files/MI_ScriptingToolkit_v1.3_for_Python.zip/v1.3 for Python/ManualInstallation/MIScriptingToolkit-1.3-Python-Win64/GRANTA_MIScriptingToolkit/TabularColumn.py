# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class TabularColumn(object):
    """TabularColumn. Describes a column within a particular Tabular data instance.
    
        Arguments:
                * type - type int
                * name - type str


    """
    class ColType:
        Local = 0
        TargetAttribute = 1
        TargetRecord = 2
        TargetTabularColumn = 3
        Unavailable = 4
    
    def __init__(self, type=None, name=None, isOwner=True):
        """

        Arguments:
                * type - type int
                * name - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            TabularColumn_Create = self.lib.TabularColumn_Create
            TabularColumn_Create.restype = POINTER(c_void_p)
            self.c_obj = TabularColumn_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if type is not None:
            self.type = type
        if name is not None:
            self.name = name


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            TabularColumn_Destroy = self.lib.TabularColumn_Destroy
            TabularColumn_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            TabularColumn_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def type(self):
        """Property type is of type int. See :py:class:`TabularColumn.ColType <TabularColumn.ColType>` for supported values.""" 
        self._type = self.__GetType()
        return self._type

    @type.setter
    def type(self, value):
        """See :py:class:`TabularColumn.ColType <TabularColumn.ColType>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('type','type: Invalid type type must be of type int')
        self.__SetType(value)
        self._type = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        
        self._name = value

    def __GetName(self):
        TabularColumn_GetName = self.lib.TabularColumn_GetName
        TabularColumn_GetName.argtypes = [POINTER(c_void_p)]
        TabularColumn_GetName.restype = POINTER(c_void_p)
        value = TabularColumn_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetType(self, value):
        """See :py:class:`TabularColumn.ColType <TabularColumn.ColType>` for supported values."""

        TabularColumn_SetType = self.lib.TabularColumn_SetType 
        TabularColumn_SetType.argtypes = [POINTER(c_void_p), c_int]
        TabularColumn_SetType(self._c_obj, value)

    def __GetType(self):
        TabularColumn_GetType = self.lib.TabularColumn_GetType
        TabularColumn_GetType.argtypes = [POINTER(c_void_p)]
        TabularColumn_GetType.restype = c_int
        value = TabularColumn_GetType(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


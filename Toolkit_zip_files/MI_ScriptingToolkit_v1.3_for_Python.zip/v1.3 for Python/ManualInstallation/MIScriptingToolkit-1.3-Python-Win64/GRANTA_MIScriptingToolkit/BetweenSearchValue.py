# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.LowEndSearchValue import LowEndSearchValue
from GRANTA_MIScriptingToolkit.HighEndSearchValue import HighEndSearchValue


class BetweenSearchValue(object):
    """BetweenSearchValue. Search criterion to search for data between two values.
Only Point, Range, and Integer attributes are supported by this search criteria. Both a LowEnd and a HighEnd value are required.
    
        Arguments:
                * lowEnd - type :py:mod:`LowEndSearchValue <GRANTA_MIScriptingToolkit.LowEndSearchValue>`
                * highEnd - type :py:mod:`HighEndSearchValue <GRANTA_MIScriptingToolkit.HighEndSearchValue>`


    """
    
    def __init__(self, lowEnd=None, highEnd=None, isOwner=True):
        """

        Arguments:
                * lowEnd - type :py:mod:`LowEndSearchValue <GRANTA_MIScriptingToolkit.LowEndSearchValue>`
                * highEnd - type :py:mod:`HighEndSearchValue <GRANTA_MIScriptingToolkit.HighEndSearchValue>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            BetweenSearchValue_Create = self.lib.BetweenSearchValue_Create
            BetweenSearchValue_Create.restype = POINTER(c_void_p)
            self.c_obj = BetweenSearchValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if lowEnd is not None:
            self.lowEnd = lowEnd
        if highEnd is not None:
            self.highEnd = highEnd


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            BetweenSearchValue_Destroy = self.lib.BetweenSearchValue_Destroy
            BetweenSearchValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            BetweenSearchValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def lowEnd(self):
        """Property lowEnd is of type :py:mod:`LowEndSearchValue <GRANTA_MIScriptingToolkit.LowEndSearchValue>`. """ 
        self._lowEnd = self.__GetLowEnd()
        return self._lowEnd

    @lowEnd.setter
    def lowEnd(self, value):
        if not isinstance(value, LowEndSearchValue):
            raise GRANTA_Exception('lowEnd','lowEnd: Invalid type lowEnd must be of type LowEndSearchValue')
        self.__SetLowEnd(value)
        self._lowEnd = value

    @property
    def highEnd(self):
        """Property highEnd is of type :py:mod:`HighEndSearchValue <GRANTA_MIScriptingToolkit.HighEndSearchValue>`. """ 
        self._highEnd = self.__GetHighEnd()
        return self._highEnd

    @highEnd.setter
    def highEnd(self, value):
        if not isinstance(value, HighEndSearchValue):
            raise GRANTA_Exception('highEnd','highEnd: Invalid type highEnd must be of type HighEndSearchValue')
        self.__SetHighEnd(value)
        self._highEnd = value

    def __GetLowEnd(self):
        _lowEndSearchValue = LowEndSearchValue()
        BetweenSearchValue_GetLowEnd = self.lib.BetweenSearchValue_GetLowEnd
        BetweenSearchValue_GetLowEnd.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        BetweenSearchValue_GetLowEnd(self._c_obj, (_lowEndSearchValue.c_obj))
        
        return _lowEndSearchValue
        
    def __SetLowEnd(self, value):

        BetweenSearchValue_SetLowEnd = self.lib.BetweenSearchValue_SetLowEnd 
        BetweenSearchValue_SetLowEnd.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        BetweenSearchValue_SetLowEnd(self._c_obj, value.c_obj)

    def __GetHighEnd(self):
        _highEndSearchValue = HighEndSearchValue()
        BetweenSearchValue_GetHighEnd = self.lib.BetweenSearchValue_GetHighEnd
        BetweenSearchValue_GetHighEnd.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        BetweenSearchValue_GetHighEnd(self._c_obj, (_highEndSearchValue.c_obj))
        
        return _highEndSearchValue
        
    def __SetHighEnd(self, value):

        BetweenSearchValue_SetHighEnd = self.lib.BetweenSearchValue_SetHighEnd 
        BetweenSearchValue_SetHighEnd.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        BetweenSearchValue_SetHighEnd(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class RecordReference(object):
    """RecordReference. A type that allows identification of a particular record in a GRANTA MI database.
This is done directly by specifying the Identity or GUID of the record. 
    
        Arguments:
                * DBKey - type str
                * historyGUID - type str
                * recordGUID - type str
                * identity - type int


    """
    
    def __init__(self, DBKey=None, historyGUID=None, recordGUID=None, identity=None, isOwner=True):
        """

        Arguments:
                * DBKey - type str
                * historyGUID - type str
                * recordGUID - type str
                * identity - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordReference_Create = self.lib.RecordReference_Create
            RecordReference_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordReference_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if DBKey is not None:
            self.DBKey = DBKey
        if historyGUID is not None:
            self.historyGUID = historyGUID
        if recordGUID is not None:
            self.recordGUID = recordGUID
        if identity is not None:
            self.identity = identity


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordReference_Destroy = self.lib.RecordReference_Destroy
            RecordReference_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordReference_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    @property
    def historyGUID(self):
        """Property historyGUID is of type str. """ 
        self._historyGUID = self.__GetHistoryGUID()
        return self._historyGUID

    @historyGUID.setter
    def historyGUID(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('historyGUID','historyGUID: Invalid type historyGUID must be of type str')
        self.__SetHistoryGUID(value)
        self._historyGUID = value

    @property
    def recordGUID(self):
        """Property recordGUID is of type str. """ 
        self._recordGUID = self.__GetRecordGUID()
        return self._recordGUID

    @recordGUID.setter
    def recordGUID(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('recordGUID','recordGUID: Invalid type recordGUID must be of type str')
        self.__SetRecordGUID(value)
        self._recordGUID = value

    @property
    def identity(self):
        """Property identity is of type int. """ 
        self._identity = self.__GetIdentity()
        return self._identity

    @identity.setter
    def identity(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('identity','identity: Invalid type identity must be of type int')
        self.__SetIdentity(value)
        self._identity = value

    def __GetIdentity(self):
        RecordReference_GetIdentity = self.lib.RecordReference_GetIdentity
        RecordReference_GetIdentity.argtypes = [POINTER(c_void_p)]
        RecordReference_GetIdentity.restype = c_int
        value = RecordReference_GetIdentity(self._c_obj)
        return value
    
    def __SetIdentity(self, value):

        RecordReference_SetIdentity = self.lib.RecordReference_SetIdentity 
        RecordReference_SetIdentity.argtypes = [POINTER(c_void_p), c_int]
        RecordReference_SetIdentity(self._c_obj, value)

    def __GetRecordGUID(self):
        RecordReference_GetRecordGUID = self.lib.RecordReference_GetRecordGUID
        RecordReference_GetRecordGUID.argtypes = [POINTER(c_void_p)]
        RecordReference_GetRecordGUID.restype = POINTER(c_void_p)
        value = RecordReference_GetRecordGUID(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetRecordGUID(self, value):

        RecordReference_SetRecordGUID = self.lib.RecordReference_SetRecordGUID 
        RecordReference_SetRecordGUID.argtypes = [POINTER(c_void_p), c_char_p]
        RecordReference_SetRecordGUID(self._c_obj, EnsureEncoded(value))

    def __GetHistoryGUID(self):
        RecordReference_GetHistoryGUID = self.lib.RecordReference_GetHistoryGUID
        RecordReference_GetHistoryGUID.argtypes = [POINTER(c_void_p)]
        RecordReference_GetHistoryGUID.restype = POINTER(c_void_p)
        value = RecordReference_GetHistoryGUID(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetHistoryGUID(self, value):

        RecordReference_SetHistoryGUID = self.lib.RecordReference_SetHistoryGUID 
        RecordReference_SetHistoryGUID.argtypes = [POINTER(c_void_p), c_char_p]
        RecordReference_SetHistoryGUID(self._c_obj, EnsureEncoded(value))

    def __GetDBKey(self):
        RecordReference_GetDBKey = self.lib.RecordReference_GetDBKey
        RecordReference_GetDBKey.argtypes = [POINTER(c_void_p)]
        RecordReference_GetDBKey.restype = POINTER(c_void_p)
        value = RecordReference_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetDBKey(self, value):

        RecordReference_SetDBKey = self.lib.RecordReference_SetDBKey 
        RecordReference_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        RecordReference_SetDBKey(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


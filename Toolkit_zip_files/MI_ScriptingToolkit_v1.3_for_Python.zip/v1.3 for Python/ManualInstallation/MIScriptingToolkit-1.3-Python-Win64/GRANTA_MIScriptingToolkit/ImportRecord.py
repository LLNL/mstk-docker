# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.ImportAttributeValue import ImportAttributeValue
from GRANTA_MIScriptingToolkit.SubsetReference import SubsetReference


class ImportRecord(object):
    """ImportRecord. A record for importing to the GRANTA MI database.
The 'importRecordMode' property specifies whether a record should be 
created, copied, or updated. The accepted values are 'Create', 'Update', and 
'Copy'. If importRecordMode is 'Create', set 'existingRecord' to the parent 
record under which the new record is to be created. If importRecordMode is 
'Update', set 'existingRecord', to the target record to be changed. If 
importRecordMode is 'Copy', set 'existingRecord' to be the source data for 
the operation, and use 'copyDestinationParent' to specify where the record 
copy should appear. For versioned databases, set releaseRecord to specify whether the new or updated record should be released.
    
        Arguments:
                * recordName - type str
                * importAttributeValues - type list of :py:mod:`ImportAttributeValue <GRANTA_MIScriptingToolkit.ImportAttributeValue>` objects
                * isFolder - type bool
                * importRecordMode - type str
                * releaseRecord - type bool
                * subsetReferences - type list of :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>` objects
                * copyDestinationParent - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * existingRecord - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`


    """
    
    def __init__(self, recordName=None, importAttributeValues=None, isFolder=None, importRecordMode=None, releaseRecord=None, subsetReferences=None, copyDestinationParent=None, existingRecord=None, isOwner=True):
        """

        Arguments:
                * recordName - type str
                * importAttributeValues - type list of :py:mod:`ImportAttributeValue <GRANTA_MIScriptingToolkit.ImportAttributeValue>` objects
                * isFolder - type bool
                * importRecordMode - type str
                * releaseRecord - type bool
                * subsetReferences - type list of :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>` objects
                * copyDestinationParent - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * existingRecord - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ImportRecord_Create = self.lib.ImportRecord_Create
            ImportRecord_Create.restype = POINTER(c_void_p)
            self.c_obj = ImportRecord_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordName is not None:
            self.recordName = recordName
        if importAttributeValues is not None:
            self.importAttributeValues = importAttributeValues
        if isFolder is not None:
            self.isFolder = isFolder
        if importRecordMode is not None:
            self.importRecordMode = importRecordMode
        if releaseRecord is not None:
            self.releaseRecord = releaseRecord
        if subsetReferences is not None:
            self.subsetReferences = subsetReferences
        if copyDestinationParent is not None:
            self.copyDestinationParent = copyDestinationParent
        if existingRecord is not None:
            self.existingRecord = existingRecord


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ImportRecord_Destroy = self.lib.ImportRecord_Destroy
            ImportRecord_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ImportRecord_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordName(self):
        """Property recordName is of type str. """ 
        self._recordName = self.__GetRecordName()
        return self._recordName

    @recordName.setter
    def recordName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('recordName','recordName: Invalid type recordName must be of type str')
        self.__SetRecordName(value)
        self._recordName = value

    @property
    def importAttributeValues(self):
        """Property importAttributeValues is a list of :py:mod:`ImportAttributeValue <GRANTA_MIScriptingToolkit.ImportAttributeValue>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._importAttributeValues = self.__GetImportAttributeValueRefs()
        except:
            pass
        return self._importAttributeValues

    @importAttributeValues.setter
    def importAttributeValues(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('importAttributeValues','importAttributeValues: Invalid type importAttributeValues must be a list of ImportAttributeValue')
                
        try:
            self.__updateimportAttributeValues = True
            self.__ClearImportAttributeValues()
            for v in value:
                self.AddImportAttributeValue(v)
        except:
            pass


    @property
    def isFolder(self):
        """Property isFolder is of type bool. """ 
        try:
            return self._isFolder
        except:
            return None

    @isFolder.setter
    def isFolder(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('isFolder','isFolder: Invalid type isFolder must be of type bool')
        self.__SetIsFolder(value)
        self._isFolder = value

    @property
    def importRecordMode(self):
        """Property importRecordMode is of type str. See :py:class:`GRANTA_Constants.ImportTypes <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        try:
            return self._importRecordMode
        except:
            return None

    @importRecordMode.setter
    def importRecordMode(self, value):
        """See :py:class:`GRANTA_Constants.ImportTypes <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('importRecordMode','importRecordMode: Invalid type importRecordMode must be of type str')
        self.__SetImportRecordMode(value)
        self._importRecordMode = value

    @property
    def releaseRecord(self):
        """Property releaseRecord is of type bool. """ 
        try:
            return self._releaseRecord
        except:
            return None

    @releaseRecord.setter
    def releaseRecord(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('releaseRecord','releaseRecord: Invalid type releaseRecord must be of type bool')
        self.__SetReleaseRecord(value)
        self._releaseRecord = value

    @property
    def subsetReferences(self):
        """Property subsetReferences is a list of :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._subsetReferences = self.__GetSubsetReferences()
        except:
            pass
        return self._subsetReferences

    @subsetReferences.setter
    def subsetReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('subsetReferences','subsetReferences: Invalid type subsetReferences must be a list of SubsetReference')
                
        try:
            self.__updatesubsetReferences = True
            self.__ClearSubsetReferences()
            for v in value:
                self.AddSubsetReference(v)
        except:
            pass


    @property
    def copyDestinationParent(self):
        """Property copyDestinationParent is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        try:
            return self._copyDestinationParent
        except:
            return None

    @copyDestinationParent.setter
    def copyDestinationParent(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('copyDestinationParent','copyDestinationParent: Invalid type copyDestinationParent must be of type RecordReference')
        self.__SetCopyDestinationParent(value)
        self._copyDestinationParent = value

    @property
    def existingRecord(self):
        """Property existingRecord is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        try:
            return self._existingRecord
        except:
            return None

    @existingRecord.setter
    def existingRecord(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('existingRecord','existingRecord: Invalid type existingRecord must be of type RecordReference')
        self.__SetExistingRecord(value)
        self._existingRecord = value

    def __SetRecordName(self, value):

        ImportRecord_SetRecordName = self.lib.ImportRecord_SetRecordName 
        ImportRecord_SetRecordName.argtypes = [POINTER(c_void_p), c_char_p]
        ImportRecord_SetRecordName(self._c_obj, EnsureEncoded(value))

    def __GetRecordName(self):
        ImportRecord_GetRecordName = self.lib.ImportRecord_GetRecordName
        ImportRecord_GetRecordName.argtypes = [POINTER(c_void_p)]
        ImportRecord_GetRecordName.restype = POINTER(c_void_p)
        value = ImportRecord_GetRecordName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetExistingRecord(self, value):

        ImportRecord_SetExistingRecord = self.lib.ImportRecord_SetExistingRecord 
        ImportRecord_SetExistingRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportRecord_SetExistingRecord(self._c_obj, value.c_obj)

    def __GetNumberOfImportAttributeValueRefs(self):
        ImportRecord_GetNumberOfImportAttributeValueRefs = self.lib.ImportRecord_GetNumberOfImportAttributeValueRefs
        ImportRecord_GetNumberOfImportAttributeValueRefs.argtypes = [POINTER(c_void_p)]
        ImportRecord_GetNumberOfImportAttributeValueRefs.restype = c_int
        value = ImportRecord_GetNumberOfImportAttributeValueRefs(self._c_obj)
        return value
    
    def __GetImportAttributeValueRefsElement(self,i):
        value = ImportAttributeValue(isOwner=False)
        ImportRecord_GetImportAttributeValueRefs = self.lib.ImportRecord_GetImportAttributeValueRefs
        ImportRecord_GetImportAttributeValueRefs.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p)), c_int]
        ImportRecord_GetImportAttributeValueRefs(self._c_obj, value.c_obj, i)
        value._parent = self
        return value
    
    def __GetImportAttributeValueRefs(self):
         n = self.__GetNumberOfImportAttributeValueRefs();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetImportAttributeValueRefsElement(i))
         return temp
    
    def AddImportAttributeValue(self, _importAttributeValue):
        """Appends _importAttributeValue to importAttributeValues property on ImportRecord C-object.

           Arguments:
                _importAttributeValue - object of type ImportAttributeValue.
        """

        if not isinstance(_importAttributeValue, ImportAttributeValue):
            raise GRANTA_Exception('ImportRecord.AddImportAttributeValue','_importAttributeValue: Invalid argument type _importAttributeValue must be of type ImportAttributeValue')
        ImportRecord_AddImportAttributeValue = self.lib.ImportRecord_AddImportAttributeValue
        ImportRecord_AddImportAttributeValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportRecord_AddImportAttributeValue(self._c_obj, _importAttributeValue.c_obj)
        return self

    def __ClearImportAttributeValues(self):
        ImportRecord_ClearImportAttributeValues = self.lib.ImportRecord_ClearImportAttributeValues
        ImportRecord_ClearImportAttributeValues.argtypes = [POINTER(c_void_p)]
        ImportRecord_ClearImportAttributeValues(self._c_obj)
        return self

    def __SetIsFolder(self, value):

        ImportRecord_SetIsFolder = self.lib.ImportRecord_SetIsFolder 
        ImportRecord_SetIsFolder.argtypes = [POINTER(c_void_p), c_bool]
        ImportRecord_SetIsFolder(self._c_obj, value)

    def __SetReleaseRecord(self, value):

        ImportRecord_SetReleaseRecord = self.lib.ImportRecord_SetReleaseRecord 
        ImportRecord_SetReleaseRecord.argtypes = [POINTER(c_void_p), c_bool]
        ImportRecord_SetReleaseRecord(self._c_obj, value)

    def __SetImportRecordMode(self, value):
        """See :py:class:`GRANTA_Constants.ImportTypes <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        ImportRecord_SetImportRecordMode = self.lib.ImportRecord_SetImportRecordMode 
        ImportRecord_SetImportRecordMode.argtypes = [POINTER(c_void_p), c_char_p]
        ImportRecord_SetImportRecordMode(self._c_obj, EnsureEncoded(value))

    def AddSubsetReference(self, _subsetReference):
        """Appends _subsetReference to subsetReferences property on ImportRecord C-object.

           Arguments:
                _subsetReference - object of type SubsetReference.
        """

        if not isinstance(_subsetReference, SubsetReference):
            raise GRANTA_Exception('ImportRecord.AddSubsetReference','_subsetReference: Invalid argument type _subsetReference must be of type SubsetReference')
        ImportRecord_AddSubsetReference = self.lib.ImportRecord_AddSubsetReference
        ImportRecord_AddSubsetReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportRecord_AddSubsetReference(self._c_obj, _subsetReference.c_obj)
        return self

    def __ClearSubsetReferences(self):
        ImportRecord_ClearSubsetReferences = self.lib.ImportRecord_ClearSubsetReferences
        ImportRecord_ClearSubsetReferences.argtypes = [POINTER(c_void_p)]
        ImportRecord_ClearSubsetReferences(self._c_obj)
        return self

    def __GetNumberOfSubsetReferences(self):
        ImportRecord_GetNumberOfSubsetReferences = self.lib.ImportRecord_GetNumberOfSubsetReferences
        ImportRecord_GetNumberOfSubsetReferences.argtypes = [POINTER(c_void_p)]
        ImportRecord_GetNumberOfSubsetReferences.restype = c_int
        value = ImportRecord_GetNumberOfSubsetReferences(self._c_obj)
        return value
    
    def __GetSubsetReferencesElement(self,i):
        value = SubsetReference()
        ImportRecord_GetSubsetReferences = self.lib.ImportRecord_GetSubsetReferences
        ImportRecord_GetSubsetReferences.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        ImportRecord_GetSubsetReferences(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetSubsetReferences(self):
         n = self.__GetNumberOfSubsetReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetSubsetReferencesElement(i))
         return temp
    
    def __SetCopyDestinationParent(self, value):

        ImportRecord_SetCopyDestinationParent = self.lib.ImportRecord_SetCopyDestinationParent 
        ImportRecord_SetCopyDestinationParent.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportRecord_SetCopyDestinationParent(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


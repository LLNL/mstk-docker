# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ListItem import ListItem

from .IDataValue import IDataValue


class ListDataType(IDataValue):
    """ListDataType. A list of values within a Cell in Tabular Data.
    
        Arguments:
                * items - type list of :py:mod:`ListItem <GRANTA_MIScriptingToolkit.ListItem>` objects


    """
    
    def __init__(self, items=None, isOwner=True):
        """

        Arguments:
                * items - type list of :py:mod:`ListItem <GRANTA_MIScriptingToolkit.ListItem>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ListDataType_Create = self.lib.ListDataType_Create
            ListDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = ListDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if items is not None:
            self.items = items


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ListDataType_Destroy = self.lib.ListDataType_Destroy
            ListDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ListDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def items(self):
        """Property items is a list of :py:mod:`ListItem <GRANTA_MIScriptingToolkit.ListItem>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._items = self.__GetItemRefs()
        except:
            pass
        return self._items

    @items.setter
    def items(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('items','items: Invalid type items must be a list of ListItem')
        
        self._items = value

    def __GetNumberOfItemRefs(self):
        ListDataType_GetNumberOfItemRefs = self.lib.ListDataType_GetNumberOfItemRefs
        ListDataType_GetNumberOfItemRefs.argtypes = [POINTER(c_void_p)]
        ListDataType_GetNumberOfItemRefs.restype = c_int
        value = ListDataType_GetNumberOfItemRefs(self._c_obj)
        return value
    
    def __GetItemRefsElement(self,i):
        value = ListItem(isOwner=False)
        ListDataType_GetItemRefs = self.lib.ListDataType_GetItemRefs
        ListDataType_GetItemRefs.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p)), c_int]
        ListDataType_GetItemRefs(self._c_obj, value.c_obj, i)
        value._parent = self
        return value
    
    def __GetItemRefs(self):
         n = self.__GetNumberOfItemRefs();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetItemRefsElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


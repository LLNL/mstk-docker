# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordLinkGroupReference import RecordLinkGroupReference
from GRANTA_MIScriptingToolkit.TableReference import TableReference


class RecordLinkGroupDetail(object):
    """RecordLinkGroupDetail. Detailed information about a Record Link Group in a GRANTA MI Database.
    
        Arguments:
                * name - type str
                * reference - type :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>`
                * standardNames - type list of str objects
                * reverseReference - type :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>`
                * linkGroupType - type str
                * fromTable - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`
                * toTable - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`
                * reverseName - type str


    """
    
    def __init__(self, name=None, reference=None, standardNames=None, reverseReference=None, linkGroupType=None, fromTable=None, toTable=None, reverseName=None, isOwner=True):
        """

        Arguments:
                * name - type str
                * reference - type :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>`
                * standardNames - type list of str objects
                * reverseReference - type :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>`
                * linkGroupType - type str
                * fromTable - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`
                * toTable - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`
                * reverseName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordLinkGroupDetail_Create = self.lib.RecordLinkGroupDetail_Create
            RecordLinkGroupDetail_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordLinkGroupDetail_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if name is not None:
            self.name = name
        if reference is not None:
            self.reference = reference
        if standardNames is not None:
            self.standardNames = standardNames
        if reverseReference is not None:
            self.reverseReference = reverseReference
        if linkGroupType is not None:
            self.linkGroupType = linkGroupType
        if fromTable is not None:
            self.fromTable = fromTable
        if toTable is not None:
            self.toTable = toTable
        if reverseName is not None:
            self.reverseName = reverseName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordLinkGroupDetail_Destroy = self.lib.RecordLinkGroupDetail_Destroy
            RecordLinkGroupDetail_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordLinkGroupDetail_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        
        self._name = value

    @property
    def reference(self):
        """Property reference is of type :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>`. """ 
        self._reference = self.__GetReference()
        return self._reference

    @reference.setter
    def reference(self, value):
        if not isinstance(value, RecordLinkGroupReference):
            raise GRANTA_Exception('reference','reference: Invalid type reference must be of type RecordLinkGroupReference')
        
        self._reference = value

    @property
    def standardNames(self):
        """Property standardNames is a list of str objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._standardNames = self.__GetStandardNames()
        except:
            pass
        return self._standardNames

    @standardNames.setter
    def standardNames(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('standardNames','standardNames: Invalid type standardNames must be a list of str')
        
        self._standardNames = value

    @property
    def reverseReference(self):
        """Property reverseReference is of type :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>`. """ 
        self._reverseReference = self.__GetReverseReference()
        return self._reverseReference

    @reverseReference.setter
    def reverseReference(self, value):
        if not isinstance(value, RecordLinkGroupReference):
            raise GRANTA_Exception('reverseReference','reverseReference: Invalid type reverseReference must be of type RecordLinkGroupReference')
        
        self._reverseReference = value

    @property
    def linkGroupType(self):
        """Property linkGroupType is of type str. See :py:class:`GRANTA_Constants.RecordLinkGroupTypes <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._linkGroupType = self.__GetLinkGroupType()
        return self._linkGroupType

    @linkGroupType.setter
    def linkGroupType(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('linkGroupType','linkGroupType: Invalid type linkGroupType must be of type str')
        
        self._linkGroupType = value

    @property
    def fromTable(self):
        """Property fromTable is of type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`. """ 
        self._fromTable = self.__GetFromTable()
        return self._fromTable

    @fromTable.setter
    def fromTable(self, value):
        if not isinstance(value, TableReference):
            raise GRANTA_Exception('fromTable','fromTable: Invalid type fromTable must be of type TableReference')
        
        self._fromTable = value

    @property
    def toTable(self):
        """Property toTable is of type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`. """ 
        self._toTable = self.__GetToTable()
        return self._toTable

    @toTable.setter
    def toTable(self, value):
        if not isinstance(value, TableReference):
            raise GRANTA_Exception('toTable','toTable: Invalid type toTable must be of type TableReference')
        
        self._toTable = value

    @property
    def reverseName(self):
        """Property reverseName is of type str. """ 
        self._reverseName = self.__GetReverseName()
        return self._reverseName

    @reverseName.setter
    def reverseName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('reverseName','reverseName: Invalid type reverseName must be of type str')
        
        self._reverseName = value

    def __GetLinkGroupType(self):
        RecordLinkGroupDetail_GetLinkGroupType = self.lib.RecordLinkGroupDetail_GetLinkGroupType
        RecordLinkGroupDetail_GetLinkGroupType.argtypes = [POINTER(c_void_p)]
        RecordLinkGroupDetail_GetLinkGroupType.restype = POINTER(c_void_p)
        value = RecordLinkGroupDetail_GetLinkGroupType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetReference(self):
        _recordLinkGroupReference = RecordLinkGroupReference()
        RecordLinkGroupDetail_GetReference = self.lib.RecordLinkGroupDetail_GetReference
        RecordLinkGroupDetail_GetReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordLinkGroupDetail_GetReference(self._c_obj, (_recordLinkGroupReference.c_obj))
        
        return _recordLinkGroupReference
        
    def __GetReverseReference(self):
        _recordLinkGroupReference = RecordLinkGroupReference()
        RecordLinkGroupDetail_GetReverseReference = self.lib.RecordLinkGroupDetail_GetReverseReference
        RecordLinkGroupDetail_GetReverseReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordLinkGroupDetail_GetReverseReference(self._c_obj, (_recordLinkGroupReference.c_obj))
        
        return _recordLinkGroupReference
        
    def __GetReverseName(self):
        RecordLinkGroupDetail_GetReverseName = self.lib.RecordLinkGroupDetail_GetReverseName
        RecordLinkGroupDetail_GetReverseName.argtypes = [POINTER(c_void_p)]
        RecordLinkGroupDetail_GetReverseName.restype = POINTER(c_void_p)
        value = RecordLinkGroupDetail_GetReverseName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetFromTable(self):
        _tableReference = TableReference()
        RecordLinkGroupDetail_GetFromTable = self.lib.RecordLinkGroupDetail_GetFromTable
        RecordLinkGroupDetail_GetFromTable.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordLinkGroupDetail_GetFromTable(self._c_obj, (_tableReference.c_obj))
        
        return _tableReference
        
    def __GetToTable(self):
        _tableReference = TableReference()
        RecordLinkGroupDetail_GetToTable = self.lib.RecordLinkGroupDetail_GetToTable
        RecordLinkGroupDetail_GetToTable.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordLinkGroupDetail_GetToTable(self._c_obj, (_tableReference.c_obj))
        
        return _tableReference
        
    def __GetName(self):
        RecordLinkGroupDetail_GetName = self.lib.RecordLinkGroupDetail_GetName
        RecordLinkGroupDetail_GetName.argtypes = [POINTER(c_void_p)]
        RecordLinkGroupDetail_GetName.restype = POINTER(c_void_p)
        value = RecordLinkGroupDetail_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetNumberOfStandardNames(self):
        RecordLinkGroupDetail_GetNumberOfStandardNames = self.lib.RecordLinkGroupDetail_GetNumberOfStandardNames
        RecordLinkGroupDetail_GetNumberOfStandardNames.argtypes = [POINTER(c_void_p)]
        RecordLinkGroupDetail_GetNumberOfStandardNames.restype = c_int
        value = RecordLinkGroupDetail_GetNumberOfStandardNames(self._c_obj)
        return value
    
    def __GetStandardNameElement(self,i):
        RecordLinkGroupDetail_GetStandardName = self.lib.RecordLinkGroupDetail_GetStandardName
        RecordLinkGroupDetail_GetStandardName.argtypes = [POINTER(c_void_p), c_int]
        RecordLinkGroupDetail_GetStandardName.restype = POINTER(c_void_p)
        value = RecordLinkGroupDetail_GetStandardName(self._c_obj, i)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
    
    def __GetStandardNames(self):
         n = self.__GetNumberOfStandardNames();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetStandardNameElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.DiscreteValue import DiscreteValue

from .IDataValue import IDataValue


class DiscreteDataType(IDataValue):
    """DiscreteDataType. Container of discrete data.
    
        Arguments:
                * discreteValues - type list of :py:mod:`DiscreteValue <GRANTA_MIScriptingToolkit.DiscreteValue>` objects


    """
    
    def __init__(self, discreteValues=None, isOwner=True):
        """

        Arguments:
                * discreteValues - type list of :py:mod:`DiscreteValue <GRANTA_MIScriptingToolkit.DiscreteValue>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            DiscreteDataType_Create = self.lib.DiscreteDataType_Create
            DiscreteDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = DiscreteDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if discreteValues is not None:
            self.discreteValues = discreteValues


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            DiscreteDataType_Destroy = self.lib.DiscreteDataType_Destroy
            DiscreteDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            DiscreteDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def discreteValues(self):
        """Property discreteValues is a list of :py:mod:`DiscreteValue <GRANTA_MIScriptingToolkit.DiscreteValue>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._discreteValues = self.__GetDiscreteValues()
        except:
            pass
        return self._discreteValues

    @discreteValues.setter
    def discreteValues(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('discreteValues','discreteValues: Invalid type discreteValues must be a list of DiscreteValue')
                
        try:
            self.__updatediscreteValues = True
            self.__ClearDiscreteValues()
            for v in value:
                self.AddDiscreteValue(v)
        except:
            pass


    def AddDiscreteValue(self, _discreteValue):
        """Appends _discreteValue to discreteValues property on DiscreteDataType C-object.

           Arguments:
                _discreteValue - object of type DiscreteValue.
        """

        if not isinstance(_discreteValue, DiscreteValue):
            raise GRANTA_Exception('DiscreteDataType.AddDiscreteValue','_discreteValue: Invalid argument type _discreteValue must be of type DiscreteValue')
        DiscreteDataType_AddDiscreteValue = self.lib.DiscreteDataType_AddDiscreteValue
        DiscreteDataType_AddDiscreteValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        DiscreteDataType_AddDiscreteValue(self._c_obj, _discreteValue.c_obj)
        return self

    def __ClearDiscreteValues(self):
        DiscreteDataType_ClearDiscreteValues = self.lib.DiscreteDataType_ClearDiscreteValues
        DiscreteDataType_ClearDiscreteValues.argtypes = [POINTER(c_void_p)]
        DiscreteDataType_ClearDiscreteValues(self._c_obj)
        return self

    def __GetNumberOfDiscreteValues(self):
        DiscreteDataType_GetNumberOfDiscreteValues = self.lib.DiscreteDataType_GetNumberOfDiscreteValues
        DiscreteDataType_GetNumberOfDiscreteValues.argtypes = [POINTER(c_void_p)]
        DiscreteDataType_GetNumberOfDiscreteValues.restype = c_int
        value = DiscreteDataType_GetNumberOfDiscreteValues(self._c_obj)
        return value
    
    def __GetDiscreteValueElement(self,i):
        value = DiscreteValue()
        DiscreteDataType_GetDiscreteValue = self.lib.DiscreteDataType_GetDiscreteValue
        DiscreteDataType_GetDiscreteValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        DiscreteDataType_GetDiscreteValue(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetDiscreteValues(self):
         n = self.__GetNumberOfDiscreteValues();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetDiscreteValueElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


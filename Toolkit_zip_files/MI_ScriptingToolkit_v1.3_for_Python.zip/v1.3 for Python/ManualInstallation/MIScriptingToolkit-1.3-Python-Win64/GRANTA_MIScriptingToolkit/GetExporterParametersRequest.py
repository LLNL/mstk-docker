# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.UnitConversionContext import UnitConversionContext


class GetExporterParametersRequest(object):
    """GetExporterParametersRequest. Input for the GetExporterParameters operation.
    
        Arguments:
                * records - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * exporterKey - type str
                * populateGUIDs - type bool
                * unitConversionContext - type :py:mod:`UnitConversionContext <GRANTA_MIScriptingToolkit.UnitConversionContext>`


    """
    
    def __init__(self, records=None, exporterKey=None, populateGUIDs=None, unitConversionContext=None, isOwner=True):
        """

        Arguments:
                * records - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * exporterKey - type str
                * populateGUIDs - type bool
                * unitConversionContext - type :py:mod:`UnitConversionContext <GRANTA_MIScriptingToolkit.UnitConversionContext>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetExporterParametersRequest_Create = self.lib.GetExporterParametersRequest_Create
            GetExporterParametersRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetExporterParametersRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if records is not None:
            self.records = records
        if exporterKey is not None:
            self.exporterKey = exporterKey
        if populateGUIDs is not None:
            self.populateGUIDs = populateGUIDs
        if unitConversionContext is not None:
            self.unitConversionContext = unitConversionContext


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetExporterParametersRequest_Destroy = self.lib.GetExporterParametersRequest_Destroy
            GetExporterParametersRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetExporterParametersRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def records(self):
        """Property records is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._records = self.__GetRecords()
        except:
            pass
        return self._records

    @records.setter
    def records(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('records','records: Invalid type records must be a list of RecordReference')
                
        try:
            self.__updaterecords = True
            self.__ClearRecords()
            for v in value:
                self.AddRecord(v)
        except:
            pass


    @property
    def exporterKey(self):
        """Property exporterKey is of type str. """ 
        self._exporterKey = self.__GetExporterKey()
        return self._exporterKey

    @exporterKey.setter
    def exporterKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('exporterKey','exporterKey: Invalid type exporterKey must be of type str')
        self.__SetExporterKey(value)
        self._exporterKey = value

    @property
    def populateGUIDs(self):
        """Property populateGUIDs is of type bool. """ 
        self._populateGUIDs = self.__GetPopulateGUIDs()
        return self._populateGUIDs

    @populateGUIDs.setter
    def populateGUIDs(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('populateGUIDs','populateGUIDs: Invalid type populateGUIDs must be of type bool')
        self.__SetPopulateGUIDs(value)
        self._populateGUIDs = value

    @property
    def unitConversionContext(self):
        """Property unitConversionContext is of type :py:mod:`UnitConversionContext <GRANTA_MIScriptingToolkit.UnitConversionContext>`. """ 
        self._unitConversionContext = self.__GetUnitConversionContext()
        return self._unitConversionContext

    @unitConversionContext.setter
    def unitConversionContext(self, value):
        if not isinstance(value, UnitConversionContext):
            raise GRANTA_Exception('unitConversionContext','unitConversionContext: Invalid type unitConversionContext must be of type UnitConversionContext')
        self.__SetUnitConversionContext(value)
        self._unitConversionContext = value

    def AddRecord(self, _recordReference):
        """Appends _recordReference to records property on GetExporterParametersRequest C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('GetExporterParametersRequest.AddRecord','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        GetExporterParametersRequest_AddRecord = self.lib.GetExporterParametersRequest_AddRecord
        GetExporterParametersRequest_AddRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetExporterParametersRequest_AddRecord(self._c_obj, _recordReference.c_obj)
        return self

    def __ClearRecords(self):
        GetExporterParametersRequest_ClearRecords = self.lib.GetExporterParametersRequest_ClearRecords
        GetExporterParametersRequest_ClearRecords.argtypes = [POINTER(c_void_p)]
        GetExporterParametersRequest_ClearRecords(self._c_obj)
        return self

    def __GetNumberOfRecords(self):
        GetExporterParametersRequest_GetNumberOfRecords = self.lib.GetExporterParametersRequest_GetNumberOfRecords
        GetExporterParametersRequest_GetNumberOfRecords.argtypes = [POINTER(c_void_p)]
        GetExporterParametersRequest_GetNumberOfRecords.restype = c_int
        value = GetExporterParametersRequest_GetNumberOfRecords(self._c_obj)
        return value
    
    def __GetRecordElement(self,i):
        value = RecordReference()
        GetExporterParametersRequest_GetRecord = self.lib.GetExporterParametersRequest_GetRecord
        GetExporterParametersRequest_GetRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetExporterParametersRequest_GetRecord(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecords(self):
         n = self.__GetNumberOfRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordElement(i))
         return temp
    
    def __SetExporterKey(self, value):

        GetExporterParametersRequest_SetExporterKey = self.lib.GetExporterParametersRequest_SetExporterKey 
        GetExporterParametersRequest_SetExporterKey.argtypes = [POINTER(c_void_p), c_char_p]
        GetExporterParametersRequest_SetExporterKey(self._c_obj, EnsureEncoded(value))

    def __GetExporterKey(self):
        GetExporterParametersRequest_GetExporterKey = self.lib.GetExporterParametersRequest_GetExporterKey
        GetExporterParametersRequest_GetExporterKey.argtypes = [POINTER(c_void_p)]
        GetExporterParametersRequest_GetExporterKey.restype = POINTER(c_void_p)
        value = GetExporterParametersRequest_GetExporterKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetUnitConversionContext(self):
        _unitConversionContext = UnitConversionContext()
        GetExporterParametersRequest_GetUnitConversionContext = self.lib.GetExporterParametersRequest_GetUnitConversionContext
        GetExporterParametersRequest_GetUnitConversionContext.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetExporterParametersRequest_GetUnitConversionContext(self._c_obj, (_unitConversionContext.c_obj))
        
        return _unitConversionContext
        
    def __SetUnitConversionContext(self, value):

        GetExporterParametersRequest_SetUnitConversionContext = self.lib.GetExporterParametersRequest_SetUnitConversionContext 
        GetExporterParametersRequest_SetUnitConversionContext.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetExporterParametersRequest_SetUnitConversionContext(self._c_obj, value.c_obj)

    def __SetPopulateGUIDs(self, value):

        GetExporterParametersRequest_SetPopulateGUIDs = self.lib.GetExporterParametersRequest_SetPopulateGUIDs 
        GetExporterParametersRequest_SetPopulateGUIDs.argtypes = [POINTER(c_void_p), c_bool]
        GetExporterParametersRequest_SetPopulateGUIDs(self._c_obj, value)

    def __GetPopulateGUIDs(self):
        GetExporterParametersRequest_GetPopulateGUIDs = self.lib.GetExporterParametersRequest_GetPopulateGUIDs
        GetExporterParametersRequest_GetPopulateGUIDs.argtypes = [POINTER(c_void_p)]
        GetExporterParametersRequest_GetPopulateGUIDs.restype = c_bool
        value = GetExporterParametersRequest_GetPopulateGUIDs(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class RecordVersionState(object):
    """RecordVersionState. The version status of a particular Record in a GRANTA MI database.
    
        Arguments:
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * versionState - type int


    """
    class VersionState:
        Released = 0
        Superseded = 1
        Withdrawn = 2
        Unreleased = 3
        Unversioned = 4
        Unknown = 5
    
    def __init__(self, recordReference=None, versionState=None, isOwner=True):
        """

        Arguments:
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * versionState - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordVersionState_Create = self.lib.RecordVersionState_Create
            RecordVersionState_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordVersionState_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordReference is not None:
            self.recordReference = recordReference
        if versionState is not None:
            self.versionState = versionState


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordVersionState_Destroy = self.lib.RecordVersionState_Destroy
            RecordVersionState_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordVersionState_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordReference(self):
        """Property recordReference is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._recordReference = self.__GetRecordReference()
        return self._recordReference

    @recordReference.setter
    def recordReference(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('recordReference','recordReference: Invalid type recordReference must be of type RecordReference')
        
        self._recordReference = value

    @property
    def versionState(self):
        """Property versionState is of type int. See :py:class:`RecordVersionState.VersionState <RecordVersionState.VersionState>` for supported values.""" 
        self._versionState = self.__GetVersionState()
        return self._versionState

    @versionState.setter
    def versionState(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('versionState','versionState: Invalid type versionState must be of type int')
        
        self._versionState = value

    def __GetRecordReference(self):
        _recordReference = RecordReference()
        RecordVersionState_GetRecordReference = self.lib.RecordVersionState_GetRecordReference
        RecordVersionState_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordVersionState_GetRecordReference(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __GetVersionState(self):
        RecordVersionState_GetVersionState = self.lib.RecordVersionState_GetVersionState
        RecordVersionState_GetVersionState.argtypes = [POINTER(c_void_p)]
        RecordVersionState_GetVersionState.restype = c_int
        value = RecordVersionState_GetVersionState(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


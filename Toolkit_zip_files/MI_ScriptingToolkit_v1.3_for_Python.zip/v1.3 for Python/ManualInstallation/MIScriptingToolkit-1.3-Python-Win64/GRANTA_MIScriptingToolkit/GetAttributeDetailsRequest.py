# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference


class GetAttributeDetailsRequest(object):
    """GetAttributeDetailsRequest. Input for the GetAttributeDetails operation.
For requests at least one :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` is required.
    
        Arguments:
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects


    """
    
    def __init__(self, attributeReferences=None, isOwner=True):
        """

        Arguments:
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetAttributeDetailsRequest_Create = self.lib.GetAttributeDetailsRequest_Create
            GetAttributeDetailsRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetAttributeDetailsRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if attributeReferences is not None:
            self.attributeReferences = attributeReferences


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetAttributeDetailsRequest_Destroy = self.lib.GetAttributeDetailsRequest_Destroy
            GetAttributeDetailsRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetAttributeDetailsRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def attributeReferences(self):
        """Property attributeReferences is a list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeReferences = self.__GetAttributeReferences()
        except:
            pass
        return self._attributeReferences

    @attributeReferences.setter
    def attributeReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeReferences','attributeReferences: Invalid type attributeReferences must be a list of AttributeReference')
                
        try:
            self.__updateattributeReferences = True
            self.__ClearAttributeReferences()
            for v in value:
                self.AddAttributeReference(v)
        except:
            pass


    def __GetNumberOfAttributeReferences(self):
        GetAttributeDetailsRequest_GetNumberOfAttributeReferences = self.lib.GetAttributeDetailsRequest_GetNumberOfAttributeReferences
        GetAttributeDetailsRequest_GetNumberOfAttributeReferences.argtypes = [POINTER(c_void_p)]
        GetAttributeDetailsRequest_GetNumberOfAttributeReferences.restype = c_int
        value = GetAttributeDetailsRequest_GetNumberOfAttributeReferences(self._c_obj)
        return value
    
    def __GetAttributeReferencesElement(self,i):
        value = AttributeReference()
        GetAttributeDetailsRequest_GetAttributeReferences = self.lib.GetAttributeDetailsRequest_GetAttributeReferences
        GetAttributeDetailsRequest_GetAttributeReferences.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetAttributeDetailsRequest_GetAttributeReferences(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributeReferences(self):
         n = self.__GetNumberOfAttributeReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeReferencesElement(i))
         return temp
    
    def AddAttributeReference(self, _attributeReference):
        """Appends _attributeReference to attributeReferences property on GetAttributeDetailsRequest C-object.

           Arguments:
                _attributeReference - object of type AttributeReference.
        """

        if not isinstance(_attributeReference, AttributeReference):
            raise GRANTA_Exception('GetAttributeDetailsRequest.AddAttributeReference','_attributeReference: Invalid argument type _attributeReference must be of type AttributeReference')
        GetAttributeDetailsRequest_AddAttributeReference = self.lib.GetAttributeDetailsRequest_AddAttributeReference
        GetAttributeDetailsRequest_AddAttributeReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetAttributeDetailsRequest_AddAttributeReference(self._c_obj, _attributeReference.c_obj)
        return self

    def __ClearAttributeReferences(self):
        GetAttributeDetailsRequest_ClearAttributeReferences = self.lib.GetAttributeDetailsRequest_ClearAttributeReferences
        GetAttributeDetailsRequest_ClearAttributeReferences.argtypes = [POINTER(c_void_p)]
        GetAttributeDetailsRequest_ClearAttributeReferences(self._c_obj)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


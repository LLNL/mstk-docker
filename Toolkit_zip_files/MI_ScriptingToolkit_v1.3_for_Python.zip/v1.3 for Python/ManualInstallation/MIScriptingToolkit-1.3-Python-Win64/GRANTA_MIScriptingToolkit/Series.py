# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.Constraints import Constraints
from GRANTA_MIScriptingToolkit.XYData import XYData


class Series(object):
    """Series. Type for functional data which includes X-Y data and any constraints.
    
        Arguments:
                * XYPoints - type :py:mod:`XYData <GRANTA_MIScriptingToolkit.XYData>`
                * decoration - type int
                * constraints - type :py:mod:`Constraints <GRANTA_MIScriptingToolkit.Constraints>`


    """
    
    def __init__(self, XYPoints=None, decoration=None, constraints=None, isOwner=True):
        """

        Arguments:
                * XYPoints - type :py:mod:`XYData <GRANTA_MIScriptingToolkit.XYData>`
                * decoration - type int
                * constraints - type :py:mod:`Constraints <GRANTA_MIScriptingToolkit.Constraints>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            Series_Create = self.lib.Series_Create
            Series_Create.restype = POINTER(c_void_p)
            self.c_obj = Series_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if XYPoints is not None:
            self.XYPoints = XYPoints
        if decoration is not None:
            self.decoration = decoration
        if constraints is not None:
            self.constraints = constraints


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            Series_Destroy = self.lib.Series_Destroy
            Series_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            Series_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def XYPoints(self):
        """Property XYPoints is of type :py:mod:`XYData <GRANTA_MIScriptingToolkit.XYData>`. """ 
        self._XYPoints = self.__GetXYPoints()
        return self._XYPoints

    @XYPoints.setter
    def XYPoints(self, value):
        if not isinstance(value, XYData):
            raise GRANTA_Exception('XYPoints','XYPoints: Invalid type XYPoints must be of type XYData')
        self.__SetXYPoints(value)
        self._XYPoints = value

    @property
    def decoration(self):
        """Property decoration is of type int. See :py:class:`GRANTA_Constants.GraphDecoration <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._decoration = self.__GetDecoration()
        return self._decoration

    @decoration.setter
    def decoration(self, value):
        """See :py:class:`GRANTA_Constants.GraphDecoration <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('decoration','decoration: Invalid type decoration must be of type int')
        self.__SetDecoration(value)
        self._decoration = value

    @property
    def constraints(self):
        """Property constraints is of type :py:mod:`Constraints <GRANTA_MIScriptingToolkit.Constraints>`. """ 
        self._constraints = self.__GetConstraints()
        return self._constraints

    @constraints.setter
    def constraints(self, value):
        if not isinstance(value, Constraints):
            raise GRANTA_Exception('constraints','constraints: Invalid type constraints must be of type Constraints')
        self.__SetConstraints(value)
        self._constraints = value

    def __GetConstraints(self):
        _constraints = Constraints()
        Series_GetConstraints = self.lib.Series_GetConstraints
        Series_GetConstraints.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        Series_GetConstraints(self._c_obj, (_constraints.c_obj))
        
        return _constraints
        
    def __SetConstraints(self, value):

        Series_SetConstraints = self.lib.Series_SetConstraints 
        Series_SetConstraints.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        Series_SetConstraints(self._c_obj, value.c_obj)

    def __GetXYPoints(self):
        _XYData = XYData()
        Series_GetXYPoints = self.lib.Series_GetXYPoints
        Series_GetXYPoints.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        Series_GetXYPoints(self._c_obj, (_XYData.c_obj))
        
        return _XYData
        
    def __SetXYPoints(self, value):

        Series_SetXYPoints = self.lib.Series_SetXYPoints 
        Series_SetXYPoints.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        Series_SetXYPoints(self._c_obj, value.c_obj)

    def __GetDecoration(self):
        Series_GetDecoration = self.lib.Series_GetDecoration
        Series_GetDecoration.argtypes = [POINTER(c_void_p)]
        Series_GetDecoration.restype = c_int
        value = Series_GetDecoration(self._c_obj)
        return value
    
    def __SetDecoration(self, value):
        """See :py:class:`GRANTA_Constants.GraphDecoration <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        Series_SetDecoration = self.lib.Series_SetDecoration 
        Series_SetDecoration.argtypes = [POINTER(c_void_p), c_int]
        Series_SetDecoration(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


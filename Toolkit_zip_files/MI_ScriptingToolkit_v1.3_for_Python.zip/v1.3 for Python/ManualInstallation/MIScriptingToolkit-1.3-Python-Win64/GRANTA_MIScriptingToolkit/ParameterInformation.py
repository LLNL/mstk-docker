# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.UnitInformation import UnitInformation
from GRANTA_MIScriptingToolkit.ParameterReference import ParameterReference


class ParameterInformation(object):
    """ParameterInformation. Information for a parameter in a GRANTA MI database.
Contains the name and unit information for a parameter and a :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>` to the parameter.
    
        Arguments:
                * parameterReference - type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`
                * name - type str
                * unit - type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`


    """
    
    def __init__(self, parameterReference=None, name=None, unit=None, isOwner=True):
        """

        Arguments:
                * parameterReference - type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`
                * name - type str
                * unit - type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ParameterInformation_Create = self.lib.ParameterInformation_Create
            ParameterInformation_Create.restype = POINTER(c_void_p)
            self.c_obj = ParameterInformation_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if parameterReference is not None:
            self.parameterReference = parameterReference
        if name is not None:
            self.name = name
        if unit is not None:
            self.unit = unit


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ParameterInformation_Destroy = self.lib.ParameterInformation_Destroy
            ParameterInformation_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ParameterInformation_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def parameterReference(self):
        """Property parameterReference is of type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`. """ 
        self._parameterReference = self.__GetParameterReference()
        return self._parameterReference

    @parameterReference.setter
    def parameterReference(self, value):
        if not isinstance(value, ParameterReference):
            raise GRANTA_Exception('parameterReference','parameterReference: Invalid type parameterReference must be of type ParameterReference')
        self.__SetParameterReference(value)
        self._parameterReference = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    @property
    def unit(self):
        """Property unit is of type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`. """ 
        self._unit = self.__GetUnit()
        return self._unit

    @unit.setter
    def unit(self, value):
        if not isinstance(value, UnitInformation):
            raise GRANTA_Exception('unit','unit: Invalid type unit must be of type UnitInformation')
        self.__SetUnit(value)
        self._unit = value

    def __GetName(self):
        ParameterInformation_GetName = self.lib.ParameterInformation_GetName
        ParameterInformation_GetName.argtypes = [POINTER(c_void_p)]
        ParameterInformation_GetName.restype = POINTER(c_void_p)
        value = ParameterInformation_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        ParameterInformation_SetName = self.lib.ParameterInformation_SetName 
        ParameterInformation_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        ParameterInformation_SetName(self._c_obj, EnsureEncoded(value))

    def __GetUnit(self):
        _unitInformation = UnitInformation()
        ParameterInformation_GetUnit = self.lib.ParameterInformation_GetUnit
        ParameterInformation_GetUnit.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ParameterInformation_GetUnit(self._c_obj, (_unitInformation.c_obj))
        
        return _unitInformation
        
    def __SetUnit(self, value):

        ParameterInformation_SetUnit = self.lib.ParameterInformation_SetUnit 
        ParameterInformation_SetUnit.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ParameterInformation_SetUnit(self._c_obj, value.c_obj)

    def __GetParameterReference(self):
        _parameterReference = ParameterReference()
        ParameterInformation_GetParameterReference = self.lib.ParameterInformation_GetParameterReference
        ParameterInformation_GetParameterReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ParameterInformation_GetParameterReference(self._c_obj, (_parameterReference.c_obj))
        
        return _parameterReference
        
    def __SetParameterReference(self, value):

        ParameterInformation_SetParameterReference = self.lib.ParameterInformation_SetParameterReference 
        ParameterInformation_SetParameterReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ParameterInformation_SetParameterReference(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


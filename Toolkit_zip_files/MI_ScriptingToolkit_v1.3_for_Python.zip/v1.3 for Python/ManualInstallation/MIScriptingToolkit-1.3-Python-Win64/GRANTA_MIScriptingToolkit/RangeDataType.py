# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs


from .IDataValue import IDataValue


class RangeDataType(IDataValue):
    """RangeDataType. Type for values of range data.
Both LowValue and HighValue must be populated.
    
        Arguments:
                * hasLow - type bool
                * high - type float
                * unitSymbol - type str
                * hasHigh - type bool
                * low - type float


    """
    
    def __init__(self, hasLow=None, high=None, unitSymbol=None, hasHigh=None, low=None, isOwner=True):
        """

        Arguments:
                * hasLow - type bool
                * high - type float
                * unitSymbol - type str
                * hasHigh - type bool
                * low - type float

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RangeDataType_Create = self.lib.RangeDataType_Create
            RangeDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = RangeDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if hasLow is not None:
            self.hasLow = hasLow
        if high is not None:
            self.high = high
        if unitSymbol is not None:
            self.unitSymbol = unitSymbol
        if hasHigh is not None:
            self.hasHigh = hasHigh
        if low is not None:
            self.low = low


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RangeDataType_Destroy = self.lib.RangeDataType_Destroy
            RangeDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RangeDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def hasLow(self):
        """Property hasLow is of type bool. """ 
        self._hasLow = self.__GetHasLow()
        return self._hasLow

    @hasLow.setter
    def hasLow(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('hasLow','hasLow: Invalid type hasLow must be of type bool')
        
        self._hasLow = value

    @property
    def high(self):
        """Property high is of type float. """ 
        self._high = self.__GetHigh()
        return self._high

    @high.setter
    def high(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('high','high: Invalid type high must be of type float')
        self.__SetHigh(value)
        self._high = value

    @property
    def unitSymbol(self):
        """Property unitSymbol is of type str. """ 
        self._unitSymbol = self.__GetUnitSymbol()
        return self._unitSymbol

    @unitSymbol.setter
    def unitSymbol(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('unitSymbol','unitSymbol: Invalid type unitSymbol must be of type str')
        self.__SetUnitSymbol(value)
        self._unitSymbol = value

    @property
    def hasHigh(self):
        """Property hasHigh is of type bool. """ 
        self._hasHigh = self.__GetHasHigh()
        return self._hasHigh

    @hasHigh.setter
    def hasHigh(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('hasHigh','hasHigh: Invalid type hasHigh must be of type bool')
        
        self._hasHigh = value

    @property
    def low(self):
        """Property low is of type float. """ 
        self._low = self.__GetLow()
        return self._low

    @low.setter
    def low(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('low','low: Invalid type low must be of type float')
        self.__SetLow(value)
        self._low = value

    def __GetLow(self):
        RangeDataType_GetLow = self.lib.RangeDataType_GetLow
        RangeDataType_GetLow.argtypes = [POINTER(c_void_p)]
        RangeDataType_GetLow.restype = c_double
        value = RangeDataType_GetLow(self._c_obj)
        return value
    
    def __GetHasLow(self):
        RangeDataType_GetHasLow = self.lib.RangeDataType_GetHasLow
        RangeDataType_GetHasLow.argtypes = [POINTER(c_void_p)]
        RangeDataType_GetHasLow.restype = c_bool
        value = RangeDataType_GetHasLow(self._c_obj)
        return value
    
    def __GetHasHigh(self):
        RangeDataType_GetHasHigh = self.lib.RangeDataType_GetHasHigh
        RangeDataType_GetHasHigh.argtypes = [POINTER(c_void_p)]
        RangeDataType_GetHasHigh.restype = c_bool
        value = RangeDataType_GetHasHigh(self._c_obj)
        return value
    
    def __GetHigh(self):
        RangeDataType_GetHigh = self.lib.RangeDataType_GetHigh
        RangeDataType_GetHigh.argtypes = [POINTER(c_void_p)]
        RangeDataType_GetHigh.restype = c_double
        value = RangeDataType_GetHigh(self._c_obj)
        return value
    
    def __SetLow(self, value):

        RangeDataType_SetLow = self.lib.RangeDataType_SetLow 
        RangeDataType_SetLow.argtypes = [POINTER(c_void_p), c_double]
        RangeDataType_SetLow(self._c_obj, value)

    def __SetHigh(self, value):

        RangeDataType_SetHigh = self.lib.RangeDataType_SetHigh 
        RangeDataType_SetHigh.argtypes = [POINTER(c_void_p), c_double]
        RangeDataType_SetHigh(self._c_obj, value)

    def __GetUnitSymbol(self):
        RangeDataType_GetUnitSymbol = self.lib.RangeDataType_GetUnitSymbol
        RangeDataType_GetUnitSymbol.argtypes = [POINTER(c_void_p)]
        RangeDataType_GetUnitSymbol.restype = POINTER(c_void_p)
        value = RangeDataType_GetUnitSymbol(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetUnitSymbol(self, value):

        RangeDataType_SetUnitSymbol = self.lib.RangeDataType_SetUnitSymbol 
        RangeDataType_SetUnitSymbol.argtypes = [POINTER(c_void_p), c_char_p]
        RangeDataType_SetUnitSymbol(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


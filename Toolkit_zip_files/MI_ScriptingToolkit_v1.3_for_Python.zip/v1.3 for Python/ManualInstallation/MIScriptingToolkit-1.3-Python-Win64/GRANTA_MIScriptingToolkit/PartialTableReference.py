# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class PartialTableReference(object):
    """PartialTableReference. A reference to a GRANTA MI table.
Usually, just one of the several optional fields should be provided; where 
more than one is provided, the highest priority one is used, where the descending priority order is: tableIdentity, tableGUID, tableName.
    
        Arguments:
                * tableName - type str
                * tableGUID - type str
                * tableID - type int


    """
    
    def __init__(self, tableName=None, tableGUID=None, tableID=None, isOwner=True):
        """

        Arguments:
                * tableName - type str
                * tableGUID - type str
                * tableID - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            PartialTableReference_Create = self.lib.PartialTableReference_Create
            PartialTableReference_Create.restype = POINTER(c_void_p)
            self.c_obj = PartialTableReference_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if tableName is not None:
            self.tableName = tableName
        if tableGUID is not None:
            self.tableGUID = tableGUID
        if tableID is not None:
            self.tableID = tableID


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            PartialTableReference_Destroy = self.lib.PartialTableReference_Destroy
            PartialTableReference_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            PartialTableReference_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def tableName(self):
        """Property tableName is of type str. """ 
        try:
            return self._tableName
        except:
            return None

    @tableName.setter
    def tableName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('tableName','tableName: Invalid type tableName must be of type str')
        self.__SetTableName(value)
        self._tableName = value

    @property
    def tableGUID(self):
        """Property tableGUID is of type str. """ 
        try:
            return self._tableGUID
        except:
            return None

    @tableGUID.setter
    def tableGUID(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('tableGUID','tableGUID: Invalid type tableGUID must be of type str')
        self.__SetTableGUID(value)
        self._tableGUID = value

    @property
    def tableID(self):
        """Property tableID is of type int. """ 
        try:
            return self._tableID
        except:
            return None

    @tableID.setter
    def tableID(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('tableID','tableID: Invalid type tableID must be of type int')
        self.__SetTableID(value)
        self._tableID = value

    def __SetTableID(self, value):

        PartialTableReference_SetTableID = self.lib.PartialTableReference_SetTableID 
        PartialTableReference_SetTableID.argtypes = [POINTER(c_void_p), c_int]
        PartialTableReference_SetTableID(self._c_obj, value)

    def __SetTableGUID(self, value):

        PartialTableReference_SetTableGUID = self.lib.PartialTableReference_SetTableGUID 
        PartialTableReference_SetTableGUID.argtypes = [POINTER(c_void_p), c_char_p]
        PartialTableReference_SetTableGUID(self._c_obj, EnsureEncoded(value))

    def __SetTableName(self, value):

        PartialTableReference_SetTableName = self.lib.PartialTableReference_SetTableName 
        PartialTableReference_SetTableName.argtypes = [POINTER(c_void_p), c_char_p]
        PartialTableReference_SetTableName(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


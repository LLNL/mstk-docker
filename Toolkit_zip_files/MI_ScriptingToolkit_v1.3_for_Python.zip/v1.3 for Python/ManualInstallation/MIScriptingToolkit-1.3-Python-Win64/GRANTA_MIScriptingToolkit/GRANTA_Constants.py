
from ctypes import POINTER
from ctypes import c_void_p
from ctypes import c_int
from ctypes import c_char_p
from ctypes import c_bool
from ctypes import c_double
import GRANTA_MIScriptingToolkit


class GRANTA_Constants(object):
    POINT_TYPE_STRING = 'POIN'
    RANGE_TYPE_STRING = 'RNGE'
    FLOAT_FUNCTIONAL_TYPE_STRING = 'FUNC'
    INTEGER_TYPE_STRING = 'INPT'
    LOGICAL_TYPE_STRING = 'LOGI'
    DISCRETE_TYPE_STRING = 'DISC'
    SHORT_TEXT_TYPE_STRING = 'STXT'
    LONG_TEXT_TYPE_STRING = 'LTXT'
    HYPERLINK_TYPE_STRING = 'HLNK'
    FLOAT_FUNCTIONAL_SERIES_TYPE_STRING = 'FLOAT_FUNCTIONAL_SERIES'
    FLOAT_FUNCTIONAL_GRIDDED_TYPE_STRING = 'FLOAT_FUNCTIONAL_GRIDDED'

    class BinaryDataRepresentation:
        Inline = 0
        URL = 1

    class VersionPolicy:
        NoPolicy = 0
        IncludeAll = 1
        LatestVersionPerName = 2

    class GraphDecoration:
        Lines = 0
        Markers = 1
        LinesAndMarkers = 2

    class ImportTypes:
        Create = "Create"
        Update = "Update"
        Copy = "Copy"

    class SearchMode:
        Normal = 0
        ReadOnly = 1
        Unspecified = 2

    class TablesFilter:
        NoFilter = 0
        MaterialsTablesOnly = 1
        ProcessesTablesOnly = 2
        SubstancesTablesOnly = 3
        LegislationsTablesOnly = 4
        TransportTypesTablesOnly = 5
        RegionsTablesOnly = 6
        EndOfLifeOptionsTablesOnly = 7
        EnergyConversionOptionsTablesOnly = 8
        CoatingsTablesOnly = 9
        PartsTablesOnly = 10
        InHouseTablesOnly = 11
        SequenceSpecificationsTablesOnly = 12
        ElementsTablesOnly = 13
        UniverseTablesOnly = 14
        ProducersTablesOnly = 15
        ShapeTablesOnly = 16
        ReferenceTablesOnly = 17
        MobileUseTypesTablesOnly = 18

    class ParameterTypes:
        Numeric = 'Numeric'
        Discrete = 'Discrete'

    class ImportErrorMode:
        Fault = "FaultAndRollbackOnAnyError"
        Continue = "LogAndContinueWherePossible"

    class RecordLinkGroupTypes:
        Static = "static"
        Dynamic = "dynamic"
        CrossDatabase = "crossDatabase"

    class RecordLinkCheckMode:
        Forward = "CheckOnlyForwardLinks"
        ForwardAndReverse = "CheckForwardAndReverseLinks"
   
    #XY Data types
    POINT_XYDATA_TYPE_STRING = 'XYPoint'
    RANGE_XYDATA_TYPE_STRING = 'XYRange'
    
    # Backwards compat
    def __init__(self):
        self.POINT_TYPE_STRING = 'POIN'
        self.RANGE_TYPE_STRING = 'RNGE'
        self.FLOAT_FUNCTIONAL_TYPE_STRING = 'FUNC'
        self.INTEGER_TYPE_STRING = 'INPT'
        self.LOGICAL_TYPE_STRING = 'LOGI'
        self.DISCRETE_TYPE_STRING = 'DISC'
        self.SHORT_TEXT_TYPE_STRING = 'STXT'
        self.LONG_TEXT_TYPE_STRING = 'LTXT'
        self.HYPERLINK_TYPE_STRING = 'HLNK'
        self.FLOAT_FUNCTIONAL_SERIES_TYPE_STRING = 'FLOAT_FUNCTIONAL_SERIES'
        self.FLOAT_FUNCTIONAL_GRIDDED_TYPE_STRING = 'FLOAT_FUNCTIONAL_GRIDDED'

        #Parameter Types
        self.NUMERIC_PARAMETER_TYPE_STRING = 'Numeric'
        self.DISCRETE_PARAMETER_TYPE_STRING = 'Discrete'
       
        #XY Data types
        self.POINT_XYDATA_TYPE_STRING = 'XYPoint'
        self.RANGE_XYDATA_TYPE_STRING = 'XYRange'


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.AttributeAddress import AttributeAddress


class RecordWithAttributeAddresses(object):
    """RecordWithAttributeAddresses. A :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` with a list of attributes and their upload URL addresses.
    
        Arguments:
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * attributeAddresses - type list of :py:mod:`AttributeAddress <GRANTA_MIScriptingToolkit.AttributeAddress>` objects


    """
    
    def __init__(self, recordReference=None, attributeAddresses=None, isOwner=True):
        """

        Arguments:
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * attributeAddresses - type list of :py:mod:`AttributeAddress <GRANTA_MIScriptingToolkit.AttributeAddress>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordWithAttributeAddresses_Create = self.lib.RecordWithAttributeAddresses_Create
            RecordWithAttributeAddresses_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordWithAttributeAddresses_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordReference is not None:
            self.recordReference = recordReference
        if attributeAddresses is not None:
            self.attributeAddresses = attributeAddresses


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordWithAttributeAddresses_Destroy = self.lib.RecordWithAttributeAddresses_Destroy
            RecordWithAttributeAddresses_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordWithAttributeAddresses_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordReference(self):
        """Property recordReference is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._recordReference = self.__GetRecordReference()
        return self._recordReference

    @recordReference.setter
    def recordReference(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('recordReference','recordReference: Invalid type recordReference must be of type RecordReference')
        self.__SetRecordReference(value)
        self._recordReference = value

    @property
    def attributeAddresses(self):
        """Property attributeAddresses is a list of :py:mod:`AttributeAddress <GRANTA_MIScriptingToolkit.AttributeAddress>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeAddresses = self.__GetAttributeAddresses()
        except:
            pass
        return self._attributeAddresses

    @attributeAddresses.setter
    def attributeAddresses(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeAddresses','attributeAddresses: Invalid type attributeAddresses must be a list of AttributeAddress')
                
        try:
            self.__updateattributeAddresses = True
            self.__ClearAttributeAddresses()
            for v in value:
                self.AddAttributeAddress(v)
        except:
            pass


    def __GetRecordReference(self):
        _recordReference = RecordReference()
        RecordWithAttributeAddresses_GetRecordReference = self.lib.RecordWithAttributeAddresses_GetRecordReference
        RecordWithAttributeAddresses_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordWithAttributeAddresses_GetRecordReference(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __SetRecordReference(self, value):

        RecordWithAttributeAddresses_SetRecordReference = self.lib.RecordWithAttributeAddresses_SetRecordReference 
        RecordWithAttributeAddresses_SetRecordReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordWithAttributeAddresses_SetRecordReference(self._c_obj, value.c_obj)

    def AddAttributeAddress(self, _attributeAddress):
        """Appends _attributeAddress to attributeAddresses property on RecordWithAttributeAddresses C-object.

           Arguments:
                _attributeAddress - object of type AttributeAddress.
        """

        if not isinstance(_attributeAddress, AttributeAddress):
            raise GRANTA_Exception('RecordWithAttributeAddresses.AddAttributeAddress','_attributeAddress: Invalid argument type _attributeAddress must be of type AttributeAddress')
        RecordWithAttributeAddresses_AddAttributeAddress = self.lib.RecordWithAttributeAddresses_AddAttributeAddress
        RecordWithAttributeAddresses_AddAttributeAddress.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordWithAttributeAddresses_AddAttributeAddress(self._c_obj, _attributeAddress.c_obj)
        return self

    def __ClearAttributeAddresses(self):
        RecordWithAttributeAddresses_ClearAttributeAddresses = self.lib.RecordWithAttributeAddresses_ClearAttributeAddresses
        RecordWithAttributeAddresses_ClearAttributeAddresses.argtypes = [POINTER(c_void_p)]
        RecordWithAttributeAddresses_ClearAttributeAddresses(self._c_obj)
        return self

    def __GetNumberOfAttributeAddresses(self):
        RecordWithAttributeAddresses_GetNumberOfAttributeAddresses = self.lib.RecordWithAttributeAddresses_GetNumberOfAttributeAddresses
        RecordWithAttributeAddresses_GetNumberOfAttributeAddresses.argtypes = [POINTER(c_void_p)]
        RecordWithAttributeAddresses_GetNumberOfAttributeAddresses.restype = c_int
        value = RecordWithAttributeAddresses_GetNumberOfAttributeAddresses(self._c_obj)
        return value
    
    def __GetAttributeAddressElement(self,i):
        value = AttributeAddress()
        RecordWithAttributeAddresses_GetAttributeAddress = self.lib.RecordWithAttributeAddresses_GetAttributeAddress
        RecordWithAttributeAddresses_GetAttributeAddress.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordWithAttributeAddresses_GetAttributeAddress(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributeAddresses(self):
         n = self.__GetNumberOfAttributeAddresses();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeAddressElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.TableDetail import TableDetail
from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse


class GetTablesResponse(object):
    """GetTablesResponse. Output from the GetTables operation.
Includes an array of :py:mod:`TableDetail <GRANTA_MIScriptingToolkit.TableDetail>` objects and a :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>` object.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetTablesResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetTablesResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetTablesResponse_Destroy = self.lib.GetTablesResponse_Destroy
            GetTablesResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetTablesResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def tableDetails(self):
        """Property tableDetails is a list of :py:mod:`TableDetail <GRANTA_MIScriptingToolkit.TableDetail>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._tableDetails = self.__GetTableDetails()
        except:
            pass
        return self._tableDetails

    @tableDetails.setter
    def tableDetails(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('tableDetails','tableDetails: Invalid type tableDetails must be a list of TableDetail')
                
        try:
            self.__updatetableDetails = True
            self.__ClearTableDetails()
            for v in value:
                self.AddTableDetail(v)
        except:
            pass


    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    def __GetNumberOfTableDetails(self):
        GetTablesResponse_GetNumberOfTableDetails = self.lib.GetTablesResponse_GetNumberOfTableDetails
        GetTablesResponse_GetNumberOfTableDetails.argtypes = [POINTER(c_void_p)]
        GetTablesResponse_GetNumberOfTableDetails.restype = c_int
        value = GetTablesResponse_GetNumberOfTableDetails(self._c_obj)
        return value
    
    def __GetTableDetailsElement(self,i):
        value = TableDetail()
        GetTablesResponse_GetTableDetails = self.lib.GetTablesResponse_GetTableDetails
        GetTablesResponse_GetTableDetails.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetTablesResponse_GetTableDetails(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetTableDetails(self):
         n = self.__GetNumberOfTableDetails();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetTableDetailsElement(i))
         return temp
    
    def AddTableDetail(self, _tableDetail):
        """Appends _tableDetail to tableDetails property on GetTablesResponse C-object.

           Arguments:
                _tableDetail - object of type TableDetail.
        """

        if not isinstance(_tableDetail, TableDetail):
            raise GRANTA_Exception('GetTablesResponse.AddTableDetail','_tableDetail: Invalid argument type _tableDetail must be of type TableDetail')
        GetTablesResponse_AddTableDetail = self.lib.GetTablesResponse_AddTableDetail
        GetTablesResponse_AddTableDetail.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetTablesResponse_AddTableDetail(self._c_obj, _tableDetail.c_obj)
        return self

    def __ClearTableDetails(self):
        GetTablesResponse_ClearTableDetails = self.lib.GetTablesResponse_ClearTableDetails
        GetTablesResponse_ClearTableDetails.argtypes = [POINTER(c_void_p)]
        GetTablesResponse_ClearTableDetails(self._c_obj)
        return self

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetTablesResponse_GetServiceLayerResponse = self.lib.GetTablesResponse_GetServiceLayerResponse
        GetTablesResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetTablesResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


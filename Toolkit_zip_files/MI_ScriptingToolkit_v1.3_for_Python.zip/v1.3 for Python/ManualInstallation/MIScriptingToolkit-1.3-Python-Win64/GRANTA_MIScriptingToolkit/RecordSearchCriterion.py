# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference
from GRANTA_MIScriptingToolkit.BetweenSearchValue import BetweenSearchValue
from GRANTA_MIScriptingToolkit.ContainsAllSearchValue import ContainsAllSearchValue
from GRANTA_MIScriptingToolkit.ContainsAnySearchValue import ContainsAnySearchValue
from GRANTA_MIScriptingToolkit.ContainsSearchValue import ContainsSearchValue
from GRANTA_MIScriptingToolkit.DoesNotContainSearchValue import DoesNotContainSearchValue
from GRANTA_MIScriptingToolkit.DoesNotExistSearchValue import DoesNotExistSearchValue
from GRANTA_MIScriptingToolkit.ExistsSearchValue import ExistsSearchValue
from GRANTA_MIScriptingToolkit.ExactlySearchValue import ExactlySearchValue
from GRANTA_MIScriptingToolkit.GreaterThanSearchValue import GreaterThanSearchValue
from GRANTA_MIScriptingToolkit.LessThanSearchValue import LessThanSearchValue
from GRANTA_MIScriptingToolkit.TabularColumnContainsSearchValue import TabularColumnContainsSearchValue
from GRANTA_MIScriptingToolkit.BetweenDateTimesSearchValue import BetweenDateTimesSearchValue


class RecordSearchCriterion(object):
    """RecordSearchCriterion. One criterion that controls results returned from a search. 
A search comprises one or more such criteria.
    
        Arguments:
                * containsAnySearchValue - type :py:mod:`ContainsAnySearchValue <GRANTA_MIScriptingToolkit.ContainsAnySearchValue>`
                * containsAllSearchValue - type :py:mod:`ContainsAllSearchValue <GRANTA_MIScriptingToolkit.ContainsAllSearchValue>`
                * betweenSearchValue - type :py:mod:`BetweenSearchValue <GRANTA_MIScriptingToolkit.BetweenSearchValue>`
                * lessThanSearchValue - type :py:mod:`LessThanSearchValue <GRANTA_MIScriptingToolkit.LessThanSearchValue>`
                * type - type str
                * betweenDateTimesSearchValue - type :py:mod:`BetweenDateTimesSearchValue <GRANTA_MIScriptingToolkit.BetweenDateTimesSearchValue>`
                * searchAttribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * greaterThanSearchValue - type :py:mod:`GreaterThanSearchValue <GRANTA_MIScriptingToolkit.GreaterThanSearchValue>`
                * exactlySearchValue - type :py:mod:`ExactlySearchValue <GRANTA_MIScriptingToolkit.ExactlySearchValue>`
                * doesNotExistSearchValue - type :py:mod:`DoesNotExistSearchValue <GRANTA_MIScriptingToolkit.DoesNotExistSearchValue>`
                * existsSearchValue - type :py:mod:`ExistsSearchValue <GRANTA_MIScriptingToolkit.ExistsSearchValue>`
                * doesNotContainSearchValue - type :py:mod:`DoesNotContainSearchValue <GRANTA_MIScriptingToolkit.DoesNotContainSearchValue>`
                * containsSearchValue - type :py:mod:`ContainsSearchValue <GRANTA_MIScriptingToolkit.ContainsSearchValue>`
                * tabularColumnContainsSearchValue - type :py:mod:`TabularColumnContainsSearchValue <GRANTA_MIScriptingToolkit.TabularColumnContainsSearchValue>`


    """
    
    def __init__(self, containsAnySearchValue=None, containsAllSearchValue=None, betweenSearchValue=None, lessThanSearchValue=None, type=None, betweenDateTimesSearchValue=None, searchAttribute=None, greaterThanSearchValue=None, exactlySearchValue=None, doesNotExistSearchValue=None, existsSearchValue=None, doesNotContainSearchValue=None, containsSearchValue=None, tabularColumnContainsSearchValue=None, isOwner=True):
        """

        Arguments:
                * containsAnySearchValue - type :py:mod:`ContainsAnySearchValue <GRANTA_MIScriptingToolkit.ContainsAnySearchValue>`
                * containsAllSearchValue - type :py:mod:`ContainsAllSearchValue <GRANTA_MIScriptingToolkit.ContainsAllSearchValue>`
                * betweenSearchValue - type :py:mod:`BetweenSearchValue <GRANTA_MIScriptingToolkit.BetweenSearchValue>`
                * lessThanSearchValue - type :py:mod:`LessThanSearchValue <GRANTA_MIScriptingToolkit.LessThanSearchValue>`
                * type - type str
                * betweenDateTimesSearchValue - type :py:mod:`BetweenDateTimesSearchValue <GRANTA_MIScriptingToolkit.BetweenDateTimesSearchValue>`
                * searchAttribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * greaterThanSearchValue - type :py:mod:`GreaterThanSearchValue <GRANTA_MIScriptingToolkit.GreaterThanSearchValue>`
                * exactlySearchValue - type :py:mod:`ExactlySearchValue <GRANTA_MIScriptingToolkit.ExactlySearchValue>`
                * doesNotExistSearchValue - type :py:mod:`DoesNotExistSearchValue <GRANTA_MIScriptingToolkit.DoesNotExistSearchValue>`
                * existsSearchValue - type :py:mod:`ExistsSearchValue <GRANTA_MIScriptingToolkit.ExistsSearchValue>`
                * doesNotContainSearchValue - type :py:mod:`DoesNotContainSearchValue <GRANTA_MIScriptingToolkit.DoesNotContainSearchValue>`
                * containsSearchValue - type :py:mod:`ContainsSearchValue <GRANTA_MIScriptingToolkit.ContainsSearchValue>`
                * tabularColumnContainsSearchValue - type :py:mod:`TabularColumnContainsSearchValue <GRANTA_MIScriptingToolkit.TabularColumnContainsSearchValue>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordSearchCriterion_Create = self.lib.RecordSearchCriterion_Create
            RecordSearchCriterion_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordSearchCriterion_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if containsAnySearchValue is not None:
            self.containsAnySearchValue = containsAnySearchValue
        if containsAllSearchValue is not None:
            self.containsAllSearchValue = containsAllSearchValue
        if betweenSearchValue is not None:
            self.betweenSearchValue = betweenSearchValue
        if lessThanSearchValue is not None:
            self.lessThanSearchValue = lessThanSearchValue
        if type is not None:
            self.type = type
        if betweenDateTimesSearchValue is not None:
            self.betweenDateTimesSearchValue = betweenDateTimesSearchValue
        if searchAttribute is not None:
            self.searchAttribute = searchAttribute
        if greaterThanSearchValue is not None:
            self.greaterThanSearchValue = greaterThanSearchValue
        if exactlySearchValue is not None:
            self.exactlySearchValue = exactlySearchValue
        if doesNotExistSearchValue is not None:
            self.doesNotExistSearchValue = doesNotExistSearchValue
        if existsSearchValue is not None:
            self.existsSearchValue = existsSearchValue
        if doesNotContainSearchValue is not None:
            self.doesNotContainSearchValue = doesNotContainSearchValue
        if containsSearchValue is not None:
            self.containsSearchValue = containsSearchValue
        if tabularColumnContainsSearchValue is not None:
            self.tabularColumnContainsSearchValue = tabularColumnContainsSearchValue


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordSearchCriterion_Destroy = self.lib.RecordSearchCriterion_Destroy
            RecordSearchCriterion_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordSearchCriterion_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def containsAnySearchValue(self):
        """Property containsAnySearchValue is of type :py:mod:`ContainsAnySearchValue <GRANTA_MIScriptingToolkit.ContainsAnySearchValue>`. """ 
        self._containsAnySearchValue = self.__GetContainsAnySearchValue()
        return self._containsAnySearchValue

    @containsAnySearchValue.setter
    def containsAnySearchValue(self, value):
        if not isinstance(value, ContainsAnySearchValue):
            raise GRANTA_Exception('containsAnySearchValue','containsAnySearchValue: Invalid type containsAnySearchValue must be of type ContainsAnySearchValue')
        self.__SetContainsAnySearchValue(value)
        self._containsAnySearchValue = value

    @property
    def containsAllSearchValue(self):
        """Property containsAllSearchValue is of type :py:mod:`ContainsAllSearchValue <GRANTA_MIScriptingToolkit.ContainsAllSearchValue>`. """ 
        self._containsAllSearchValue = self.__GetContainsAllSearchValue()
        return self._containsAllSearchValue

    @containsAllSearchValue.setter
    def containsAllSearchValue(self, value):
        if not isinstance(value, ContainsAllSearchValue):
            raise GRANTA_Exception('containsAllSearchValue','containsAllSearchValue: Invalid type containsAllSearchValue must be of type ContainsAllSearchValue')
        self.__SetContainsAllSearchValue(value)
        self._containsAllSearchValue = value

    @property
    def betweenSearchValue(self):
        """Property betweenSearchValue is of type :py:mod:`BetweenSearchValue <GRANTA_MIScriptingToolkit.BetweenSearchValue>`. """ 
        self._betweenSearchValue = self.__GetBetweenSearchValue()
        return self._betweenSearchValue

    @betweenSearchValue.setter
    def betweenSearchValue(self, value):
        if not isinstance(value, BetweenSearchValue):
            raise GRANTA_Exception('betweenSearchValue','betweenSearchValue: Invalid type betweenSearchValue must be of type BetweenSearchValue')
        self.__SetBetweenSearchValue(value)
        self._betweenSearchValue = value

    @property
    def lessThanSearchValue(self):
        """Property lessThanSearchValue is of type :py:mod:`LessThanSearchValue <GRANTA_MIScriptingToolkit.LessThanSearchValue>`. """ 
        self._lessThanSearchValue = self.__GetLessThanSearchValue()
        return self._lessThanSearchValue

    @lessThanSearchValue.setter
    def lessThanSearchValue(self, value):
        if not isinstance(value, LessThanSearchValue):
            raise GRANTA_Exception('lessThanSearchValue','lessThanSearchValue: Invalid type lessThanSearchValue must be of type LessThanSearchValue')
        self.__SetLessThanSearchValue(value)
        self._lessThanSearchValue = value

    @property
    def type(self):
        """Property type is of type str. """ 
        self._type = self.__GetType()
        return self._type

    @type.setter
    def type(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('type','type: Invalid type type must be of type str')
        
        self._type = value

    @property
    def betweenDateTimesSearchValue(self):
        """Property betweenDateTimesSearchValue is of type :py:mod:`BetweenDateTimesSearchValue <GRANTA_MIScriptingToolkit.BetweenDateTimesSearchValue>`. """ 
        self._betweenDateTimesSearchValue = self.__GetBetweenDateTimesSearchValue()
        return self._betweenDateTimesSearchValue

    @betweenDateTimesSearchValue.setter
    def betweenDateTimesSearchValue(self, value):
        if not isinstance(value, BetweenDateTimesSearchValue):
            raise GRANTA_Exception('betweenDateTimesSearchValue','betweenDateTimesSearchValue: Invalid type betweenDateTimesSearchValue must be of type BetweenDateTimesSearchValue')
        self.__SetBetweenDateTimesSearchValue(value)
        self._betweenDateTimesSearchValue = value

    @property
    def searchAttribute(self):
        """Property searchAttribute is of type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`. """ 
        self._searchAttribute = self.__GetSearchAttribute()
        return self._searchAttribute

    @searchAttribute.setter
    def searchAttribute(self, value):
        if not isinstance(value, AttributeReference):
            raise GRANTA_Exception('searchAttribute','searchAttribute: Invalid type searchAttribute must be of type AttributeReference')
        self.__SetSearchAttribute(value)
        self._searchAttribute = value

    @property
    def greaterThanSearchValue(self):
        """Property greaterThanSearchValue is of type :py:mod:`GreaterThanSearchValue <GRANTA_MIScriptingToolkit.GreaterThanSearchValue>`. """ 
        self._greaterThanSearchValue = self.__GetGreaterThanSearchValue()
        return self._greaterThanSearchValue

    @greaterThanSearchValue.setter
    def greaterThanSearchValue(self, value):
        if not isinstance(value, GreaterThanSearchValue):
            raise GRANTA_Exception('greaterThanSearchValue','greaterThanSearchValue: Invalid type greaterThanSearchValue must be of type GreaterThanSearchValue')
        self.__SetGreaterThanSearchValue(value)
        self._greaterThanSearchValue = value

    @property
    def exactlySearchValue(self):
        """Property exactlySearchValue is of type :py:mod:`ExactlySearchValue <GRANTA_MIScriptingToolkit.ExactlySearchValue>`. """ 
        self._exactlySearchValue = self.__GetExactlySearchValue()
        return self._exactlySearchValue

    @exactlySearchValue.setter
    def exactlySearchValue(self, value):
        if not isinstance(value, ExactlySearchValue):
            raise GRANTA_Exception('exactlySearchValue','exactlySearchValue: Invalid type exactlySearchValue must be of type ExactlySearchValue')
        self.__SetExactlySearchValue(value)
        self._exactlySearchValue = value

    @property
    def doesNotExistSearchValue(self):
        """Property doesNotExistSearchValue is of type :py:mod:`DoesNotExistSearchValue <GRANTA_MIScriptingToolkit.DoesNotExistSearchValue>`. """ 
        self._doesNotExistSearchValue = self.__GetDoesNotExistSearchValue()
        return self._doesNotExistSearchValue

    @doesNotExistSearchValue.setter
    def doesNotExistSearchValue(self, value):
        if not isinstance(value, DoesNotExistSearchValue):
            raise GRANTA_Exception('doesNotExistSearchValue','doesNotExistSearchValue: Invalid type doesNotExistSearchValue must be of type DoesNotExistSearchValue')
        self.__SetDoesNotExistSearchValue(value)
        self._doesNotExistSearchValue = value

    @property
    def existsSearchValue(self):
        """Property existsSearchValue is of type :py:mod:`ExistsSearchValue <GRANTA_MIScriptingToolkit.ExistsSearchValue>`. """ 
        self._existsSearchValue = self.__GetExistsSearchValue()
        return self._existsSearchValue

    @existsSearchValue.setter
    def existsSearchValue(self, value):
        if not isinstance(value, ExistsSearchValue):
            raise GRANTA_Exception('existsSearchValue','existsSearchValue: Invalid type existsSearchValue must be of type ExistsSearchValue')
        self.__SetExistsSearchValue(value)
        self._existsSearchValue = value

    @property
    def doesNotContainSearchValue(self):
        """Property doesNotContainSearchValue is of type :py:mod:`DoesNotContainSearchValue <GRANTA_MIScriptingToolkit.DoesNotContainSearchValue>`. """ 
        self._doesNotContainSearchValue = self.__GetDoesNotContainSearchValue()
        return self._doesNotContainSearchValue

    @doesNotContainSearchValue.setter
    def doesNotContainSearchValue(self, value):
        if not isinstance(value, DoesNotContainSearchValue):
            raise GRANTA_Exception('doesNotContainSearchValue','doesNotContainSearchValue: Invalid type doesNotContainSearchValue must be of type DoesNotContainSearchValue')
        self.__SetDoesNotContainSearchValue(value)
        self._doesNotContainSearchValue = value

    @property
    def containsSearchValue(self):
        """Property containsSearchValue is of type :py:mod:`ContainsSearchValue <GRANTA_MIScriptingToolkit.ContainsSearchValue>`. """ 
        self._containsSearchValue = self.__GetContainsSearchValue()
        return self._containsSearchValue

    @containsSearchValue.setter
    def containsSearchValue(self, value):
        if not isinstance(value, ContainsSearchValue):
            raise GRANTA_Exception('containsSearchValue','containsSearchValue: Invalid type containsSearchValue must be of type ContainsSearchValue')
        self.__SetContainsSearchValue(value)
        self._containsSearchValue = value

    @property
    def tabularColumnContainsSearchValue(self):
        """Property tabularColumnContainsSearchValue is of type :py:mod:`TabularColumnContainsSearchValue <GRANTA_MIScriptingToolkit.TabularColumnContainsSearchValue>`. """ 
        self._tabularColumnContainsSearchValue = self.__GetTabularColumnContainsSearchValue()
        return self._tabularColumnContainsSearchValue

    @tabularColumnContainsSearchValue.setter
    def tabularColumnContainsSearchValue(self, value):
        if not isinstance(value, TabularColumnContainsSearchValue):
            raise GRANTA_Exception('tabularColumnContainsSearchValue','tabularColumnContainsSearchValue: Invalid type tabularColumnContainsSearchValue must be of type TabularColumnContainsSearchValue')
        self.__SetTabularColumnContainsSearchValue(value)
        self._tabularColumnContainsSearchValue = value

    def __GetSearchAttribute(self):
        _attributeReference = AttributeReference()
        RecordSearchCriterion_GetSearchAttribute = self.lib.RecordSearchCriterion_GetSearchAttribute
        RecordSearchCriterion_GetSearchAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetSearchAttribute(self._c_obj, (_attributeReference.c_obj))
        
        return _attributeReference
        
    def __SetSearchAttribute(self, value):

        RecordSearchCriterion_SetSearchAttribute = self.lib.RecordSearchCriterion_SetSearchAttribute 
        RecordSearchCriterion_SetSearchAttribute.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetSearchAttribute(self._c_obj, value.c_obj)

    def __SetBetweenSearchValue(self, value):

        RecordSearchCriterion_SetBetweenSearchValue = self.lib.RecordSearchCriterion_SetBetweenSearchValue 
        RecordSearchCriterion_SetBetweenSearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetBetweenSearchValue(self._c_obj, value.c_obj)

    def __SetContainsAllSearchValue(self, value):

        RecordSearchCriterion_SetContainsAllSearchValue = self.lib.RecordSearchCriterion_SetContainsAllSearchValue 
        RecordSearchCriterion_SetContainsAllSearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetContainsAllSearchValue(self._c_obj, value.c_obj)

    def __SetContainsAnySearchValue(self, value):

        RecordSearchCriterion_SetContainsAnySearchValue = self.lib.RecordSearchCriterion_SetContainsAnySearchValue 
        RecordSearchCriterion_SetContainsAnySearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetContainsAnySearchValue(self._c_obj, value.c_obj)

    def __SetContainsSearchValue(self, value):

        RecordSearchCriterion_SetContainsSearchValue = self.lib.RecordSearchCriterion_SetContainsSearchValue 
        RecordSearchCriterion_SetContainsSearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetContainsSearchValue(self._c_obj, value.c_obj)

    def __SetDoesNotContainSearchValue(self, value):

        RecordSearchCriterion_SetDoesNotContainSearchValue = self.lib.RecordSearchCriterion_SetDoesNotContainSearchValue 
        RecordSearchCriterion_SetDoesNotContainSearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetDoesNotContainSearchValue(self._c_obj, value.c_obj)

    def __SetDoesNotExistSearchValue(self, value):

        RecordSearchCriterion_SetDoesNotExistSearchValue = self.lib.RecordSearchCriterion_SetDoesNotExistSearchValue 
        RecordSearchCriterion_SetDoesNotExistSearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetDoesNotExistSearchValue(self._c_obj, value.c_obj)

    def __SetExistsSearchValue(self, value):

        RecordSearchCriterion_SetExistsSearchValue = self.lib.RecordSearchCriterion_SetExistsSearchValue 
        RecordSearchCriterion_SetExistsSearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetExistsSearchValue(self._c_obj, value.c_obj)

    def __SetExactlySearchValue(self, value):

        RecordSearchCriterion_SetExactlySearchValue = self.lib.RecordSearchCriterion_SetExactlySearchValue 
        RecordSearchCriterion_SetExactlySearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetExactlySearchValue(self._c_obj, value.c_obj)

    def __SetGreaterThanSearchValue(self, value):

        RecordSearchCriterion_SetGreaterThanSearchValue = self.lib.RecordSearchCriterion_SetGreaterThanSearchValue 
        RecordSearchCriterion_SetGreaterThanSearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetGreaterThanSearchValue(self._c_obj, value.c_obj)

    def __SetLessThanSearchValue(self, value):

        RecordSearchCriterion_SetLessThanSearchValue = self.lib.RecordSearchCriterion_SetLessThanSearchValue 
        RecordSearchCriterion_SetLessThanSearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetLessThanSearchValue(self._c_obj, value.c_obj)

    def __GetBetweenSearchValue(self):
        _betweenSearchValue = BetweenSearchValue()
        RecordSearchCriterion_GetBetweenSearchValue = self.lib.RecordSearchCriterion_GetBetweenSearchValue
        RecordSearchCriterion_GetBetweenSearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetBetweenSearchValue(self._c_obj, (_betweenSearchValue.c_obj))
        
        return _betweenSearchValue
        
    def __GetContainsAllSearchValue(self):
        _containsAllSearchValue = ContainsAllSearchValue()
        RecordSearchCriterion_GetContainsAllSearchValue = self.lib.RecordSearchCriterion_GetContainsAllSearchValue
        RecordSearchCriterion_GetContainsAllSearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetContainsAllSearchValue(self._c_obj, (_containsAllSearchValue.c_obj))
        
        return _containsAllSearchValue
        
    def __GetContainsAnySearchValue(self):
        _containsAnySearchValue = ContainsAnySearchValue()
        RecordSearchCriterion_GetContainsAnySearchValue = self.lib.RecordSearchCriterion_GetContainsAnySearchValue
        RecordSearchCriterion_GetContainsAnySearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetContainsAnySearchValue(self._c_obj, (_containsAnySearchValue.c_obj))
        
        return _containsAnySearchValue
        
    def __GetContainsSearchValue(self):
        _containsSearchValue = ContainsSearchValue()
        RecordSearchCriterion_GetContainsSearchValue = self.lib.RecordSearchCriterion_GetContainsSearchValue
        RecordSearchCriterion_GetContainsSearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetContainsSearchValue(self._c_obj, (_containsSearchValue.c_obj))
        
        return _containsSearchValue
        
    def __GetDoesNotContainSearchValue(self):
        _doesNotContainSearchValue = DoesNotContainSearchValue()
        RecordSearchCriterion_GetDoesNotContainSearchValue = self.lib.RecordSearchCriterion_GetDoesNotContainSearchValue
        RecordSearchCriterion_GetDoesNotContainSearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetDoesNotContainSearchValue(self._c_obj, (_doesNotContainSearchValue.c_obj))
        
        return _doesNotContainSearchValue
        
    def __GetDoesNotExistSearchValue(self):
        _doesNotExistSearchValue = DoesNotExistSearchValue()
        RecordSearchCriterion_GetDoesNotExistSearchValue = self.lib.RecordSearchCriterion_GetDoesNotExistSearchValue
        RecordSearchCriterion_GetDoesNotExistSearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetDoesNotExistSearchValue(self._c_obj, (_doesNotExistSearchValue.c_obj))
        
        return _doesNotExistSearchValue
        
    def __GetExistsSearchValue(self):
        _existsSearchValue = ExistsSearchValue()
        RecordSearchCriterion_GetExistsSearchValue = self.lib.RecordSearchCriterion_GetExistsSearchValue
        RecordSearchCriterion_GetExistsSearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetExistsSearchValue(self._c_obj, (_existsSearchValue.c_obj))
        
        return _existsSearchValue
        
    def __GetExactlySearchValue(self):
        _exactlySearchValue = ExactlySearchValue()
        RecordSearchCriterion_GetExactlySearchValue = self.lib.RecordSearchCriterion_GetExactlySearchValue
        RecordSearchCriterion_GetExactlySearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetExactlySearchValue(self._c_obj, (_exactlySearchValue.c_obj))
        
        return _exactlySearchValue
        
    def __GetGreaterThanSearchValue(self):
        _greaterThanSearchValue = GreaterThanSearchValue()
        RecordSearchCriterion_GetGreaterThanSearchValue = self.lib.RecordSearchCriterion_GetGreaterThanSearchValue
        RecordSearchCriterion_GetGreaterThanSearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetGreaterThanSearchValue(self._c_obj, (_greaterThanSearchValue.c_obj))
        
        return _greaterThanSearchValue
        
    def __GetLessThanSearchValue(self):
        _lessThanSearchValue = LessThanSearchValue()
        RecordSearchCriterion_GetLessThanSearchValue = self.lib.RecordSearchCriterion_GetLessThanSearchValue
        RecordSearchCriterion_GetLessThanSearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetLessThanSearchValue(self._c_obj, (_lessThanSearchValue.c_obj))
        
        return _lessThanSearchValue
        
    def __GetType(self):
        RecordSearchCriterion_GetType = self.lib.RecordSearchCriterion_GetType
        RecordSearchCriterion_GetType.argtypes = [POINTER(c_void_p)]
        RecordSearchCriterion_GetType.restype = POINTER(c_void_p)
        value = RecordSearchCriterion_GetType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetTabularColumnContainsSearchValue(self):
        _tabularColumnContainsSearchValue = TabularColumnContainsSearchValue()
        RecordSearchCriterion_GetTabularColumnContainsSearchValue = self.lib.RecordSearchCriterion_GetTabularColumnContainsSearchValue
        RecordSearchCriterion_GetTabularColumnContainsSearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetTabularColumnContainsSearchValue(self._c_obj, (_tabularColumnContainsSearchValue.c_obj))
        
        return _tabularColumnContainsSearchValue
        
    def __SetTabularColumnContainsSearchValue(self, value):

        RecordSearchCriterion_SetTabularColumnContainsSearchValue = self.lib.RecordSearchCriterion_SetTabularColumnContainsSearchValue 
        RecordSearchCriterion_SetTabularColumnContainsSearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetTabularColumnContainsSearchValue(self._c_obj, value.c_obj)

    def __GetBetweenDateTimesSearchValue(self):
        _betweenDateTimesSearchValue = BetweenDateTimesSearchValue()
        RecordSearchCriterion_GetBetweenDateTimesSearchValue = self.lib.RecordSearchCriterion_GetBetweenDateTimesSearchValue
        RecordSearchCriterion_GetBetweenDateTimesSearchValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordSearchCriterion_GetBetweenDateTimesSearchValue(self._c_obj, (_betweenDateTimesSearchValue.c_obj))
        
        return _betweenDateTimesSearchValue
        
    def __SetBetweenDateTimesSearchValue(self, value):

        RecordSearchCriterion_SetBetweenDateTimesSearchValue = self.lib.RecordSearchCriterion_SetBetweenDateTimesSearchValue 
        RecordSearchCriterion_SetBetweenDateTimesSearchValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordSearchCriterion_SetBetweenDateTimesSearchValue(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


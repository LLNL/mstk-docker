# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ImportRecord import ImportRecord


class SetRecordAttributesRequest(object):
    """SetRecordAttributesRequest. The input to a set record attributes operation. Includes an array of records to import.
    
        Arguments:
                * importRecords - type list of :py:mod:`ImportRecord <GRANTA_MIScriptingToolkit.ImportRecord>` objects
                * importErrorMode - type str


    """
    
    def __init__(self, importRecords=None, importErrorMode=None, isOwner=True):
        """

        Arguments:
                * importRecords - type list of :py:mod:`ImportRecord <GRANTA_MIScriptingToolkit.ImportRecord>` objects
                * importErrorMode - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            SetRecordAttributesRequest_Create = self.lib.SetRecordAttributesRequest_Create
            SetRecordAttributesRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = SetRecordAttributesRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if importRecords is not None:
            self.importRecords = importRecords
        if importErrorMode is not None:
            self.importErrorMode = importErrorMode


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            SetRecordAttributesRequest_Destroy = self.lib.SetRecordAttributesRequest_Destroy
            SetRecordAttributesRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            SetRecordAttributesRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def importRecords(self):
        """Property importRecords is of type list of :py:mod:`ImportRecord <GRANTA_MIScriptingToolkit.ImportRecord>`. """ 
        try:
            return self._importRecords
        except:
            return None

    @importRecords.setter
    def importRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('importRecords','importRecords: Invalid type importRecords must be a list of ImportRecord')
                
        try:
            self.__updateimportRecords = True
            self.__ClearImportRecords()
            for v in value:
                self.AddImportRecord(v)
        except:
            pass


    @property
    def importErrorMode(self):
        """Property importErrorMode is of type str. See :py:class:`GRANTA_Constants.ImportErrorMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        try:
            return self._importErrorMode
        except:
            return None

    @importErrorMode.setter
    def importErrorMode(self, value):
        """See :py:class:`GRANTA_Constants.ImportErrorMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('importErrorMode','importErrorMode: Invalid type importErrorMode must be of type str')
        self.__SetImportErrorMode(value)
        self._importErrorMode = value

    def __SetImportErrorMode(self, value):
        """See :py:class:`GRANTA_Constants.ImportErrorMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        SetRecordAttributesRequest_SetImportErrorMode = self.lib.SetRecordAttributesRequest_SetImportErrorMode 
        SetRecordAttributesRequest_SetImportErrorMode.argtypes = [POINTER(c_void_p), c_char_p]
        SetRecordAttributesRequest_SetImportErrorMode(self._c_obj, EnsureEncoded(value))

    def AddImportRecord(self, _importRecord):
        """Appends _importRecord to importRecords property on SetRecordAttributesRequest C-object.

           Arguments:
                _importRecord - object of type ImportRecord.
        """

        if not isinstance(_importRecord, ImportRecord):
            raise GRANTA_Exception('SetRecordAttributesRequest.AddImportRecord','_importRecord: Invalid argument type _importRecord must be of type ImportRecord')
        SetRecordAttributesRequest_AddImportRecord = self.lib.SetRecordAttributesRequest_AddImportRecord
        SetRecordAttributesRequest_AddImportRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        SetRecordAttributesRequest_AddImportRecord(self._c_obj, _importRecord.c_obj)
        return self

    def __ClearImportRecords(self):
        SetRecordAttributesRequest_ClearImportRecords = self.lib.SetRecordAttributesRequest_ClearImportRecords
        SetRecordAttributesRequest_ClearImportRecords.argtypes = [POINTER(c_void_p)]
        SetRecordAttributesRequest_ClearImportRecords(self._c_obj)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


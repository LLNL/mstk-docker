# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.SubsetReference import SubsetReference


class NamedSubset(object):
    """NamedSubset. A :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>` with the subset name.
    
        Arguments:
                * subset - type :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>`
                * name - type str


    """
    
    def __init__(self, subset=None, name=None, isOwner=True):
        """

        Arguments:
                * subset - type :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>`
                * name - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            NamedSubset_Create = self.lib.NamedSubset_Create
            NamedSubset_Create.restype = POINTER(c_void_p)
            self.c_obj = NamedSubset_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if subset is not None:
            self.subset = subset
        if name is not None:
            self.name = name


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            NamedSubset_Destroy = self.lib.NamedSubset_Destroy
            NamedSubset_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            NamedSubset_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def subset(self):
        """Property subset is of type :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>`. """ 
        self._subset = self.__GetSubset()
        return self._subset

    @subset.setter
    def subset(self, value):
        if not isinstance(value, SubsetReference):
            raise GRANTA_Exception('subset','subset: Invalid type subset must be of type SubsetReference')
        self.__SetSubset(value)
        self._subset = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    def __GetName(self):
        NamedSubset_GetName = self.lib.NamedSubset_GetName
        NamedSubset_GetName.argtypes = [POINTER(c_void_p)]
        NamedSubset_GetName.restype = POINTER(c_void_p)
        value = NamedSubset_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        NamedSubset_SetName = self.lib.NamedSubset_SetName 
        NamedSubset_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        NamedSubset_SetName(self._c_obj, EnsureEncoded(value))

    def __GetSubset(self):
        _subsetReference = SubsetReference()
        NamedSubset_GetSubset = self.lib.NamedSubset_GetSubset
        NamedSubset_GetSubset.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        NamedSubset_GetSubset(self._c_obj, (_subsetReference.c_obj))
        
        return _subsetReference
        
    def __SetSubset(self, value):

        NamedSubset_SetSubset = self.lib.NamedSubset_SetSubset 
        NamedSubset_SetSubset.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        NamedSubset_SetSubset(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


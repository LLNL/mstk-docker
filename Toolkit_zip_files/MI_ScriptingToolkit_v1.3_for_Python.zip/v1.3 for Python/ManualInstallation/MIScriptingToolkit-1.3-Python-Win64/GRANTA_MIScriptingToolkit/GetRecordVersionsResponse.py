# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse
from GRANTA_MIScriptingToolkit.RecordVersionState import RecordVersionState


class GetRecordVersionsResponse(object):
    """GetRecordVersionsResponse. Output from the GetRecordVersions operation. Contains a list of version states.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetRecordVersionsResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetRecordVersionsResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetRecordVersionsResponse_Destroy = self.lib.GetRecordVersionsResponse_Destroy
            GetRecordVersionsResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetRecordVersionsResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordStates(self):
        """Property recordStates is a list of :py:mod:`RecordVersionState <GRANTA_MIScriptingToolkit.RecordVersionState>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordStates = self.__GetRecordStateRefs()
        except:
            pass
        return self._recordStates

    @recordStates.setter
    def recordStates(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordStates','recordStates: Invalid type recordStates must be a list of RecordVersionState')
        
        self._recordStates = value

    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetRecordVersionsResponse_GetServiceLayerResponse = self.lib.GetRecordVersionsResponse_GetServiceLayerResponse
        GetRecordVersionsResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetRecordVersionsResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __GetNumberOfRecordStateRefs(self):
        GetRecordVersionsResponse_GetNumberOfRecordStateRefs = self.lib.GetRecordVersionsResponse_GetNumberOfRecordStateRefs
        GetRecordVersionsResponse_GetNumberOfRecordStateRefs.argtypes = [POINTER(c_void_p)]
        GetRecordVersionsResponse_GetNumberOfRecordStateRefs.restype = c_int
        value = GetRecordVersionsResponse_GetNumberOfRecordStateRefs(self._c_obj)
        return value
    
    def __GetRecordStateRefsElement(self,i):
        value = RecordVersionState(isOwner=False)
        GetRecordVersionsResponse_GetRecordStateRefs = self.lib.GetRecordVersionsResponse_GetRecordStateRefs
        GetRecordVersionsResponse_GetRecordStateRefs.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p)), c_int]
        GetRecordVersionsResponse_GetRecordStateRefs(self._c_obj, value.c_obj, i)
        value._parent = self
        return value
    
    def __GetRecordStateRefs(self):
         n = self.__GetNumberOfRecordStateRefs();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordStateRefsElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


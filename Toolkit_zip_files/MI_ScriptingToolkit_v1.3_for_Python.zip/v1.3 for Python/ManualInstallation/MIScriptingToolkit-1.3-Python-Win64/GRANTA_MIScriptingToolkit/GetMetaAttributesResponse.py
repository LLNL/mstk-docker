# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse
from GRANTA_MIScriptingToolkit.AttributeMetaAttributes import AttributeMetaAttributes


class GetMetaAttributesResponse(object):
    """GetMetaAttributesResponse. Output from the GetMetaAttributes operation. Includes an array of :py:mod:`AttributeMetaAttributes <GRANTA_MIScriptingToolkit.AttributeMetaAttributes>` objects and a :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>` object.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetMetaAttributesResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetMetaAttributesResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetMetaAttributesResponse_Destroy = self.lib.GetMetaAttributesResponse_Destroy
            GetMetaAttributesResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetMetaAttributesResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def attributes(self):
        """Property attributes is a list of :py:mod:`AttributeMetaAttributes <GRANTA_MIScriptingToolkit.AttributeMetaAttributes>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributes = self.__GetAttributes()
        except:
            pass
        return self._attributes

    @attributes.setter
    def attributes(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributes','attributes: Invalid type attributes must be a list of AttributeMetaAttributes')
        
        self._attributes = value

    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        self.__SetServiceLayerResponse(value)
        self._serviceLayerResponse = value

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetMetaAttributesResponse_GetServiceLayerResponse = self.lib.GetMetaAttributesResponse_GetServiceLayerResponse
        GetMetaAttributesResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetMetaAttributesResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __SetServiceLayerResponse(self, value):

        GetMetaAttributesResponse_SetServiceLayerResponse = self.lib.GetMetaAttributesResponse_SetServiceLayerResponse 
        GetMetaAttributesResponse_SetServiceLayerResponse.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetMetaAttributesResponse_SetServiceLayerResponse(self._c_obj, value.c_obj)

    def __GetNumberOfAttributes(self):
        GetMetaAttributesResponse_GetNumberOfAttributes = self.lib.GetMetaAttributesResponse_GetNumberOfAttributes
        GetMetaAttributesResponse_GetNumberOfAttributes.argtypes = [POINTER(c_void_p)]
        GetMetaAttributesResponse_GetNumberOfAttributes.restype = c_int
        value = GetMetaAttributesResponse_GetNumberOfAttributes(self._c_obj)
        return value
    
    def __GetAttributeElement(self,i):
        value = AttributeMetaAttributes()
        GetMetaAttributesResponse_GetAttribute = self.lib.GetMetaAttributesResponse_GetAttribute
        GetMetaAttributesResponse_GetAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetMetaAttributesResponse_GetAttribute(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributes(self):
         n = self.__GetNumberOfAttributes();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


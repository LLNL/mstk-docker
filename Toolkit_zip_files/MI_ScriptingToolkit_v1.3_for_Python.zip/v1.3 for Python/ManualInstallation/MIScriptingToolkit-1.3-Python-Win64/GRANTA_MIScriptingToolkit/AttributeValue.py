# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.FloatFunctionalSeriesDataType import FloatFunctionalSeriesDataType
from GRANTA_MIScriptingToolkit.FloatFunctionalGriddedDataType import FloatFunctionalGriddedDataType
from GRANTA_MIScriptingToolkit.RangeDataType import RangeDataType
from GRANTA_MIScriptingToolkit.PointDataType import PointDataType
from GRANTA_MIScriptingToolkit.ShortTextDataType import ShortTextDataType
from GRANTA_MIScriptingToolkit.LongTextDataType import LongTextDataType
from GRANTA_MIScriptingToolkit.DiscreteDataType import DiscreteDataType
from GRANTA_MIScriptingToolkit.IntegerDataType import IntegerDataType
from GRANTA_MIScriptingToolkit.LogicalDataType import LogicalDataType
from GRANTA_MIScriptingToolkit.HyperlinkDataType import HyperlinkDataType
from GRANTA_MIScriptingToolkit.FileDataType import FileDataType
from GRANTA_MIScriptingToolkit.TabularDataType import TabularDataType
from GRANTA_MIScriptingToolkit.DateDataType import DateDataType


class AttributeValue(object):
    """AttributeValue. Type representing the value of a piece of data for a particular attribute. 
Access supported data types, and the attribute identity by Name, ID, or Standard Name.
    
        Arguments:
                * tabularDataType - type :py:mod:`TabularDataType <GRANTA_MIScriptingToolkit.TabularDataType>`
                * discreteDataValue - type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`
                * rangeDataType - type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`
                * hyperlinkDataValue - type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`
                * attributeStandardName - type str
                * dataType - type str
                * shortTextDataType - type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`
                * longTextDataType - type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`
                * attributeName - type str
                * floatFunctionalGriddedDataType - type :py:mod:`FloatFunctionalGriddedDataType <GRANTA_MIScriptingToolkit.FloatFunctionalGriddedDataType>`
                * logicalDataValue - type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`
                * integerDataValue - type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`
                * floatFunctionalSeriesDataType - type :py:mod:`FloatFunctionalSeriesDataType <GRANTA_MIScriptingToolkit.FloatFunctionalSeriesDataType>`
                * attributeID - type int
                * fileDataType - type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`
                * dateDataType - type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`
                * pointDataType - type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`


    """
    
    def __init__(self, tabularDataType=None, discreteDataValue=None, rangeDataType=None, hyperlinkDataValue=None, attributeStandardName=None, dataType=None, shortTextDataType=None, longTextDataType=None, attributeName=None, floatFunctionalGriddedDataType=None, logicalDataValue=None, integerDataValue=None, floatFunctionalSeriesDataType=None, attributeID=None, fileDataType=None, dateDataType=None, pointDataType=None, isOwner=True):
        """

        Arguments:
                * tabularDataType - type :py:mod:`TabularDataType <GRANTA_MIScriptingToolkit.TabularDataType>`
                * discreteDataValue - type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`
                * rangeDataType - type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`
                * hyperlinkDataValue - type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`
                * attributeStandardName - type str
                * dataType - type str
                * shortTextDataType - type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`
                * longTextDataType - type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`
                * attributeName - type str
                * floatFunctionalGriddedDataType - type :py:mod:`FloatFunctionalGriddedDataType <GRANTA_MIScriptingToolkit.FloatFunctionalGriddedDataType>`
                * logicalDataValue - type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`
                * integerDataValue - type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`
                * floatFunctionalSeriesDataType - type :py:mod:`FloatFunctionalSeriesDataType <GRANTA_MIScriptingToolkit.FloatFunctionalSeriesDataType>`
                * attributeID - type int
                * fileDataType - type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`
                * dateDataType - type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`
                * pointDataType - type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            AttributeValue_Create = self.lib.AttributeValue_Create
            AttributeValue_Create.restype = POINTER(c_void_p)
            self.c_obj = AttributeValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if tabularDataType is not None:
            self.tabularDataType = tabularDataType
        if discreteDataValue is not None:
            self.discreteDataValue = discreteDataValue
        if rangeDataType is not None:
            self.rangeDataType = rangeDataType
        if hyperlinkDataValue is not None:
            self.hyperlinkDataValue = hyperlinkDataValue
        if attributeStandardName is not None:
            self.attributeStandardName = attributeStandardName
        if dataType is not None:
            self.dataType = dataType
        if shortTextDataType is not None:
            self.shortTextDataType = shortTextDataType
        if longTextDataType is not None:
            self.longTextDataType = longTextDataType
        if attributeName is not None:
            self.attributeName = attributeName
        if floatFunctionalGriddedDataType is not None:
            self.floatFunctionalGriddedDataType = floatFunctionalGriddedDataType
        if logicalDataValue is not None:
            self.logicalDataValue = logicalDataValue
        if integerDataValue is not None:
            self.integerDataValue = integerDataValue
        if floatFunctionalSeriesDataType is not None:
            self.floatFunctionalSeriesDataType = floatFunctionalSeriesDataType
        if attributeID is not None:
            self.attributeID = attributeID
        if fileDataType is not None:
            self.fileDataType = fileDataType
        if dateDataType is not None:
            self.dateDataType = dateDataType
        if pointDataType is not None:
            self.pointDataType = pointDataType


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            AttributeValue_Destroy = self.lib.AttributeValue_Destroy
            AttributeValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            AttributeValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def tabularDataType(self):
        """Property tabularDataType is of type :py:mod:`TabularDataType <GRANTA_MIScriptingToolkit.TabularDataType>`. """ 
        self._tabularDataType = self.__GetTabularDataTypeRef()
        return self._tabularDataType

    @tabularDataType.setter
    def tabularDataType(self, value):
        if not isinstance(value, TabularDataType):
            raise GRANTA_Exception('tabularDataType','tabularDataType: Invalid type tabularDataType must be of type TabularDataType')
        
        self._tabularDataType = value

    @property
    def discreteDataValue(self):
        """Property discreteDataValue is of type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`. """ 
        self._discreteDataValue = self.__GetDiscreteDataValue()
        return self._discreteDataValue

    @discreteDataValue.setter
    def discreteDataValue(self, value):
        if not isinstance(value, DiscreteDataType):
            raise GRANTA_Exception('discreteDataValue','discreteDataValue: Invalid type discreteDataValue must be of type DiscreteDataType')
        
        self._discreteDataValue = value

    @property
    def rangeDataType(self):
        """Property rangeDataType is of type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`. """ 
        self._rangeDataType = self.__GetRangeDataType()
        return self._rangeDataType

    @rangeDataType.setter
    def rangeDataType(self, value):
        if not isinstance(value, RangeDataType):
            raise GRANTA_Exception('rangeDataType','rangeDataType: Invalid type rangeDataType must be of type RangeDataType')
        
        self._rangeDataType = value

    @property
    def hyperlinkDataValue(self):
        """Property hyperlinkDataValue is of type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`. """ 
        self._hyperlinkDataValue = self.__GetHyperlinkDataValue()
        return self._hyperlinkDataValue

    @hyperlinkDataValue.setter
    def hyperlinkDataValue(self, value):
        if not isinstance(value, HyperlinkDataType):
            raise GRANTA_Exception('hyperlinkDataValue','hyperlinkDataValue: Invalid type hyperlinkDataValue must be of type HyperlinkDataType')
        
        self._hyperlinkDataValue = value

    @property
    def attributeStandardName(self):
        """Property attributeStandardName is of type str. """ 
        self._attributeStandardName = self.__GetAttributeStandardName()
        return self._attributeStandardName

    @attributeStandardName.setter
    def attributeStandardName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('attributeStandardName','attributeStandardName: Invalid type attributeStandardName must be of type str')
        
        self._attributeStandardName = value

    @property
    def dataType(self):
        """Property dataType is of type str. """ 
        self._dataType = self.__GetDataType()
        return self._dataType

    @dataType.setter
    def dataType(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('dataType','dataType: Invalid type dataType must be of type str')
        
        self._dataType = value

    @property
    def shortTextDataType(self):
        """Property shortTextDataType is of type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`. """ 
        self._shortTextDataType = self.__GetShortTextDataType()
        return self._shortTextDataType

    @shortTextDataType.setter
    def shortTextDataType(self, value):
        if not isinstance(value, ShortTextDataType):
            raise GRANTA_Exception('shortTextDataType','shortTextDataType: Invalid type shortTextDataType must be of type ShortTextDataType')
        
        self._shortTextDataType = value

    @property
    def longTextDataType(self):
        """Property longTextDataType is of type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`. """ 
        self._longTextDataType = self.__GetLongTextDataType()
        return self._longTextDataType

    @longTextDataType.setter
    def longTextDataType(self, value):
        if not isinstance(value, LongTextDataType):
            raise GRANTA_Exception('longTextDataType','longTextDataType: Invalid type longTextDataType must be of type LongTextDataType')
        
        self._longTextDataType = value

    @property
    def attributeName(self):
        """Property attributeName is of type str. """ 
        self._attributeName = self.__GetAttributeName()
        return self._attributeName

    @attributeName.setter
    def attributeName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('attributeName','attributeName: Invalid type attributeName must be of type str')
        self.__SetAttributeName(value)
        self._attributeName = value

    @property
    def floatFunctionalGriddedDataType(self):
        """Property floatFunctionalGriddedDataType is of type :py:mod:`FloatFunctionalGriddedDataType <GRANTA_MIScriptingToolkit.FloatFunctionalGriddedDataType>`. """ 
        self._floatFunctionalGriddedDataType = self.__GetFloatFunctionalGriddedDataType()
        return self._floatFunctionalGriddedDataType

    @floatFunctionalGriddedDataType.setter
    def floatFunctionalGriddedDataType(self, value):
        if not isinstance(value, FloatFunctionalGriddedDataType):
            raise GRANTA_Exception('floatFunctionalGriddedDataType','floatFunctionalGriddedDataType: Invalid type floatFunctionalGriddedDataType must be of type FloatFunctionalGriddedDataType')
        
        self._floatFunctionalGriddedDataType = value

    @property
    def logicalDataValue(self):
        """Property logicalDataValue is of type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`. """ 
        self._logicalDataValue = self.__GetLogicalDataValue()
        return self._logicalDataValue

    @logicalDataValue.setter
    def logicalDataValue(self, value):
        if not isinstance(value, LogicalDataType):
            raise GRANTA_Exception('logicalDataValue','logicalDataValue: Invalid type logicalDataValue must be of type LogicalDataType')
        
        self._logicalDataValue = value

    @property
    def integerDataValue(self):
        """Property integerDataValue is of type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`. """ 
        self._integerDataValue = self.__GetIntegerDataValue()
        return self._integerDataValue

    @integerDataValue.setter
    def integerDataValue(self, value):
        if not isinstance(value, IntegerDataType):
            raise GRANTA_Exception('integerDataValue','integerDataValue: Invalid type integerDataValue must be of type IntegerDataType')
        
        self._integerDataValue = value

    @property
    def floatFunctionalSeriesDataType(self):
        """Property floatFunctionalSeriesDataType is of type :py:mod:`FloatFunctionalSeriesDataType <GRANTA_MIScriptingToolkit.FloatFunctionalSeriesDataType>`. """ 
        self._floatFunctionalSeriesDataType = self.__GetFloatFunctionalSeriesDataType()
        return self._floatFunctionalSeriesDataType

    @floatFunctionalSeriesDataType.setter
    def floatFunctionalSeriesDataType(self, value):
        if not isinstance(value, FloatFunctionalSeriesDataType):
            raise GRANTA_Exception('floatFunctionalSeriesDataType','floatFunctionalSeriesDataType: Invalid type floatFunctionalSeriesDataType must be of type FloatFunctionalSeriesDataType')
        
        self._floatFunctionalSeriesDataType = value

    @property
    def attributeID(self):
        """Property attributeID is of type int. """ 
        self._attributeID = self.__GetAttributeID()
        return self._attributeID

    @attributeID.setter
    def attributeID(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('attributeID','attributeID: Invalid type attributeID must be of type int')
        self.__SetAttributeID(value)
        self._attributeID = value

    @property
    def fileDataType(self):
        """Property fileDataType is of type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`. """ 
        self._fileDataType = self.__GetFileDataType()
        return self._fileDataType

    @fileDataType.setter
    def fileDataType(self, value):
        if not isinstance(value, FileDataType):
            raise GRANTA_Exception('fileDataType','fileDataType: Invalid type fileDataType must be of type FileDataType')
        
        self._fileDataType = value

    @property
    def dateDataType(self):
        """Property dateDataType is of type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`. """ 
        self._dateDataType = self.__GetDateDataType()
        return self._dateDataType

    @dateDataType.setter
    def dateDataType(self, value):
        if not isinstance(value, DateDataType):
            raise GRANTA_Exception('dateDataType','dateDataType: Invalid type dateDataType must be of type DateDataType')
        
        self._dateDataType = value

    @property
    def pointDataType(self):
        """Property pointDataType is of type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`. """ 
        self._pointDataType = self.__GetPointDataType()
        return self._pointDataType

    @pointDataType.setter
    def pointDataType(self, value):
        if not isinstance(value, PointDataType):
            raise GRANTA_Exception('pointDataType','pointDataType: Invalid type pointDataType must be of type PointDataType')
        
        self._pointDataType = value

    def __GetDataType(self):
        AttributeValue_GetDataType = self.lib.AttributeValue_GetDataType
        AttributeValue_GetDataType.argtypes = [POINTER(c_void_p)]
        AttributeValue_GetDataType.restype = POINTER(c_void_p)
        value = AttributeValue_GetDataType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetAttributeName(self):
        AttributeValue_GetAttributeName = self.lib.AttributeValue_GetAttributeName
        AttributeValue_GetAttributeName.argtypes = [POINTER(c_void_p)]
        AttributeValue_GetAttributeName.restype = POINTER(c_void_p)
        value = AttributeValue_GetAttributeName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetAttributeStandardName(self):
        AttributeValue_GetAttributeStandardName = self.lib.AttributeValue_GetAttributeStandardName
        AttributeValue_GetAttributeStandardName.argtypes = [POINTER(c_void_p)]
        AttributeValue_GetAttributeStandardName.restype = POINTER(c_void_p)
        value = AttributeValue_GetAttributeStandardName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetAttributeName(self, value):

        AttributeValue_SetAttributeName = self.lib.AttributeValue_SetAttributeName 
        AttributeValue_SetAttributeName.argtypes = [POINTER(c_void_p), c_char_p]
        AttributeValue_SetAttributeName(self._c_obj, EnsureEncoded(value))

    def __GetAttributeID(self):
        AttributeValue_GetAttributeID = self.lib.AttributeValue_GetAttributeID
        AttributeValue_GetAttributeID.argtypes = [POINTER(c_void_p)]
        AttributeValue_GetAttributeID.restype = c_int
        value = AttributeValue_GetAttributeID(self._c_obj)
        return value
    
    def __SetAttributeID(self, value):

        AttributeValue_SetAttributeID = self.lib.AttributeValue_SetAttributeID 
        AttributeValue_SetAttributeID.argtypes = [POINTER(c_void_p), c_int]
        AttributeValue_SetAttributeID(self._c_obj, value)

    def __GetFloatFunctionalSeriesDataType(self):
        _floatFunctionalSeriesDataType = FloatFunctionalSeriesDataType()
        AttributeValue_GetFloatFunctionalSeriesDataType = self.lib.AttributeValue_GetFloatFunctionalSeriesDataType
        AttributeValue_GetFloatFunctionalSeriesDataType.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetFloatFunctionalSeriesDataType(self._c_obj, (_floatFunctionalSeriesDataType.c_obj))
        
        return _floatFunctionalSeriesDataType
        
    def __GetFloatFunctionalGriddedDataType(self):
        _floatFunctionalGriddedDataType = FloatFunctionalGriddedDataType()
        AttributeValue_GetFloatFunctionalGriddedDataType = self.lib.AttributeValue_GetFloatFunctionalGriddedDataType
        AttributeValue_GetFloatFunctionalGriddedDataType.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetFloatFunctionalGriddedDataType(self._c_obj, (_floatFunctionalGriddedDataType.c_obj))
        
        return _floatFunctionalGriddedDataType
        
    def __GetRangeDataType(self):
        _rangeDataType = RangeDataType()
        AttributeValue_GetRangeDataType = self.lib.AttributeValue_GetRangeDataType
        AttributeValue_GetRangeDataType.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetRangeDataType(self._c_obj, (_rangeDataType.c_obj))
        
        return _rangeDataType
        
    def __GetPointDataType(self):
        _pointDataType = PointDataType()
        AttributeValue_GetPointDataType = self.lib.AttributeValue_GetPointDataType
        AttributeValue_GetPointDataType.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetPointDataType(self._c_obj, (_pointDataType.c_obj))
        
        return _pointDataType
        
    def __GetShortTextDataType(self):
        _shortTextDataType = ShortTextDataType()
        AttributeValue_GetShortTextDataType = self.lib.AttributeValue_GetShortTextDataType
        AttributeValue_GetShortTextDataType.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetShortTextDataType(self._c_obj, (_shortTextDataType.c_obj))
        
        return _shortTextDataType
        
    def __GetLongTextDataType(self):
        _longTextDataType = LongTextDataType()
        AttributeValue_GetLongTextDataType = self.lib.AttributeValue_GetLongTextDataType
        AttributeValue_GetLongTextDataType.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetLongTextDataType(self._c_obj, (_longTextDataType.c_obj))
        
        return _longTextDataType
        
    def __GetDiscreteDataValue(self):
        _discreteDataType = DiscreteDataType()
        AttributeValue_GetDiscreteDataValue = self.lib.AttributeValue_GetDiscreteDataValue
        AttributeValue_GetDiscreteDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetDiscreteDataValue(self._c_obj, (_discreteDataType.c_obj))
        
        return _discreteDataType
        
    def __GetIntegerDataValue(self):
        _integerDataType = IntegerDataType()
        AttributeValue_GetIntegerDataValue = self.lib.AttributeValue_GetIntegerDataValue
        AttributeValue_GetIntegerDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetIntegerDataValue(self._c_obj, (_integerDataType.c_obj))
        
        return _integerDataType
        
    def __GetLogicalDataValue(self):
        _logicalDataType = LogicalDataType()
        AttributeValue_GetLogicalDataValue = self.lib.AttributeValue_GetLogicalDataValue
        AttributeValue_GetLogicalDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetLogicalDataValue(self._c_obj, (_logicalDataType.c_obj))
        
        return _logicalDataType
        
    def __GetHyperlinkDataValue(self):
        _hyperlinkDataType = HyperlinkDataType()
        AttributeValue_GetHyperlinkDataValue = self.lib.AttributeValue_GetHyperlinkDataValue
        AttributeValue_GetHyperlinkDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetHyperlinkDataValue(self._c_obj, (_hyperlinkDataType.c_obj))
        
        return _hyperlinkDataType
        
    def __GetFileDataType(self):
        _fileDataType = FileDataType()
        AttributeValue_GetFileDataType = self.lib.AttributeValue_GetFileDataType
        AttributeValue_GetFileDataType.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetFileDataType(self._c_obj, (_fileDataType.c_obj))
        
        return _fileDataType
        
    def __GetTabularDataTypeRef(self):
        _tabularDataType = TabularDataType(isOwner=False)
        AttributeValue_GetTabularDataTypeRef = self.lib.AttributeValue_GetTabularDataTypeRef
        AttributeValue_GetTabularDataTypeRef.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p))]
        AttributeValue_GetTabularDataTypeRef(self._c_obj, byref(_tabularDataType.c_obj))
        _tabularDataType._parent = self
        return _tabularDataType
        
    def __GetDateDataType(self):
        _dateDataType = DateDataType()
        AttributeValue_GetDateDataType = self.lib.AttributeValue_GetDateDataType
        AttributeValue_GetDateDataType.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeValue_GetDateDataType(self._c_obj, (_dateDataType.c_obj))
        
        return _dateDataType
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


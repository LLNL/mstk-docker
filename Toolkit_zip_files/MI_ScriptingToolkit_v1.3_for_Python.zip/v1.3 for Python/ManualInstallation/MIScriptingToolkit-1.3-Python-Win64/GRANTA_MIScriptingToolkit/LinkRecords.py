# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.NotatedTargetedSourceRecord import NotatedTargetedSourceRecord


class LinkRecords(object):
    """LinkRecords. For each given source record, add links to the target records specified for that source record. Silently skip any links that already exist.
    
        Arguments:
                * sourceRecords - type list of :py:mod:`NotatedTargetedSourceRecord <GRANTA_MIScriptingToolkit.NotatedTargetedSourceRecord>` objects
                * nodeName - type str


    """
    
    def __init__(self, sourceRecords=None, nodeName=None, isOwner=True):
        """

        Arguments:
                * sourceRecords - type list of :py:mod:`NotatedTargetedSourceRecord <GRANTA_MIScriptingToolkit.NotatedTargetedSourceRecord>` objects
                * nodeName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            LinkRecords_Create = self.lib.LinkRecords_Create
            LinkRecords_Create.restype = POINTER(c_void_p)
            self.c_obj = LinkRecords_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if sourceRecords is not None:
            self.sourceRecords = sourceRecords
        if nodeName is not None:
            self.nodeName = nodeName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            LinkRecords_Destroy = self.lib.LinkRecords_Destroy
            LinkRecords_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            LinkRecords_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def sourceRecords(self):
        """Property sourceRecords is of type list of :py:mod:`NotatedTargetedSourceRecord <GRANTA_MIScriptingToolkit.NotatedTargetedSourceRecord>`. """ 
        try:
            return self._sourceRecords
        except:
            return None

    @sourceRecords.setter
    def sourceRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('sourceRecords','sourceRecords: Invalid type sourceRecords must be a list of NotatedTargetedSourceRecord')
                
        try:
            self.__updatesourceRecords = True
            self.__ClearSourceRecords()
            for v in value:
                self.AddSourceRecord(v)
        except:
            pass


    @property
    def nodeName(self):
        """Property nodeName is of type str. """ 
        self._nodeName = self.__GetNodeName()
        return self._nodeName

    @nodeName.setter
    def nodeName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('nodeName','nodeName: Invalid type nodeName must be of type str')
        
        self._nodeName = value

    def AddSourceRecord(self, _notatedTargetedSourceRecord):
        """Appends _notatedTargetedSourceRecord to sourceRecords property on LinkRecords C-object.

           Arguments:
                _notatedTargetedSourceRecord - object of type NotatedTargetedSourceRecord.
        """

        if not isinstance(_notatedTargetedSourceRecord, NotatedTargetedSourceRecord):
            raise GRANTA_Exception('LinkRecords.AddSourceRecord','_notatedTargetedSourceRecord: Invalid argument type _notatedTargetedSourceRecord must be of type NotatedTargetedSourceRecord')
        LinkRecords_AddSourceRecord = self.lib.LinkRecords_AddSourceRecord
        LinkRecords_AddSourceRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        LinkRecords_AddSourceRecord(self._c_obj, _notatedTargetedSourceRecord.c_obj)
        return self

    def __ClearSourceRecords(self):
        LinkRecords_ClearSourceRecords = self.lib.LinkRecords_ClearSourceRecords
        LinkRecords_ClearSourceRecords.argtypes = [POINTER(c_void_p)]
        LinkRecords_ClearSourceRecords(self._c_obj)
        return self

    def __GetNodeName(self):
        LinkRecords_GetNodeName = self.lib.LinkRecords_GetNodeName
        LinkRecords_GetNodeName.argtypes = [POINTER(c_void_p)]
        LinkRecords_GetNodeName.restype = POINTER(c_void_p)
        value = LinkRecords_GetNodeName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


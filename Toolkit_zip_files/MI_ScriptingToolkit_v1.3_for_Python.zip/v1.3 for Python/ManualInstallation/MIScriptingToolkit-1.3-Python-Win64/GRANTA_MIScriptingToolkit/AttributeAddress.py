# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class AttributeAddress(object):
    """AttributeAddress. The upload URL of an attribute and an attribute identifier. 
The attribute is identified by the identity, name, and where available, standard name. 
    
        Arguments:
                * URL - type str
                * attributeID - type int
                * attributeName - type str
                * attributeStandardName - type str


    """
    
    def __init__(self, URL=None, attributeID=None, attributeName=None, attributeStandardName=None, isOwner=True):
        """

        Arguments:
                * URL - type str
                * attributeID - type int
                * attributeName - type str
                * attributeStandardName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            AttributeAddress_Create = self.lib.AttributeAddress_Create
            AttributeAddress_Create.restype = POINTER(c_void_p)
            self.c_obj = AttributeAddress_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if URL is not None:
            self.URL = URL
        if attributeID is not None:
            self.attributeID = attributeID
        if attributeName is not None:
            self.attributeName = attributeName
        if attributeStandardName is not None:
            self.attributeStandardName = attributeStandardName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            AttributeAddress_Destroy = self.lib.AttributeAddress_Destroy
            AttributeAddress_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            AttributeAddress_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def URL(self):
        """Property URL is of type str. """ 
        self._URL = self.__GetURL()
        return self._URL

    @URL.setter
    def URL(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('URL','URL: Invalid type URL must be of type str')
        
        self._URL = value

    @property
    def attributeID(self):
        """Property attributeID is of type int. """ 
        self._attributeID = self.__GetAttributeID()
        return self._attributeID

    @attributeID.setter
    def attributeID(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('attributeID','attributeID: Invalid type attributeID must be of type int')
        self.__SetAttributeID(value)
        self._attributeID = value

    @property
    def attributeName(self):
        """Property attributeName is of type str. """ 
        self._attributeName = self.__GetAttributeName()
        return self._attributeName

    @attributeName.setter
    def attributeName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('attributeName','attributeName: Invalid type attributeName must be of type str')
        self.__SetAttributeName(value)
        self._attributeName = value

    @property
    def attributeStandardName(self):
        """Property attributeStandardName is of type str. """ 
        self._attributeStandardName = self.__GetAttributeStandardName()
        return self._attributeStandardName

    @attributeStandardName.setter
    def attributeStandardName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('attributeStandardName','attributeStandardName: Invalid type attributeStandardName must be of type str')
        
        self._attributeStandardName = value

    def __GetURL(self):
        AttributeAddress_GetURL = self.lib.AttributeAddress_GetURL
        AttributeAddress_GetURL.argtypes = [POINTER(c_void_p)]
        AttributeAddress_GetURL.restype = POINTER(c_void_p)
        value = AttributeAddress_GetURL(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetAttributeName(self):
        AttributeAddress_GetAttributeName = self.lib.AttributeAddress_GetAttributeName
        AttributeAddress_GetAttributeName.argtypes = [POINTER(c_void_p)]
        AttributeAddress_GetAttributeName.restype = POINTER(c_void_p)
        value = AttributeAddress_GetAttributeName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetAttributeStandardName(self):
        AttributeAddress_GetAttributeStandardName = self.lib.AttributeAddress_GetAttributeStandardName
        AttributeAddress_GetAttributeStandardName.argtypes = [POINTER(c_void_p)]
        AttributeAddress_GetAttributeStandardName.restype = POINTER(c_void_p)
        value = AttributeAddress_GetAttributeStandardName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetAttributeName(self, value):

        AttributeAddress_SetAttributeName = self.lib.AttributeAddress_SetAttributeName 
        AttributeAddress_SetAttributeName.argtypes = [POINTER(c_void_p), c_char_p]
        AttributeAddress_SetAttributeName(self._c_obj, EnsureEncoded(value))

    def __GetAttributeID(self):
        AttributeAddress_GetAttributeID = self.lib.AttributeAddress_GetAttributeID
        AttributeAddress_GetAttributeID.argtypes = [POINTER(c_void_p)]
        AttributeAddress_GetAttributeID.restype = c_int
        value = AttributeAddress_GetAttributeID(self._c_obj)
        return value
    
    def __SetAttributeID(self, value):

        AttributeAddress_SetAttributeID = self.lib.AttributeAddress_SetAttributeID 
        AttributeAddress_SetAttributeID.argtypes = [POINTER(c_void_p), c_int]
        AttributeAddress_SetAttributeID(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


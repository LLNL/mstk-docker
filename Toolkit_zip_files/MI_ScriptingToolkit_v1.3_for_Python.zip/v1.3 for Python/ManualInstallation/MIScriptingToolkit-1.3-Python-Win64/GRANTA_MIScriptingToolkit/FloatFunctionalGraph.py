# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.Series import Series


class FloatFunctionalGraph(object):
    """FloatFunctionalGraph. A type to contain a collection of series which contain the data functional data.
    
        Arguments:
                * series - type list of :py:mod:`Series <GRANTA_MIScriptingToolkit.Series>` objects
                * hideGraph - type bool
                * logarithmicYAxis - type bool


    """
    
    def __init__(self, series=None, hideGraph=None, logarithmicYAxis=None, isOwner=True):
        """

        Arguments:
                * series - type list of :py:mod:`Series <GRANTA_MIScriptingToolkit.Series>` objects
                * hideGraph - type bool
                * logarithmicYAxis - type bool

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            FloatFunctionalGraph_Create = self.lib.FloatFunctionalGraph_Create
            FloatFunctionalGraph_Create.restype = POINTER(c_void_p)
            self.c_obj = FloatFunctionalGraph_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if series is not None:
            self.series = series
        if hideGraph is not None:
            self.hideGraph = hideGraph
        if logarithmicYAxis is not None:
            self.logarithmicYAxis = logarithmicYAxis


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            FloatFunctionalGraph_Destroy = self.lib.FloatFunctionalGraph_Destroy
            FloatFunctionalGraph_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            FloatFunctionalGraph_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def series(self):
        """Property series is a list of :py:mod:`Series <GRANTA_MIScriptingToolkit.Series>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._series = self.__GetSeries()
        except:
            pass
        return self._series

    @series.setter
    def series(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('series','series: Invalid type series must be a list of Series')
                
        try:
            self.__updateseries = True
            self.__ClearSeries()
            for v in value:
                self.AddSeries(v)
        except:
            pass


    @property
    def hideGraph(self):
        """Property hideGraph is of type bool. """ 
        self._hideGraph = self.__GetHideGraph()
        return self._hideGraph

    @hideGraph.setter
    def hideGraph(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('hideGraph','hideGraph: Invalid type hideGraph must be of type bool')
        self.__SetHideGraph(value)
        self._hideGraph = value

    @property
    def logarithmicYAxis(self):
        """Property logarithmicYAxis is of type bool. """ 
        self._logarithmicYAxis = self.__GetLogarithmicYAxis()
        return self._logarithmicYAxis

    @logarithmicYAxis.setter
    def logarithmicYAxis(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('logarithmicYAxis','logarithmicYAxis: Invalid type logarithmicYAxis must be of type bool')
        self.__SetLogarithmicYAxis(value)
        self._logarithmicYAxis = value

    def __GetNumberOfSeries(self):
        FloatFunctionalGraph_GetNumberOfSeries = self.lib.FloatFunctionalGraph_GetNumberOfSeries
        FloatFunctionalGraph_GetNumberOfSeries.argtypes = [POINTER(c_void_p)]
        FloatFunctionalGraph_GetNumberOfSeries.restype = c_int
        value = FloatFunctionalGraph_GetNumberOfSeries(self._c_obj)
        return value
    
    def __GetSeriesElement(self,i):
        value = Series()
        FloatFunctionalGraph_GetSeries = self.lib.FloatFunctionalGraph_GetSeries
        FloatFunctionalGraph_GetSeries.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        FloatFunctionalGraph_GetSeries(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetSeries(self):
         n = self.__GetNumberOfSeries();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetSeriesElement(i))
         return temp
    
    def AddSeries(self, _series):
        """Appends _series to series property on FloatFunctionalGraph C-object.

           Arguments:
                _series - object of type Series.
        """

        if not isinstance(_series, Series):
            raise GRANTA_Exception('FloatFunctionalGraph.AddSeries','_series: Invalid argument type _series must be of type Series')
        FloatFunctionalGraph_AddSeries = self.lib.FloatFunctionalGraph_AddSeries
        FloatFunctionalGraph_AddSeries.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalGraph_AddSeries(self._c_obj, _series.c_obj)
        return self

    def __ClearSeries(self):
        FloatFunctionalGraph_ClearSeries = self.lib.FloatFunctionalGraph_ClearSeries
        FloatFunctionalGraph_ClearSeries.argtypes = [POINTER(c_void_p)]
        FloatFunctionalGraph_ClearSeries(self._c_obj)
        return self

    def __GetHideGraph(self):
        FloatFunctionalGraph_GetHideGraph = self.lib.FloatFunctionalGraph_GetHideGraph
        FloatFunctionalGraph_GetHideGraph.argtypes = [POINTER(c_void_p)]
        FloatFunctionalGraph_GetHideGraph.restype = c_bool
        value = FloatFunctionalGraph_GetHideGraph(self._c_obj)
        return value
    
    def __SetHideGraph(self, value):

        FloatFunctionalGraph_SetHideGraph = self.lib.FloatFunctionalGraph_SetHideGraph 
        FloatFunctionalGraph_SetHideGraph.argtypes = [POINTER(c_void_p), c_bool]
        FloatFunctionalGraph_SetHideGraph(self._c_obj, value)

    def __GetLogarithmicYAxis(self):
        FloatFunctionalGraph_GetLogarithmicYAxis = self.lib.FloatFunctionalGraph_GetLogarithmicYAxis
        FloatFunctionalGraph_GetLogarithmicYAxis.argtypes = [POINTER(c_void_p)]
        FloatFunctionalGraph_GetLogarithmicYAxis.restype = c_bool
        value = FloatFunctionalGraph_GetLogarithmicYAxis(self._c_obj)
        return value
    
    def __SetLogarithmicYAxis(self, value):

        FloatFunctionalGraph_SetLogarithmicYAxis = self.lib.FloatFunctionalGraph_SetLogarithmicYAxis 
        FloatFunctionalGraph_SetLogarithmicYAxis.argtypes = [POINTER(c_void_p), c_bool]
        FloatFunctionalGraph_SetLogarithmicYAxis(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


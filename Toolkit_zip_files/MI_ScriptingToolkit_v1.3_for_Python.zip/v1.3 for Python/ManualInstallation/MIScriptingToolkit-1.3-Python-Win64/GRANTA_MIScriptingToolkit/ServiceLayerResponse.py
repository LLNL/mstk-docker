# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class ServiceLayerResponse(object):
    """ServiceLayerResponse. The HTTP response information from GRANTA MI:ServiceLayer. Useful for debugging bad requests. 
    
        Arguments:
                * errorMessage - type str
                * requestMessage - type str
                * responseMessage - type str
                * responseCode - type int


    """
    
    def __init__(self, errorMessage=None, requestMessage=None, responseMessage=None, responseCode=None, isOwner=True):
        """

        Arguments:
                * errorMessage - type str
                * requestMessage - type str
                * responseMessage - type str
                * responseCode - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ServiceLayerResponse_Create = self.lib.ServiceLayerResponse_Create
            ServiceLayerResponse_Create.restype = POINTER(c_void_p)
            self.c_obj = ServiceLayerResponse_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if errorMessage is not None:
            self.errorMessage = errorMessage
        if requestMessage is not None:
            self.requestMessage = requestMessage
        if responseMessage is not None:
            self.responseMessage = responseMessage
        if responseCode is not None:
            self.responseCode = responseCode


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ServiceLayerResponse_Destroy = self.lib.ServiceLayerResponse_Destroy
            ServiceLayerResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ServiceLayerResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def errorMessage(self):
        """Property errorMessage is of type str. """ 
        self._errorMessage = self.__GetErrorMessage()
        return self._errorMessage

    @errorMessage.setter
    def errorMessage(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('errorMessage','errorMessage: Invalid type errorMessage must be of type str')
        
        self._errorMessage = value

    @property
    def requestMessage(self):
        """Property requestMessage is of type str. """ 
        self._requestMessage = self.__GetRequestMessage()
        return self._requestMessage

    @requestMessage.setter
    def requestMessage(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('requestMessage','requestMessage: Invalid type requestMessage must be of type str')
        
        self._requestMessage = value

    @property
    def responseMessage(self):
        """Property responseMessage is of type str. """ 
        self._responseMessage = self.__GetResponseMessage()
        return self._responseMessage

    @responseMessage.setter
    def responseMessage(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('responseMessage','responseMessage: Invalid type responseMessage must be of type str')
        
        self._responseMessage = value

    @property
    def responseCode(self):
        """Property responseCode is of type int. This is an HTTP status code.""" 
        self._responseCode = self.__GetResponseCode()
        return self._responseCode

    @responseCode.setter
    def responseCode(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('responseCode','responseCode: Invalid type responseCode must be of type int')
        
        self._responseCode = value

    def __GetResponseCode(self):
        ServiceLayerResponse_GetResponseCode = self.lib.ServiceLayerResponse_GetResponseCode
        ServiceLayerResponse_GetResponseCode.argtypes = [POINTER(c_void_p)]
        ServiceLayerResponse_GetResponseCode.restype = c_int
        value = ServiceLayerResponse_GetResponseCode(self._c_obj)
        return value
    
    def __GetResponseMessage(self):
        ServiceLayerResponse_GetResponseMessage = self.lib.ServiceLayerResponse_GetResponseMessage
        ServiceLayerResponse_GetResponseMessage.argtypes = [POINTER(c_void_p)]
        ServiceLayerResponse_GetResponseMessage.restype = POINTER(c_void_p)
        value = ServiceLayerResponse_GetResponseMessage(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetRequestMessage(self):
        ServiceLayerResponse_GetRequestMessage = self.lib.ServiceLayerResponse_GetRequestMessage
        ServiceLayerResponse_GetRequestMessage.argtypes = [POINTER(c_void_p)]
        ServiceLayerResponse_GetRequestMessage.restype = POINTER(c_void_p)
        value = ServiceLayerResponse_GetRequestMessage(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetErrorMessage(self):
        ServiceLayerResponse_GetErrorMessage = self.lib.ServiceLayerResponse_GetErrorMessage
        ServiceLayerResponse_GetErrorMessage.argtypes = [POINTER(c_void_p)]
        ServiceLayerResponse_GetErrorMessage.restype = POINTER(c_void_p)
        value = ServiceLayerResponse_GetErrorMessage(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


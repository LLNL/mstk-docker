# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs


from .IDataValue import IDataValue


class FileDataType(IDataValue):
    """FileDataType. A type representing a piece of File data in a GRANTA MI database.
The URL can be used to data export a file from a GRANTA MI database. For 
importing a file into a GRANTA MI database a value the 'fileName', file 
'contentType' and file 'data' must be sepcified, where 'fileName' is the name 
you want the file to appear as in GRANTA MI, the 'contentType' data is 
the MIME content type of the binary data, and 'data' is the contents of the file you wish to import to GRANTA MI. 
    
        Arguments:
                * URL - type str
                * contentType - type str
                * data - type str
                * description - type str
                * fileName - type str


    """
    
    def __init__(self, URL=None, contentType=None, data=None, description=None, fileName=None, isOwner=True):
        """

        Arguments:
                * URL - type str
                * contentType - type str
                * data - type str
                * description - type str
                * fileName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            FileDataType_Create = self.lib.FileDataType_Create
            FileDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = FileDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if URL is not None:
            self.URL = URL
        if contentType is not None:
            self.contentType = contentType
        if data is not None:
            self.data = data
        if description is not None:
            self.description = description
        if fileName is not None:
            self.fileName = fileName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            FileDataType_Destroy = self.lib.FileDataType_Destroy
            FileDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            FileDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    def ReadBinaryData(self):
        """Return a byte string representation of this file."""

        func = self.lib.FileDataType_ReadBinaryData
        func.argtypes = [POINTER(c_void_p), POINTER(c_int)]
        func.restype = POINTER(c_void_p)
        datalen = c_int()
        value = func(self._c_obj, byref(datalen))
        ret = string_at(value, datalen)
        StringUtils().delete(value)
        return ret 
    
    @property
    def URL(self):
        """Property URL is of type str. """ 
        self._URL = self.__GetURL()
        return self._URL

    @URL.setter
    def URL(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('URL','URL: Invalid type URL must be of type str')
        self.__SetURL(value)
        self._URL = value

    @property
    def contentType(self):
        """Property contentType is of type str. """ 
        self._contentType = self.__GetContentType()
        return self._contentType

    @contentType.setter
    def contentType(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('contentType','contentType: Invalid type contentType must be of type str')
        self.__SetContentType(value)
        self._contentType = value

    @property
    def data(self):
        """Property data is of type str. """ 
        self._data = self.__GetData()
        return self._data

    @data.setter
    def data(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('data','data: Invalid type data must be of type str')
        self.__SetData(value)
        self._data = value

    @property
    def description(self):
        """Property description is of type str. """ 
        self._description = self.__GetDescription()
        return self._description

    @description.setter
    def description(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('description','description: Invalid type description must be of type str')
        self.__SetDescription(value)
        self._description = value

    @property
    def fileName(self):
        """Property fileName is of type str. """ 
        self._fileName = self.__GetFileName()
        return self._fileName

    @fileName.setter
    def fileName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('fileName','fileName: Invalid type fileName must be of type str')
        self.__SetFileName(value)
        self._fileName = value

    def __GetURL(self):
        FileDataType_GetURL = self.lib.FileDataType_GetURL
        FileDataType_GetURL.argtypes = [POINTER(c_void_p)]
        FileDataType_GetURL.restype = POINTER(c_void_p)
        value = FileDataType_GetURL(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetFileName(self):
        FileDataType_GetFileName = self.lib.FileDataType_GetFileName
        FileDataType_GetFileName.argtypes = [POINTER(c_void_p)]
        FileDataType_GetFileName.restype = POINTER(c_void_p)
        value = FileDataType_GetFileName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetDescription(self):
        FileDataType_GetDescription = self.lib.FileDataType_GetDescription
        FileDataType_GetDescription.argtypes = [POINTER(c_void_p)]
        FileDataType_GetDescription.restype = POINTER(c_void_p)
        value = FileDataType_GetDescription(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetData(self):
        FileDataType_GetData = self.lib.FileDataType_GetData
        FileDataType_GetData.argtypes = [POINTER(c_void_p)]
        FileDataType_GetData.restype = POINTER(c_void_p)
        value = FileDataType_GetData(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetContentType(self):
        FileDataType_GetContentType = self.lib.FileDataType_GetContentType
        FileDataType_GetContentType.argtypes = [POINTER(c_void_p)]
        FileDataType_GetContentType.restype = POINTER(c_void_p)
        value = FileDataType_GetContentType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetURL(self, value):

        FileDataType_SetURL = self.lib.FileDataType_SetURL 
        FileDataType_SetURL.argtypes = [POINTER(c_void_p), c_char_p]
        FileDataType_SetURL(self._c_obj, EnsureEncoded(value))

    def __SetFileName(self, value):

        FileDataType_SetFileName = self.lib.FileDataType_SetFileName 
        FileDataType_SetFileName.argtypes = [POINTER(c_void_p), c_char_p]
        FileDataType_SetFileName(self._c_obj, EnsureEncoded(value))

    def __SetDescription(self, value):

        FileDataType_SetDescription = self.lib.FileDataType_SetDescription 
        FileDataType_SetDescription.argtypes = [POINTER(c_void_p), c_char_p]
        FileDataType_SetDescription(self._c_obj, EnsureEncoded(value))

    def __SetData(self, value):

        FileDataType_SetData = self.lib.FileDataType_SetData 
        FileDataType_SetData.argtypes = [POINTER(c_void_p), c_char_p]
        FileDataType_SetData(self._c_obj, EnsureEncoded(value))

    def __SetContentType(self, value):

        FileDataType_SetContentType = self.lib.FileDataType_SetContentType 
        FileDataType_SetContentType.argtypes = [POINTER(c_void_p), c_char_p]
        FileDataType_SetContentType(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


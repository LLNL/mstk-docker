# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.TabularDataCell import TabularDataCell
from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class TabularDataRow(object):
    """TabularDataRow. A Row within an item of Tabular Data. When importing, this must be created 
by TabularDataType's CreateRow() or CreateUpdateRow() functions. These 
functions return rows with empty cells (the number of which is the number of columns added with AddColumn()) 
    
        Arguments:
                * cells - type list of :py:mod:`TabularDataCell <GRANTA_MIScriptingToolkit.TabularDataCell>` objects
                * Id - type int
                * linkedRecords - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * linkingValue - type str


    """
    
    def __init__(self, cells=None, Id=None, linkedRecords=None, linkingValue=None, isOwner=True):
        """

        Arguments:
                * cells - type list of :py:mod:`TabularDataCell <GRANTA_MIScriptingToolkit.TabularDataCell>` objects
                * Id - type int
                * linkedRecords - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * linkingValue - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            TabularDataRow_Create = self.lib.TabularDataRow_Create
            TabularDataRow_Create.restype = POINTER(c_void_p)
            self.c_obj = TabularDataRow_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if cells is not None:
            self.cells = cells
        if Id is not None:
            self.Id = Id
        if linkedRecords is not None:
            self.linkedRecords = linkedRecords
        if linkingValue is not None:
            self.linkingValue = linkingValue


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            TabularDataRow_Destroy = self.lib.TabularDataRow_Destroy
            TabularDataRow_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            TabularDataRow_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def cells(self):
        """Property cells is a list of :py:mod:`TabularDataCell <GRANTA_MIScriptingToolkit.TabularDataCell>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._cells = self.__GetCellRefs()
        except:
            pass
        return self._cells

    @cells.setter
    def cells(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('cells','cells: Invalid type cells must be a list of TabularDataCell')
        
        self._cells = value

    @property
    def Id(self):
        """Property Id is of type int. """ 
        self._Id = self.__GetId()
        return self._Id

    @Id.setter
    def Id(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('Id','Id: Invalid type Id must be of type int')
        
        self._Id = value

    @property
    def linkedRecords(self):
        """Property linkedRecords is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._linkedRecords = self.__GetLinkedRecords()
        except:
            pass
        return self._linkedRecords

    @linkedRecords.setter
    def linkedRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('linkedRecords','linkedRecords: Invalid type linkedRecords must be a list of RecordReference')
        
        self._linkedRecords = value

    @property
    def linkingValue(self):
        """Property linkingValue is of type str. """ 
        self._linkingValue = self.__GetLinkingValue()
        return self._linkingValue

    @linkingValue.setter
    def linkingValue(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('linkingValue','linkingValue: Invalid type linkingValue must be of type str')
        self.__SetLinkingValue(value)
        self._linkingValue = value

    def __GetNumberOfCellRefs(self):
        TabularDataRow_GetNumberOfCellRefs = self.lib.TabularDataRow_GetNumberOfCellRefs
        TabularDataRow_GetNumberOfCellRefs.argtypes = [POINTER(c_void_p)]
        TabularDataRow_GetNumberOfCellRefs.restype = c_int
        value = TabularDataRow_GetNumberOfCellRefs(self._c_obj)
        return value
    
    def __GetCellRefsElement(self,i):
        value = TabularDataCell(isOwner=False)
        TabularDataRow_GetCellRefs = self.lib.TabularDataRow_GetCellRefs
        TabularDataRow_GetCellRefs.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p)), c_int]
        TabularDataRow_GetCellRefs(self._c_obj, value.c_obj, i)
        value._parent = self
        return value
    
    def __GetCellRefs(self):
         n = self.__GetNumberOfCellRefs();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetCellRefsElement(i))
         return temp
    
    def __GetId(self):
        TabularDataRow_GetId = self.lib.TabularDataRow_GetId
        TabularDataRow_GetId.argtypes = [POINTER(c_void_p)]
        TabularDataRow_GetId.restype = c_int
        value = TabularDataRow_GetId(self._c_obj)
        return value
    
    def __SetLinkingValue(self, value):

        TabularDataRow_SetLinkingValue = self.lib.TabularDataRow_SetLinkingValue 
        TabularDataRow_SetLinkingValue.argtypes = [POINTER(c_void_p), c_char_p]
        TabularDataRow_SetLinkingValue(self._c_obj, EnsureEncoded(value))

    def __GetLinkingValue(self):
        TabularDataRow_GetLinkingValue = self.lib.TabularDataRow_GetLinkingValue
        TabularDataRow_GetLinkingValue.argtypes = [POINTER(c_void_p)]
        TabularDataRow_GetLinkingValue.restype = POINTER(c_void_p)
        value = TabularDataRow_GetLinkingValue(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetNumberOfLinkedRecords(self):
        TabularDataRow_GetNumberOfLinkedRecords = self.lib.TabularDataRow_GetNumberOfLinkedRecords
        TabularDataRow_GetNumberOfLinkedRecords.argtypes = [POINTER(c_void_p)]
        TabularDataRow_GetNumberOfLinkedRecords.restype = c_int
        value = TabularDataRow_GetNumberOfLinkedRecords(self._c_obj)
        return value
    
    def __GetLinkedRecordElement(self,i):
        value = RecordReference()
        TabularDataRow_GetLinkedRecord = self.lib.TabularDataRow_GetLinkedRecord
        TabularDataRow_GetLinkedRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        TabularDataRow_GetLinkedRecord(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetLinkedRecords(self):
         n = self.__GetNumberOfLinkedRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetLinkedRecordElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.ExporterPopulation import ExporterPopulation


class ExportersForRecord(object):
    """ExportersForRecord. A type to contain a record and its associated exporters.
    
        Arguments:
                * record - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * exporters - type list of :py:mod:`ExporterPopulation <GRANTA_MIScriptingToolkit.ExporterPopulation>` objects


    """
    
    def __init__(self, record=None, exporters=None, isOwner=True):
        """

        Arguments:
                * record - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * exporters - type list of :py:mod:`ExporterPopulation <GRANTA_MIScriptingToolkit.ExporterPopulation>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ExportersForRecord_Create = self.lib.ExportersForRecord_Create
            ExportersForRecord_Create.restype = POINTER(c_void_p)
            self.c_obj = ExportersForRecord_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if record is not None:
            self.record = record
        if exporters is not None:
            self.exporters = exporters


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ExportersForRecord_Destroy = self.lib.ExportersForRecord_Destroy
            ExportersForRecord_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ExportersForRecord_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def record(self):
        """Property record is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._record = self.__GetRecord()
        return self._record

    @record.setter
    def record(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('record','record: Invalid type record must be of type RecordReference')
        
        self._record = value

    @property
    def exporters(self):
        """Property exporters is a list of :py:mod:`ExporterPopulation <GRANTA_MIScriptingToolkit.ExporterPopulation>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._exporters = self.__GetExporters()
        except:
            pass
        return self._exporters

    @exporters.setter
    def exporters(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('exporters','exporters: Invalid type exporters must be a list of ExporterPopulation')
        
        self._exporters = value

    def __GetRecord(self):
        _recordReference = RecordReference()
        ExportersForRecord_GetRecord = self.lib.ExportersForRecord_GetRecord
        ExportersForRecord_GetRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ExportersForRecord_GetRecord(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __GetNumberOfExporters(self):
        ExportersForRecord_GetNumberOfExporters = self.lib.ExportersForRecord_GetNumberOfExporters
        ExportersForRecord_GetNumberOfExporters.argtypes = [POINTER(c_void_p)]
        ExportersForRecord_GetNumberOfExporters.restype = c_int
        value = ExportersForRecord_GetNumberOfExporters(self._c_obj)
        return value
    
    def __GetExporterElement(self,i):
        value = ExporterPopulation()
        ExportersForRecord_GetExporter = self.lib.ExportersForRecord_GetExporter
        ExportersForRecord_GetExporter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        ExportersForRecord_GetExporter(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetExporters(self):
         n = self.__GetNumberOfExporters();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetExporterElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


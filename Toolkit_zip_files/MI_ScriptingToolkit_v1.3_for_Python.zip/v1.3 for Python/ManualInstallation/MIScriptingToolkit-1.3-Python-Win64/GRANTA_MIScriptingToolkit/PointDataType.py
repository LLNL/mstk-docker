# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.PointValueWithParameters import PointValueWithParameters
from GRANTA_MIScriptingToolkit.Parameters import Parameters

from .IDataValue import IDataValue


class PointDataType(IDataValue):
    """PointDataType. A type to contain an array of float data types.
    
        Arguments:
                * unitSymbol - type str
                * points - type list of :py:mod:`PointValueWithParameters <GRANTA_MIScriptingToolkit.PointValueWithParameters>` objects
                * parameters - type :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>`


    """
    
    def __init__(self, unitSymbol=None, points=None, parameters=None, isOwner=True):
        """

        Arguments:
                * unitSymbol - type str
                * points - type list of :py:mod:`PointValueWithParameters <GRANTA_MIScriptingToolkit.PointValueWithParameters>` objects
                * parameters - type :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            PointDataType_Create = self.lib.PointDataType_Create
            PointDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = PointDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if unitSymbol is not None:
            self.unitSymbol = unitSymbol
        if points is not None:
            self.points = points
        if parameters is not None:
            self.parameters = parameters


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            PointDataType_Destroy = self.lib.PointDataType_Destroy
            PointDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            PointDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def unitSymbol(self):
        """Property unitSymbol is of type str. """ 
        self._unitSymbol = self.__GetUnitSymbol()
        return self._unitSymbol

    @unitSymbol.setter
    def unitSymbol(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('unitSymbol','unitSymbol: Invalid type unitSymbol must be of type str')
        self.__SetUnitSymbol(value)
        self._unitSymbol = value

    @property
    def points(self):
        """Property points is a list of :py:mod:`PointValueWithParameters <GRANTA_MIScriptingToolkit.PointValueWithParameters>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._points = self.__GetPoints()
        except:
            pass
        return self._points

    @points.setter
    def points(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('points','points: Invalid type points must be a list of PointValueWithParameters')
                
        try:
            self.__updatepoints = True
            self.__ClearPoints()
            for v in value:
                self.AddPoint(v)
        except:
            pass


    @property
    def parameters(self):
        """Property parameters is of type :py:mod:`Parameters <GRANTA_MIScriptingToolkit.Parameters>`. """ 
        self._parameters = self.__GetParameters()
        return self._parameters

    @parameters.setter
    def parameters(self, value):
        if not isinstance(value, Parameters):
            raise GRANTA_Exception('parameters','parameters: Invalid type parameters must be of type Parameters')
        self.__SetParameters(value)
        self._parameters = value

    def AddPoint(self, _pointValueWithParameters):
        """Appends _pointValueWithParameters to points property on PointDataType C-object.

           Arguments:
                _pointValueWithParameters - object of type PointValueWithParameters.
        """

        if not isinstance(_pointValueWithParameters, PointValueWithParameters):
            raise GRANTA_Exception('PointDataType.AddPoint','_pointValueWithParameters: Invalid argument type _pointValueWithParameters must be of type PointValueWithParameters')
        PointDataType_AddPoint = self.lib.PointDataType_AddPoint
        PointDataType_AddPoint.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        PointDataType_AddPoint(self._c_obj, _pointValueWithParameters.c_obj)
        return self

    def __ClearPoints(self):
        PointDataType_ClearPoints = self.lib.PointDataType_ClearPoints
        PointDataType_ClearPoints.argtypes = [POINTER(c_void_p)]
        PointDataType_ClearPoints(self._c_obj)
        return self

    def __GetNumberOfPoints(self):
        PointDataType_GetNumberOfPoints = self.lib.PointDataType_GetNumberOfPoints
        PointDataType_GetNumberOfPoints.argtypes = [POINTER(c_void_p)]
        PointDataType_GetNumberOfPoints.restype = c_int
        value = PointDataType_GetNumberOfPoints(self._c_obj)
        return value
    
    def __GetPointsElement(self,i):
        value = PointValueWithParameters()
        PointDataType_GetPoints = self.lib.PointDataType_GetPoints
        PointDataType_GetPoints.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        PointDataType_GetPoints(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetPoints(self):
         n = self.__GetNumberOfPoints();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetPointsElement(i))
         return temp
    
    def __GetParameters(self):
        _parameters = Parameters()
        PointDataType_GetParameters = self.lib.PointDataType_GetParameters
        PointDataType_GetParameters.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        PointDataType_GetParameters(self._c_obj, (_parameters.c_obj))
        
        return _parameters
        
    def __SetParameters(self, value):

        PointDataType_SetParameters = self.lib.PointDataType_SetParameters 
        PointDataType_SetParameters.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        PointDataType_SetParameters(self._c_obj, value.c_obj)

    def __GetUnitSymbol(self):
        PointDataType_GetUnitSymbol = self.lib.PointDataType_GetUnitSymbol
        PointDataType_GetUnitSymbol.argtypes = [POINTER(c_void_p)]
        PointDataType_GetUnitSymbol.restype = POINTER(c_void_p)
        value = PointDataType_GetUnitSymbol(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetUnitSymbol(self, value):

        PointDataType_SetUnitSymbol = self.lib.PointDataType_SetUnitSymbol 
        PointDataType_SetUnitSymbol.argtypes = [POINTER(c_void_p), c_char_p]
        PointDataType_SetUnitSymbol(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class GetRecordAttributesRequest(object):
    """GetRecordAttributesRequest. Input for the GetRecordAttribute operation. 
    
        Arguments:
                * includeMeta - type bool
                * recordReferences - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * includeEmpty - type bool
                * includeParamDetails - type bool


    """
    
    def __init__(self, includeMeta=None, recordReferences=None, includeEmpty=None, includeParamDetails=None, isOwner=True):
        """

        Arguments:
                * includeMeta - type bool
                * recordReferences - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * includeEmpty - type bool
                * includeParamDetails - type bool

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetRecordAttributesRequest_Create = self.lib.GetRecordAttributesRequest_Create
            GetRecordAttributesRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetRecordAttributesRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if includeMeta is not None:
            self.includeMeta = includeMeta
        if recordReferences is not None:
            self.recordReferences = recordReferences
        if includeEmpty is not None:
            self.includeEmpty = includeEmpty
        if includeParamDetails is not None:
            self.includeParamDetails = includeParamDetails


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetRecordAttributesRequest_Destroy = self.lib.GetRecordAttributesRequest_Destroy
            GetRecordAttributesRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetRecordAttributesRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def includeMeta(self):
        """Property includeMeta is of type bool. """ 
        try:
            return self._includeMeta
        except:
            return None

    @includeMeta.setter
    def includeMeta(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('includeMeta','includeMeta: Invalid type includeMeta must be of type bool')
        self.__SetIncludeMeta(value)
        self._includeMeta = value

    @property
    def recordReferences(self):
        """Property recordReferences is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordReferences = self.__GetRecordReferences()
        except:
            pass
        return self._recordReferences

    @recordReferences.setter
    def recordReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordReferences','recordReferences: Invalid type recordReferences must be a list of RecordReference')
                
        try:
            self.__updaterecordReferences = True
            self.__ClearRecordReferences()
            for v in value:
                self.AddRecordReference(v)
        except:
            pass


    @property
    def includeEmpty(self):
        """Property includeEmpty is of type bool. """ 
        try:
            return self._includeEmpty
        except:
            return None

    @includeEmpty.setter
    def includeEmpty(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('includeEmpty','includeEmpty: Invalid type includeEmpty must be of type bool')
        self.__SetIncludeEmpty(value)
        self._includeEmpty = value

    @property
    def includeParamDetails(self):
        """Property includeParamDetails is of type bool. """ 
        try:
            return self._includeParamDetails
        except:
            return None

    @includeParamDetails.setter
    def includeParamDetails(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('includeParamDetails','includeParamDetails: Invalid type includeParamDetails must be of type bool')
        self.__SetIncludeParamDetails(value)
        self._includeParamDetails = value

    def __GetNumberOfRecordReferences(self):
        GetRecordAttributesRequest_GetNumberOfRecordReferences = self.lib.GetRecordAttributesRequest_GetNumberOfRecordReferences
        GetRecordAttributesRequest_GetNumberOfRecordReferences.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesRequest_GetNumberOfRecordReferences.restype = c_int
        value = GetRecordAttributesRequest_GetNumberOfRecordReferences(self._c_obj)
        return value
    
    def __GetRecordReferenceElement(self,i):
        value = RecordReference()
        GetRecordAttributesRequest_GetRecordReference = self.lib.GetRecordAttributesRequest_GetRecordReference
        GetRecordAttributesRequest_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetRecordAttributesRequest_GetRecordReference(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordReferences(self):
         n = self.__GetNumberOfRecordReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordReferenceElement(i))
         return temp
    
    def __ClearRecordReferences(self):
        GetRecordAttributesRequest_ClearRecordReferences = self.lib.GetRecordAttributesRequest_ClearRecordReferences
        GetRecordAttributesRequest_ClearRecordReferences.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesRequest_ClearRecordReferences(self._c_obj)
        return self

    def AddRecordReference(self, _recordReference):
        """Appends _recordReference to recordReferences property on GetRecordAttributesRequest C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('GetRecordAttributesRequest.AddRecordReference','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        GetRecordAttributesRequest_AddRecordReference = self.lib.GetRecordAttributesRequest_AddRecordReference
        GetRecordAttributesRequest_AddRecordReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRecordAttributesRequest_AddRecordReference(self._c_obj, _recordReference.c_obj)
        return self

    def __SetIncludeMeta(self, value):

        GetRecordAttributesRequest_SetIncludeMeta = self.lib.GetRecordAttributesRequest_SetIncludeMeta 
        GetRecordAttributesRequest_SetIncludeMeta.argtypes = [POINTER(c_void_p), c_bool]
        GetRecordAttributesRequest_SetIncludeMeta(self._c_obj, value)

    def __SetIncludeEmpty(self, value):

        GetRecordAttributesRequest_SetIncludeEmpty = self.lib.GetRecordAttributesRequest_SetIncludeEmpty 
        GetRecordAttributesRequest_SetIncludeEmpty.argtypes = [POINTER(c_void_p), c_bool]
        GetRecordAttributesRequest_SetIncludeEmpty(self._c_obj, value)

    def __SetIncludeParamDetails(self, value):

        GetRecordAttributesRequest_SetIncludeParamDetails = self.lib.GetRecordAttributesRequest_SetIncludeParamDetails 
        GetRecordAttributesRequest_SetIncludeParamDetails.argtypes = [POINTER(c_void_p), c_bool]
        GetRecordAttributesRequest_SetIncludeParamDetails(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


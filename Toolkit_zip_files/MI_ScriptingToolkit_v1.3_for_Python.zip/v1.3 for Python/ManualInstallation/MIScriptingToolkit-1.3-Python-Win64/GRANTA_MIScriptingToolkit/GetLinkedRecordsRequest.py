# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordLinkGroupReference import RecordLinkGroupReference
from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.RecordFilter import RecordFilter


class GetLinkedRecordsRequest(object):
    """GetLinkedRecordsRequest. Input for the GetLinkedRecords operation. 
    
        Arguments:
                * recordReferences - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * recordLinkGroups - type list of :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>` objects
                * populateGUIDs - type bool
                * recordFilter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`


    """
    
    def __init__(self, recordReferences=None, recordLinkGroups=None, populateGUIDs=None, recordFilter=None, isOwner=True):
        """

        Arguments:
                * recordReferences - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * recordLinkGroups - type list of :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>` objects
                * populateGUIDs - type bool
                * recordFilter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetLinkedRecordsRequest_Create = self.lib.GetLinkedRecordsRequest_Create
            GetLinkedRecordsRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetLinkedRecordsRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordReferences is not None:
            self.recordReferences = recordReferences
        if recordLinkGroups is not None:
            self.recordLinkGroups = recordLinkGroups
        if populateGUIDs is not None:
            self.populateGUIDs = populateGUIDs
        if recordFilter is not None:
            self.recordFilter = recordFilter


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetLinkedRecordsRequest_Destroy = self.lib.GetLinkedRecordsRequest_Destroy
            GetLinkedRecordsRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetLinkedRecordsRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordReferences(self):
        """Property recordReferences is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordReferences = self.__GetRecordReferences()
        except:
            pass
        return self._recordReferences

    @recordReferences.setter
    def recordReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordReferences','recordReferences: Invalid type recordReferences must be a list of RecordReference')
                
        try:
            self.__updaterecordReferences = True
            self.__ClearRecordReferences()
            for v in value:
                self.AddRecordReference(v)
        except:
            pass


    @property
    def recordLinkGroups(self):
        """Property recordLinkGroups is a list of :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordLinkGroups = self.__GetRecordLinkGroups()
        except:
            pass
        return self._recordLinkGroups

    @recordLinkGroups.setter
    def recordLinkGroups(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordLinkGroups','recordLinkGroups: Invalid type recordLinkGroups must be a list of RecordLinkGroupReference')
                
        try:
            self.__updaterecordLinkGroups = True
            self.__ClearRecordLinkGroups()
            for v in value:
                self.AddRecordLinkGroup(v)
        except:
            pass


    @property
    def populateGUIDs(self):
        """Property populateGUIDs is of type bool. """ 
        self._populateGUIDs = self.__GetPopulateGUIDs()
        return self._populateGUIDs

    @populateGUIDs.setter
    def populateGUIDs(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('populateGUIDs','populateGUIDs: Invalid type populateGUIDs must be of type bool')
        self.__SetPopulateGUIDs(value)
        self._populateGUIDs = value

    @property
    def recordFilter(self):
        """Property recordFilter is of type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`. """ 
        self._recordFilter = self.__GetRecordFilter()
        return self._recordFilter

    @recordFilter.setter
    def recordFilter(self, value):
        if not isinstance(value, RecordFilter):
            raise GRANTA_Exception('recordFilter','recordFilter: Invalid type recordFilter must be of type RecordFilter')
        self.__SetRecordFilter(value)
        self._recordFilter = value

    def __GetNumberOfRecordLinkGroups(self):
        GetLinkedRecordsRequest_GetNumberOfRecordLinkGroups = self.lib.GetLinkedRecordsRequest_GetNumberOfRecordLinkGroups
        GetLinkedRecordsRequest_GetNumberOfRecordLinkGroups.argtypes = [POINTER(c_void_p)]
        GetLinkedRecordsRequest_GetNumberOfRecordLinkGroups.restype = c_int
        value = GetLinkedRecordsRequest_GetNumberOfRecordLinkGroups(self._c_obj)
        return value
    
    def __GetRecordLinkGroupElement(self,i):
        value = RecordLinkGroupReference()
        GetLinkedRecordsRequest_GetRecordLinkGroup = self.lib.GetLinkedRecordsRequest_GetRecordLinkGroup
        GetLinkedRecordsRequest_GetRecordLinkGroup.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetLinkedRecordsRequest_GetRecordLinkGroup(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordLinkGroups(self):
         n = self.__GetNumberOfRecordLinkGroups();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordLinkGroupElement(i))
         return temp
    
    def __ClearRecordLinkGroups(self):
        GetLinkedRecordsRequest_ClearRecordLinkGroups = self.lib.GetLinkedRecordsRequest_ClearRecordLinkGroups
        GetLinkedRecordsRequest_ClearRecordLinkGroups.argtypes = [POINTER(c_void_p)]
        GetLinkedRecordsRequest_ClearRecordLinkGroups(self._c_obj)
        return self

    def AddRecordLinkGroup(self, _recordLinkGroupReference):
        """Appends _recordLinkGroupReference to recordLinkGroups property on GetLinkedRecordsRequest C-object.

           Arguments:
                _recordLinkGroupReference - object of type RecordLinkGroupReference.
        """

        if not isinstance(_recordLinkGroupReference, RecordLinkGroupReference):
            raise GRANTA_Exception('GetLinkedRecordsRequest.AddRecordLinkGroup','_recordLinkGroupReference: Invalid argument type _recordLinkGroupReference must be of type RecordLinkGroupReference')
        GetLinkedRecordsRequest_AddRecordLinkGroup = self.lib.GetLinkedRecordsRequest_AddRecordLinkGroup
        GetLinkedRecordsRequest_AddRecordLinkGroup.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetLinkedRecordsRequest_AddRecordLinkGroup(self._c_obj, _recordLinkGroupReference.c_obj)
        return self

    def __GetNumberOfRecordReferences(self):
        GetLinkedRecordsRequest_GetNumberOfRecordReferences = self.lib.GetLinkedRecordsRequest_GetNumberOfRecordReferences
        GetLinkedRecordsRequest_GetNumberOfRecordReferences.argtypes = [POINTER(c_void_p)]
        GetLinkedRecordsRequest_GetNumberOfRecordReferences.restype = c_int
        value = GetLinkedRecordsRequest_GetNumberOfRecordReferences(self._c_obj)
        return value
    
    def __GetRecordReferenceElement(self,i):
        value = RecordReference()
        GetLinkedRecordsRequest_GetRecordReference = self.lib.GetLinkedRecordsRequest_GetRecordReference
        GetLinkedRecordsRequest_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetLinkedRecordsRequest_GetRecordReference(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordReferences(self):
         n = self.__GetNumberOfRecordReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordReferenceElement(i))
         return temp
    
    def __ClearRecordReferences(self):
        GetLinkedRecordsRequest_ClearRecordReferences = self.lib.GetLinkedRecordsRequest_ClearRecordReferences
        GetLinkedRecordsRequest_ClearRecordReferences.argtypes = [POINTER(c_void_p)]
        GetLinkedRecordsRequest_ClearRecordReferences(self._c_obj)
        return self

    def AddRecordReference(self, _recordReference):
        """Appends _recordReference to recordReferences property on GetLinkedRecordsRequest C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('GetLinkedRecordsRequest.AddRecordReference','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        GetLinkedRecordsRequest_AddRecordReference = self.lib.GetLinkedRecordsRequest_AddRecordReference
        GetLinkedRecordsRequest_AddRecordReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetLinkedRecordsRequest_AddRecordReference(self._c_obj, _recordReference.c_obj)
        return self

    def __GetPopulateGUIDs(self):
        GetLinkedRecordsRequest_GetPopulateGUIDs = self.lib.GetLinkedRecordsRequest_GetPopulateGUIDs
        GetLinkedRecordsRequest_GetPopulateGUIDs.argtypes = [POINTER(c_void_p)]
        GetLinkedRecordsRequest_GetPopulateGUIDs.restype = c_bool
        value = GetLinkedRecordsRequest_GetPopulateGUIDs(self._c_obj)
        return value
    
    def __SetPopulateGUIDs(self, value):

        GetLinkedRecordsRequest_SetPopulateGUIDs = self.lib.GetLinkedRecordsRequest_SetPopulateGUIDs 
        GetLinkedRecordsRequest_SetPopulateGUIDs.argtypes = [POINTER(c_void_p), c_bool]
        GetLinkedRecordsRequest_SetPopulateGUIDs(self._c_obj, value)

    def __GetRecordFilter(self):
        _recordFilter = RecordFilter()
        GetLinkedRecordsRequest_GetRecordFilter = self.lib.GetLinkedRecordsRequest_GetRecordFilter
        GetLinkedRecordsRequest_GetRecordFilter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetLinkedRecordsRequest_GetRecordFilter(self._c_obj, (_recordFilter.c_obj))
        
        return _recordFilter
        
    def __SetRecordFilter(self, value):

        GetLinkedRecordsRequest_SetRecordFilter = self.lib.GetLinkedRecordsRequest_SetRecordFilter 
        GetLinkedRecordsRequest_SetRecordFilter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetLinkedRecordsRequest_SetRecordFilter(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference


class NamedAttribute(object):
    """NamedAttribute. Name information about an Attribute in a GRANTA MI database.
    
        Arguments:
                * attribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * about - type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`
                * name - type str
                * isMeta - type bool


    """
    
    def __init__(self, attribute=None, about=None, name=None, isMeta=None, isOwner=True):
        """

        Arguments:
                * attribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * about - type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`
                * name - type str
                * isMeta - type bool

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            NamedAttribute_Create = self.lib.NamedAttribute_Create
            NamedAttribute_Create.restype = POINTER(c_void_p)
            self.c_obj = NamedAttribute_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if attribute is not None:
            self.attribute = attribute
        if about is not None:
            self.about = about
        if name is not None:
            self.name = name
        if isMeta is not None:
            self.isMeta = isMeta


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            NamedAttribute_Destroy = self.lib.NamedAttribute_Destroy
            NamedAttribute_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            NamedAttribute_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def attribute(self):
        """Property attribute is of type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`. """ 
        self._attribute = self.__GetAttribute()
        return self._attribute

    @attribute.setter
    def attribute(self, value):
        if not isinstance(value, AttributeReference):
            raise GRANTA_Exception('attribute','attribute: Invalid type attribute must be of type AttributeReference')
        self.__SetAttribute(value)
        self._attribute = value

    @property
    def about(self):
        """Property about is of type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`. Only populated if 'isMeta' is True.""" 
        self._about = self.__GetAbout()
        return self._about

    @about.setter
    def about(self, value):
        if not isinstance(value, NamedAttribute):
            raise GRANTA_Exception('about','about: Invalid type about must be of type NamedAttribute')
        
        self._about = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    @property
    def isMeta(self):
        """Property isMeta is of type bool. If this is True, the 'about' property may have additional information about the related parent attribute.""" 
        self._isMeta = self.__GetIsMeta()
        return self._isMeta

    @isMeta.setter
    def isMeta(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('isMeta','isMeta: Invalid type isMeta must be of type bool')
        
        self._isMeta = value

    def __GetAttribute(self):
        _attributeReference = AttributeReference()
        NamedAttribute_GetAttribute = self.lib.NamedAttribute_GetAttribute
        NamedAttribute_GetAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        NamedAttribute_GetAttribute(self._c_obj, (_attributeReference.c_obj))
        
        return _attributeReference
        
    def __SetAttribute(self, value):

        NamedAttribute_SetAttribute = self.lib.NamedAttribute_SetAttribute 
        NamedAttribute_SetAttribute.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        NamedAttribute_SetAttribute(self._c_obj, value.c_obj)

    def __GetName(self):
        NamedAttribute_GetName = self.lib.NamedAttribute_GetName
        NamedAttribute_GetName.argtypes = [POINTER(c_void_p)]
        NamedAttribute_GetName.restype = POINTER(c_void_p)
        value = NamedAttribute_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        NamedAttribute_SetName = self.lib.NamedAttribute_SetName 
        NamedAttribute_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        NamedAttribute_SetName(self._c_obj, EnsureEncoded(value))

    def __GetIsMeta(self):
        NamedAttribute_GetIsMeta = self.lib.NamedAttribute_GetIsMeta
        NamedAttribute_GetIsMeta.argtypes = [POINTER(c_void_p)]
        NamedAttribute_GetIsMeta.restype = c_bool
        value = NamedAttribute_GetIsMeta(self._c_obj)
        return value
    
    def __GetAbout(self):
        _namedAttribute = NamedAttribute()
        NamedAttribute_GetAbout = self.lib.NamedAttribute_GetAbout
        NamedAttribute_GetAbout.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        NamedAttribute_GetAbout(self._c_obj, (_namedAttribute.c_obj))
        
        return _namedAttribute
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


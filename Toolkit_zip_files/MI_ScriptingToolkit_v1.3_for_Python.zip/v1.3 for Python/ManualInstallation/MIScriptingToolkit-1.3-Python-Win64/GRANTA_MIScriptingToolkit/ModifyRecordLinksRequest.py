# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordLinkGroupReference import RecordLinkGroupReference
from GRANTA_MIScriptingToolkit.RecordLinkModifications import RecordLinkModifications


class ModifyRecordLinksRequest(object):
    """ModifyRecordLinksRequest. Input to the ModifyRecordLinks operation.
Requires a :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>` to the record link group you wish to 
modify and a :py:mod:`RecordLinkModifications <GRANTA_MIScriptingToolkit.RecordLinkModifications>` object, which contains the 
modifications you wish to make to the record link group. The 'importErrorMode' 
property defines how to handle errors which occur during linking and can take 
the following values: 'FaultAndRollbackOnAnyError',  which stops the linking 
request when an error occurs and attempts to roll back to the state 
before the request was issued; or  'LogAndContinueWherePossible', which will 
log non-fatal errors and attempt to continue with the linking request. The 
'recordLinkCheckMode' property defines how to check the status of existing 
links and takes the following values: 'CheckOnlyForwardLinks', which 
checks for link only in the forward direction and is quicker than checking both 
directions; or 'CheckForwardAndReverseLinks', which is slower but safer as it checks for both forward and backward links.
    
        Arguments:
                * recordLinkModifications - type :py:mod:`RecordLinkModifications <GRANTA_MIScriptingToolkit.RecordLinkModifications>`
                * recordLinkCheckMode - type str
                * importErrorMode - type str
                * recordLinkGroupReference - type :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>`


    """
    
    def __init__(self, recordLinkModifications=None, recordLinkCheckMode=None, importErrorMode=None, recordLinkGroupReference=None, isOwner=True):
        """

        Arguments:
                * recordLinkModifications - type :py:mod:`RecordLinkModifications <GRANTA_MIScriptingToolkit.RecordLinkModifications>`
                * recordLinkCheckMode - type str
                * importErrorMode - type str
                * recordLinkGroupReference - type :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ModifyRecordLinksRequest_Create = self.lib.ModifyRecordLinksRequest_Create
            ModifyRecordLinksRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = ModifyRecordLinksRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordLinkModifications is not None:
            self.recordLinkModifications = recordLinkModifications
        if recordLinkCheckMode is not None:
            self.recordLinkCheckMode = recordLinkCheckMode
        if importErrorMode is not None:
            self.importErrorMode = importErrorMode
        if recordLinkGroupReference is not None:
            self.recordLinkGroupReference = recordLinkGroupReference


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ModifyRecordLinksRequest_Destroy = self.lib.ModifyRecordLinksRequest_Destroy
            ModifyRecordLinksRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ModifyRecordLinksRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordLinkModifications(self):
        """Property recordLinkModifications is of type :py:mod:`RecordLinkModifications <GRANTA_MIScriptingToolkit.RecordLinkModifications>`. """ 
        self._recordLinkModifications = self.__GetRecordLinkModifications()
        return self._recordLinkModifications

    @recordLinkModifications.setter
    def recordLinkModifications(self, value):
        if not isinstance(value, RecordLinkModifications):
            raise GRANTA_Exception('recordLinkModifications','recordLinkModifications: Invalid type recordLinkModifications must be of type RecordLinkModifications')
        self.__SetRecordLinkModifications(value)
        self._recordLinkModifications = value

    @property
    def recordLinkCheckMode(self):
        """Property recordLinkCheckMode is of type str. See :py:class:`GRANTA_Constants.RecordLinkCheckMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._recordLinkCheckMode = self.__GetRecordLinkCheckMode()
        return self._recordLinkCheckMode

    @recordLinkCheckMode.setter
    def recordLinkCheckMode(self, value):
        """See :py:class:`GRANTA_Constants.RecordLinkCheckMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('recordLinkCheckMode','recordLinkCheckMode: Invalid type recordLinkCheckMode must be of type str')
        self.__SetRecordLinkCheckMode(value)
        self._recordLinkCheckMode = value

    @property
    def importErrorMode(self):
        """Property importErrorMode is of type str. See :py:class:`GRANTA_Constants.ImportErrorMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._importErrorMode = self.__GetImportErrorMode()
        return self._importErrorMode

    @importErrorMode.setter
    def importErrorMode(self, value):
        """See :py:class:`GRANTA_Constants.ImportErrorMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('importErrorMode','importErrorMode: Invalid type importErrorMode must be of type str')
        self.__SetImportErrorMode(value)
        self._importErrorMode = value

    @property
    def recordLinkGroupReference(self):
        """Property recordLinkGroupReference is of type :py:mod:`RecordLinkGroupReference <GRANTA_MIScriptingToolkit.RecordLinkGroupReference>`. """ 
        self._recordLinkGroupReference = self.__GetRecordLinkGroupReference()
        return self._recordLinkGroupReference

    @recordLinkGroupReference.setter
    def recordLinkGroupReference(self, value):
        if not isinstance(value, RecordLinkGroupReference):
            raise GRANTA_Exception('recordLinkGroupReference','recordLinkGroupReference: Invalid type recordLinkGroupReference must be of type RecordLinkGroupReference')
        self.__SetRecordLinkGroupReference(value)
        self._recordLinkGroupReference = value

    def __GetRecordLinkGroupReference(self):
        _recordLinkGroupReference = RecordLinkGroupReference()
        ModifyRecordLinksRequest_GetRecordLinkGroupReference = self.lib.ModifyRecordLinksRequest_GetRecordLinkGroupReference
        ModifyRecordLinksRequest_GetRecordLinkGroupReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ModifyRecordLinksRequest_GetRecordLinkGroupReference(self._c_obj, (_recordLinkGroupReference.c_obj))
        
        return _recordLinkGroupReference
        
    def __SetRecordLinkGroupReference(self, value):

        ModifyRecordLinksRequest_SetRecordLinkGroupReference = self.lib.ModifyRecordLinksRequest_SetRecordLinkGroupReference 
        ModifyRecordLinksRequest_SetRecordLinkGroupReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ModifyRecordLinksRequest_SetRecordLinkGroupReference(self._c_obj, value.c_obj)

    def __GetImportErrorMode(self):
        ModifyRecordLinksRequest_GetImportErrorMode = self.lib.ModifyRecordLinksRequest_GetImportErrorMode
        ModifyRecordLinksRequest_GetImportErrorMode.argtypes = [POINTER(c_void_p)]
        ModifyRecordLinksRequest_GetImportErrorMode.restype = POINTER(c_void_p)
        value = ModifyRecordLinksRequest_GetImportErrorMode(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetImportErrorMode(self, value):
        """See :py:class:`GRANTA_Constants.ImportErrorMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        ModifyRecordLinksRequest_SetImportErrorMode = self.lib.ModifyRecordLinksRequest_SetImportErrorMode 
        ModifyRecordLinksRequest_SetImportErrorMode.argtypes = [POINTER(c_void_p), c_char_p]
        ModifyRecordLinksRequest_SetImportErrorMode(self._c_obj, EnsureEncoded(value))

    def __GetRecordLinkCheckMode(self):
        ModifyRecordLinksRequest_GetRecordLinkCheckMode = self.lib.ModifyRecordLinksRequest_GetRecordLinkCheckMode
        ModifyRecordLinksRequest_GetRecordLinkCheckMode.argtypes = [POINTER(c_void_p)]
        ModifyRecordLinksRequest_GetRecordLinkCheckMode.restype = POINTER(c_void_p)
        value = ModifyRecordLinksRequest_GetRecordLinkCheckMode(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetRecordLinkCheckMode(self, value):
        """See :py:class:`GRANTA_Constants.RecordLinkCheckMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        ModifyRecordLinksRequest_SetRecordLinkCheckMode = self.lib.ModifyRecordLinksRequest_SetRecordLinkCheckMode 
        ModifyRecordLinksRequest_SetRecordLinkCheckMode.argtypes = [POINTER(c_void_p), c_char_p]
        ModifyRecordLinksRequest_SetRecordLinkCheckMode(self._c_obj, EnsureEncoded(value))

    def __GetRecordLinkModifications(self):
        _recordLinkModifications = RecordLinkModifications()
        ModifyRecordLinksRequest_GetRecordLinkModifications = self.lib.ModifyRecordLinksRequest_GetRecordLinkModifications
        ModifyRecordLinksRequest_GetRecordLinkModifications.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ModifyRecordLinksRequest_GetRecordLinkModifications(self._c_obj, (_recordLinkModifications.c_obj))
        
        return _recordLinkModifications
        
    def __SetRecordLinkModifications(self, value):

        ModifyRecordLinksRequest_SetRecordLinkModifications = self.lib.ModifyRecordLinksRequest_SetRecordLinkModifications 
        ModifyRecordLinksRequest_SetRecordLinkModifications.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ModifyRecordLinksRequest_SetRecordLinkModifications(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


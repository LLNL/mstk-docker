# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.IDataValue import IDataValue
from GRANTA_MIScriptingToolkit.RangeDataType import RangeDataType
from GRANTA_MIScriptingToolkit.PointDataType import PointDataType
from GRANTA_MIScriptingToolkit.ShortTextDataType import ShortTextDataType
from GRANTA_MIScriptingToolkit.LongTextDataType import LongTextDataType
from GRANTA_MIScriptingToolkit.DiscreteDataType import DiscreteDataType
from GRANTA_MIScriptingToolkit.IntegerDataType import IntegerDataType
from GRANTA_MIScriptingToolkit.LogicalDataType import LogicalDataType
from GRANTA_MIScriptingToolkit.HyperlinkDataType import HyperlinkDataType
from GRANTA_MIScriptingToolkit.FileDataType import FileDataType
from GRANTA_MIScriptingToolkit.ListDataType import ListDataType
from GRANTA_MIScriptingToolkit.DateDataType import DateDataType


class TabularDataCell(object):
    """TabularDataCell. A Cell within an item of Tabular Data. When importing, TabularDataRow's 
CreateRow() and CreateUpdateRow() functions initialize empty cells. You can 
set this type's data member to be various data types: range, point, short text, long text, discrete, integer, logical, hyperlink, file, or date. 
    
        Arguments:
                * rangeDataValue - type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`
                * discreteDataValue - type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`
                * hyperlinkDataValue - type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`
                * listDataValue - type :py:mod:`ListDataType <GRANTA_MIScriptingToolkit.ListDataType>`
                * fileDataValue - type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`
                * dataType - type str
                * shortTextDataValue - type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`
                * integerDataValue - type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`
                * pointDataValue - type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`
                * logicalDataValue - type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`
                * longTextDataValue - type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`
                * dateDataValue - type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`
                * data - type :py:mod:`IDataValue <GRANTA_MIScriptingToolkit.IDataValue>`


    """
    
    def __init__(self, rangeDataValue=None, discreteDataValue=None, hyperlinkDataValue=None, listDataValue=None, fileDataValue=None, dataType=None, shortTextDataValue=None, integerDataValue=None, pointDataValue=None, logicalDataValue=None, longTextDataValue=None, dateDataValue=None, data=None, isOwner=True):
        """

        Arguments:
                * rangeDataValue - type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`
                * discreteDataValue - type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`
                * hyperlinkDataValue - type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`
                * listDataValue - type :py:mod:`ListDataType <GRANTA_MIScriptingToolkit.ListDataType>`
                * fileDataValue - type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`
                * dataType - type str
                * shortTextDataValue - type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`
                * integerDataValue - type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`
                * pointDataValue - type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`
                * logicalDataValue - type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`
                * longTextDataValue - type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`
                * dateDataValue - type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`
                * data - type :py:mod:`IDataValue <GRANTA_MIScriptingToolkit.IDataValue>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            TabularDataCell_Create = self.lib.TabularDataCell_Create
            TabularDataCell_Create.restype = POINTER(c_void_p)
            self.c_obj = TabularDataCell_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if rangeDataValue is not None:
            self.rangeDataValue = rangeDataValue
        if discreteDataValue is not None:
            self.discreteDataValue = discreteDataValue
        if hyperlinkDataValue is not None:
            self.hyperlinkDataValue = hyperlinkDataValue
        if listDataValue is not None:
            self.listDataValue = listDataValue
        if fileDataValue is not None:
            self.fileDataValue = fileDataValue
        if dataType is not None:
            self.dataType = dataType
        if shortTextDataValue is not None:
            self.shortTextDataValue = shortTextDataValue
        if integerDataValue is not None:
            self.integerDataValue = integerDataValue
        if pointDataValue is not None:
            self.pointDataValue = pointDataValue
        if logicalDataValue is not None:
            self.logicalDataValue = logicalDataValue
        if longTextDataValue is not None:
            self.longTextDataValue = longTextDataValue
        if dateDataValue is not None:
            self.dateDataValue = dateDataValue
        if data is not None:
            self.data = data


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            TabularDataCell_Destroy = self.lib.TabularDataCell_Destroy
            TabularDataCell_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            TabularDataCell_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def rangeDataValue(self):
        """Property rangeDataValue is of type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`. """ 
        self._rangeDataValue = self.__GetRangeDataValue()
        return self._rangeDataValue

    @rangeDataValue.setter
    def rangeDataValue(self, value):
        if not isinstance(value, RangeDataType):
            raise GRANTA_Exception('rangeDataValue','rangeDataValue: Invalid type rangeDataValue must be of type RangeDataType')
        
        self._rangeDataValue = value

    @property
    def discreteDataValue(self):
        """Property discreteDataValue is of type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`. """ 
        self._discreteDataValue = self.__GetDiscreteDataValue()
        return self._discreteDataValue

    @discreteDataValue.setter
    def discreteDataValue(self, value):
        if not isinstance(value, DiscreteDataType):
            raise GRANTA_Exception('discreteDataValue','discreteDataValue: Invalid type discreteDataValue must be of type DiscreteDataType')
        
        self._discreteDataValue = value

    @property
    def hyperlinkDataValue(self):
        """Property hyperlinkDataValue is of type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`. """ 
        self._hyperlinkDataValue = self.__GetHyperlinkDataValue()
        return self._hyperlinkDataValue

    @hyperlinkDataValue.setter
    def hyperlinkDataValue(self, value):
        if not isinstance(value, HyperlinkDataType):
            raise GRANTA_Exception('hyperlinkDataValue','hyperlinkDataValue: Invalid type hyperlinkDataValue must be of type HyperlinkDataType')
        
        self._hyperlinkDataValue = value

    @property
    def listDataValue(self):
        """Property listDataValue is of type :py:mod:`ListDataType <GRANTA_MIScriptingToolkit.ListDataType>`. """ 
        self._listDataValue = self.__GetListDataValueRef()
        return self._listDataValue

    @listDataValue.setter
    def listDataValue(self, value):
        if not isinstance(value, ListDataType):
            raise GRANTA_Exception('listDataValue','listDataValue: Invalid type listDataValue must be of type ListDataType')
        
        self._listDataValue = value

    @property
    def fileDataValue(self):
        """Property fileDataValue is of type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`. """ 
        self._fileDataValue = self.__GetFileDataValue()
        return self._fileDataValue

    @fileDataValue.setter
    def fileDataValue(self, value):
        if not isinstance(value, FileDataType):
            raise GRANTA_Exception('fileDataValue','fileDataValue: Invalid type fileDataValue must be of type FileDataType')
        
        self._fileDataValue = value

    @property
    def dataType(self):
        """Property dataType is of type str. """ 
        self._dataType = self.__GetDataType()
        return self._dataType

    @dataType.setter
    def dataType(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('dataType','dataType: Invalid type dataType must be of type str')
        
        self._dataType = value

    @property
    def shortTextDataValue(self):
        """Property shortTextDataValue is of type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`. """ 
        self._shortTextDataValue = self.__GetShortTextDataValue()
        return self._shortTextDataValue

    @shortTextDataValue.setter
    def shortTextDataValue(self, value):
        if not isinstance(value, ShortTextDataType):
            raise GRANTA_Exception('shortTextDataValue','shortTextDataValue: Invalid type shortTextDataValue must be of type ShortTextDataType')
        
        self._shortTextDataValue = value

    @property
    def integerDataValue(self):
        """Property integerDataValue is of type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`. """ 
        self._integerDataValue = self.__GetIntegerDataValue()
        return self._integerDataValue

    @integerDataValue.setter
    def integerDataValue(self, value):
        if not isinstance(value, IntegerDataType):
            raise GRANTA_Exception('integerDataValue','integerDataValue: Invalid type integerDataValue must be of type IntegerDataType')
        
        self._integerDataValue = value

    @property
    def pointDataValue(self):
        """Property pointDataValue is of type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`. """ 
        self._pointDataValue = self.__GetPointDataValue()
        return self._pointDataValue

    @pointDataValue.setter
    def pointDataValue(self, value):
        if not isinstance(value, PointDataType):
            raise GRANTA_Exception('pointDataValue','pointDataValue: Invalid type pointDataValue must be of type PointDataType')
        
        self._pointDataValue = value

    @property
    def logicalDataValue(self):
        """Property logicalDataValue is of type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`. """ 
        self._logicalDataValue = self.__GetLogicalDataValue()
        return self._logicalDataValue

    @logicalDataValue.setter
    def logicalDataValue(self, value):
        if not isinstance(value, LogicalDataType):
            raise GRANTA_Exception('logicalDataValue','logicalDataValue: Invalid type logicalDataValue must be of type LogicalDataType')
        
        self._logicalDataValue = value

    @property
    def longTextDataValue(self):
        """Property longTextDataValue is of type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`. """ 
        self._longTextDataValue = self.__GetLongTextDataValue()
        return self._longTextDataValue

    @longTextDataValue.setter
    def longTextDataValue(self, value):
        if not isinstance(value, LongTextDataType):
            raise GRANTA_Exception('longTextDataValue','longTextDataValue: Invalid type longTextDataValue must be of type LongTextDataType')
        
        self._longTextDataValue = value

    @property
    def dateDataValue(self):
        """Property dateDataValue is of type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`. """ 
        self._dateDataValue = self.__GetDateDataValue()
        return self._dateDataValue

    @dateDataValue.setter
    def dateDataValue(self, value):
        if not isinstance(value, DateDataType):
            raise GRANTA_Exception('dateDataValue','dateDataValue: Invalid type dateDataValue must be of type DateDataType')
        
        self._dateDataValue = value

    @property
    def data(self):
        """Property data is of type :py:mod:`IDataValue <GRANTA_MIScriptingToolkit.IDataValue>`. """ 
        try:
            return self._data
        except:
            return None

    @data.setter
    def data(self, value):
        if not isinstance(value, IDataValue):
            raise GRANTA_Exception('data','data: Invalid type data must be of type IDataValue')
        self.__SetDataAndClaim(value)
        self._data = value

    def __GetDataType(self):
        TabularDataCell_GetDataType = self.lib.TabularDataCell_GetDataType
        TabularDataCell_GetDataType.argtypes = [POINTER(c_void_p)]
        TabularDataCell_GetDataType.restype = POINTER(c_void_p)
        value = TabularDataCell_GetDataType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetDataAndClaim(self, value):

        if not value._isOwner:
            raise ValueError("This setter only works on data not referenced by another type - create a new object and copy attributes over")
        TabularDataCell_SetDataAndClaim = self.lib.TabularDataCell_SetDataAndClaim 
        TabularDataCell_SetDataAndClaim.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        TabularDataCell_SetDataAndClaim(self._c_obj, value.c_obj)
        value._isOwner = False
        value._parent = self

    def __GetRangeDataValue(self):
        _rangeDataType = RangeDataType()
        TabularDataCell_GetRangeDataValue = self.lib.TabularDataCell_GetRangeDataValue
        TabularDataCell_GetRangeDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularDataCell_GetRangeDataValue(self._c_obj, (_rangeDataType.c_obj))
        
        return _rangeDataType
        
    def __GetPointDataValue(self):
        _pointDataType = PointDataType()
        TabularDataCell_GetPointDataValue = self.lib.TabularDataCell_GetPointDataValue
        TabularDataCell_GetPointDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularDataCell_GetPointDataValue(self._c_obj, (_pointDataType.c_obj))
        
        return _pointDataType
        
    def __GetShortTextDataValue(self):
        _shortTextDataType = ShortTextDataType()
        TabularDataCell_GetShortTextDataValue = self.lib.TabularDataCell_GetShortTextDataValue
        TabularDataCell_GetShortTextDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularDataCell_GetShortTextDataValue(self._c_obj, (_shortTextDataType.c_obj))
        
        return _shortTextDataType
        
    def __GetLongTextDataValue(self):
        _longTextDataType = LongTextDataType()
        TabularDataCell_GetLongTextDataValue = self.lib.TabularDataCell_GetLongTextDataValue
        TabularDataCell_GetLongTextDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularDataCell_GetLongTextDataValue(self._c_obj, (_longTextDataType.c_obj))
        
        return _longTextDataType
        
    def __GetDiscreteDataValue(self):
        _discreteDataType = DiscreteDataType()
        TabularDataCell_GetDiscreteDataValue = self.lib.TabularDataCell_GetDiscreteDataValue
        TabularDataCell_GetDiscreteDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularDataCell_GetDiscreteDataValue(self._c_obj, (_discreteDataType.c_obj))
        
        return _discreteDataType
        
    def __GetIntegerDataValue(self):
        _integerDataType = IntegerDataType()
        TabularDataCell_GetIntegerDataValue = self.lib.TabularDataCell_GetIntegerDataValue
        TabularDataCell_GetIntegerDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularDataCell_GetIntegerDataValue(self._c_obj, (_integerDataType.c_obj))
        
        return _integerDataType
        
    def __GetLogicalDataValue(self):
        _logicalDataType = LogicalDataType()
        TabularDataCell_GetLogicalDataValue = self.lib.TabularDataCell_GetLogicalDataValue
        TabularDataCell_GetLogicalDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularDataCell_GetLogicalDataValue(self._c_obj, (_logicalDataType.c_obj))
        
        return _logicalDataType
        
    def __GetHyperlinkDataValue(self):
        _hyperlinkDataType = HyperlinkDataType()
        TabularDataCell_GetHyperlinkDataValue = self.lib.TabularDataCell_GetHyperlinkDataValue
        TabularDataCell_GetHyperlinkDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularDataCell_GetHyperlinkDataValue(self._c_obj, (_hyperlinkDataType.c_obj))
        
        return _hyperlinkDataType
        
    def __GetFileDataValue(self):
        _fileDataType = FileDataType()
        TabularDataCell_GetFileDataValue = self.lib.TabularDataCell_GetFileDataValue
        TabularDataCell_GetFileDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularDataCell_GetFileDataValue(self._c_obj, (_fileDataType.c_obj))
        
        return _fileDataType
        
    def __GetListDataValueRef(self):
        _listDataType = ListDataType(isOwner=False)
        TabularDataCell_GetListDataValueRef = self.lib.TabularDataCell_GetListDataValueRef
        TabularDataCell_GetListDataValueRef.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p))]
        TabularDataCell_GetListDataValueRef(self._c_obj, byref(_listDataType.c_obj))
        _listDataType._parent = self
        return _listDataType
        
    def __GetDateDataValue(self):
        _dateDataType = DateDataType()
        TabularDataCell_GetDateDataValue = self.lib.TabularDataCell_GetDateDataValue
        TabularDataCell_GetDateDataValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TabularDataCell_GetDateDataValue(self._c_obj, (_dateDataType.c_obj))
        
        return _dateDataType
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.SubsetReference import SubsetReference


class RecordFilter(object):
    """RecordFilter. A type allowing lists of Records to be filtered, e.g., by membership of 
Subset(s). You should specify either a profile or a subset reference, but 
not both. You can pass in a list containing an uninitialized :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>` to effectively disable the subset filter.
    
        Arguments:
                * profile - type str
                * subsets - type list of :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>` objects


    """
    
    def __init__(self, profile=None, subsets=None, isOwner=True):
        """

        Arguments:
                * profile - type str
                * subsets - type list of :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordFilter_Create = self.lib.RecordFilter_Create
            RecordFilter_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordFilter_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if profile is not None:
            self.profile = profile
        if subsets is not None:
            self.subsets = subsets


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordFilter_Destroy = self.lib.RecordFilter_Destroy
            RecordFilter_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordFilter_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def profile(self):
        """Property profile is of type str. """ 
        try:
            return self._profile
        except:
            return None

    @profile.setter
    def profile(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('profile','profile: Invalid type profile must be of type str')
        self.__SetProfile(value)
        self._profile = value

    @property
    def subsets(self):
        """Property subsets is of type list of :py:mod:`SubsetReference <GRANTA_MIScriptingToolkit.SubsetReference>`. """ 
        try:
            return self._subsets
        except:
            return None

    @subsets.setter
    def subsets(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('subsets','subsets: Invalid type subsets must be a list of SubsetReference')
                
        try:
            self.__updatesubsets = True
            self.__ClearSubsets()
            for v in value:
                self.AddSubset(v)
        except:
            pass


    def __SetProfile(self, value):

        RecordFilter_SetProfile = self.lib.RecordFilter_SetProfile 
        RecordFilter_SetProfile.argtypes = [POINTER(c_void_p), c_char_p]
        RecordFilter_SetProfile(self._c_obj, EnsureEncoded(value))

    def AddSubset(self, _subsetReference):
        """Appends _subsetReference to subsets property on RecordFilter C-object.

           Arguments:
                _subsetReference - object of type SubsetReference.
        """

        if not isinstance(_subsetReference, SubsetReference):
            raise GRANTA_Exception('RecordFilter.AddSubset','_subsetReference: Invalid argument type _subsetReference must be of type SubsetReference')
        RecordFilter_AddSubset = self.lib.RecordFilter_AddSubset
        RecordFilter_AddSubset.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordFilter_AddSubset(self._c_obj, _subsetReference.c_obj)
        return self

    def __ClearSubsets(self):
        RecordFilter_ClearSubsets = self.lib.RecordFilter_ClearSubsets
        RecordFilter_ClearSubsets.argtypes = [POINTER(c_void_p)]
        RecordFilter_ClearSubsets(self._c_obj)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


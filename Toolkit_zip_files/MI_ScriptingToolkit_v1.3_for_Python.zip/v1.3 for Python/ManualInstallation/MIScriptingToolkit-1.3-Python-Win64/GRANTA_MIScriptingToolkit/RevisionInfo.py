# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class RevisionInfo(object):
    """RevisionInfo. Describes when an entity in a GRANTA MI database was created and updated.
    
        Arguments:
                * modifiedUser - type str
                * createdUser - type str
                * updateCount - type int
                * modified - type str
                * created - type str


    """
    
    def __init__(self, modifiedUser=None, createdUser=None, updateCount=None, modified=None, created=None, isOwner=True):
        """

        Arguments:
                * modifiedUser - type str
                * createdUser - type str
                * updateCount - type int
                * modified - type str
                * created - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RevisionInfo_Create = self.lib.RevisionInfo_Create
            RevisionInfo_Create.restype = POINTER(c_void_p)
            self.c_obj = RevisionInfo_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if modifiedUser is not None:
            self.modifiedUser = modifiedUser
        if createdUser is not None:
            self.createdUser = createdUser
        if updateCount is not None:
            self.updateCount = updateCount
        if modified is not None:
            self.modified = modified
        if created is not None:
            self.created = created


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RevisionInfo_Destroy = self.lib.RevisionInfo_Destroy
            RevisionInfo_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RevisionInfo_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def modifiedUser(self):
        """Property modifiedUser is of type str. """ 
        self._modifiedUser = self.__GetModifiedUser()
        return self._modifiedUser

    @modifiedUser.setter
    def modifiedUser(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('modifiedUser','modifiedUser: Invalid type modifiedUser must be of type str')
        
        self._modifiedUser = value

    @property
    def createdUser(self):
        """Property createdUser is of type str. """ 
        self._createdUser = self.__GetCreatedUser()
        return self._createdUser

    @createdUser.setter
    def createdUser(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('createdUser','createdUser: Invalid type createdUser must be of type str')
        
        self._createdUser = value

    @property
    def updateCount(self):
        """Property updateCount is of type int. """ 
        self._updateCount = self.__GetUpdateCount()
        return self._updateCount

    @updateCount.setter
    def updateCount(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('updateCount','updateCount: Invalid type updateCount must be of type int')
        
        self._updateCount = value

    @property
    def modified(self):
        """Property modified is of type str. """ 
        self._modified = self.__GetModified()
        return self._modified

    @modified.setter
    def modified(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('modified','modified: Invalid type modified must be of type str')
        
        self._modified = value

    @property
    def created(self):
        """Property created is of type str. """ 
        self._created = self.__GetCreated()
        return self._created

    @created.setter
    def created(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('created','created: Invalid type created must be of type str')
        
        self._created = value

    def __GetModified(self):
        RevisionInfo_GetModified = self.lib.RevisionInfo_GetModified
        RevisionInfo_GetModified.argtypes = [POINTER(c_void_p)]
        RevisionInfo_GetModified.restype = POINTER(c_void_p)
        value = RevisionInfo_GetModified(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetModifiedUser(self):
        RevisionInfo_GetModifiedUser = self.lib.RevisionInfo_GetModifiedUser
        RevisionInfo_GetModifiedUser.argtypes = [POINTER(c_void_p)]
        RevisionInfo_GetModifiedUser.restype = POINTER(c_void_p)
        value = RevisionInfo_GetModifiedUser(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetCreated(self):
        RevisionInfo_GetCreated = self.lib.RevisionInfo_GetCreated
        RevisionInfo_GetCreated.argtypes = [POINTER(c_void_p)]
        RevisionInfo_GetCreated.restype = POINTER(c_void_p)
        value = RevisionInfo_GetCreated(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetCreatedUser(self):
        RevisionInfo_GetCreatedUser = self.lib.RevisionInfo_GetCreatedUser
        RevisionInfo_GetCreatedUser.argtypes = [POINTER(c_void_p)]
        RevisionInfo_GetCreatedUser.restype = POINTER(c_void_p)
        value = RevisionInfo_GetCreatedUser(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetUpdateCount(self):
        RevisionInfo_GetUpdateCount = self.lib.RevisionInfo_GetUpdateCount
        RevisionInfo_GetUpdateCount.argtypes = [POINTER(c_void_p)]
        RevisionInfo_GetUpdateCount.restype = c_int
        value = RevisionInfo_GetUpdateCount(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


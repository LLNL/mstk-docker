# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class TabularColumnContainsSearchValue(object):
    """TabularColumnContainsSearchValue. Criterion used for searching for text within a Column of a Tabular Attribute.
    
        Arguments:
                * colName - type str
                * value - type str


    """
    
    def __init__(self, colName=None, value=None, isOwner=True):
        """

        Arguments:
                * colName - type str
                * value - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            TabularColumnContainsSearchValue_Create = self.lib.TabularColumnContainsSearchValue_Create
            TabularColumnContainsSearchValue_Create.restype = POINTER(c_void_p)
            self.c_obj = TabularColumnContainsSearchValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if colName is not None:
            self.colName = colName
        if value is not None:
            self.value = value


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            TabularColumnContainsSearchValue_Destroy = self.lib.TabularColumnContainsSearchValue_Destroy
            TabularColumnContainsSearchValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            TabularColumnContainsSearchValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def colName(self):
        """Property colName is of type str. """ 
        self._colName = self.__GetColName()
        return self._colName

    @colName.setter
    def colName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('colName','colName: Invalid type colName must be of type str')
        self.__SetColName(value)
        self._colName = value

    @property
    def value(self):
        """Property value is of type str. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('value','value: Invalid type value must be of type str')
        self.__SetValue(value)
        self._value = value

    def __GetValue(self):
        TabularColumnContainsSearchValue_GetValue = self.lib.TabularColumnContainsSearchValue_GetValue
        TabularColumnContainsSearchValue_GetValue.argtypes = [POINTER(c_void_p)]
        TabularColumnContainsSearchValue_GetValue.restype = POINTER(c_void_p)
        value = TabularColumnContainsSearchValue_GetValue(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetValue(self, value):

        TabularColumnContainsSearchValue_SetValue = self.lib.TabularColumnContainsSearchValue_SetValue 
        TabularColumnContainsSearchValue_SetValue.argtypes = [POINTER(c_void_p), c_char_p]
        TabularColumnContainsSearchValue_SetValue(self._c_obj, EnsureEncoded(value))

    def __GetColName(self):
        TabularColumnContainsSearchValue_GetColName = self.lib.TabularColumnContainsSearchValue_GetColName
        TabularColumnContainsSearchValue_GetColName.argtypes = [POINTER(c_void_p)]
        TabularColumnContainsSearchValue_GetColName.restype = POINTER(c_void_p)
        value = TabularColumnContainsSearchValue_GetColName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetColName(self, value):

        TabularColumnContainsSearchValue_SetColName = self.lib.TabularColumnContainsSearchValue_SetColName 
        TabularColumnContainsSearchValue_SetColName.argtypes = [POINTER(c_void_p), c_char_p]
        TabularColumnContainsSearchValue_SetColName(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


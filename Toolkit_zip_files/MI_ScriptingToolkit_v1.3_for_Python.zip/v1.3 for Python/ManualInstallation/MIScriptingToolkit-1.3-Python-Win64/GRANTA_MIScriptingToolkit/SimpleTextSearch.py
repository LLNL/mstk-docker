# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordFilter import RecordFilter
from GRANTA_MIScriptingToolkit.PartialTableReference import PartialTableReference


class SimpleTextSearch(object):
    """SimpleTextSearch. The input to a simple text search operation. 
Both the DBKey, and search value are required. 
    
        Arguments:
                * recordFilter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * searchFilter - type int
                * restrictToTables - type list of :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>` objects
                * searchValue - type str
                * DBKey - type str
                * searchMode - type int
                * populateGUIDs - type bool


    """
    
    def __init__(self, recordFilter=None, searchFilter=None, restrictToTables=None, searchValue=None, DBKey=None, searchMode=None, populateGUIDs=None, isOwner=True):
        """

        Arguments:
                * recordFilter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * searchFilter - type int
                * restrictToTables - type list of :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>` objects
                * searchValue - type str
                * DBKey - type str
                * searchMode - type int
                * populateGUIDs - type bool

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            SimpleTextSearch_Create = self.lib.SimpleTextSearch_Create
            SimpleTextSearch_Create.restype = POINTER(c_void_p)
            self.c_obj = SimpleTextSearch_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordFilter is not None:
            self.recordFilter = recordFilter
        if searchFilter is not None:
            self.searchFilter = searchFilter
        if restrictToTables is not None:
            self.restrictToTables = restrictToTables
        if searchValue is not None:
            self.searchValue = searchValue
        if DBKey is not None:
            self.DBKey = DBKey
        if searchMode is not None:
            self.searchMode = searchMode
        if populateGUIDs is not None:
            self.populateGUIDs = populateGUIDs


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            SimpleTextSearch_Destroy = self.lib.SimpleTextSearch_Destroy
            SimpleTextSearch_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            SimpleTextSearch_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordFilter(self):
        """Property recordFilter is of type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`. """ 
        try:
            return self._recordFilter
        except:
            return None

    @recordFilter.setter
    def recordFilter(self, value):
        if not isinstance(value, RecordFilter):
            raise GRANTA_Exception('recordFilter','recordFilter: Invalid type recordFilter must be of type RecordFilter')
        self.__SetRecordFilter(value)
        self._recordFilter = value

    @property
    def searchFilter(self):
        """Property searchFilter is of type int. See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        try:
            return self._searchFilter
        except:
            return None

    @searchFilter.setter
    def searchFilter(self, value):
        """See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('searchFilter','searchFilter: Invalid type searchFilter must be of type int')
        self.__SetSearchFilter(value)
        self._searchFilter = value

    @property
    def restrictToTables(self):
        """Property restrictToTables is a list of :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._restrictToTables = self.__GetRestrictToTables()
        except:
            pass
        return self._restrictToTables

    @restrictToTables.setter
    def restrictToTables(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('restrictToTables','restrictToTables: Invalid type restrictToTables must be a list of PartialTableReference')
                
        try:
            self.__updaterestrictToTables = True
            self.__ClearRestrictToTables()
            for v in value:
                self.AddRestrictToTable(v)
        except:
            pass


    @property
    def searchValue(self):
        """Property searchValue is of type str. """ 
        self._searchValue = self.__GetSearchValue()
        return self._searchValue

    @searchValue.setter
    def searchValue(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('searchValue','searchValue: Invalid type searchValue must be of type str')
        self.__SetSearchValue(value)
        self._searchValue = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    @property
    def searchMode(self):
        """Property searchMode is of type int. See :py:class:`GRANTA_Constants.SearchMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        try:
            return self._searchMode
        except:
            return None

    @searchMode.setter
    def searchMode(self, value):
        """See :py:class:`GRANTA_Constants.SearchMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('searchMode','searchMode: Invalid type searchMode must be of type int')
        self.__SetSearchMode(value)
        self._searchMode = value

    @property
    def populateGUIDs(self):
        """Property populateGUIDs is of type bool. """ 
        self._populateGUIDs = self.__GetPopulateGUIDs()
        return self._populateGUIDs

    @populateGUIDs.setter
    def populateGUIDs(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('populateGUIDs','populateGUIDs: Invalid type populateGUIDs must be of type bool')
        self.__SetPopulateGUIDs(value)
        self._populateGUIDs = value

    def __SetDBKey(self, value):

        SimpleTextSearch_SetDBKey = self.lib.SimpleTextSearch_SetDBKey 
        SimpleTextSearch_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        SimpleTextSearch_SetDBKey(self._c_obj, EnsureEncoded(value))

    def __GetDBKey(self):
        SimpleTextSearch_GetDBKey = self.lib.SimpleTextSearch_GetDBKey
        SimpleTextSearch_GetDBKey.argtypes = [POINTER(c_void_p)]
        SimpleTextSearch_GetDBKey.restype = POINTER(c_void_p)
        value = SimpleTextSearch_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetSearchValue(self, value):

        SimpleTextSearch_SetSearchValue = self.lib.SimpleTextSearch_SetSearchValue 
        SimpleTextSearch_SetSearchValue.argtypes = [POINTER(c_void_p), c_char_p]
        SimpleTextSearch_SetSearchValue(self._c_obj, EnsureEncoded(value))

    def __GetSearchValue(self):
        SimpleTextSearch_GetSearchValue = self.lib.SimpleTextSearch_GetSearchValue
        SimpleTextSearch_GetSearchValue.argtypes = [POINTER(c_void_p)]
        SimpleTextSearch_GetSearchValue.restype = POINTER(c_void_p)
        value = SimpleTextSearch_GetSearchValue(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetPopulateGUIDs(self, value):

        SimpleTextSearch_SetPopulateGUIDs = self.lib.SimpleTextSearch_SetPopulateGUIDs 
        SimpleTextSearch_SetPopulateGUIDs.argtypes = [POINTER(c_void_p), c_bool]
        SimpleTextSearch_SetPopulateGUIDs(self._c_obj, value)

    def __GetPopulateGUIDs(self):
        SimpleTextSearch_GetPopulateGUIDs = self.lib.SimpleTextSearch_GetPopulateGUIDs
        SimpleTextSearch_GetPopulateGUIDs.argtypes = [POINTER(c_void_p)]
        SimpleTextSearch_GetPopulateGUIDs.restype = c_bool
        value = SimpleTextSearch_GetPopulateGUIDs(self._c_obj)
        return value
    
    def __SetSearchFilter(self, value):
        """See :py:class:`GRANTA_Constants.TablesFilter <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        SimpleTextSearch_SetSearchFilter = self.lib.SimpleTextSearch_SetSearchFilter 
        SimpleTextSearch_SetSearchFilter.argtypes = [POINTER(c_void_p), c_int]
        SimpleTextSearch_SetSearchFilter(self._c_obj, value)

    def __SetSearchMode(self, value):
        """See :py:class:`GRANTA_Constants.SearchMode <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        SimpleTextSearch_SetSearchMode = self.lib.SimpleTextSearch_SetSearchMode 
        SimpleTextSearch_SetSearchMode.argtypes = [POINTER(c_void_p), c_int]
        SimpleTextSearch_SetSearchMode(self._c_obj, value)

    def __SetRecordFilter(self, value):

        SimpleTextSearch_SetRecordFilter = self.lib.SimpleTextSearch_SetRecordFilter 
        SimpleTextSearch_SetRecordFilter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        SimpleTextSearch_SetRecordFilter(self._c_obj, value.c_obj)

    def __GetNumberOfRestrictToTables(self):
        SimpleTextSearch_GetNumberOfRestrictToTables = self.lib.SimpleTextSearch_GetNumberOfRestrictToTables
        SimpleTextSearch_GetNumberOfRestrictToTables.argtypes = [POINTER(c_void_p)]
        SimpleTextSearch_GetNumberOfRestrictToTables.restype = c_int
        value = SimpleTextSearch_GetNumberOfRestrictToTables(self._c_obj)
        return value
    
    def __GetRestrictToTableElement(self,i):
        value = PartialTableReference()
        SimpleTextSearch_GetRestrictToTable = self.lib.SimpleTextSearch_GetRestrictToTable
        SimpleTextSearch_GetRestrictToTable.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        SimpleTextSearch_GetRestrictToTable(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRestrictToTables(self):
         n = self.__GetNumberOfRestrictToTables();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRestrictToTableElement(i))
         return temp
    
    def __ClearRestrictToTables(self):
        SimpleTextSearch_ClearRestrictToTables = self.lib.SimpleTextSearch_ClearRestrictToTables
        SimpleTextSearch_ClearRestrictToTables.argtypes = [POINTER(c_void_p)]
        SimpleTextSearch_ClearRestrictToTables(self._c_obj)
        return self

    def AddRestrictToTable(self, _partialTableReference):
        """Appends _partialTableReference to restrictToTables property on SimpleTextSearch C-object.

           Arguments:
                _partialTableReference - object of type PartialTableReference.
        """

        if not isinstance(_partialTableReference, PartialTableReference):
            raise GRANTA_Exception('SimpleTextSearch.AddRestrictToTable','_partialTableReference: Invalid argument type _partialTableReference must be of type PartialTableReference')
        SimpleTextSearch_AddRestrictToTable = self.lib.SimpleTextSearch_AddRestrictToTable
        SimpleTextSearch_AddRestrictToTable.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        SimpleTextSearch_AddRestrictToTable(self._c_obj, _partialTableReference.c_obj)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.UnlinkAllRecords import UnlinkAllRecords
from GRANTA_MIScriptingToolkit.UnlinkRecords import UnlinkRecords
from GRANTA_MIScriptingToolkit.LinkRecords import LinkRecords
from GRANTA_MIScriptingToolkit.LinkAllCombinations import LinkAllCombinations


class RecordLinkModifications(object):
    """RecordLinkModifications. A set of modifications to be made to record link groups
    
        Arguments:
                * unlinkRecords - type list of :py:mod:`UnlinkRecords <GRANTA_MIScriptingToolkit.UnlinkRecords>` objects
                * linkAllCombinations - type list of :py:mod:`LinkAllCombinations <GRANTA_MIScriptingToolkit.LinkAllCombinations>` objects
                * unlinkAllRecords - type list of :py:mod:`UnlinkAllRecords <GRANTA_MIScriptingToolkit.UnlinkAllRecords>` objects
                * linkRecords - type list of :py:mod:`LinkRecords <GRANTA_MIScriptingToolkit.LinkRecords>` objects


    """
    
    def __init__(self, unlinkRecords=None, linkAllCombinations=None, unlinkAllRecords=None, linkRecords=None, isOwner=True):
        """

        Arguments:
                * unlinkRecords - type list of :py:mod:`UnlinkRecords <GRANTA_MIScriptingToolkit.UnlinkRecords>` objects
                * linkAllCombinations - type list of :py:mod:`LinkAllCombinations <GRANTA_MIScriptingToolkit.LinkAllCombinations>` objects
                * unlinkAllRecords - type list of :py:mod:`UnlinkAllRecords <GRANTA_MIScriptingToolkit.UnlinkAllRecords>` objects
                * linkRecords - type list of :py:mod:`LinkRecords <GRANTA_MIScriptingToolkit.LinkRecords>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordLinkModifications_Create = self.lib.RecordLinkModifications_Create
            RecordLinkModifications_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordLinkModifications_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if unlinkRecords is not None:
            self.unlinkRecords = unlinkRecords
        if linkAllCombinations is not None:
            self.linkAllCombinations = linkAllCombinations
        if unlinkAllRecords is not None:
            self.unlinkAllRecords = unlinkAllRecords
        if linkRecords is not None:
            self.linkRecords = linkRecords


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordLinkModifications_Destroy = self.lib.RecordLinkModifications_Destroy
            RecordLinkModifications_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordLinkModifications_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def unlinkRecords(self):
        """Property unlinkRecords is a list of :py:mod:`UnlinkRecords <GRANTA_MIScriptingToolkit.UnlinkRecords>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._unlinkRecords = self.__GetUnlinkRecords()
        except:
            pass
        return self._unlinkRecords

    @unlinkRecords.setter
    def unlinkRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('unlinkRecords','unlinkRecords: Invalid type unlinkRecords must be a list of UnlinkRecords')
                
        try:
            self.__updateunlinkRecords = True
            self.__ClearUnlinkRecords()
            for v in value:
                self.AddUnlinkRecords(v)
        except:
            pass


    @property
    def linkAllCombinations(self):
        """Property linkAllCombinations is a list of :py:mod:`LinkAllCombinations <GRANTA_MIScriptingToolkit.LinkAllCombinations>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._linkAllCombinations = self.__GetLinkAllCombinations()
        except:
            pass
        return self._linkAllCombinations

    @linkAllCombinations.setter
    def linkAllCombinations(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('linkAllCombinations','linkAllCombinations: Invalid type linkAllCombinations must be a list of LinkAllCombinations')
                
        try:
            self.__updatelinkAllCombinations = True
            self.__ClearLinkAllCombinations()
            for v in value:
                self.AddLinkAllCombinations(v)
        except:
            pass


    @property
    def unlinkAllRecords(self):
        """Property unlinkAllRecords is a list of :py:mod:`UnlinkAllRecords <GRANTA_MIScriptingToolkit.UnlinkAllRecords>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._unlinkAllRecords = self.__GetUnlinkAllRecords()
        except:
            pass
        return self._unlinkAllRecords

    @unlinkAllRecords.setter
    def unlinkAllRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('unlinkAllRecords','unlinkAllRecords: Invalid type unlinkAllRecords must be a list of UnlinkAllRecords')
                
        try:
            self.__updateunlinkAllRecords = True
            self.__ClearUnlinkAllRecords()
            for v in value:
                self.AddUnlinkAllRecords(v)
        except:
            pass


    @property
    def linkRecords(self):
        """Property linkRecords is a list of :py:mod:`LinkRecords <GRANTA_MIScriptingToolkit.LinkRecords>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._linkRecords = self.__GetLinkRecords()
        except:
            pass
        return self._linkRecords

    @linkRecords.setter
    def linkRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('linkRecords','linkRecords: Invalid type linkRecords must be a list of LinkRecords')
                
        try:
            self.__updatelinkRecords = True
            self.__ClearLinkRecords()
            for v in value:
                self.AddLinkRecords(v)
        except:
            pass


    def __GetNumberOfUnlinkAllRecords(self):
        RecordLinkModifications_GetNumberOfUnlinkAllRecords = self.lib.RecordLinkModifications_GetNumberOfUnlinkAllRecords
        RecordLinkModifications_GetNumberOfUnlinkAllRecords.argtypes = [POINTER(c_void_p)]
        RecordLinkModifications_GetNumberOfUnlinkAllRecords.restype = c_int
        value = RecordLinkModifications_GetNumberOfUnlinkAllRecords(self._c_obj)
        return value
    
    def __GetUnlinkAllRecordsElement(self,i):
        value = UnlinkAllRecords()
        RecordLinkModifications_GetUnlinkAllRecords = self.lib.RecordLinkModifications_GetUnlinkAllRecords
        RecordLinkModifications_GetUnlinkAllRecords.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordLinkModifications_GetUnlinkAllRecords(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetUnlinkAllRecords(self):
         n = self.__GetNumberOfUnlinkAllRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetUnlinkAllRecordsElement(i))
         return temp
    
    def AddUnlinkAllRecords(self, _unlinkAllRecords):
        """Appends _unlinkAllRecords to unlinkAllRecords property on RecordLinkModifications C-object.

           Arguments:
                _unlinkAllRecords - object of type UnlinkAllRecords.
        """

        if not isinstance(_unlinkAllRecords, UnlinkAllRecords):
            raise GRANTA_Exception('RecordLinkModifications.AddUnlinkAllRecords','_unlinkAllRecords: Invalid argument type _unlinkAllRecords must be of type UnlinkAllRecords')
        RecordLinkModifications_AddUnlinkAllRecords = self.lib.RecordLinkModifications_AddUnlinkAllRecords
        RecordLinkModifications_AddUnlinkAllRecords.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordLinkModifications_AddUnlinkAllRecords(self._c_obj, _unlinkAllRecords.c_obj)
        return self

    def __ClearUnlinkAllRecords(self):
        RecordLinkModifications_ClearUnlinkAllRecords = self.lib.RecordLinkModifications_ClearUnlinkAllRecords
        RecordLinkModifications_ClearUnlinkAllRecords.argtypes = [POINTER(c_void_p)]
        RecordLinkModifications_ClearUnlinkAllRecords(self._c_obj)
        return self

    def __GetNumberOfUnlinkRecords(self):
        RecordLinkModifications_GetNumberOfUnlinkRecords = self.lib.RecordLinkModifications_GetNumberOfUnlinkRecords
        RecordLinkModifications_GetNumberOfUnlinkRecords.argtypes = [POINTER(c_void_p)]
        RecordLinkModifications_GetNumberOfUnlinkRecords.restype = c_int
        value = RecordLinkModifications_GetNumberOfUnlinkRecords(self._c_obj)
        return value
    
    def __GetUnlinkRecordsElement(self,i):
        value = UnlinkRecords()
        RecordLinkModifications_GetUnlinkRecords = self.lib.RecordLinkModifications_GetUnlinkRecords
        RecordLinkModifications_GetUnlinkRecords.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordLinkModifications_GetUnlinkRecords(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetUnlinkRecords(self):
         n = self.__GetNumberOfUnlinkRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetUnlinkRecordsElement(i))
         return temp
    
    def AddUnlinkRecords(self, _unlinkRecords):
        """Appends _unlinkRecords to unlinkRecords property on RecordLinkModifications C-object.

           Arguments:
                _unlinkRecords - object of type UnlinkRecords.
        """

        if not isinstance(_unlinkRecords, UnlinkRecords):
            raise GRANTA_Exception('RecordLinkModifications.AddUnlinkRecords','_unlinkRecords: Invalid argument type _unlinkRecords must be of type UnlinkRecords')
        RecordLinkModifications_AddUnlinkRecords = self.lib.RecordLinkModifications_AddUnlinkRecords
        RecordLinkModifications_AddUnlinkRecords.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordLinkModifications_AddUnlinkRecords(self._c_obj, _unlinkRecords.c_obj)
        return self

    def __ClearUnlinkRecords(self):
        RecordLinkModifications_ClearUnlinkRecords = self.lib.RecordLinkModifications_ClearUnlinkRecords
        RecordLinkModifications_ClearUnlinkRecords.argtypes = [POINTER(c_void_p)]
        RecordLinkModifications_ClearUnlinkRecords(self._c_obj)
        return self

    def __GetNumberOfLinkRecords(self):
        RecordLinkModifications_GetNumberOfLinkRecords = self.lib.RecordLinkModifications_GetNumberOfLinkRecords
        RecordLinkModifications_GetNumberOfLinkRecords.argtypes = [POINTER(c_void_p)]
        RecordLinkModifications_GetNumberOfLinkRecords.restype = c_int
        value = RecordLinkModifications_GetNumberOfLinkRecords(self._c_obj)
        return value
    
    def __GetLinkRecordsElement(self,i):
        value = LinkRecords()
        RecordLinkModifications_GetLinkRecords = self.lib.RecordLinkModifications_GetLinkRecords
        RecordLinkModifications_GetLinkRecords.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordLinkModifications_GetLinkRecords(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetLinkRecords(self):
         n = self.__GetNumberOfLinkRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetLinkRecordsElement(i))
         return temp
    
    def AddLinkRecords(self, _linkRecords):
        """Appends _linkRecords to linkRecords property on RecordLinkModifications C-object.

           Arguments:
                _linkRecords - object of type LinkRecords.
        """

        if not isinstance(_linkRecords, LinkRecords):
            raise GRANTA_Exception('RecordLinkModifications.AddLinkRecords','_linkRecords: Invalid argument type _linkRecords must be of type LinkRecords')
        RecordLinkModifications_AddLinkRecords = self.lib.RecordLinkModifications_AddLinkRecords
        RecordLinkModifications_AddLinkRecords.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordLinkModifications_AddLinkRecords(self._c_obj, _linkRecords.c_obj)
        return self

    def __ClearLinkRecords(self):
        RecordLinkModifications_ClearLinkRecords = self.lib.RecordLinkModifications_ClearLinkRecords
        RecordLinkModifications_ClearLinkRecords.argtypes = [POINTER(c_void_p)]
        RecordLinkModifications_ClearLinkRecords(self._c_obj)
        return self

    def __GetNumberOfLinkAllCombinations(self):
        RecordLinkModifications_GetNumberOfLinkAllCombinations = self.lib.RecordLinkModifications_GetNumberOfLinkAllCombinations
        RecordLinkModifications_GetNumberOfLinkAllCombinations.argtypes = [POINTER(c_void_p)]
        RecordLinkModifications_GetNumberOfLinkAllCombinations.restype = c_int
        value = RecordLinkModifications_GetNumberOfLinkAllCombinations(self._c_obj)
        return value
    
    def __GetLinkAllCombinationsElement(self,i):
        value = LinkAllCombinations()
        RecordLinkModifications_GetLinkAllCombinations = self.lib.RecordLinkModifications_GetLinkAllCombinations
        RecordLinkModifications_GetLinkAllCombinations.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordLinkModifications_GetLinkAllCombinations(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetLinkAllCombinations(self):
         n = self.__GetNumberOfLinkAllCombinations();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetLinkAllCombinationsElement(i))
         return temp
    
    def AddLinkAllCombinations(self, _linkAllCombinations):
        """Appends _linkAllCombinations to linkAllCombinations property on RecordLinkModifications C-object.

           Arguments:
                _linkAllCombinations - object of type LinkAllCombinations.
        """

        if not isinstance(_linkAllCombinations, LinkAllCombinations):
            raise GRANTA_Exception('RecordLinkModifications.AddLinkAllCombinations','_linkAllCombinations: Invalid argument type _linkAllCombinations must be of type LinkAllCombinations')
        RecordLinkModifications_AddLinkAllCombinations = self.lib.RecordLinkModifications_AddLinkAllCombinations
        RecordLinkModifications_AddLinkAllCombinations.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordLinkModifications_AddLinkAllCombinations(self._c_obj, _linkAllCombinations.c_obj)
        return self

    def __ClearLinkAllCombinations(self):
        RecordLinkModifications_ClearLinkAllCombinations = self.lib.RecordLinkModifications_ClearLinkAllCombinations
        RecordLinkModifications_ClearLinkAllCombinations.argtypes = [POINTER(c_void_p)]
        RecordLinkModifications_ClearLinkAllCombinations(self._c_obj)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


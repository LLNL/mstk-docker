# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference


class GetMetaAttributesRequest(object):
    """GetMetaAttributesRequest. Input for the GetMetaAttributesRequest operation. 
    
        Arguments:
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects


    """
    
    def __init__(self, attributeReferences=None, isOwner=True):
        """

        Arguments:
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetMetaAttributesRequest_Create = self.lib.GetMetaAttributesRequest_Create
            GetMetaAttributesRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetMetaAttributesRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if attributeReferences is not None:
            self.attributeReferences = attributeReferences


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetMetaAttributesRequest_Destroy = self.lib.GetMetaAttributesRequest_Destroy
            GetMetaAttributesRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetMetaAttributesRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def attributeReferences(self):
        """Property attributeReferences is a list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeReferences = self.__GetAttributeReferences()
        except:
            pass
        return self._attributeReferences

    @attributeReferences.setter
    def attributeReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeReferences','attributeReferences: Invalid type attributeReferences must be a list of AttributeReference')
                
        try:
            self.__updateattributeReferences = True
            self.__ClearAttributeReferences()
            for v in value:
                self.AddAttributeReference(v)
        except:
            pass


    def __GetNumberOfAttributeReferences(self):
        GetMetaAttributesRequest_GetNumberOfAttributeReferences = self.lib.GetMetaAttributesRequest_GetNumberOfAttributeReferences
        GetMetaAttributesRequest_GetNumberOfAttributeReferences.argtypes = [POINTER(c_void_p)]
        GetMetaAttributesRequest_GetNumberOfAttributeReferences.restype = c_int
        value = GetMetaAttributesRequest_GetNumberOfAttributeReferences(self._c_obj)
        return value
    
    def __GetAttributeReferenceElement(self,i):
        value = AttributeReference()
        GetMetaAttributesRequest_GetAttributeReference = self.lib.GetMetaAttributesRequest_GetAttributeReference
        GetMetaAttributesRequest_GetAttributeReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetMetaAttributesRequest_GetAttributeReference(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributeReferences(self):
         n = self.__GetNumberOfAttributeReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeReferenceElement(i))
         return temp
    
    def __ClearAttributeReferences(self):
        GetMetaAttributesRequest_ClearAttributeReferences = self.lib.GetMetaAttributesRequest_ClearAttributeReferences
        GetMetaAttributesRequest_ClearAttributeReferences.argtypes = [POINTER(c_void_p)]
        GetMetaAttributesRequest_ClearAttributeReferences(self._c_obj)
        return self

    def AddAttributeReference(self, _attributeReference):
        """Appends _attributeReference to attributeReferences property on GetMetaAttributesRequest C-object.

           Arguments:
                _attributeReference - object of type AttributeReference.
        """

        if not isinstance(_attributeReference, AttributeReference):
            raise GRANTA_Exception('GetMetaAttributesRequest.AddAttributeReference','_attributeReference: Invalid argument type _attributeReference must be of type AttributeReference')
        GetMetaAttributesRequest_AddAttributeReference = self.lib.GetMetaAttributesRequest_AddAttributeReference
        GetMetaAttributesRequest_AddAttributeReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetMetaAttributesRequest_AddAttributeReference(self._c_obj, _attributeReference.c_obj)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


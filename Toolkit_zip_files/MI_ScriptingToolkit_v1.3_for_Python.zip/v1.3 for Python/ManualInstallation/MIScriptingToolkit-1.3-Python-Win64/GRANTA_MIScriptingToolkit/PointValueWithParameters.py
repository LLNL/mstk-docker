# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterReferencesAndValues import ParameterReferencesAndValues


class PointValueWithParameters(object):
    """PointValueWithParameters. A numeric value with associated :py:mod:`ParameterReferencesAndValues <GRANTA_MIScriptingToolkit.ParameterReferencesAndValues>` object.
    
        Arguments:
                * valueParameters - type :py:mod:`ParameterReferencesAndValues <GRANTA_MIScriptingToolkit.ParameterReferencesAndValues>`
                * value - type float


    """
    
    def __init__(self, valueParameters=None, value=None, isOwner=True):
        """

        Arguments:
                * valueParameters - type :py:mod:`ParameterReferencesAndValues <GRANTA_MIScriptingToolkit.ParameterReferencesAndValues>`
                * value - type float

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            PointValueWithParameters_Create = self.lib.PointValueWithParameters_Create
            PointValueWithParameters_Create.restype = POINTER(c_void_p)
            self.c_obj = PointValueWithParameters_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if valueParameters is not None:
            self.valueParameters = valueParameters
        if value is not None:
            self.value = value


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            PointValueWithParameters_Destroy = self.lib.PointValueWithParameters_Destroy
            PointValueWithParameters_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            PointValueWithParameters_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def valueParameters(self):
        """Property valueParameters is of type :py:mod:`ParameterReferencesAndValues <GRANTA_MIScriptingToolkit.ParameterReferencesAndValues>`. """ 
        self._valueParameters = self.__GetValueParameters()
        return self._valueParameters

    @valueParameters.setter
    def valueParameters(self, value):
        if not isinstance(value, ParameterReferencesAndValues):
            raise GRANTA_Exception('valueParameters','valueParameters: Invalid type valueParameters must be of type ParameterReferencesAndValues')
        self.__SetValueParameters(value)
        self._valueParameters = value

    @property
    def value(self):
        """Property value is of type float. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('value','value: Invalid type value must be of type float')
        self.__SetValue(value)
        self._value = value

    def __GetValue(self):
        PointValueWithParameters_GetValue = self.lib.PointValueWithParameters_GetValue
        PointValueWithParameters_GetValue.argtypes = [POINTER(c_void_p)]
        PointValueWithParameters_GetValue.restype = c_double
        value = PointValueWithParameters_GetValue(self._c_obj)
        return value
    
    def __SetValue(self, value):

        PointValueWithParameters_SetValue = self.lib.PointValueWithParameters_SetValue 
        PointValueWithParameters_SetValue.argtypes = [POINTER(c_void_p), c_double]
        PointValueWithParameters_SetValue(self._c_obj, value)

    def __GetValueParameters(self):
        _parameterReferencesAndValues = ParameterReferencesAndValues()
        PointValueWithParameters_GetValueParameters = self.lib.PointValueWithParameters_GetValueParameters
        PointValueWithParameters_GetValueParameters.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        PointValueWithParameters_GetValueParameters(self._c_obj, (_parameterReferencesAndValues.c_obj))
        
        return _parameterReferencesAndValues
        
    def __SetValueParameters(self, value):

        PointValueWithParameters_SetValueParameters = self.lib.PointValueWithParameters_SetValueParameters 
        PointValueWithParameters_SetValueParameters.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        PointValueWithParameters_SetValueParameters(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


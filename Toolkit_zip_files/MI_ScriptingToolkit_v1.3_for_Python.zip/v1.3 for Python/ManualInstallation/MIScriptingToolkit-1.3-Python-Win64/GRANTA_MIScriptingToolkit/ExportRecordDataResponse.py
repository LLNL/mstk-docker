# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse


class ExportRecordDataResponse(object):
    """ExportRecordDataResponse. Output for the ExportRecordData operation.
    
        Arguments:
            c_obj - ctypes.POINTER to a ExportRecordDataResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a ExportRecordDataResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ExportRecordDataResponse_Destroy = self.lib.ExportRecordDataResponse_Destroy
            ExportRecordDataResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ExportRecordDataResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def text(self):
        """Property text is of type str. """ 
        self._text = self.__GetText()
        return self._text

    @text.setter
    def text(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('text','text: Invalid type text must be of type str')
        
        self._text = value

    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        ExportRecordDataResponse_GetServiceLayerResponse = self.lib.ExportRecordDataResponse_GetServiceLayerResponse
        ExportRecordDataResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ExportRecordDataResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __GetText(self):
        ExportRecordDataResponse_GetText = self.lib.ExportRecordDataResponse_GetText
        ExportRecordDataResponse_GetText.argtypes = [POINTER(c_void_p)]
        ExportRecordDataResponse_GetText.restype = POINTER(c_void_p)
        value = ExportRecordDataResponse_GetText(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


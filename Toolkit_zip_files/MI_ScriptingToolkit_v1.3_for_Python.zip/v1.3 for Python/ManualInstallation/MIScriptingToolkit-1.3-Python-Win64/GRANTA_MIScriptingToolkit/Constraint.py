# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterReference import ParameterReference
from GRANTA_MIScriptingToolkit.ParameterValue import ParameterValue


class Constraint(object):
    """Constraint. A constraint on functional data.
For requests, both parameter and parameter value are required.
    
        Arguments:
                * parameterValue - type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`
                * parameter - type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`
                * label - type str


    """
    
    def __init__(self, parameterValue=None, parameter=None, label=None, isOwner=True):
        """

        Arguments:
                * parameterValue - type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`
                * parameter - type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`
                * label - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            Constraint_Create = self.lib.Constraint_Create
            Constraint_Create.restype = POINTER(c_void_p)
            self.c_obj = Constraint_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if parameterValue is not None:
            self.parameterValue = parameterValue
        if parameter is not None:
            self.parameter = parameter
        if label is not None:
            self.label = label


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            Constraint_Destroy = self.lib.Constraint_Destroy
            Constraint_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            Constraint_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def parameterValue(self):
        """Property parameterValue is of type :py:mod:`ParameterValue <GRANTA_MIScriptingToolkit.ParameterValue>`. """ 
        self._parameterValue = self.__GetParameterValue()
        return self._parameterValue

    @parameterValue.setter
    def parameterValue(self, value):
        if not isinstance(value, ParameterValue):
            raise GRANTA_Exception('parameterValue','parameterValue: Invalid type parameterValue must be of type ParameterValue')
        self.__SetParameterValue(value)
        self._parameterValue = value

    @property
    def parameter(self):
        """Property parameter is of type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`. """ 
        self._parameter = self.__GetParameter()
        return self._parameter

    @parameter.setter
    def parameter(self, value):
        if not isinstance(value, ParameterReference):
            raise GRANTA_Exception('parameter','parameter: Invalid type parameter must be of type ParameterReference')
        self.__SetParameter(value)
        self._parameter = value

    @property
    def label(self):
        """Property label is of type str. """ 
        self._label = self.__GetLabel()
        return self._label

    @label.setter
    def label(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('label','label: Invalid type label must be of type str')
        self.__SetLabel(value)
        self._label = value

    def __GetLabel(self):
        Constraint_GetLabel = self.lib.Constraint_GetLabel
        Constraint_GetLabel.argtypes = [POINTER(c_void_p)]
        Constraint_GetLabel.restype = POINTER(c_void_p)
        value = Constraint_GetLabel(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetLabel(self, value):

        Constraint_SetLabel = self.lib.Constraint_SetLabel 
        Constraint_SetLabel.argtypes = [POINTER(c_void_p), c_char_p]
        Constraint_SetLabel(self._c_obj, EnsureEncoded(value))

    def __SetParameter(self, value):

        Constraint_SetParameter = self.lib.Constraint_SetParameter 
        Constraint_SetParameter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        Constraint_SetParameter(self._c_obj, value.c_obj)

    def __GetParameter(self):
        _parameterReference = ParameterReference()
        Constraint_GetParameter = self.lib.Constraint_GetParameter
        Constraint_GetParameter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        Constraint_GetParameter(self._c_obj, (_parameterReference.c_obj))
        
        return _parameterReference
        
    def __SetParameterValue(self, value):

        Constraint_SetParameterValue = self.lib.Constraint_SetParameterValue 
        Constraint_SetParameterValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        Constraint_SetParameterValue(self._c_obj, value.c_obj)

    def __GetParameterValue(self):
        _parameterValue = ParameterValue()
        Constraint_GetParameterValue = self.lib.Constraint_GetParameterValue
        Constraint_GetParameterValue.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        Constraint_GetParameterValue(self._c_obj, (_parameterValue.c_obj))
        
        return _parameterValue
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


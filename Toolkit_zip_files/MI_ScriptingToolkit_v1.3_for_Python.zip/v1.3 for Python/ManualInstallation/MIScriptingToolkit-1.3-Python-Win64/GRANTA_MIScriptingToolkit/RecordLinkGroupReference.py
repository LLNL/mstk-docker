# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.PartialTableReference import PartialTableReference


class RecordLinkGroupReference(object):
    """RecordLinkGroupReference. A type that allows identification of a particular record link group in a GRANTA MI database.
 This may be done by specifying the identity of the group, or its name and a partial table reference.
    
        Arguments:
                * isStandardName - type bool
                * name - type str
                * partialTableReference - type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`
                * DBKey - type str
                * recordLinkGroupIdentity - type int
                * recordLinkGroupType - type str


    """
    
    def __init__(self, isStandardName=None, name=None, partialTableReference=None, DBKey=None, recordLinkGroupIdentity=None, recordLinkGroupType=None, isOwner=True):
        """

        Arguments:
                * isStandardName - type bool
                * name - type str
                * partialTableReference - type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`
                * DBKey - type str
                * recordLinkGroupIdentity - type int
                * recordLinkGroupType - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordLinkGroupReference_Create = self.lib.RecordLinkGroupReference_Create
            RecordLinkGroupReference_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordLinkGroupReference_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if isStandardName is not None:
            self.isStandardName = isStandardName
        if name is not None:
            self.name = name
        if partialTableReference is not None:
            self.partialTableReference = partialTableReference
        if DBKey is not None:
            self.DBKey = DBKey
        if recordLinkGroupIdentity is not None:
            self.recordLinkGroupIdentity = recordLinkGroupIdentity
        if recordLinkGroupType is not None:
            self.recordLinkGroupType = recordLinkGroupType


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordLinkGroupReference_Destroy = self.lib.RecordLinkGroupReference_Destroy
            RecordLinkGroupReference_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordLinkGroupReference_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def isStandardName(self):
        """Property isStandardName is of type bool. """ 
        self._isStandardName = self.__GetIsStandardName()
        return self._isStandardName

    @isStandardName.setter
    def isStandardName(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('isStandardName','isStandardName: Invalid type isStandardName must be of type bool')
        self.__SetIsStandardName(value)
        self._isStandardName = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    @property
    def partialTableReference(self):
        """Property partialTableReference is of type :py:mod:`PartialTableReference <GRANTA_MIScriptingToolkit.PartialTableReference>`. """ 
        self._partialTableReference = self.__GetPartialTableReference()
        return self._partialTableReference

    @partialTableReference.setter
    def partialTableReference(self, value):
        if not isinstance(value, PartialTableReference):
            raise GRANTA_Exception('partialTableReference','partialTableReference: Invalid type partialTableReference must be of type PartialTableReference')
        self.__SetPartialTableReference(value)
        self._partialTableReference = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        self.__SetDBKey(value)
        self._DBKey = value

    @property
    def recordLinkGroupIdentity(self):
        """Property recordLinkGroupIdentity is of type int. """ 
        self._recordLinkGroupIdentity = self.__GetRecordLinkGroupIdentity()
        return self._recordLinkGroupIdentity

    @recordLinkGroupIdentity.setter
    def recordLinkGroupIdentity(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('recordLinkGroupIdentity','recordLinkGroupIdentity: Invalid type recordLinkGroupIdentity must be of type int')
        self.__SetRecordLinkGroupIdentity(value)
        self._recordLinkGroupIdentity = value

    @property
    def recordLinkGroupType(self):
        """Property recordLinkGroupType is of type str. See :py:class:`GRANTA_Constants.RecordLinkGroupTypes <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._recordLinkGroupType = self.__GetRecordLinkGroupType()
        return self._recordLinkGroupType

    @recordLinkGroupType.setter
    def recordLinkGroupType(self, value):
        """See :py:class:`GRANTA_Constants.RecordLinkGroupTypes <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('recordLinkGroupType','recordLinkGroupType: Invalid type recordLinkGroupType must be of type str')
        self.__SetRecordLinkGroupType(value)
        self._recordLinkGroupType = value

    def __GetName(self):
        RecordLinkGroupReference_GetName = self.lib.RecordLinkGroupReference_GetName
        RecordLinkGroupReference_GetName.argtypes = [POINTER(c_void_p)]
        RecordLinkGroupReference_GetName.restype = POINTER(c_void_p)
        value = RecordLinkGroupReference_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        RecordLinkGroupReference_SetName = self.lib.RecordLinkGroupReference_SetName 
        RecordLinkGroupReference_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        RecordLinkGroupReference_SetName(self._c_obj, EnsureEncoded(value))

    def __GetRecordLinkGroupIdentity(self):
        RecordLinkGroupReference_GetRecordLinkGroupIdentity = self.lib.RecordLinkGroupReference_GetRecordLinkGroupIdentity
        RecordLinkGroupReference_GetRecordLinkGroupIdentity.argtypes = [POINTER(c_void_p)]
        RecordLinkGroupReference_GetRecordLinkGroupIdentity.restype = c_int
        value = RecordLinkGroupReference_GetRecordLinkGroupIdentity(self._c_obj)
        return value
    
    def __SetRecordLinkGroupIdentity(self, value):

        RecordLinkGroupReference_SetRecordLinkGroupIdentity = self.lib.RecordLinkGroupReference_SetRecordLinkGroupIdentity 
        RecordLinkGroupReference_SetRecordLinkGroupIdentity.argtypes = [POINTER(c_void_p), c_int]
        RecordLinkGroupReference_SetRecordLinkGroupIdentity(self._c_obj, value)

    def __GetIsStandardName(self):
        RecordLinkGroupReference_GetIsStandardName = self.lib.RecordLinkGroupReference_GetIsStandardName
        RecordLinkGroupReference_GetIsStandardName.argtypes = [POINTER(c_void_p)]
        RecordLinkGroupReference_GetIsStandardName.restype = c_bool
        value = RecordLinkGroupReference_GetIsStandardName(self._c_obj)
        return value
    
    def __SetIsStandardName(self, value):

        RecordLinkGroupReference_SetIsStandardName = self.lib.RecordLinkGroupReference_SetIsStandardName 
        RecordLinkGroupReference_SetIsStandardName.argtypes = [POINTER(c_void_p), c_bool]
        RecordLinkGroupReference_SetIsStandardName(self._c_obj, value)

    def __GetPartialTableReference(self):
        _partialTableReference = PartialTableReference()
        RecordLinkGroupReference_GetPartialTableReference = self.lib.RecordLinkGroupReference_GetPartialTableReference
        RecordLinkGroupReference_GetPartialTableReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordLinkGroupReference_GetPartialTableReference(self._c_obj, (_partialTableReference.c_obj))
        
        return _partialTableReference
        
    def __SetPartialTableReference(self, value):

        RecordLinkGroupReference_SetPartialTableReference = self.lib.RecordLinkGroupReference_SetPartialTableReference 
        RecordLinkGroupReference_SetPartialTableReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordLinkGroupReference_SetPartialTableReference(self._c_obj, value.c_obj)

    def __GetRecordLinkGroupType(self):
        RecordLinkGroupReference_GetRecordLinkGroupType = self.lib.RecordLinkGroupReference_GetRecordLinkGroupType
        RecordLinkGroupReference_GetRecordLinkGroupType.argtypes = [POINTER(c_void_p)]
        RecordLinkGroupReference_GetRecordLinkGroupType.restype = POINTER(c_void_p)
        value = RecordLinkGroupReference_GetRecordLinkGroupType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetRecordLinkGroupType(self, value):
        """See :py:class:`GRANTA_Constants.RecordLinkGroupTypes <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        RecordLinkGroupReference_SetRecordLinkGroupType = self.lib.RecordLinkGroupReference_SetRecordLinkGroupType 
        RecordLinkGroupReference_SetRecordLinkGroupType.argtypes = [POINTER(c_void_p), c_char_p]
        RecordLinkGroupReference_SetRecordLinkGroupType(self._c_obj, EnsureEncoded(value))

    def __GetDBKey(self):
        RecordLinkGroupReference_GetDBKey = self.lib.RecordLinkGroupReference_GetDBKey
        RecordLinkGroupReference_GetDBKey.argtypes = [POINTER(c_void_p)]
        RecordLinkGroupReference_GetDBKey.restype = POINTER(c_void_p)
        value = RecordLinkGroupReference_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetDBKey(self, value):

        RecordLinkGroupReference_SetDBKey = self.lib.RecordLinkGroupReference_SetDBKey 
        RecordLinkGroupReference_SetDBKey.argtypes = [POINTER(c_void_p), c_char_p]
        RecordLinkGroupReference_SetDBKey(self._c_obj, EnsureEncoded(value))

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


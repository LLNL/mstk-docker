# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.Constraints import Constraints


class FloatFunctionalPointValue(object):
    """FloatFunctionalPointValue. A single grid point in Gridded Float-Valued Functional Data, where the Y-axis value is a point
    
        Arguments:
                * estimated - type bool
                * value - type float
                * constraints - type :py:mod:`Constraints <GRANTA_MIScriptingToolkit.Constraints>`


    """
    
    def __init__(self, estimated=None, value=None, constraints=None, isOwner=True):
        """

        Arguments:
                * estimated - type bool
                * value - type float
                * constraints - type :py:mod:`Constraints <GRANTA_MIScriptingToolkit.Constraints>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            FloatFunctionalPointValue_Create = self.lib.FloatFunctionalPointValue_Create
            FloatFunctionalPointValue_Create.restype = POINTER(c_void_p)
            self.c_obj = FloatFunctionalPointValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if estimated is not None:
            self.estimated = estimated
        if value is not None:
            self.value = value
        if constraints is not None:
            self.constraints = constraints


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            FloatFunctionalPointValue_Destroy = self.lib.FloatFunctionalPointValue_Destroy
            FloatFunctionalPointValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            FloatFunctionalPointValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def estimated(self):
        """Property estimated is of type bool. """ 
        self._estimated = self.__GetEstimated()
        return self._estimated

    @estimated.setter
    def estimated(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('estimated','estimated: Invalid type estimated must be of type bool')
        self.__SetEstimated(value)
        self._estimated = value

    @property
    def value(self):
        """Property value is of type float. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('value','value: Invalid type value must be of type float')
        self.__SetValue(value)
        self._value = value

    @property
    def constraints(self):
        """Property constraints is of type :py:mod:`Constraints <GRANTA_MIScriptingToolkit.Constraints>`. """ 
        self._constraints = self.__GetConstraints()
        return self._constraints

    @constraints.setter
    def constraints(self, value):
        if not isinstance(value, Constraints):
            raise GRANTA_Exception('constraints','constraints: Invalid type constraints must be of type Constraints')
        self.__SetConstraints(value)
        self._constraints = value

    def __GetConstraints(self):
        _constraints = Constraints()
        FloatFunctionalPointValue_GetConstraints = self.lib.FloatFunctionalPointValue_GetConstraints
        FloatFunctionalPointValue_GetConstraints.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        FloatFunctionalPointValue_GetConstraints(self._c_obj, (_constraints.c_obj))
        
        return _constraints
        
    def __SetConstraints(self, value):

        FloatFunctionalPointValue_SetConstraints = self.lib.FloatFunctionalPointValue_SetConstraints 
        FloatFunctionalPointValue_SetConstraints.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalPointValue_SetConstraints(self._c_obj, value.c_obj)

    def __SetEstimated(self, value):

        FloatFunctionalPointValue_SetEstimated = self.lib.FloatFunctionalPointValue_SetEstimated 
        FloatFunctionalPointValue_SetEstimated.argtypes = [POINTER(c_void_p), c_bool]
        FloatFunctionalPointValue_SetEstimated(self._c_obj, value)

    def __GetEstimated(self):
        FloatFunctionalPointValue_GetEstimated = self.lib.FloatFunctionalPointValue_GetEstimated
        FloatFunctionalPointValue_GetEstimated.argtypes = [POINTER(c_void_p)]
        FloatFunctionalPointValue_GetEstimated.restype = c_bool
        value = FloatFunctionalPointValue_GetEstimated(self._c_obj)
        return value
    
    def __GetValue(self):
        FloatFunctionalPointValue_GetValue = self.lib.FloatFunctionalPointValue_GetValue
        FloatFunctionalPointValue_GetValue.argtypes = [POINTER(c_void_p)]
        FloatFunctionalPointValue_GetValue.restype = c_double
        value = FloatFunctionalPointValue_GetValue(self._c_obj)
        return value
    
    def __SetValue(self, value):

        FloatFunctionalPointValue_SetValue = self.lib.FloatFunctionalPointValue_SetValue 
        FloatFunctionalPointValue_SetValue.argtypes = [POINTER(c_void_p), c_double]
        FloatFunctionalPointValue_SetValue(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordAttribute import RecordAttribute
from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse


class GetRecordAttributesResponse(object):
    """GetRecordAttributesResponse. Output from the GetRecordAttributes operation.
Includes an array of :py:mod:`RecordAttribute <GRANTA_MIScriptingToolkit.RecordAttribute>` objects and a :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>` object.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetRecordAttributesResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetRecordAttributesResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetRecordAttributesResponse_Destroy = self.lib.GetRecordAttributesResponse_Destroy
            GetRecordAttributesResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetRecordAttributesResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordAttributes(self):
        """Property recordAttributes is a list of :py:mod:`RecordAttribute <GRANTA_MIScriptingToolkit.RecordAttribute>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordAttributes = self.__GetRecordAttributes()
        except:
            pass
        return self._recordAttributes

    @recordAttributes.setter
    def recordAttributes(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordAttributes','recordAttributes: Invalid type recordAttributes must be a list of RecordAttribute')
                
        try:
            self.__updaterecordAttributes = True
            self.__ClearRecordAttributes()
            for v in value:
                self.AddRecordAttribute(v)
        except:
            pass


    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    def AddRecordAttribute(self, _recordAttribute):
        """Appends _recordAttribute to recordAttributes property on GetRecordAttributesResponse C-object.

           Arguments:
                _recordAttribute - object of type RecordAttribute.
        """

        if not isinstance(_recordAttribute, RecordAttribute):
            raise GRANTA_Exception('GetRecordAttributesResponse.AddRecordAttribute','_recordAttribute: Invalid argument type _recordAttribute must be of type RecordAttribute')
        GetRecordAttributesResponse_AddRecordAttribute = self.lib.GetRecordAttributesResponse_AddRecordAttribute
        GetRecordAttributesResponse_AddRecordAttribute.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRecordAttributesResponse_AddRecordAttribute(self._c_obj, _recordAttribute.c_obj)
        return self

    def __ClearRecordAttributes(self):
        GetRecordAttributesResponse_ClearRecordAttributes = self.lib.GetRecordAttributesResponse_ClearRecordAttributes
        GetRecordAttributesResponse_ClearRecordAttributes.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesResponse_ClearRecordAttributes(self._c_obj)
        return self

    def __GetNumberOfRecordAttributes(self):
        GetRecordAttributesResponse_GetNumberOfRecordAttributes = self.lib.GetRecordAttributesResponse_GetNumberOfRecordAttributes
        GetRecordAttributesResponse_GetNumberOfRecordAttributes.argtypes = [POINTER(c_void_p)]
        GetRecordAttributesResponse_GetNumberOfRecordAttributes.restype = c_int
        value = GetRecordAttributesResponse_GetNumberOfRecordAttributes(self._c_obj)
        return value
    
    def __GetRecordAttributesElement(self,i):
        value = RecordAttribute()
        GetRecordAttributesResponse_GetRecordAttributes = self.lib.GetRecordAttributesResponse_GetRecordAttributes
        GetRecordAttributesResponse_GetRecordAttributes.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetRecordAttributesResponse_GetRecordAttributes(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordAttributes(self):
         n = self.__GetNumberOfRecordAttributes();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordAttributesElement(i))
         return temp
    
    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetRecordAttributesResponse_GetServiceLayerResponse = self.lib.GetRecordAttributesResponse_GetServiceLayerResponse
        GetRecordAttributesResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetRecordAttributesResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


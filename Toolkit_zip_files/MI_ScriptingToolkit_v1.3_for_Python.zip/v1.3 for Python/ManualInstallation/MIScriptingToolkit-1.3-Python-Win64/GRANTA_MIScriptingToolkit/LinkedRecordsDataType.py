# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordLinkGroup import RecordLinkGroup

from .IDataValue import IDataValue


class LinkedRecordsDataType(IDataValue):
    """LinkedRecordsDataType. A type representing a list of linked Records.
    
        Arguments:
                * typeString - type str
                * recordLinkGroups - type list of :py:mod:`RecordLinkGroup <GRANTA_MIScriptingToolkit.RecordLinkGroup>` objects
                * nodeName - type str


    """
    
    def __init__(self, typeString=None, recordLinkGroups=None, nodeName=None, isOwner=True):
        """

        Arguments:
                * typeString - type str
                * recordLinkGroups - type list of :py:mod:`RecordLinkGroup <GRANTA_MIScriptingToolkit.RecordLinkGroup>` objects
                * nodeName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            LinkedRecordsDataType_Create = self.lib.LinkedRecordsDataType_Create
            LinkedRecordsDataType_Create.restype = POINTER(c_void_p)
            self.c_obj = LinkedRecordsDataType_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if typeString is not None:
            self.typeString = typeString
        if recordLinkGroups is not None:
            self.recordLinkGroups = recordLinkGroups
        if nodeName is not None:
            self.nodeName = nodeName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            LinkedRecordsDataType_Destroy = self.lib.LinkedRecordsDataType_Destroy
            LinkedRecordsDataType_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            LinkedRecordsDataType_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def typeString(self):
        """Property typeString is of type str. """ 
        self._typeString = self.__GetTypeString()
        return self._typeString

    @typeString.setter
    def typeString(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('typeString','typeString: Invalid type typeString must be of type str')
        
        self._typeString = value

    @property
    def recordLinkGroups(self):
        """Property recordLinkGroups is a list of :py:mod:`RecordLinkGroup <GRANTA_MIScriptingToolkit.RecordLinkGroup>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordLinkGroups = self.__GetRecordLinkGroups()
        except:
            pass
        return self._recordLinkGroups

    @recordLinkGroups.setter
    def recordLinkGroups(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordLinkGroups','recordLinkGroups: Invalid type recordLinkGroups must be a list of RecordLinkGroup')
        
        self._recordLinkGroups = value

    @property
    def nodeName(self):
        """Property nodeName is of type str. """ 
        self._nodeName = self.__GetNodeName()
        return self._nodeName

    @nodeName.setter
    def nodeName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('nodeName','nodeName: Invalid type nodeName must be of type str')
        
        self._nodeName = value

    def __GetNodeName(self):
        LinkedRecordsDataType_GetNodeName = self.lib.LinkedRecordsDataType_GetNodeName
        LinkedRecordsDataType_GetNodeName.argtypes = [POINTER(c_void_p)]
        LinkedRecordsDataType_GetNodeName.restype = POINTER(c_void_p)
        value = LinkedRecordsDataType_GetNodeName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetNumberOfRecordLinkGroups(self):
        LinkedRecordsDataType_GetNumberOfRecordLinkGroups = self.lib.LinkedRecordsDataType_GetNumberOfRecordLinkGroups
        LinkedRecordsDataType_GetNumberOfRecordLinkGroups.argtypes = [POINTER(c_void_p)]
        LinkedRecordsDataType_GetNumberOfRecordLinkGroups.restype = c_int
        value = LinkedRecordsDataType_GetNumberOfRecordLinkGroups(self._c_obj)
        return value
    
    def __GetRecordLinkGroupElement(self,i):
        value = RecordLinkGroup()
        LinkedRecordsDataType_GetRecordLinkGroup = self.lib.LinkedRecordsDataType_GetRecordLinkGroup
        LinkedRecordsDataType_GetRecordLinkGroup.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        LinkedRecordsDataType_GetRecordLinkGroup(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordLinkGroups(self):
         n = self.__GetNumberOfRecordLinkGroups();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordLinkGroupElement(i))
         return temp
    
    def __ClearRecordLinkGroups(self):
        LinkedRecordsDataType_ClearRecordLinkGroups = self.lib.LinkedRecordsDataType_ClearRecordLinkGroups
        LinkedRecordsDataType_ClearRecordLinkGroups.argtypes = [POINTER(c_void_p)]
        LinkedRecordsDataType_ClearRecordLinkGroups(self._c_obj)
        return self

    def __GetTypeString(self):
        LinkedRecordsDataType_GetTypeString = self.lib.LinkedRecordsDataType_GetTypeString
        LinkedRecordsDataType_GetTypeString.argtypes = [POINTER(c_void_p)]
        LinkedRecordsDataType_GetTypeString.restype = POINTER(c_void_p)
        value = LinkedRecordsDataType_GetTypeString(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


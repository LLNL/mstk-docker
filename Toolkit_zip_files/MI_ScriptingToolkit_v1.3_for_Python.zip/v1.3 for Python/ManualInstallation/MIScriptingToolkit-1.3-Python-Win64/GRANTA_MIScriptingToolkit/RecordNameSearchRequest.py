# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.TableReference import TableReference
from GRANTA_MIScriptingToolkit.RecordFilter import RecordFilter


class RecordNameSearchRequest(object):
    """RecordNameSearchRequest. The input for the RecordNameSearch operation. Both the table and recordName are required.
    
        Arguments:
                * searchFullNames - type bool
                * recordName - type str
                * caseSensitiveNames - type bool
                * filter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * populateGUIDs - type bool
                * searchShortNames - type bool
                * table - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`


    """
    
    def __init__(self, searchFullNames=None, recordName=None, caseSensitiveNames=None, filter=None, populateGUIDs=None, searchShortNames=None, table=None, isOwner=True):
        """

        Arguments:
                * searchFullNames - type bool
                * recordName - type str
                * caseSensitiveNames - type bool
                * filter - type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`
                * populateGUIDs - type bool
                * searchShortNames - type bool
                * table - type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordNameSearchRequest_Create = self.lib.RecordNameSearchRequest_Create
            RecordNameSearchRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordNameSearchRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if searchFullNames is not None:
            self.searchFullNames = searchFullNames
        if recordName is not None:
            self.recordName = recordName
        if caseSensitiveNames is not None:
            self.caseSensitiveNames = caseSensitiveNames
        if filter is not None:
            self.filter = filter
        if populateGUIDs is not None:
            self.populateGUIDs = populateGUIDs
        if searchShortNames is not None:
            self.searchShortNames = searchShortNames
        if table is not None:
            self.table = table


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordNameSearchRequest_Destroy = self.lib.RecordNameSearchRequest_Destroy
            RecordNameSearchRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordNameSearchRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def searchFullNames(self):
        """Property searchFullNames is of type bool. """ 
        self._searchFullNames = self.__GetSearchFullNames()
        return self._searchFullNames

    @searchFullNames.setter
    def searchFullNames(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('searchFullNames','searchFullNames: Invalid type searchFullNames must be of type bool')
        self.__SetSearchFullNames(value)
        self._searchFullNames = value

    @property
    def recordName(self):
        """Property recordName is of type str. """ 
        self._recordName = self.__GetRecordName()
        return self._recordName

    @recordName.setter
    def recordName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('recordName','recordName: Invalid type recordName must be of type str')
        self.__SetRecordName(value)
        self._recordName = value

    @property
    def caseSensitiveNames(self):
        """Property caseSensitiveNames is of type bool. """ 
        self._caseSensitiveNames = self.__GetCaseSensitiveNames()
        return self._caseSensitiveNames

    @caseSensitiveNames.setter
    def caseSensitiveNames(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('caseSensitiveNames','caseSensitiveNames: Invalid type caseSensitiveNames must be of type bool')
        self.__SetCaseSensitiveNames(value)
        self._caseSensitiveNames = value

    @property
    def filter(self):
        """Property filter is of type :py:mod:`RecordFilter <GRANTA_MIScriptingToolkit.RecordFilter>`. """ 
        self._filter = self.__GetFilter()
        return self._filter

    @filter.setter
    def filter(self, value):
        if not isinstance(value, RecordFilter):
            raise GRANTA_Exception('filter','filter: Invalid type filter must be of type RecordFilter')
        self.__SetFilter(value)
        self._filter = value

    @property
    def populateGUIDs(self):
        """Property populateGUIDs is of type bool. """ 
        self._populateGUIDs = self.__GetPopulateGUIDs()
        return self._populateGUIDs

    @populateGUIDs.setter
    def populateGUIDs(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('populateGUIDs','populateGUIDs: Invalid type populateGUIDs must be of type bool')
        self.__SetPopulateGUIDs(value)
        self._populateGUIDs = value

    @property
    def searchShortNames(self):
        """Property searchShortNames is of type bool. """ 
        self._searchShortNames = self.__GetSearchShortNames()
        return self._searchShortNames

    @searchShortNames.setter
    def searchShortNames(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('searchShortNames','searchShortNames: Invalid type searchShortNames must be of type bool')
        self.__SetSearchShortNames(value)
        self._searchShortNames = value

    @property
    def table(self):
        """Property table is of type :py:mod:`TableReference <GRANTA_MIScriptingToolkit.TableReference>`. """ 
        self._table = self.__GetTable()
        return self._table

    @table.setter
    def table(self, value):
        if not isinstance(value, TableReference):
            raise GRANTA_Exception('table','table: Invalid type table must be of type TableReference')
        self.__SetTable(value)
        self._table = value

    def __GetTable(self):
        _tableReference = TableReference()
        RecordNameSearchRequest_GetTable = self.lib.RecordNameSearchRequest_GetTable
        RecordNameSearchRequest_GetTable.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordNameSearchRequest_GetTable(self._c_obj, (_tableReference.c_obj))
        
        return _tableReference
        
    def __SetTable(self, value):

        RecordNameSearchRequest_SetTable = self.lib.RecordNameSearchRequest_SetTable 
        RecordNameSearchRequest_SetTable.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordNameSearchRequest_SetTable(self._c_obj, value.c_obj)

    def __GetRecordName(self):
        RecordNameSearchRequest_GetRecordName = self.lib.RecordNameSearchRequest_GetRecordName
        RecordNameSearchRequest_GetRecordName.argtypes = [POINTER(c_void_p)]
        RecordNameSearchRequest_GetRecordName.restype = POINTER(c_void_p)
        value = RecordNameSearchRequest_GetRecordName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetRecordName(self, value):

        RecordNameSearchRequest_SetRecordName = self.lib.RecordNameSearchRequest_SetRecordName 
        RecordNameSearchRequest_SetRecordName.argtypes = [POINTER(c_void_p), c_char_p]
        RecordNameSearchRequest_SetRecordName(self._c_obj, EnsureEncoded(value))

    def __GetFilter(self):
        _recordFilter = RecordFilter()
        RecordNameSearchRequest_GetFilter = self.lib.RecordNameSearchRequest_GetFilter
        RecordNameSearchRequest_GetFilter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordNameSearchRequest_GetFilter(self._c_obj, (_recordFilter.c_obj))
        
        return _recordFilter
        
    def __SetFilter(self, value):

        RecordNameSearchRequest_SetFilter = self.lib.RecordNameSearchRequest_SetFilter 
        RecordNameSearchRequest_SetFilter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        RecordNameSearchRequest_SetFilter(self._c_obj, value.c_obj)

    def __GetPopulateGUIDs(self):
        RecordNameSearchRequest_GetPopulateGUIDs = self.lib.RecordNameSearchRequest_GetPopulateGUIDs
        RecordNameSearchRequest_GetPopulateGUIDs.argtypes = [POINTER(c_void_p)]
        RecordNameSearchRequest_GetPopulateGUIDs.restype = c_bool
        value = RecordNameSearchRequest_GetPopulateGUIDs(self._c_obj)
        return value
    
    def __SetPopulateGUIDs(self, value):

        RecordNameSearchRequest_SetPopulateGUIDs = self.lib.RecordNameSearchRequest_SetPopulateGUIDs 
        RecordNameSearchRequest_SetPopulateGUIDs.argtypes = [POINTER(c_void_p), c_bool]
        RecordNameSearchRequest_SetPopulateGUIDs(self._c_obj, value)

    def __GetSearchFullNames(self):
        RecordNameSearchRequest_GetSearchFullNames = self.lib.RecordNameSearchRequest_GetSearchFullNames
        RecordNameSearchRequest_GetSearchFullNames.argtypes = [POINTER(c_void_p)]
        RecordNameSearchRequest_GetSearchFullNames.restype = c_bool
        value = RecordNameSearchRequest_GetSearchFullNames(self._c_obj)
        return value
    
    def __SetSearchFullNames(self, value):

        RecordNameSearchRequest_SetSearchFullNames = self.lib.RecordNameSearchRequest_SetSearchFullNames 
        RecordNameSearchRequest_SetSearchFullNames.argtypes = [POINTER(c_void_p), c_bool]
        RecordNameSearchRequest_SetSearchFullNames(self._c_obj, value)

    def __GetSearchShortNames(self):
        RecordNameSearchRequest_GetSearchShortNames = self.lib.RecordNameSearchRequest_GetSearchShortNames
        RecordNameSearchRequest_GetSearchShortNames.argtypes = [POINTER(c_void_p)]
        RecordNameSearchRequest_GetSearchShortNames.restype = c_bool
        value = RecordNameSearchRequest_GetSearchShortNames(self._c_obj)
        return value
    
    def __SetSearchShortNames(self, value):

        RecordNameSearchRequest_SetSearchShortNames = self.lib.RecordNameSearchRequest_SetSearchShortNames 
        RecordNameSearchRequest_SetSearchShortNames.argtypes = [POINTER(c_void_p), c_bool]
        RecordNameSearchRequest_SetSearchShortNames(self._c_obj, value)

    def __GetCaseSensitiveNames(self):
        RecordNameSearchRequest_GetCaseSensitiveNames = self.lib.RecordNameSearchRequest_GetCaseSensitiveNames
        RecordNameSearchRequest_GetCaseSensitiveNames.argtypes = [POINTER(c_void_p)]
        RecordNameSearchRequest_GetCaseSensitiveNames.restype = c_bool
        value = RecordNameSearchRequest_GetCaseSensitiveNames(self._c_obj)
        return value
    
    def __SetCaseSensitiveNames(self, value):

        RecordNameSearchRequest_SetCaseSensitiveNames = self.lib.RecordNameSearchRequest_SetCaseSensitiveNames 
        RecordNameSearchRequest_SetCaseSensitiveNames.argtypes = [POINTER(c_void_p), c_bool]
        RecordNameSearchRequest_SetCaseSensitiveNames(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


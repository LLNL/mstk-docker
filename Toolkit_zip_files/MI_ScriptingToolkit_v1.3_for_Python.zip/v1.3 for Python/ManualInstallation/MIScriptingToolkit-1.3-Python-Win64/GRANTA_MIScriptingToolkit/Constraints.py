# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.Constraint import Constraint


class Constraints(object):
    """Constraints. A container of constraints.
    
        Arguments:
                * constraints - type list of :py:mod:`Constraint <GRANTA_MIScriptingToolkit.Constraint>` objects


    """
    
    def __init__(self, constraints=None, isOwner=True):
        """

        Arguments:
                * constraints - type list of :py:mod:`Constraint <GRANTA_MIScriptingToolkit.Constraint>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            Constraints_Create = self.lib.Constraints_Create
            Constraints_Create.restype = POINTER(c_void_p)
            self.c_obj = Constraints_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if constraints is not None:
            self.constraints = constraints


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            Constraints_Destroy = self.lib.Constraints_Destroy
            Constraints_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            Constraints_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def constraints(self):
        """Property constraints is a list of :py:mod:`Constraint <GRANTA_MIScriptingToolkit.Constraint>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._constraints = self.__GetConstraints()
        except:
            pass
        return self._constraints

    @constraints.setter
    def constraints(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('constraints','constraints: Invalid type constraints must be a list of Constraint')
                
        try:
            self.__updateconstraints = True
            self.__ClearConstraints()
            for v in value:
                self.AddConstraint(v)
        except:
            pass


    def __GetNumberOfConstraints(self):
        Constraints_GetNumberOfConstraints = self.lib.Constraints_GetNumberOfConstraints
        Constraints_GetNumberOfConstraints.argtypes = [POINTER(c_void_p)]
        Constraints_GetNumberOfConstraints.restype = c_int
        value = Constraints_GetNumberOfConstraints(self._c_obj)
        return value
    
    def __GetConstraintElement(self,i):
        value = Constraint()
        Constraints_GetConstraint = self.lib.Constraints_GetConstraint
        Constraints_GetConstraint.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        Constraints_GetConstraint(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetConstraints(self):
         n = self.__GetNumberOfConstraints();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetConstraintElement(i))
         return temp
    
    def AddConstraint(self, _constraint):
        """Appends _constraint to constraints property on Constraints C-object.

           Arguments:
                _constraint - object of type Constraint.
        """

        if not isinstance(_constraint, Constraint):
            raise GRANTA_Exception('Constraints.AddConstraint','_constraint: Invalid argument type _constraint must be of type Constraint')
        Constraints_AddConstraint = self.lib.Constraints_AddConstraint
        Constraints_AddConstraint.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        Constraints_AddConstraint(self._c_obj, _constraint.c_obj)
        return self

    def __ClearConstraints(self):
        Constraints_ClearConstraints = self.lib.Constraints_ClearConstraints
        Constraints_ClearConstraints.argtypes = [POINTER(c_void_p)]
        Constraints_ClearConstraints(self._c_obj)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


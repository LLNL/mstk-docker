# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.UnitInformation import UnitInformation
from GRANTA_MIScriptingToolkit.ParameterReference import ParameterReference


class ExporterParameter(object):
    """ExporterParameter. Information about a Parameter of Functional Data.
    
        Arguments:
                * usage - type int
                * parameterReference - type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`
                * Id - type str
                * unit - type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`
                * name - type str


    """
    class Usage:
        Unknown = 0
        free = 1
        fixed = 2
        unused = 3
    
    def __init__(self, usage=None, parameterReference=None, Id=None, unit=None, name=None, isOwner=True):
        """

        Arguments:
                * usage - type int
                * parameterReference - type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`
                * Id - type str
                * unit - type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`
                * name - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ExporterParameter_Create = self.lib.ExporterParameter_Create
            ExporterParameter_Create.restype = POINTER(c_void_p)
            self.c_obj = ExporterParameter_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if usage is not None:
            self.usage = usage
        if parameterReference is not None:
            self.parameterReference = parameterReference
        if Id is not None:
            self.Id = Id
        if unit is not None:
            self.unit = unit
        if name is not None:
            self.name = name


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ExporterParameter_Destroy = self.lib.ExporterParameter_Destroy
            ExporterParameter_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ExporterParameter_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def usage(self):
        """Property usage is of type int. See :py:class:`ExporterParameter.Usage <ExporterParameter.Usage>` for supported values.""" 
        self._usage = self.__GetUsage()
        return self._usage

    @usage.setter
    def usage(self, value):
        """See :py:class:`ExporterParameter.Usage <ExporterParameter.Usage>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('usage','usage: Invalid type usage must be of type int')
        self.__SetUsage(value)
        self._usage = value

    @property
    def parameterReference(self):
        """Property parameterReference is of type :py:mod:`ParameterReference <GRANTA_MIScriptingToolkit.ParameterReference>`. """ 
        self._parameterReference = self.__GetParameterReference()
        return self._parameterReference

    @parameterReference.setter
    def parameterReference(self, value):
        if not isinstance(value, ParameterReference):
            raise GRANTA_Exception('parameterReference','parameterReference: Invalid type parameterReference must be of type ParameterReference')
        self.__SetParameterReference(value)
        self._parameterReference = value

    @property
    def Id(self):
        """Property Id is of type str. """ 
        self._Id = self.__GetId()
        return self._Id

    @Id.setter
    def Id(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('Id','Id: Invalid type Id must be of type str')
        self.__SetId(value)
        self._Id = value

    @property
    def unit(self):
        """Property unit is of type :py:mod:`UnitInformation <GRANTA_MIScriptingToolkit.UnitInformation>`. """ 
        self._unit = self.__GetUnit()
        return self._unit

    @unit.setter
    def unit(self, value):
        if not isinstance(value, UnitInformation):
            raise GRANTA_Exception('unit','unit: Invalid type unit must be of type UnitInformation')
        self.__SetUnit(value)
        self._unit = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    def __GetId(self):
        ExporterParameter_GetId = self.lib.ExporterParameter_GetId
        ExporterParameter_GetId.argtypes = [POINTER(c_void_p)]
        ExporterParameter_GetId.restype = POINTER(c_void_p)
        value = ExporterParameter_GetId(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetId(self, value):

        ExporterParameter_SetId = self.lib.ExporterParameter_SetId 
        ExporterParameter_SetId.argtypes = [POINTER(c_void_p), c_char_p]
        ExporterParameter_SetId(self._c_obj, EnsureEncoded(value))

    def __GetUsage(self):
        ExporterParameter_GetUsage = self.lib.ExporterParameter_GetUsage
        ExporterParameter_GetUsage.argtypes = [POINTER(c_void_p)]
        ExporterParameter_GetUsage.restype = c_int
        value = ExporterParameter_GetUsage(self._c_obj)
        return value
    
    def __SetUsage(self, value):
        """See :py:class:`ExporterParameter.Usage <ExporterParameter.Usage>` for supported values."""

        ExporterParameter_SetUsage = self.lib.ExporterParameter_SetUsage 
        ExporterParameter_SetUsage.argtypes = [POINTER(c_void_p), c_int]
        ExporterParameter_SetUsage(self._c_obj, value)

    def __GetName(self):
        ExporterParameter_GetName = self.lib.ExporterParameter_GetName
        ExporterParameter_GetName.argtypes = [POINTER(c_void_p)]
        ExporterParameter_GetName.restype = POINTER(c_void_p)
        value = ExporterParameter_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        ExporterParameter_SetName = self.lib.ExporterParameter_SetName 
        ExporterParameter_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        ExporterParameter_SetName(self._c_obj, EnsureEncoded(value))

    def __GetUnit(self):
        _unitInformation = UnitInformation()
        ExporterParameter_GetUnit = self.lib.ExporterParameter_GetUnit
        ExporterParameter_GetUnit.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ExporterParameter_GetUnit(self._c_obj, (_unitInformation.c_obj))
        
        return _unitInformation
        
    def __SetUnit(self, value):

        ExporterParameter_SetUnit = self.lib.ExporterParameter_SetUnit 
        ExporterParameter_SetUnit.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ExporterParameter_SetUnit(self._c_obj, value.c_obj)

    def __GetParameterReference(self):
        _parameterReference = ParameterReference()
        ExporterParameter_GetParameterReference = self.lib.ExporterParameter_GetParameterReference
        ExporterParameter_GetParameterReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        ExporterParameter_GetParameterReference(self._c_obj, (_parameterReference.c_obj))
        
        return _parameterReference
        
    def __SetParameterReference(self, value):

        ExporterParameter_SetParameterReference = self.lib.ExporterParameter_SetParameterReference 
        ExporterParameter_SetParameterReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ExporterParameter_SetParameterReference(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


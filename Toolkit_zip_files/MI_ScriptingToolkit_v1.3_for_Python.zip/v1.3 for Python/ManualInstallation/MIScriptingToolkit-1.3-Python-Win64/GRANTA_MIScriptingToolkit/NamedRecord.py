# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class NamedRecord(object):
    """NamedRecord. A :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` with the short and long name of the record.
    
        Arguments:
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * shortName - type str
                * longName - type str


    """
    
    def __init__(self, recordReference=None, shortName=None, longName=None, isOwner=True):
        """

        Arguments:
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * shortName - type str
                * longName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            NamedRecord_Create = self.lib.NamedRecord_Create
            NamedRecord_Create.restype = POINTER(c_void_p)
            self.c_obj = NamedRecord_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordReference is not None:
            self.recordReference = recordReference
        if shortName is not None:
            self.shortName = shortName
        if longName is not None:
            self.longName = longName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            NamedRecord_Destroy = self.lib.NamedRecord_Destroy
            NamedRecord_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            NamedRecord_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordReference(self):
        """Property recordReference is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._recordReference = self.__GetRecordReference()
        return self._recordReference

    @recordReference.setter
    def recordReference(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('recordReference','recordReference: Invalid type recordReference must be of type RecordReference')
        
        self._recordReference = value

    @property
    def shortName(self):
        """Property shortName is of type str. """ 
        self._shortName = self.__GetShortName()
        return self._shortName

    @shortName.setter
    def shortName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('shortName','shortName: Invalid type shortName must be of type str')
        
        self._shortName = value

    @property
    def longName(self):
        """Property longName is of type str. """ 
        self._longName = self.__GetLongName()
        return self._longName

    @longName.setter
    def longName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('longName','longName: Invalid type longName must be of type str')
        
        self._longName = value

    def __GetShortName(self):
        NamedRecord_GetShortName = self.lib.NamedRecord_GetShortName
        NamedRecord_GetShortName.argtypes = [POINTER(c_void_p)]
        NamedRecord_GetShortName.restype = POINTER(c_void_p)
        value = NamedRecord_GetShortName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetLongName(self):
        NamedRecord_GetLongName = self.lib.NamedRecord_GetLongName
        NamedRecord_GetLongName.argtypes = [POINTER(c_void_p)]
        NamedRecord_GetLongName.restype = POINTER(c_void_p)
        value = NamedRecord_GetLongName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetRecordReference(self):
        _recordReference = RecordReference()
        NamedRecord_GetRecordReference = self.lib.NamedRecord_GetRecordReference
        NamedRecord_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        NamedRecord_GetRecordReference(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class UnitConversionContext(object):
    """UnitConversionContext. Type defining how values with units should be represented
    
        Arguments:
                * currency - type str
                * absoluteUnits - type bool
                * unitSystem - type str


    """
    
    def __init__(self, currency=None, absoluteUnits=None, unitSystem=None, isOwner=True):
        """

        Arguments:
                * currency - type str
                * absoluteUnits - type bool
                * unitSystem - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            UnitConversionContext_Create = self.lib.UnitConversionContext_Create
            UnitConversionContext_Create.restype = POINTER(c_void_p)
            self.c_obj = UnitConversionContext_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if currency is not None:
            self.currency = currency
        if absoluteUnits is not None:
            self.absoluteUnits = absoluteUnits
        if unitSystem is not None:
            self.unitSystem = unitSystem


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            UnitConversionContext_Destroy = self.lib.UnitConversionContext_Destroy
            UnitConversionContext_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            UnitConversionContext_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def currency(self):
        """Property currency is of type str. """ 
        self._currency = self.__GetCurrency()
        return self._currency

    @currency.setter
    def currency(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('currency','currency: Invalid type currency must be of type str')
        self.__SetCurrency(value)
        self._currency = value

    @property
    def absoluteUnits(self):
        """Property absoluteUnits is of type bool. """ 
        self._absoluteUnits = self.__GetAbsoluteUnits()
        return self._absoluteUnits

    @absoluteUnits.setter
    def absoluteUnits(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('absoluteUnits','absoluteUnits: Invalid type absoluteUnits must be of type bool')
        self.__SetAbsoluteUnits(value)
        self._absoluteUnits = value

    @property
    def unitSystem(self):
        """Property unitSystem is of type str. """ 
        self._unitSystem = self.__GetUnitSystem()
        return self._unitSystem

    @unitSystem.setter
    def unitSystem(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('unitSystem','unitSystem: Invalid type unitSystem must be of type str')
        self.__SetUnitSystem(value)
        self._unitSystem = value

    def __SetUnitSystem(self, value):

        UnitConversionContext_SetUnitSystem = self.lib.UnitConversionContext_SetUnitSystem 
        UnitConversionContext_SetUnitSystem.argtypes = [POINTER(c_void_p), c_char_p]
        UnitConversionContext_SetUnitSystem(self._c_obj, EnsureEncoded(value))

    def __GetUnitSystem(self):
        UnitConversionContext_GetUnitSystem = self.lib.UnitConversionContext_GetUnitSystem
        UnitConversionContext_GetUnitSystem.argtypes = [POINTER(c_void_p)]
        UnitConversionContext_GetUnitSystem.restype = POINTER(c_void_p)
        value = UnitConversionContext_GetUnitSystem(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetCurrency(self, value):

        UnitConversionContext_SetCurrency = self.lib.UnitConversionContext_SetCurrency 
        UnitConversionContext_SetCurrency.argtypes = [POINTER(c_void_p), c_char_p]
        UnitConversionContext_SetCurrency(self._c_obj, EnsureEncoded(value))

    def __GetCurrency(self):
        UnitConversionContext_GetCurrency = self.lib.UnitConversionContext_GetCurrency
        UnitConversionContext_GetCurrency.argtypes = [POINTER(c_void_p)]
        UnitConversionContext_GetCurrency.restype = POINTER(c_void_p)
        value = UnitConversionContext_GetCurrency(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetAbsoluteUnits(self):
        UnitConversionContext_GetAbsoluteUnits = self.lib.UnitConversionContext_GetAbsoluteUnits
        UnitConversionContext_GetAbsoluteUnits.argtypes = [POINTER(c_void_p)]
        UnitConversionContext_GetAbsoluteUnits.restype = c_bool
        value = UnitConversionContext_GetAbsoluteUnits(self._c_obj)
        return value
    
    def __SetAbsoluteUnits(self, value):

        UnitConversionContext_SetAbsoluteUnits = self.lib.UnitConversionContext_SetAbsoluteUnits 
        UnitConversionContext_SetAbsoluteUnits.argtypes = [POINTER(c_void_p), c_bool]
        UnitConversionContext_SetAbsoluteUnits(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


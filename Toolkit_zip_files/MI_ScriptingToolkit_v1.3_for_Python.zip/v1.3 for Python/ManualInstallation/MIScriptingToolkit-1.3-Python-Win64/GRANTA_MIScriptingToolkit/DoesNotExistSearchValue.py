# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class DoesNotExistSearchValue(object):
    """DoesNotExistSearchValue. Search criterion to search for attributes with no data. 
All attribute types supported.
    
    """
    
    def __init__(self, isOwner=True):
        """
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            DoesNotExistSearchValue_Create = self.lib.DoesNotExistSearchValue_Create
            DoesNotExistSearchValue_Create.restype = POINTER(c_void_p)
            self.c_obj = DoesNotExistSearchValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            DoesNotExistSearchValue_Destroy = self.lib.DoesNotExistSearchValue_Destroy
            DoesNotExistSearchValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            DoesNotExistSearchValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


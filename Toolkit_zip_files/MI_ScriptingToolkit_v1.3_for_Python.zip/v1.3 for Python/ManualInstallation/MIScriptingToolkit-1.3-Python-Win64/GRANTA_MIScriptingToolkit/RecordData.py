# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.AttributeValue import AttributeValue


class RecordData(object):
    """RecordData. The values of data for attribute(s) of a particular record.
    
        Arguments:
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * attributeValues - type list of :py:mod:`AttributeValue <GRANTA_MIScriptingToolkit.AttributeValue>` objects


    """
    
    def __init__(self, recordReference=None, attributeValues=None, isOwner=True):
        """

        Arguments:
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * attributeValues - type list of :py:mod:`AttributeValue <GRANTA_MIScriptingToolkit.AttributeValue>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordData_Create = self.lib.RecordData_Create
            RecordData_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordData_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordReference is not None:
            self.recordReference = recordReference
        if attributeValues is not None:
            self.attributeValues = attributeValues


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordData_Destroy = self.lib.RecordData_Destroy
            RecordData_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordData_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordReference(self):
        """Property recordReference is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._recordReference = self.__GetRecordReference()
        return self._recordReference

    @recordReference.setter
    def recordReference(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('recordReference','recordReference: Invalid type recordReference must be of type RecordReference')
        
        self._recordReference = value

    @property
    def attributeValues(self):
        """Property attributeValues is a list of :py:mod:`AttributeValue <GRANTA_MIScriptingToolkit.AttributeValue>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeValues = self.__GetAttributeValues()
        except:
            pass
        return self._attributeValues

    @attributeValues.setter
    def attributeValues(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeValues','attributeValues: Invalid type attributeValues must be a list of AttributeValue')
        
        self._attributeValues = value

    def __GetRecordReference(self):
        _recordReference = RecordReference()
        RecordData_GetRecordReference = self.lib.RecordData_GetRecordReference
        RecordData_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordData_GetRecordReference(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __GetNumberOfAttributeValues(self):
        RecordData_GetNumberOfAttributeValues = self.lib.RecordData_GetNumberOfAttributeValues
        RecordData_GetNumberOfAttributeValues.argtypes = [POINTER(c_void_p)]
        RecordData_GetNumberOfAttributeValues.restype = c_int
        value = RecordData_GetNumberOfAttributeValues(self._c_obj)
        return value
    
    def __GetAttributeValuesElement(self,i):
        value = AttributeValue()
        RecordData_GetAttributeValues = self.lib.RecordData_GetAttributeValues
        RecordData_GetAttributeValues.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordData_GetAttributeValues(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributeValues(self):
         n = self.__GetNumberOfAttributeValues();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeValuesElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class TargetedSourceRecord(object):
    """TargetedSourceRecord. A type for unlinking records, contains a source :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` and an array of target :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.
    
        Arguments:
                * sourceRecord - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * targetRecords - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects


    """
    
    def __init__(self, sourceRecord=None, targetRecords=None, isOwner=True):
        """

        Arguments:
                * sourceRecord - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * targetRecords - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            TargetedSourceRecord_Create = self.lib.TargetedSourceRecord_Create
            TargetedSourceRecord_Create.restype = POINTER(c_void_p)
            self.c_obj = TargetedSourceRecord_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if sourceRecord is not None:
            self.sourceRecord = sourceRecord
        if targetRecords is not None:
            self.targetRecords = targetRecords


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            TargetedSourceRecord_Destroy = self.lib.TargetedSourceRecord_Destroy
            TargetedSourceRecord_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            TargetedSourceRecord_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def sourceRecord(self):
        """Property sourceRecord is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._sourceRecord = self.__GetSourceRecord()
        return self._sourceRecord

    @sourceRecord.setter
    def sourceRecord(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('sourceRecord','sourceRecord: Invalid type sourceRecord must be of type RecordReference')
        self.__SetSourceRecord(value)
        self._sourceRecord = value

    @property
    def targetRecords(self):
        """Property targetRecords is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._targetRecords = self.__GetTargetRecords()
        except:
            pass
        return self._targetRecords

    @targetRecords.setter
    def targetRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('targetRecords','targetRecords: Invalid type targetRecords must be a list of RecordReference')
                
        try:
            self.__updatetargetRecords = True
            self.__ClearTargetRecords()
            for v in value:
                self.AddTargetRecord(v)
        except:
            pass


    def AddTargetRecord(self, _recordReference):
        """Appends _recordReference to targetRecords property on TargetedSourceRecord C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('TargetedSourceRecord.AddTargetRecord','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        TargetedSourceRecord_AddTargetRecord = self.lib.TargetedSourceRecord_AddTargetRecord
        TargetedSourceRecord_AddTargetRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        TargetedSourceRecord_AddTargetRecord(self._c_obj, _recordReference.c_obj)
        return self

    def __ClearTargetRecords(self):
        TargetedSourceRecord_ClearTargetRecords = self.lib.TargetedSourceRecord_ClearTargetRecords
        TargetedSourceRecord_ClearTargetRecords.argtypes = [POINTER(c_void_p)]
        TargetedSourceRecord_ClearTargetRecords(self._c_obj)
        return self

    def __GetSourceRecord(self):
        _recordReference = RecordReference()
        TargetedSourceRecord_GetSourceRecord = self.lib.TargetedSourceRecord_GetSourceRecord
        TargetedSourceRecord_GetSourceRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        TargetedSourceRecord_GetSourceRecord(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __SetSourceRecord(self, value):

        TargetedSourceRecord_SetSourceRecord = self.lib.TargetedSourceRecord_SetSourceRecord 
        TargetedSourceRecord_SetSourceRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        TargetedSourceRecord_SetSourceRecord(self._c_obj, value.c_obj)

    def __GetNumberOfTargetRecords(self):
        TargetedSourceRecord_GetNumberOfTargetRecords = self.lib.TargetedSourceRecord_GetNumberOfTargetRecords
        TargetedSourceRecord_GetNumberOfTargetRecords.argtypes = [POINTER(c_void_p)]
        TargetedSourceRecord_GetNumberOfTargetRecords.restype = c_int
        value = TargetedSourceRecord_GetNumberOfTargetRecords(self._c_obj)
        return value
    
    def __GetTargetRecordsElement(self,i):
        value = RecordReference()
        TargetedSourceRecord_GetTargetRecords = self.lib.TargetedSourceRecord_GetTargetRecords
        TargetedSourceRecord_GetTargetRecords.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        TargetedSourceRecord_GetTargetRecords(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetTargetRecords(self):
         n = self.__GetNumberOfTargetRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetTargetRecordsElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


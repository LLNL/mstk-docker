# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference
from GRANTA_MIScriptingToolkit.RangeDataType import RangeDataType
from GRANTA_MIScriptingToolkit.PointDataType import PointDataType
from GRANTA_MIScriptingToolkit.FloatFunctionalSeriesDataType import FloatFunctionalSeriesDataType
from GRANTA_MIScriptingToolkit.FloatFunctionalGriddedDataType import FloatFunctionalGriddedDataType
from GRANTA_MIScriptingToolkit.ShortTextDataType import ShortTextDataType
from GRANTA_MIScriptingToolkit.LongTextDataType import LongTextDataType
from GRANTA_MIScriptingToolkit.DiscreteDataType import DiscreteDataType
from GRANTA_MIScriptingToolkit.IntegerDataType import IntegerDataType
from GRANTA_MIScriptingToolkit.LogicalDataType import LogicalDataType
from GRANTA_MIScriptingToolkit.HyperlinkDataType import HyperlinkDataType
from GRANTA_MIScriptingToolkit.FileDataType import FileDataType
from GRANTA_MIScriptingToolkit.TabularDataType import TabularDataType
from GRANTA_MIScriptingToolkit.DateDataType import DateDataType


class ImportAttributeValue(object):
    """ImportAttributeValue. An :py:mod:`AttributeValue <GRANTA_MIScriptingToolkit.AttributeValue>` to import to a GRANTA MI database.
Requires a :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` and an attribute value for the data type you 
wish to upload. Supports: PointDataType, RangeDataType, 
FloatFunctionalSeriesDataType, FloatFunctionalGriddedDataType,  ShortTextDataType, 
LongTextDataType,  DiscreteDataType, IntegerDataType,  LogicalDataType, HyperLinkDataType, and :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`.
    
        Arguments:
                * rangeDataValue - type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`
                * discreteDataValue - type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`
                * hyperlinkDataValue - type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`
                * fileDataValue - type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`
                * floatFunctionalGriddedDataType - type :py:mod:`FloatFunctionalGriddedDataType <GRANTA_MIScriptingToolkit.FloatFunctionalGriddedDataType>`
                * shortTextDataValue - type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`
                * integerDataValue - type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`
                * pointDataValue - type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`
                * logicalDataValue - type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`
                * longTextDataValue - type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`
                * dateDataValue - type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`
                * floatFunctionalSeriesDataType - type :py:mod:`FloatFunctionalSeriesDataType <GRANTA_MIScriptingToolkit.FloatFunctionalSeriesDataType>`
                * attributeReference - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * tabularDataValue - type :py:mod:`TabularDataType <GRANTA_MIScriptingToolkit.TabularDataType>`


    """
    
    def __init__(self, rangeDataValue=None, discreteDataValue=None, hyperlinkDataValue=None, fileDataValue=None, floatFunctionalGriddedDataType=None, shortTextDataValue=None, integerDataValue=None, pointDataValue=None, logicalDataValue=None, longTextDataValue=None, dateDataValue=None, floatFunctionalSeriesDataType=None, attributeReference=None, tabularDataValue=None, isOwner=True):
        """

        Arguments:
                * rangeDataValue - type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`
                * discreteDataValue - type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`
                * hyperlinkDataValue - type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`
                * fileDataValue - type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`
                * floatFunctionalGriddedDataType - type :py:mod:`FloatFunctionalGriddedDataType <GRANTA_MIScriptingToolkit.FloatFunctionalGriddedDataType>`
                * shortTextDataValue - type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`
                * integerDataValue - type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`
                * pointDataValue - type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`
                * logicalDataValue - type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`
                * longTextDataValue - type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`
                * dateDataValue - type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`
                * floatFunctionalSeriesDataType - type :py:mod:`FloatFunctionalSeriesDataType <GRANTA_MIScriptingToolkit.FloatFunctionalSeriesDataType>`
                * attributeReference - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * tabularDataValue - type :py:mod:`TabularDataType <GRANTA_MIScriptingToolkit.TabularDataType>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ImportAttributeValue_Create = self.lib.ImportAttributeValue_Create
            ImportAttributeValue_Create.restype = POINTER(c_void_p)
            self.c_obj = ImportAttributeValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if rangeDataValue is not None:
            self.rangeDataValue = rangeDataValue
        if discreteDataValue is not None:
            self.discreteDataValue = discreteDataValue
        if hyperlinkDataValue is not None:
            self.hyperlinkDataValue = hyperlinkDataValue
        if fileDataValue is not None:
            self.fileDataValue = fileDataValue
        if floatFunctionalGriddedDataType is not None:
            self.floatFunctionalGriddedDataType = floatFunctionalGriddedDataType
        if shortTextDataValue is not None:
            self.shortTextDataValue = shortTextDataValue
        if integerDataValue is not None:
            self.integerDataValue = integerDataValue
        if pointDataValue is not None:
            self.pointDataValue = pointDataValue
        if logicalDataValue is not None:
            self.logicalDataValue = logicalDataValue
        if longTextDataValue is not None:
            self.longTextDataValue = longTextDataValue
        if dateDataValue is not None:
            self.dateDataValue = dateDataValue
        if floatFunctionalSeriesDataType is not None:
            self.floatFunctionalSeriesDataType = floatFunctionalSeriesDataType
        if attributeReference is not None:
            self.attributeReference = attributeReference
        if tabularDataValue is not None:
            self.tabularDataValue = tabularDataValue


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ImportAttributeValue_Destroy = self.lib.ImportAttributeValue_Destroy
            ImportAttributeValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ImportAttributeValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def rangeDataValue(self):
        """Property rangeDataValue is of type :py:mod:`RangeDataType <GRANTA_MIScriptingToolkit.RangeDataType>`. """ 
        try:
            return self._rangeDataValue
        except:
            return None

    @rangeDataValue.setter
    def rangeDataValue(self, value):
        if not isinstance(value, RangeDataType):
            raise GRANTA_Exception('rangeDataValue','rangeDataValue: Invalid type rangeDataValue must be of type RangeDataType')
        self.__SetRangeDataValue(value)
        self._rangeDataValue = value

    @property
    def discreteDataValue(self):
        """Property discreteDataValue is of type :py:mod:`DiscreteDataType <GRANTA_MIScriptingToolkit.DiscreteDataType>`. """ 
        try:
            return self._discreteDataValue
        except:
            return None

    @discreteDataValue.setter
    def discreteDataValue(self, value):
        if not isinstance(value, DiscreteDataType):
            raise GRANTA_Exception('discreteDataValue','discreteDataValue: Invalid type discreteDataValue must be of type DiscreteDataType')
        self.__SetDiscreteDataValue(value)
        self._discreteDataValue = value

    @property
    def hyperlinkDataValue(self):
        """Property hyperlinkDataValue is of type :py:mod:`HyperlinkDataType <GRANTA_MIScriptingToolkit.HyperlinkDataType>`. """ 
        try:
            return self._hyperlinkDataValue
        except:
            return None

    @hyperlinkDataValue.setter
    def hyperlinkDataValue(self, value):
        if not isinstance(value, HyperlinkDataType):
            raise GRANTA_Exception('hyperlinkDataValue','hyperlinkDataValue: Invalid type hyperlinkDataValue must be of type HyperlinkDataType')
        self.__SetHyperlinkDataValue(value)
        self._hyperlinkDataValue = value

    @property
    def fileDataValue(self):
        """Property fileDataValue is of type :py:mod:`FileDataType <GRANTA_MIScriptingToolkit.FileDataType>`. """ 
        try:
            return self._fileDataValue
        except:
            return None

    @fileDataValue.setter
    def fileDataValue(self, value):
        if not isinstance(value, FileDataType):
            raise GRANTA_Exception('fileDataValue','fileDataValue: Invalid type fileDataValue must be of type FileDataType')
        self.__SetFileDataValue(value)
        self._fileDataValue = value

    @property
    def floatFunctionalGriddedDataType(self):
        """Property floatFunctionalGriddedDataType is of type :py:mod:`FloatFunctionalGriddedDataType <GRANTA_MIScriptingToolkit.FloatFunctionalGriddedDataType>`. """ 
        try:
            return self._floatFunctionalGriddedDataType
        except:
            return None

    @floatFunctionalGriddedDataType.setter
    def floatFunctionalGriddedDataType(self, value):
        if not isinstance(value, FloatFunctionalGriddedDataType):
            raise GRANTA_Exception('floatFunctionalGriddedDataType','floatFunctionalGriddedDataType: Invalid type floatFunctionalGriddedDataType must be of type FloatFunctionalGriddedDataType')
        self.__SetFloatFunctionalGriddedDataType(value)
        self._floatFunctionalGriddedDataType = value

    @property
    def shortTextDataValue(self):
        """Property shortTextDataValue is of type :py:mod:`ShortTextDataType <GRANTA_MIScriptingToolkit.ShortTextDataType>`. """ 
        try:
            return self._shortTextDataValue
        except:
            return None

    @shortTextDataValue.setter
    def shortTextDataValue(self, value):
        if not isinstance(value, ShortTextDataType):
            raise GRANTA_Exception('shortTextDataValue','shortTextDataValue: Invalid type shortTextDataValue must be of type ShortTextDataType')
        self.__SetShortTextDataValue(value)
        self._shortTextDataValue = value

    @property
    def integerDataValue(self):
        """Property integerDataValue is of type :py:mod:`IntegerDataType <GRANTA_MIScriptingToolkit.IntegerDataType>`. """ 
        try:
            return self._integerDataValue
        except:
            return None

    @integerDataValue.setter
    def integerDataValue(self, value):
        if not isinstance(value, IntegerDataType):
            raise GRANTA_Exception('integerDataValue','integerDataValue: Invalid type integerDataValue must be of type IntegerDataType')
        self.__SetIntegerDataValue(value)
        self._integerDataValue = value

    @property
    def pointDataValue(self):
        """Property pointDataValue is of type :py:mod:`PointDataType <GRANTA_MIScriptingToolkit.PointDataType>`. """ 
        try:
            return self._pointDataValue
        except:
            return None

    @pointDataValue.setter
    def pointDataValue(self, value):
        if not isinstance(value, PointDataType):
            raise GRANTA_Exception('pointDataValue','pointDataValue: Invalid type pointDataValue must be of type PointDataType')
        self.__SetPointDataValue(value)
        self._pointDataValue = value

    @property
    def logicalDataValue(self):
        """Property logicalDataValue is of type :py:mod:`LogicalDataType <GRANTA_MIScriptingToolkit.LogicalDataType>`. """ 
        try:
            return self._logicalDataValue
        except:
            return None

    @logicalDataValue.setter
    def logicalDataValue(self, value):
        if not isinstance(value, LogicalDataType):
            raise GRANTA_Exception('logicalDataValue','logicalDataValue: Invalid type logicalDataValue must be of type LogicalDataType')
        self.__SetLogicalDataValue(value)
        self._logicalDataValue = value

    @property
    def longTextDataValue(self):
        """Property longTextDataValue is of type :py:mod:`LongTextDataType <GRANTA_MIScriptingToolkit.LongTextDataType>`. """ 
        try:
            return self._longTextDataValue
        except:
            return None

    @longTextDataValue.setter
    def longTextDataValue(self, value):
        if not isinstance(value, LongTextDataType):
            raise GRANTA_Exception('longTextDataValue','longTextDataValue: Invalid type longTextDataValue must be of type LongTextDataType')
        self.__SetLongTextDataValue(value)
        self._longTextDataValue = value

    @property
    def dateDataValue(self):
        """Property dateDataValue is of type :py:mod:`DateDataType <GRANTA_MIScriptingToolkit.DateDataType>`. """ 
        try:
            return self._dateDataValue
        except:
            return None

    @dateDataValue.setter
    def dateDataValue(self, value):
        if not isinstance(value, DateDataType):
            raise GRANTA_Exception('dateDataValue','dateDataValue: Invalid type dateDataValue must be of type DateDataType')
        self.__SetDateDataValue(value)
        self._dateDataValue = value

    @property
    def floatFunctionalSeriesDataType(self):
        """Property floatFunctionalSeriesDataType is of type :py:mod:`FloatFunctionalSeriesDataType <GRANTA_MIScriptingToolkit.FloatFunctionalSeriesDataType>`. """ 
        try:
            return self._floatFunctionalSeriesDataType
        except:
            return None

    @floatFunctionalSeriesDataType.setter
    def floatFunctionalSeriesDataType(self, value):
        if not isinstance(value, FloatFunctionalSeriesDataType):
            raise GRANTA_Exception('floatFunctionalSeriesDataType','floatFunctionalSeriesDataType: Invalid type floatFunctionalSeriesDataType must be of type FloatFunctionalSeriesDataType')
        self.__SetFloatFunctionalSeriesDataType(value)
        self._floatFunctionalSeriesDataType = value

    @property
    def attributeReference(self):
        """Property attributeReference is of type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`. """ 
        try:
            return self._attributeReference
        except:
            return None

    @attributeReference.setter
    def attributeReference(self, value):
        if not isinstance(value, AttributeReference):
            raise GRANTA_Exception('attributeReference','attributeReference: Invalid type attributeReference must be of type AttributeReference')
        self.__SetAttributeReference(value)
        self._attributeReference = value

    @property
    def tabularDataValue(self):
        """Property tabularDataValue is of type :py:mod:`TabularDataType <GRANTA_MIScriptingToolkit.TabularDataType>`. """ 
        try:
            return self._tabularDataValue
        except:
            return None

    @tabularDataValue.setter
    def tabularDataValue(self, value):
        if not isinstance(value, TabularDataType):
            raise GRANTA_Exception('tabularDataValue','tabularDataValue: Invalid type tabularDataValue must be of type TabularDataType')
        self.__SetTabularDataValue(value)
        self._tabularDataValue = value

    def __SetAttributeReference(self, value):

        ImportAttributeValue_SetAttributeReference = self.lib.ImportAttributeValue_SetAttributeReference 
        ImportAttributeValue_SetAttributeReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetAttributeReference(self._c_obj, value.c_obj)

    def __SetRangeDataValue(self, value):

        ImportAttributeValue_SetRangeDataValue = self.lib.ImportAttributeValue_SetRangeDataValue 
        ImportAttributeValue_SetRangeDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetRangeDataValue(self._c_obj, value.c_obj)

    def __SetPointDataValue(self, value):

        ImportAttributeValue_SetPointDataValue = self.lib.ImportAttributeValue_SetPointDataValue 
        ImportAttributeValue_SetPointDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetPointDataValue(self._c_obj, value.c_obj)

    def __SetFloatFunctionalSeriesDataType(self, value):

        ImportAttributeValue_SetFloatFunctionalSeriesDataType = self.lib.ImportAttributeValue_SetFloatFunctionalSeriesDataType 
        ImportAttributeValue_SetFloatFunctionalSeriesDataType.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetFloatFunctionalSeriesDataType(self._c_obj, value.c_obj)

    def __SetFloatFunctionalGriddedDataType(self, value):

        ImportAttributeValue_SetFloatFunctionalGriddedDataType = self.lib.ImportAttributeValue_SetFloatFunctionalGriddedDataType 
        ImportAttributeValue_SetFloatFunctionalGriddedDataType.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetFloatFunctionalGriddedDataType(self._c_obj, value.c_obj)

    def __SetShortTextDataValue(self, value):

        ImportAttributeValue_SetShortTextDataValue = self.lib.ImportAttributeValue_SetShortTextDataValue 
        ImportAttributeValue_SetShortTextDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetShortTextDataValue(self._c_obj, value.c_obj)

    def __SetLongTextDataValue(self, value):

        ImportAttributeValue_SetLongTextDataValue = self.lib.ImportAttributeValue_SetLongTextDataValue 
        ImportAttributeValue_SetLongTextDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetLongTextDataValue(self._c_obj, value.c_obj)

    def __SetDiscreteDataValue(self, value):

        ImportAttributeValue_SetDiscreteDataValue = self.lib.ImportAttributeValue_SetDiscreteDataValue 
        ImportAttributeValue_SetDiscreteDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetDiscreteDataValue(self._c_obj, value.c_obj)

    def __SetIntegerDataValue(self, value):

        ImportAttributeValue_SetIntegerDataValue = self.lib.ImportAttributeValue_SetIntegerDataValue 
        ImportAttributeValue_SetIntegerDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetIntegerDataValue(self._c_obj, value.c_obj)

    def __SetLogicalDataValue(self, value):

        ImportAttributeValue_SetLogicalDataValue = self.lib.ImportAttributeValue_SetLogicalDataValue 
        ImportAttributeValue_SetLogicalDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetLogicalDataValue(self._c_obj, value.c_obj)

    def __SetHyperlinkDataValue(self, value):

        ImportAttributeValue_SetHyperlinkDataValue = self.lib.ImportAttributeValue_SetHyperlinkDataValue 
        ImportAttributeValue_SetHyperlinkDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetHyperlinkDataValue(self._c_obj, value.c_obj)

    def __SetFileDataValue(self, value):

        ImportAttributeValue_SetFileDataValue = self.lib.ImportAttributeValue_SetFileDataValue 
        ImportAttributeValue_SetFileDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetFileDataValue(self._c_obj, value.c_obj)

    def __SetTabularDataValue(self, value):

        ImportAttributeValue_SetTabularDataValue = self.lib.ImportAttributeValue_SetTabularDataValue 
        ImportAttributeValue_SetTabularDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetTabularDataValue(self._c_obj, value.c_obj)

    def __SetDateDataValue(self, value):

        ImportAttributeValue_SetDateDataValue = self.lib.ImportAttributeValue_SetDateDataValue 
        ImportAttributeValue_SetDateDataValue.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ImportAttributeValue_SetDateDataValue(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


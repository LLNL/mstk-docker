import time
import GRANTA_MIScriptingToolkit.GRANTA_libs as GRANTA_libs
from ctypes import c_char_p, POINTER, c_bool, c_double, c_void_p, c_int
from GRANTA_MIScriptingToolkit.GRANTA_Logging import GRANTA_Logging
from GRANTA_MIScriptingToolkit.Service import Service
from GRANTA_MIScriptingToolkit.GRANTA_Exceptions import GRANTA_Exception
from GRANTA_MIScriptingToolkit.GetAvailableExportersRequest import GetAvailableExportersRequest
from GRANTA_MIScriptingToolkit.GetAvailableExportersResponse import GetAvailableExportersResponse
from GRANTA_MIScriptingToolkit.ExportRecordDataRequest import ExportRecordDataRequest
from GRANTA_MIScriptingToolkit.ExportRecordDataResponse import ExportRecordDataResponse
from GRANTA_MIScriptingToolkit.ExportersForRecordsRequest import ExportersForRecordsRequest
from GRANTA_MIScriptingToolkit.ExportersForRecordsResponse import ExportersForRecordsResponse
from GRANTA_MIScriptingToolkit.GetExporterParametersRequest import GetExporterParametersRequest
from GRANTA_MIScriptingToolkit.GetExporterParametersResponse import GetExporterParametersResponse

# This file was automatically generated
class EngineeringDataService(Service):
    """The EngineeringData service provides custom data export operations for a GRANTA MI Server."""

    def __init__(self, mi_session):
        """Initialize a EngineeringDataService object
                Arguments:
                    mi_session - MI_Session object
        """
        self.mi_session = mi_session
        self.lib = GRANTA_libs.MIServiceLayerCAPILib

    def GetAvailableExporters(self, _req):
        """Returns the FEA Exporter configurations known to the MI Server, optionally filtering for their applicability to particular situations.

        Arguments:
            _req - :py:mod:`GetAvailableExportersRequest <GRANTA_MIScriptingToolkit.GetAvailableExportersRequest>` object
        Returns:
            :py:mod:`GetAvailableExportersResponse <GRANTA_MIScriptingToolkit.GetAvailableExportersResponse>` object
        
        """
        if not isinstance(_req, GetAvailableExportersRequest):
            raise GRANTA_Exception('EngineeringData.GetAvailableExporters','EngineeringData.GetAvailableExporters(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetAvailableExportersRequest')

        startTime = time.clock()
        func = self.lib.EngineeringData_GetAvailableExporters
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetAvailableExportersResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran EngineeringData.GetAvailableExporters() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'EngineeringData.GetAvailableExporters')
        return response

    def ExportRecordData(self, _req):
        """Performs an FEA Export and returns the result as the response.

        Arguments:
            _req - :py:mod:`ExportRecordDataRequest <GRANTA_MIScriptingToolkit.ExportRecordDataRequest>` object
        Returns:
            :py:mod:`ExportRecordDataResponse <GRANTA_MIScriptingToolkit.ExportRecordDataResponse>` object
        
        """
        if not isinstance(_req, ExportRecordDataRequest):
            raise GRANTA_Exception('EngineeringData.ExportRecordData','EngineeringData.ExportRecordData(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.ExportRecordDataRequest')

        startTime = time.clock()
        func = self.lib.EngineeringData_ExportRecordData
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = ExportRecordDataResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran EngineeringData.ExportRecordData() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'EngineeringData.ExportRecordData')
        return response

    def ExportersForRecords(self, _req):
        """Returns the FEA Exporter configurations, known to the MI:Server, filtering for their applicability to given Record(s) and optionally to particular situations.

        Arguments:
            _req - :py:mod:`ExportersForRecordsRequest <GRANTA_MIScriptingToolkit.ExportersForRecordsRequest>` object
        Returns:
            :py:mod:`ExportersForRecordsResponse <GRANTA_MIScriptingToolkit.ExportersForRecordsResponse>` object
        
        """
        if not isinstance(_req, ExportersForRecordsRequest):
            raise GRANTA_Exception('EngineeringData.ExportersForRecords','EngineeringData.ExportersForRecords(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.ExportersForRecordsRequest')

        startTime = time.clock()
        func = self.lib.EngineeringData_ExportersForRecords
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = ExportersForRecordsResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran EngineeringData.ExportersForRecords() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'EngineeringData.ExportersForRecords')
        return response

    def GetExporterParameters(self, _req):
        """Returns information about the MI Parameter Values that will need to be chosen, to run the specified Exporter on the specified Record(s).

        Arguments:
            _req - :py:mod:`GetExporterParametersRequest <GRANTA_MIScriptingToolkit.GetExporterParametersRequest>` object
        Returns:
            :py:mod:`GetExporterParametersResponse <GRANTA_MIScriptingToolkit.GetExporterParametersResponse>` object
        
        """
        if not isinstance(_req, GetExporterParametersRequest):
            raise GRANTA_Exception('EngineeringData.GetExporterParameters','EngineeringData.GetExporterParameters(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.GetExporterParametersRequest')

        startTime = time.clock()
        func = self.lib.EngineeringData_GetExporterParameters
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = GetExporterParametersResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran EngineeringData.GetExporterParameters() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'EngineeringData.GetExporterParameters')
        return response


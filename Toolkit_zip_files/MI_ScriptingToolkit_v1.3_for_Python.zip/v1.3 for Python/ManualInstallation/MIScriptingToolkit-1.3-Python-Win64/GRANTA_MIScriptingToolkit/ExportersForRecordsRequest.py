# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class ExportersForRecordsRequest(object):
    """ExportersForRecordsRequest. Input for the ExportersForRecords operation.
    
        Arguments:
                * specificAttributeExportersOnly - type bool
                * package - type str
                * packageAndModelRequired - type bool
                * versionPolicy - type int
                * records - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * model - type str
                * applicabilityTag - type str


    """
    
    def __init__(self, specificAttributeExportersOnly=None, package=None, packageAndModelRequired=None, versionPolicy=None, records=None, model=None, applicabilityTag=None, isOwner=True):
        """

        Arguments:
                * specificAttributeExportersOnly - type bool
                * package - type str
                * packageAndModelRequired - type bool
                * versionPolicy - type int
                * records - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * model - type str
                * applicabilityTag - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ExportersForRecordsRequest_Create = self.lib.ExportersForRecordsRequest_Create
            ExportersForRecordsRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = ExportersForRecordsRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if specificAttributeExportersOnly is not None:
            self.specificAttributeExportersOnly = specificAttributeExportersOnly
        if package is not None:
            self.package = package
        if packageAndModelRequired is not None:
            self.packageAndModelRequired = packageAndModelRequired
        if versionPolicy is not None:
            self.versionPolicy = versionPolicy
        if records is not None:
            self.records = records
        if model is not None:
            self.model = model
        if applicabilityTag is not None:
            self.applicabilityTag = applicabilityTag


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ExportersForRecordsRequest_Destroy = self.lib.ExportersForRecordsRequest_Destroy
            ExportersForRecordsRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ExportersForRecordsRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def specificAttributeExportersOnly(self):
        """Property specificAttributeExportersOnly is of type bool. """ 
        self._specificAttributeExportersOnly = self.__GetSpecificAttributeExportersOnly()
        return self._specificAttributeExportersOnly

    @specificAttributeExportersOnly.setter
    def specificAttributeExportersOnly(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('specificAttributeExportersOnly','specificAttributeExportersOnly: Invalid type specificAttributeExportersOnly must be of type bool')
        self.__SetSpecificAttributeExportersOnly(value)
        self._specificAttributeExportersOnly = value

    @property
    def package(self):
        """Property package is of type str. """ 
        self._package = self.__GetPackage()
        return self._package

    @package.setter
    def package(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('package','package: Invalid type package must be of type str')
        self.__SetPackage(value)
        self._package = value

    @property
    def packageAndModelRequired(self):
        """Property packageAndModelRequired is of type bool. """ 
        self._packageAndModelRequired = self.__GetPackageAndModelRequired()
        return self._packageAndModelRequired

    @packageAndModelRequired.setter
    def packageAndModelRequired(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('packageAndModelRequired','packageAndModelRequired: Invalid type packageAndModelRequired must be of type bool')
        self.__SetPackageAndModelRequired(value)
        self._packageAndModelRequired = value

    @property
    def versionPolicy(self):
        """Property versionPolicy is of type int. See :py:class:`GRANTA_Constants.VersionPolicy <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values.""" 
        self._versionPolicy = self.__GetVersionPolicy()
        return self._versionPolicy

    @versionPolicy.setter
    def versionPolicy(self, value):
        """See :py:class:`GRANTA_Constants.VersionPolicy <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""
        if not isinstance(value, int):
            raise GRANTA_Exception('versionPolicy','versionPolicy: Invalid type versionPolicy must be of type int')
        self.__SetVersionPolicy(value)
        self._versionPolicy = value

    @property
    def records(self):
        """Property records is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._records = self.__GetRecords()
        except:
            pass
        return self._records

    @records.setter
    def records(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('records','records: Invalid type records must be a list of RecordReference')
                
        try:
            self.__updaterecords = True
            self.__ClearRecords()
            for v in value:
                self.AddRecord(v)
        except:
            pass


    @property
    def model(self):
        """Property model is of type str. """ 
        self._model = self.__GetModel()
        return self._model

    @model.setter
    def model(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('model','model: Invalid type model must be of type str')
        self.__SetModel(value)
        self._model = value

    @property
    def applicabilityTag(self):
        """Property applicabilityTag is of type str. """ 
        self._applicabilityTag = self.__GetApplicabilityTag()
        return self._applicabilityTag

    @applicabilityTag.setter
    def applicabilityTag(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('applicabilityTag','applicabilityTag: Invalid type applicabilityTag must be of type str')
        self.__SetApplicabilityTag(value)
        self._applicabilityTag = value

    def __SetPackage(self, value):

        ExportersForRecordsRequest_SetPackage = self.lib.ExportersForRecordsRequest_SetPackage 
        ExportersForRecordsRequest_SetPackage.argtypes = [POINTER(c_void_p), c_char_p]
        ExportersForRecordsRequest_SetPackage(self._c_obj, EnsureEncoded(value))

    def __GetPackage(self):
        ExportersForRecordsRequest_GetPackage = self.lib.ExportersForRecordsRequest_GetPackage
        ExportersForRecordsRequest_GetPackage.argtypes = [POINTER(c_void_p)]
        ExportersForRecordsRequest_GetPackage.restype = POINTER(c_void_p)
        value = ExportersForRecordsRequest_GetPackage(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetModel(self):
        ExportersForRecordsRequest_GetModel = self.lib.ExportersForRecordsRequest_GetModel
        ExportersForRecordsRequest_GetModel.argtypes = [POINTER(c_void_p)]
        ExportersForRecordsRequest_GetModel.restype = POINTER(c_void_p)
        value = ExportersForRecordsRequest_GetModel(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetModel(self, value):

        ExportersForRecordsRequest_SetModel = self.lib.ExportersForRecordsRequest_SetModel 
        ExportersForRecordsRequest_SetModel.argtypes = [POINTER(c_void_p), c_char_p]
        ExportersForRecordsRequest_SetModel(self._c_obj, EnsureEncoded(value))

    def __GetVersionPolicy(self):
        ExportersForRecordsRequest_GetVersionPolicy = self.lib.ExportersForRecordsRequest_GetVersionPolicy
        ExportersForRecordsRequest_GetVersionPolicy.argtypes = [POINTER(c_void_p)]
        ExportersForRecordsRequest_GetVersionPolicy.restype = c_int
        value = ExportersForRecordsRequest_GetVersionPolicy(self._c_obj)
        return value
    
    def __SetVersionPolicy(self, value):
        """See :py:class:`GRANTA_Constants.VersionPolicy <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values."""

        ExportersForRecordsRequest_SetVersionPolicy = self.lib.ExportersForRecordsRequest_SetVersionPolicy 
        ExportersForRecordsRequest_SetVersionPolicy.argtypes = [POINTER(c_void_p), c_int]
        ExportersForRecordsRequest_SetVersionPolicy(self._c_obj, value)

    def __GetApplicabilityTag(self):
        ExportersForRecordsRequest_GetApplicabilityTag = self.lib.ExportersForRecordsRequest_GetApplicabilityTag
        ExportersForRecordsRequest_GetApplicabilityTag.argtypes = [POINTER(c_void_p)]
        ExportersForRecordsRequest_GetApplicabilityTag.restype = POINTER(c_void_p)
        value = ExportersForRecordsRequest_GetApplicabilityTag(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetApplicabilityTag(self, value):

        ExportersForRecordsRequest_SetApplicabilityTag = self.lib.ExportersForRecordsRequest_SetApplicabilityTag 
        ExportersForRecordsRequest_SetApplicabilityTag.argtypes = [POINTER(c_void_p), c_char_p]
        ExportersForRecordsRequest_SetApplicabilityTag(self._c_obj, EnsureEncoded(value))

    def __GetPackageAndModelRequired(self):
        ExportersForRecordsRequest_GetPackageAndModelRequired = self.lib.ExportersForRecordsRequest_GetPackageAndModelRequired
        ExportersForRecordsRequest_GetPackageAndModelRequired.argtypes = [POINTER(c_void_p)]
        ExportersForRecordsRequest_GetPackageAndModelRequired.restype = c_bool
        value = ExportersForRecordsRequest_GetPackageAndModelRequired(self._c_obj)
        return value
    
    def __SetPackageAndModelRequired(self, value):

        ExportersForRecordsRequest_SetPackageAndModelRequired = self.lib.ExportersForRecordsRequest_SetPackageAndModelRequired 
        ExportersForRecordsRequest_SetPackageAndModelRequired.argtypes = [POINTER(c_void_p), c_bool]
        ExportersForRecordsRequest_SetPackageAndModelRequired(self._c_obj, value)

    def __GetSpecificAttributeExportersOnly(self):
        ExportersForRecordsRequest_GetSpecificAttributeExportersOnly = self.lib.ExportersForRecordsRequest_GetSpecificAttributeExportersOnly
        ExportersForRecordsRequest_GetSpecificAttributeExportersOnly.argtypes = [POINTER(c_void_p)]
        ExportersForRecordsRequest_GetSpecificAttributeExportersOnly.restype = c_bool
        value = ExportersForRecordsRequest_GetSpecificAttributeExportersOnly(self._c_obj)
        return value
    
    def __SetSpecificAttributeExportersOnly(self, value):

        ExportersForRecordsRequest_SetSpecificAttributeExportersOnly = self.lib.ExportersForRecordsRequest_SetSpecificAttributeExportersOnly 
        ExportersForRecordsRequest_SetSpecificAttributeExportersOnly.argtypes = [POINTER(c_void_p), c_bool]
        ExportersForRecordsRequest_SetSpecificAttributeExportersOnly(self._c_obj, value)

    def __GetNumberOfRecords(self):
        ExportersForRecordsRequest_GetNumberOfRecords = self.lib.ExportersForRecordsRequest_GetNumberOfRecords
        ExportersForRecordsRequest_GetNumberOfRecords.argtypes = [POINTER(c_void_p)]
        ExportersForRecordsRequest_GetNumberOfRecords.restype = c_int
        value = ExportersForRecordsRequest_GetNumberOfRecords(self._c_obj)
        return value
    
    def __GetRecordElement(self,i):
        value = RecordReference()
        ExportersForRecordsRequest_GetRecord = self.lib.ExportersForRecordsRequest_GetRecord
        ExportersForRecordsRequest_GetRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        ExportersForRecordsRequest_GetRecord(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecords(self):
         n = self.__GetNumberOfRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordElement(i))
         return temp
    
    def __ClearRecords(self):
        ExportersForRecordsRequest_ClearRecords = self.lib.ExportersForRecordsRequest_ClearRecords
        ExportersForRecordsRequest_ClearRecords.argtypes = [POINTER(c_void_p)]
        ExportersForRecordsRequest_ClearRecords(self._c_obj)
        return self

    def AddRecord(self, _recordReference):
        """Appends _recordReference to records property on ExportersForRecordsRequest C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('ExportersForRecordsRequest.AddRecord','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        ExportersForRecordsRequest_AddRecord = self.lib.ExportersForRecordsRequest_AddRecord
        ExportersForRecordsRequest_AddRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        ExportersForRecordsRequest_AddRecord(self._c_obj, _recordReference.c_obj)
        return self

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


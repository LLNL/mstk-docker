# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class GetRecordVersionsRequest(object):
    """GetRecordVersionsRequest. Input for the GetRecordVersions operation.
    
        Arguments:
                * records - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * versions - type int


    """
    class VersionSelector:
        LatestRead = 0
        Latest = 1
        AllReleased = 2
        All = 3
    
    def __init__(self, records=None, versions=None, isOwner=True):
        """

        Arguments:
                * records - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * versions - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetRecordVersionsRequest_Create = self.lib.GetRecordVersionsRequest_Create
            GetRecordVersionsRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetRecordVersionsRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if records is not None:
            self.records = records
        if versions is not None:
            self.versions = versions


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetRecordVersionsRequest_Destroy = self.lib.GetRecordVersionsRequest_Destroy
            GetRecordVersionsRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetRecordVersionsRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def records(self):
        """Property records is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._records = self.__GetRecords()
        except:
            pass
        return self._records

    @records.setter
    def records(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('records','records: Invalid type records must be a list of RecordReference')
                
        try:
            self.__updaterecords = True
            self.__ClearRecords()
            for v in value:
                self.AddRecord(v)
        except:
            pass


    @property
    def versions(self):
        """Property versions is of type int. """ 
        self._versions = self.__GetVersions()
        return self._versions

    @versions.setter
    def versions(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('versions','versions: Invalid type versions must be of type int')
        self.__SetVersions(value)
        self._versions = value

    def AddRecord(self, _recordReference):
        """Appends _recordReference to records property on GetRecordVersionsRequest C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('GetRecordVersionsRequest.AddRecord','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        GetRecordVersionsRequest_AddRecord = self.lib.GetRecordVersionsRequest_AddRecord
        GetRecordVersionsRequest_AddRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetRecordVersionsRequest_AddRecord(self._c_obj, _recordReference.c_obj)
        return self

    def __ClearRecords(self):
        GetRecordVersionsRequest_ClearRecords = self.lib.GetRecordVersionsRequest_ClearRecords
        GetRecordVersionsRequest_ClearRecords.argtypes = [POINTER(c_void_p)]
        GetRecordVersionsRequest_ClearRecords(self._c_obj)
        return self

    def __GetNumberOfRecords(self):
        GetRecordVersionsRequest_GetNumberOfRecords = self.lib.GetRecordVersionsRequest_GetNumberOfRecords
        GetRecordVersionsRequest_GetNumberOfRecords.argtypes = [POINTER(c_void_p)]
        GetRecordVersionsRequest_GetNumberOfRecords.restype = c_int
        value = GetRecordVersionsRequest_GetNumberOfRecords(self._c_obj)
        return value
    
    def __GetRecordsElement(self,i):
        value = RecordReference()
        GetRecordVersionsRequest_GetRecords = self.lib.GetRecordVersionsRequest_GetRecords
        GetRecordVersionsRequest_GetRecords.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetRecordVersionsRequest_GetRecords(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecords(self):
         n = self.__GetNumberOfRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordsElement(i))
         return temp
    
    def __SetVersions(self, value):

        GetRecordVersionsRequest_SetVersions = self.lib.GetRecordVersionsRequest_SetVersions 
        GetRecordVersionsRequest_SetVersions.argtypes = [POINTER(c_void_p), c_int]
        GetRecordVersionsRequest_SetVersions(self._c_obj, value)

    def __GetVersions(self):
        GetRecordVersionsRequest_GetVersions = self.lib.GetRecordVersionsRequest_GetVersions
        GetRecordVersionsRequest_GetVersions.argtypes = [POINTER(c_void_p)]
        GetRecordVersionsRequest_GetVersions.restype = c_int
        value = GetRecordVersionsRequest_GetVersions(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


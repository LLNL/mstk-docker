# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ParameterInformation import ParameterInformation
from GRANTA_MIScriptingToolkit.Series import Series


class FloatFunctionalSeriesGraph(object):
    """FloatFunctionalSeriesGraph. A type a collection of series which contain the data functional data and parameter information for the graph x-axis.
For requests an XAxisParameter is required.
    
        Arguments:
                * series - type list of :py:mod:`Series <GRANTA_MIScriptingToolkit.Series>` objects
                * XAxisParameter - type :py:mod:`ParameterInformation <GRANTA_MIScriptingToolkit.ParameterInformation>`
                * hideGraph - type bool
                * logarithmicYAxis - type bool


    """
    
    def __init__(self, series=None, XAxisParameter=None, hideGraph=None, logarithmicYAxis=None, isOwner=True):
        """

        Arguments:
                * series - type list of :py:mod:`Series <GRANTA_MIScriptingToolkit.Series>` objects
                * XAxisParameter - type :py:mod:`ParameterInformation <GRANTA_MIScriptingToolkit.ParameterInformation>`
                * hideGraph - type bool
                * logarithmicYAxis - type bool

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            FloatFunctionalSeriesGraph_Create = self.lib.FloatFunctionalSeriesGraph_Create
            FloatFunctionalSeriesGraph_Create.restype = POINTER(c_void_p)
            self.c_obj = FloatFunctionalSeriesGraph_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if series is not None:
            self.series = series
        if XAxisParameter is not None:
            self.XAxisParameter = XAxisParameter
        if hideGraph is not None:
            self.hideGraph = hideGraph
        if logarithmicYAxis is not None:
            self.logarithmicYAxis = logarithmicYAxis


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            FloatFunctionalSeriesGraph_Destroy = self.lib.FloatFunctionalSeriesGraph_Destroy
            FloatFunctionalSeriesGraph_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            FloatFunctionalSeriesGraph_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def series(self):
        """Property series is a list of :py:mod:`Series <GRANTA_MIScriptingToolkit.Series>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._series = self.__GetSeries()
        except:
            pass
        return self._series

    @series.setter
    def series(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('series','series: Invalid type series must be a list of Series')
                
        try:
            self.__updateseries = True
            self.__ClearSeries()
            for v in value:
                self.AddSeries(v)
        except:
            pass


    @property
    def XAxisParameter(self):
        """Property XAxisParameter is of type :py:mod:`ParameterInformation <GRANTA_MIScriptingToolkit.ParameterInformation>`. """ 
        self._XAxisParameter = self.__GetXAxisParameter()
        return self._XAxisParameter

    @XAxisParameter.setter
    def XAxisParameter(self, value):
        if not isinstance(value, ParameterInformation):
            raise GRANTA_Exception('XAxisParameter','XAxisParameter: Invalid type XAxisParameter must be of type ParameterInformation')
        self.__SetXAxisParameter(value)
        self._XAxisParameter = value

    @property
    def hideGraph(self):
        """Property hideGraph is of type bool. """ 
        self._hideGraph = self.__GetHideGraph()
        return self._hideGraph

    @hideGraph.setter
    def hideGraph(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('hideGraph','hideGraph: Invalid type hideGraph must be of type bool')
        self.__SetHideGraph(value)
        self._hideGraph = value

    @property
    def logarithmicYAxis(self):
        """Property logarithmicYAxis is of type bool. """ 
        self._logarithmicYAxis = self.__GetLogarithmicYAxis()
        return self._logarithmicYAxis

    @logarithmicYAxis.setter
    def logarithmicYAxis(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('logarithmicYAxis','logarithmicYAxis: Invalid type logarithmicYAxis must be of type bool')
        self.__SetLogarithmicYAxis(value)
        self._logarithmicYAxis = value

    def __GetXAxisParameter(self):
        _parameterInformation = ParameterInformation()
        FloatFunctionalSeriesGraph_GetXAxisParameter = self.lib.FloatFunctionalSeriesGraph_GetXAxisParameter
        FloatFunctionalSeriesGraph_GetXAxisParameter.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        FloatFunctionalSeriesGraph_GetXAxisParameter(self._c_obj, (_parameterInformation.c_obj))
        
        return _parameterInformation
        
    def __SetXAxisParameter(self, value):

        FloatFunctionalSeriesGraph_SetXAxisParameter = self.lib.FloatFunctionalSeriesGraph_SetXAxisParameter 
        FloatFunctionalSeriesGraph_SetXAxisParameter.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalSeriesGraph_SetXAxisParameter(self._c_obj, value.c_obj)

    def __GetNumberOfSeries(self):
        FloatFunctionalSeriesGraph_GetNumberOfSeries = self.lib.FloatFunctionalSeriesGraph_GetNumberOfSeries
        FloatFunctionalSeriesGraph_GetNumberOfSeries.argtypes = [POINTER(c_void_p)]
        FloatFunctionalSeriesGraph_GetNumberOfSeries.restype = c_int
        value = FloatFunctionalSeriesGraph_GetNumberOfSeries(self._c_obj)
        return value
    
    def __GetSeriesElement(self,i):
        value = Series()
        FloatFunctionalSeriesGraph_GetSeries = self.lib.FloatFunctionalSeriesGraph_GetSeries
        FloatFunctionalSeriesGraph_GetSeries.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        FloatFunctionalSeriesGraph_GetSeries(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetSeries(self):
         n = self.__GetNumberOfSeries();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetSeriesElement(i))
         return temp
    
    def AddSeries(self, _series):
        """Appends _series to series property on FloatFunctionalSeriesGraph C-object.

           Arguments:
                _series - object of type Series.
        """

        if not isinstance(_series, Series):
            raise GRANTA_Exception('FloatFunctionalSeriesGraph.AddSeries','_series: Invalid argument type _series must be of type Series')
        FloatFunctionalSeriesGraph_AddSeries = self.lib.FloatFunctionalSeriesGraph_AddSeries
        FloatFunctionalSeriesGraph_AddSeries.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        FloatFunctionalSeriesGraph_AddSeries(self._c_obj, _series.c_obj)
        return self

    def __ClearSeries(self):
        FloatFunctionalSeriesGraph_ClearSeries = self.lib.FloatFunctionalSeriesGraph_ClearSeries
        FloatFunctionalSeriesGraph_ClearSeries.argtypes = [POINTER(c_void_p)]
        FloatFunctionalSeriesGraph_ClearSeries(self._c_obj)
        return self

    def __GetHideGraph(self):
        FloatFunctionalSeriesGraph_GetHideGraph = self.lib.FloatFunctionalSeriesGraph_GetHideGraph
        FloatFunctionalSeriesGraph_GetHideGraph.argtypes = [POINTER(c_void_p)]
        FloatFunctionalSeriesGraph_GetHideGraph.restype = c_bool
        value = FloatFunctionalSeriesGraph_GetHideGraph(self._c_obj)
        return value
    
    def __SetHideGraph(self, value):

        FloatFunctionalSeriesGraph_SetHideGraph = self.lib.FloatFunctionalSeriesGraph_SetHideGraph 
        FloatFunctionalSeriesGraph_SetHideGraph.argtypes = [POINTER(c_void_p), c_bool]
        FloatFunctionalSeriesGraph_SetHideGraph(self._c_obj, value)

    def __GetLogarithmicYAxis(self):
        FloatFunctionalSeriesGraph_GetLogarithmicYAxis = self.lib.FloatFunctionalSeriesGraph_GetLogarithmicYAxis
        FloatFunctionalSeriesGraph_GetLogarithmicYAxis.argtypes = [POINTER(c_void_p)]
        FloatFunctionalSeriesGraph_GetLogarithmicYAxis.restype = c_bool
        value = FloatFunctionalSeriesGraph_GetLogarithmicYAxis(self._c_obj)
        return value
    
    def __SetLogarithmicYAxis(self, value):

        FloatFunctionalSeriesGraph_SetLogarithmicYAxis = self.lib.FloatFunctionalSeriesGraph_SetLogarithmicYAxis 
        FloatFunctionalSeriesGraph_SetLogarithmicYAxis.argtypes = [POINTER(c_void_p), c_bool]
        FloatFunctionalSeriesGraph_SetLogarithmicYAxis(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class SearchResult(object):
    """SearchResult. An extension of :py:mod:`NamedRecord <GRANTA_MIScriptingToolkit.NamedRecord>` with a ranking. The higher the ranking the better the match to your search criteria. 
    
        Arguments:
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * ranking - type str
                * shortName - type str
                * longName - type str


    """
    
    def __init__(self, recordReference=None, ranking=None, shortName=None, longName=None, isOwner=True):
        """

        Arguments:
                * recordReference - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * ranking - type str
                * shortName - type str
                * longName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            SearchResult_Create = self.lib.SearchResult_Create
            SearchResult_Create.restype = POINTER(c_void_p)
            self.c_obj = SearchResult_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordReference is not None:
            self.recordReference = recordReference
        if ranking is not None:
            self.ranking = ranking
        if shortName is not None:
            self.shortName = shortName
        if longName is not None:
            self.longName = longName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            SearchResult_Destroy = self.lib.SearchResult_Destroy
            SearchResult_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            SearchResult_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordReference(self):
        """Property recordReference is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._recordReference = self.__GetRecordReference()
        return self._recordReference

    @recordReference.setter
    def recordReference(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('recordReference','recordReference: Invalid type recordReference must be of type RecordReference')
        
        self._recordReference = value

    @property
    def ranking(self):
        """Property ranking is of type str. """ 
        self._ranking = self.__GetRanking()
        return self._ranking

    @ranking.setter
    def ranking(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('ranking','ranking: Invalid type ranking must be of type str')
        
        self._ranking = value

    @property
    def shortName(self):
        """Property shortName is of type str. """ 
        self._shortName = self.__GetShortName()
        return self._shortName

    @shortName.setter
    def shortName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('shortName','shortName: Invalid type shortName must be of type str')
        
        self._shortName = value

    @property
    def longName(self):
        """Property longName is of type str. """ 
        self._longName = self.__GetLongName()
        return self._longName

    @longName.setter
    def longName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('longName','longName: Invalid type longName must be of type str')
        
        self._longName = value

    def __GetRanking(self):
        SearchResult_GetRanking = self.lib.SearchResult_GetRanking
        SearchResult_GetRanking.argtypes = [POINTER(c_void_p)]
        SearchResult_GetRanking.restype = POINTER(c_void_p)
        value = SearchResult_GetRanking(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetLongName(self):
        SearchResult_GetLongName = self.lib.SearchResult_GetLongName
        SearchResult_GetLongName.argtypes = [POINTER(c_void_p)]
        SearchResult_GetLongName.restype = POINTER(c_void_p)
        value = SearchResult_GetLongName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetShortName(self):
        SearchResult_GetShortName = self.lib.SearchResult_GetShortName
        SearchResult_GetShortName.argtypes = [POINTER(c_void_p)]
        SearchResult_GetShortName.restype = POINTER(c_void_p)
        value = SearchResult_GetShortName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetRecordReference(self):
        _recordReference = RecordReference()
        SearchResult_GetRecordReference = self.lib.SearchResult_GetRecordReference
        SearchResult_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        SearchResult_GetRecordReference(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class ParameterValue(object):
    """ParameterValue. A value of a Parameter in Functional data.
    
        Arguments:
                * numericValue - type float
                * type - type str
                * discreteValue - type str


    """
    
    def __init__(self, numericValue=None, type=None, discreteValue=None, isOwner=True):
        """

        Arguments:
                * numericValue - type float
                * type - type str
                * discreteValue - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ParameterValue_Create = self.lib.ParameterValue_Create
            ParameterValue_Create.restype = POINTER(c_void_p)
            self.c_obj = ParameterValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if numericValue is not None:
            self.numericValue = numericValue
        if type is not None:
            self.type = type
        if discreteValue is not None:
            self.discreteValue = discreteValue


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ParameterValue_Destroy = self.lib.ParameterValue_Destroy
            ParameterValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ParameterValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def numericValue(self):
        """Property numericValue is of type float. """ 
        self._numericValue = self.__GetNumericValue()
        return self._numericValue

    @numericValue.setter
    def numericValue(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('numericValue','numericValue: Invalid type numericValue must be of type float')
        self.__SetNumericValue(value)
        self._numericValue = value

    @property
    def type(self):
        """Property type is of type str. See :py:class:`GRANTA_Constants.ParameterTypes <GRANTA_MIScriptingToolkit.GRANTA_Constants>` for supported values. There is no need to set this property manually.""" 
        self._type = self.__GetType()
        return self._type

    @type.setter
    def type(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('type','type: Invalid type type must be of type str')
        self.__SetType(value)
        self._type = value

    @property
    def discreteValue(self):
        """Property discreteValue is of type str. """ 
        self._discreteValue = self.__GetDiscreteValue()
        return self._discreteValue

    @discreteValue.setter
    def discreteValue(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('discreteValue','discreteValue: Invalid type discreteValue must be of type str')
        self.__SetDiscreteValue(value)
        self._discreteValue = value

    def __GetType(self):
        ParameterValue_GetType = self.lib.ParameterValue_GetType
        ParameterValue_GetType.argtypes = [POINTER(c_void_p)]
        ParameterValue_GetType.restype = POINTER(c_void_p)
        value = ParameterValue_GetType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetType(self, value):

        ParameterValue_SetType = self.lib.ParameterValue_SetType 
        ParameterValue_SetType.argtypes = [POINTER(c_void_p), c_char_p]
        ParameterValue_SetType(self._c_obj, EnsureEncoded(value))

    def __SetDiscreteValue(self, value):

        ParameterValue_SetDiscreteValue = self.lib.ParameterValue_SetDiscreteValue 
        ParameterValue_SetDiscreteValue.argtypes = [POINTER(c_void_p), c_char_p]
        ParameterValue_SetDiscreteValue(self._c_obj, EnsureEncoded(value))

    def __GetDiscreteValue(self):
        ParameterValue_GetDiscreteValue = self.lib.ParameterValue_GetDiscreteValue
        ParameterValue_GetDiscreteValue.argtypes = [POINTER(c_void_p)]
        ParameterValue_GetDiscreteValue.restype = POINTER(c_void_p)
        value = ParameterValue_GetDiscreteValue(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetNumericValue(self, value):

        ParameterValue_SetNumericValue = self.lib.ParameterValue_SetNumericValue 
        ParameterValue_SetNumericValue.argtypes = [POINTER(c_void_p), c_double]
        ParameterValue_SetNumericValue(self._c_obj, value)

    def __GetNumericValue(self):
        ParameterValue_GetNumericValue = self.lib.ParameterValue_GetNumericValue
        ParameterValue_GetNumericValue.argtypes = [POINTER(c_void_p)]
        ParameterValue_GetNumericValue.restype = c_double
        value = ParameterValue_GetNumericValue(self._c_obj)
        return value
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


import time
import GRANTA_MIScriptingToolkit.GRANTA_libs as GRANTA_libs
from ctypes import c_char_p, POINTER, c_bool, c_double, c_void_p, c_int
from GRANTA_MIScriptingToolkit.GRANTA_Logging import GRANTA_Logging
from GRANTA_MIScriptingToolkit.Service import Service
from GRANTA_MIScriptingToolkit.GRANTA_Exceptions import GRANTA_Exception
from GRANTA_MIScriptingToolkit.RecordNameSearchRequest import RecordNameSearchRequest
from GRANTA_MIScriptingToolkit.SimpleTextSearchResponse import SimpleTextSearchResponse
from GRANTA_MIScriptingToolkit.CriteriaSearch import CriteriaSearch
from GRANTA_MIScriptingToolkit.SimpleTextSearch import SimpleTextSearch

# This file was automatically generated
class SearchService(Service):
    """The Search service finds Records, within a GRANTA MI Databases, matching specified criteria."""

    def __init__(self, mi_session):
        """Initialize a SearchService object
                Arguments:
                    mi_session - MI_Session object
        """
        self.mi_session = mi_session
        self.lib = GRANTA_libs.MIServiceLayerCAPILib

    def RecordNameSearch(self, _req):
        """Searches for Records with a given exact Record name.

        Arguments:
            _req - :py:mod:`RecordNameSearchRequest <GRANTA_MIScriptingToolkit.RecordNameSearchRequest>` object
        Returns:
            :py:mod:`SimpleTextSearchResponse <GRANTA_MIScriptingToolkit.SimpleTextSearchResponse>` object
        
        """
        if not isinstance(_req, RecordNameSearchRequest):
            raise GRANTA_Exception('Search.RecordNameSearch','Search.RecordNameSearch(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.RecordNameSearchRequest')

        startTime = time.clock()
        func = self.lib.Search_RecordNameSearch
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = SimpleTextSearchResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Search.RecordNameSearch() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Search.RecordNameSearch')
        return response

    def CriteriaSearch(self, _req):
        """Searches for records matching attribute-based criteria.

        Arguments:
            _req - :py:mod:`CriteriaSearch <GRANTA_MIScriptingToolkit.CriteriaSearch>` object
        Returns:
            :py:mod:`SimpleTextSearchResponse <GRANTA_MIScriptingToolkit.SimpleTextSearchResponse>` object
        
        """
        if not isinstance(_req, CriteriaSearch):
            raise GRANTA_Exception('Search.CriteriaSearch','Search.CriteriaSearch(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.CriteriaSearch')

        startTime = time.clock()
        func = self.lib.Search_CriteriaSearch
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = SimpleTextSearchResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Search.CriteriaSearch() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Search.CriteriaSearch')
        return response

    def SimpleTextSearch(self, _req):
        """Searches for records matching simple text criteria.

        Arguments:
            _req - :py:mod:`SimpleTextSearch <GRANTA_MIScriptingToolkit.SimpleTextSearch>` object
        Returns:
            :py:mod:`SimpleTextSearchResponse <GRANTA_MIScriptingToolkit.SimpleTextSearchResponse>` object
        
        """
        if not isinstance(_req, SimpleTextSearch):
            raise GRANTA_Exception('Search.SimpleTextSearch','Search.SimpleTextSearch(self, _req): Invalid argument type _req must be of type GRANTA_MIScriptingToolkit.SimpleTextSearch')

        startTime = time.clock()
        func = self.lib.Search_SimpleTextSearch
        func.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        func.restype = POINTER(c_void_p)
        response_c = func(self.mi_session.c_obj, _req.c_obj)
        response = SimpleTextSearchResponse(response_c)
        totalTime = time.clock() - startTime
        GRANTA_Logging().info('Ran Search.SimpleTextSearch() command, total time {0}s '.format(str(totalTime)))
        self._CheckResponse(response, 'Search.SimpleTextSearch')
        return response


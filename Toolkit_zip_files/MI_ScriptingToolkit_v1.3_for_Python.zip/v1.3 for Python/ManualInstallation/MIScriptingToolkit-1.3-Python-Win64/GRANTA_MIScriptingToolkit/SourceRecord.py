# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.LinkedRecordsDataType import LinkedRecordsDataType


class SourceRecord(object):
    """SourceRecord. A type that contains a record reference and associated record link groups.
    
        Arguments:
                * record - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * recordLinkGroups - type :py:mod:`LinkedRecordsDataType <GRANTA_MIScriptingToolkit.LinkedRecordsDataType>`


    """
    
    def __init__(self, record=None, recordLinkGroups=None, isOwner=True):
        """

        Arguments:
                * record - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * recordLinkGroups - type :py:mod:`LinkedRecordsDataType <GRANTA_MIScriptingToolkit.LinkedRecordsDataType>`

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            SourceRecord_Create = self.lib.SourceRecord_Create
            SourceRecord_Create.restype = POINTER(c_void_p)
            self.c_obj = SourceRecord_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if record is not None:
            self.record = record
        if recordLinkGroups is not None:
            self.recordLinkGroups = recordLinkGroups


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            SourceRecord_Destroy = self.lib.SourceRecord_Destroy
            SourceRecord_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            SourceRecord_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def record(self):
        """Property record is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._record = self.__GetRecord()
        return self._record

    @record.setter
    def record(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('record','record: Invalid type record must be of type RecordReference')
        
        self._record = value

    @property
    def recordLinkGroups(self):
        """Property recordLinkGroups is of type :py:mod:`LinkedRecordsDataType <GRANTA_MIScriptingToolkit.LinkedRecordsDataType>`. """ 
        self._recordLinkGroups = self.__GetRecordLinkGroups()
        return self._recordLinkGroups

    @recordLinkGroups.setter
    def recordLinkGroups(self, value):
        if not isinstance(value, LinkedRecordsDataType):
            raise GRANTA_Exception('recordLinkGroups','recordLinkGroups: Invalid type recordLinkGroups must be of type LinkedRecordsDataType')
        
        self._recordLinkGroups = value

    def __GetRecord(self):
        _recordReference = RecordReference()
        SourceRecord_GetRecord = self.lib.SourceRecord_GetRecord
        SourceRecord_GetRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        SourceRecord_GetRecord(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __GetRecordLinkGroups(self):
        _linkedRecordsDataType = LinkedRecordsDataType()
        SourceRecord_GetRecordLinkGroups = self.lib.SourceRecord_GetRecordLinkGroups
        SourceRecord_GetRecordLinkGroups.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        SourceRecord_GetRecordLinkGroups(self._c_obj, (_linkedRecordsDataType.c_obj))
        
        return _linkedRecordsDataType
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


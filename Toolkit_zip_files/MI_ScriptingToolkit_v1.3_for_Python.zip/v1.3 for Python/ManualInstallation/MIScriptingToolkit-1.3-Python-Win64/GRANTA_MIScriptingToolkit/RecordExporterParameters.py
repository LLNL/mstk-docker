# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.AttributeExporterParameters import AttributeExporterParameters


class RecordExporterParameters(object):
    """RecordExporterParameters. A type to contain a record and its associated attribute exporter parameters.
    
        Arguments:
                * record - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * attributes - type list of :py:mod:`AttributeExporterParameters <GRANTA_MIScriptingToolkit.AttributeExporterParameters>` objects


    """
    
    def __init__(self, record=None, attributes=None, isOwner=True):
        """

        Arguments:
                * record - type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`
                * attributes - type list of :py:mod:`AttributeExporterParameters <GRANTA_MIScriptingToolkit.AttributeExporterParameters>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            RecordExporterParameters_Create = self.lib.RecordExporterParameters_Create
            RecordExporterParameters_Create.restype = POINTER(c_void_p)
            self.c_obj = RecordExporterParameters_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if record is not None:
            self.record = record
        if attributes is not None:
            self.attributes = attributes


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            RecordExporterParameters_Destroy = self.lib.RecordExporterParameters_Destroy
            RecordExporterParameters_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            RecordExporterParameters_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def record(self):
        """Property record is of type :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        self._record = self.__GetRecord()
        return self._record

    @record.setter
    def record(self, value):
        if not isinstance(value, RecordReference):
            raise GRANTA_Exception('record','record: Invalid type record must be of type RecordReference')
        
        self._record = value

    @property
    def attributes(self):
        """Property attributes is a list of :py:mod:`AttributeExporterParameters <GRANTA_MIScriptingToolkit.AttributeExporterParameters>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributes = self.__GetAttributes()
        except:
            pass
        return self._attributes

    @attributes.setter
    def attributes(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributes','attributes: Invalid type attributes must be a list of AttributeExporterParameters')
        
        self._attributes = value

    def __GetRecord(self):
        _recordReference = RecordReference()
        RecordExporterParameters_GetRecord = self.lib.RecordExporterParameters_GetRecord
        RecordExporterParameters_GetRecord.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        RecordExporterParameters_GetRecord(self._c_obj, (_recordReference.c_obj))
        
        return _recordReference
        
    def __GetNumberOfAttributes(self):
        RecordExporterParameters_GetNumberOfAttributes = self.lib.RecordExporterParameters_GetNumberOfAttributes
        RecordExporterParameters_GetNumberOfAttributes.argtypes = [POINTER(c_void_p)]
        RecordExporterParameters_GetNumberOfAttributes.restype = c_int
        value = RecordExporterParameters_GetNumberOfAttributes(self._c_obj)
        return value
    
    def __GetAttributeElement(self,i):
        value = AttributeExporterParameters()
        RecordExporterParameters_GetAttribute = self.lib.RecordExporterParameters_GetAttribute
        RecordExporterParameters_GetAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        RecordExporterParameters_GetAttribute(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributes(self):
         n = self.__GetNumberOfAttributes();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


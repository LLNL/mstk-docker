from .GRANTA_Logging import GRANTA_Logging
from GRANTA_MIScriptingToolkit.GRANTA_Exceptions import GRANTA_ServiceLayerError,GRANTA_Exception

class Service(object):
    """ Base class for GRANTA MI Service objects. For internal use only. """
    def _CheckResponse(self, response, method):
        slResponse = response.serviceLayerResponse;
        responseCode = slResponse.responseCode;
        responseMessage = slResponse.responseMessage;
        if responseCode == 0:
            GRANTA_Logging().error("{0}: No response from server.".format(method))
            raise GRANTA_Exception(method, "No response from server.")
        
        if responseCode != 200:           
            GRANTA_Logging().error('{}() failed with code: {}, and message:\n{}'.format(method, str(responseCode), responseMessage))
            raise GRANTA_ServiceLayerError(response.serviceLayerResponse, method)
        
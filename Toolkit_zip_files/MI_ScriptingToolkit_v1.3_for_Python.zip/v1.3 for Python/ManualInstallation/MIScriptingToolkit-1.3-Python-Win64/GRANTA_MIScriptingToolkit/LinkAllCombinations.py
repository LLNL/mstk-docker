# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference


class LinkAllCombinations(object):
    """LinkAllCombinations. For each given source record, add links to all the given target records. Silently skip any links that already exist.
    
        Arguments:
                * sourceRecords - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * nodeName - type str
                * targetRecords - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects


    """
    
    def __init__(self, sourceRecords=None, nodeName=None, targetRecords=None, isOwner=True):
        """

        Arguments:
                * sourceRecords - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * nodeName - type str
                * targetRecords - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            LinkAllCombinations_Create = self.lib.LinkAllCombinations_Create
            LinkAllCombinations_Create.restype = POINTER(c_void_p)
            self.c_obj = LinkAllCombinations_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if sourceRecords is not None:
            self.sourceRecords = sourceRecords
        if nodeName is not None:
            self.nodeName = nodeName
        if targetRecords is not None:
            self.targetRecords = targetRecords


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            LinkAllCombinations_Destroy = self.lib.LinkAllCombinations_Destroy
            LinkAllCombinations_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            LinkAllCombinations_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def sourceRecords(self):
        """Property sourceRecords is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._sourceRecords = self.__GetSourceRecords()
        except:
            pass
        return self._sourceRecords

    @sourceRecords.setter
    def sourceRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('sourceRecords','sourceRecords: Invalid type sourceRecords must be a list of RecordReference')
                
        try:
            self.__updatesourceRecords = True
            self.__ClearSourceRecords()
            for v in value:
                self.AddSourceRecord(v)
        except:
            pass


    @property
    def nodeName(self):
        """Property nodeName is of type str. """ 
        self._nodeName = self.__GetNodeName()
        return self._nodeName

    @nodeName.setter
    def nodeName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('nodeName','nodeName: Invalid type nodeName must be of type str')
        
        self._nodeName = value

    @property
    def targetRecords(self):
        """Property targetRecords is of type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>`. """ 
        try:
            return self._targetRecords
        except:
            return None

    @targetRecords.setter
    def targetRecords(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('targetRecords','targetRecords: Invalid type targetRecords must be a list of RecordReference')
                
        try:
            self.__updatetargetRecords = True
            self.__ClearTargetRecords()
            for v in value:
                self.AddTargetRecord(v)
        except:
            pass


    def AddTargetRecord(self, _recordReference):
        """Appends _recordReference to targetRecords property on LinkAllCombinations C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('LinkAllCombinations.AddTargetRecord','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        LinkAllCombinations_AddTargetRecord = self.lib.LinkAllCombinations_AddTargetRecord
        LinkAllCombinations_AddTargetRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        LinkAllCombinations_AddTargetRecord(self._c_obj, _recordReference.c_obj)
        return self

    def __ClearTargetRecords(self):
        LinkAllCombinations_ClearTargetRecords = self.lib.LinkAllCombinations_ClearTargetRecords
        LinkAllCombinations_ClearTargetRecords.argtypes = [POINTER(c_void_p)]
        LinkAllCombinations_ClearTargetRecords(self._c_obj)
        return self

    def __GetNodeName(self):
        LinkAllCombinations_GetNodeName = self.lib.LinkAllCombinations_GetNodeName
        LinkAllCombinations_GetNodeName.argtypes = [POINTER(c_void_p)]
        LinkAllCombinations_GetNodeName.restype = POINTER(c_void_p)
        value = LinkAllCombinations_GetNodeName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def AddSourceRecord(self, _recordReference):
        """Appends _recordReference to sourceRecords property on LinkAllCombinations C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('LinkAllCombinations.AddSourceRecord','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        LinkAllCombinations_AddSourceRecord = self.lib.LinkAllCombinations_AddSourceRecord
        LinkAllCombinations_AddSourceRecord.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        LinkAllCombinations_AddSourceRecord(self._c_obj, _recordReference.c_obj)
        return self

    def __ClearSourceRecords(self):
        LinkAllCombinations_ClearSourceRecords = self.lib.LinkAllCombinations_ClearSourceRecords
        LinkAllCombinations_ClearSourceRecords.argtypes = [POINTER(c_void_p)]
        LinkAllCombinations_ClearSourceRecords(self._c_obj)
        return self

    def __GetNumberOfSourceRecords(self):
        LinkAllCombinations_GetNumberOfSourceRecords = self.lib.LinkAllCombinations_GetNumberOfSourceRecords
        LinkAllCombinations_GetNumberOfSourceRecords.argtypes = [POINTER(c_void_p)]
        LinkAllCombinations_GetNumberOfSourceRecords.restype = c_int
        value = LinkAllCombinations_GetNumberOfSourceRecords(self._c_obj)
        return value
    
    def __GetSourceRecordsElement(self,i):
        value = RecordReference()
        LinkAllCombinations_GetSourceRecords = self.lib.LinkAllCombinations_GetSourceRecords
        LinkAllCombinations_GetSourceRecords.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        LinkAllCombinations_GetSourceRecords(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetSourceRecords(self):
         n = self.__GetNumberOfSourceRecords();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetSourceRecordsElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


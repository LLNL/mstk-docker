# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference


class GetUploadAddressesRequest(object):
    """GetUploadAddressesRequest. Input to the GetUploadAddresses operation.
Contains a list of records and attributes to get the upload URL addresses of. 
    
        Arguments:
                * recordReferences - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects


    """
    
    def __init__(self, recordReferences=None, attributeReferences=None, isOwner=True):
        """

        Arguments:
                * recordReferences - type list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects
                * attributeReferences - type list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            GetUploadAddressesRequest_Create = self.lib.GetUploadAddressesRequest_Create
            GetUploadAddressesRequest_Create.restype = POINTER(c_void_p)
            self.c_obj = GetUploadAddressesRequest_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if recordReferences is not None:
            self.recordReferences = recordReferences
        if attributeReferences is not None:
            self.attributeReferences = attributeReferences


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetUploadAddressesRequest_Destroy = self.lib.GetUploadAddressesRequest_Destroy
            GetUploadAddressesRequest_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetUploadAddressesRequest_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def recordReferences(self):
        """Property recordReferences is a list of :py:mod:`RecordReference <GRANTA_MIScriptingToolkit.RecordReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._recordReferences = self.__GetRecordReferences()
        except:
            pass
        return self._recordReferences

    @recordReferences.setter
    def recordReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('recordReferences','recordReferences: Invalid type recordReferences must be a list of RecordReference')
                
        try:
            self.__updaterecordReferences = True
            self.__ClearRecordReferences()
            for v in value:
                self.AddRecordReference(v)
        except:
            pass


    @property
    def attributeReferences(self):
        """Property attributeReferences is a list of :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._attributeReferences = self.__GetAttributeReferences()
        except:
            pass
        return self._attributeReferences

    @attributeReferences.setter
    def attributeReferences(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('attributeReferences','attributeReferences: Invalid type attributeReferences must be a list of AttributeReference')
                
        try:
            self.__updateattributeReferences = True
            self.__ClearAttributeReferences()
            for v in value:
                self.AddAttributeReference(v)
        except:
            pass


    def AddRecordReference(self, _recordReference):
        """Appends _recordReference to recordReferences property on GetUploadAddressesRequest C-object.

           Arguments:
                _recordReference - object of type RecordReference.
        """

        if not isinstance(_recordReference, RecordReference):
            raise GRANTA_Exception('GetUploadAddressesRequest.AddRecordReference','_recordReference: Invalid argument type _recordReference must be of type RecordReference')
        GetUploadAddressesRequest_AddRecordReference = self.lib.GetUploadAddressesRequest_AddRecordReference
        GetUploadAddressesRequest_AddRecordReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetUploadAddressesRequest_AddRecordReference(self._c_obj, _recordReference.c_obj)
        return self

    def __ClearRecordReferences(self):
        GetUploadAddressesRequest_ClearRecordReferences = self.lib.GetUploadAddressesRequest_ClearRecordReferences
        GetUploadAddressesRequest_ClearRecordReferences.argtypes = [POINTER(c_void_p)]
        GetUploadAddressesRequest_ClearRecordReferences(self._c_obj)
        return self

    def __GetNumberOfRecordReferences(self):
        GetUploadAddressesRequest_GetNumberOfRecordReferences = self.lib.GetUploadAddressesRequest_GetNumberOfRecordReferences
        GetUploadAddressesRequest_GetNumberOfRecordReferences.argtypes = [POINTER(c_void_p)]
        GetUploadAddressesRequest_GetNumberOfRecordReferences.restype = c_int
        value = GetUploadAddressesRequest_GetNumberOfRecordReferences(self._c_obj)
        return value
    
    def __GetRecordReferenceElement(self,i):
        value = RecordReference()
        GetUploadAddressesRequest_GetRecordReference = self.lib.GetUploadAddressesRequest_GetRecordReference
        GetUploadAddressesRequest_GetRecordReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetUploadAddressesRequest_GetRecordReference(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetRecordReferences(self):
         n = self.__GetNumberOfRecordReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetRecordReferenceElement(i))
         return temp
    
    def AddAttributeReference(self, _attributeReference):
        """Appends _attributeReference to attributeReferences property on GetUploadAddressesRequest C-object.

           Arguments:
                _attributeReference - object of type AttributeReference.
        """

        if not isinstance(_attributeReference, AttributeReference):
            raise GRANTA_Exception('GetUploadAddressesRequest.AddAttributeReference','_attributeReference: Invalid argument type _attributeReference must be of type AttributeReference')
        GetUploadAddressesRequest_AddAttributeReference = self.lib.GetUploadAddressesRequest_AddAttributeReference
        GetUploadAddressesRequest_AddAttributeReference.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        GetUploadAddressesRequest_AddAttributeReference(self._c_obj, _attributeReference.c_obj)
        return self

    def __ClearAttributeReferences(self):
        GetUploadAddressesRequest_ClearAttributeReferences = self.lib.GetUploadAddressesRequest_ClearAttributeReferences
        GetUploadAddressesRequest_ClearAttributeReferences.argtypes = [POINTER(c_void_p)]
        GetUploadAddressesRequest_ClearAttributeReferences(self._c_obj)
        return self

    def __GetNumberOfAttributeReferences(self):
        GetUploadAddressesRequest_GetNumberOfAttributeReferences = self.lib.GetUploadAddressesRequest_GetNumberOfAttributeReferences
        GetUploadAddressesRequest_GetNumberOfAttributeReferences.argtypes = [POINTER(c_void_p)]
        GetUploadAddressesRequest_GetNumberOfAttributeReferences.restype = c_int
        value = GetUploadAddressesRequest_GetNumberOfAttributeReferences(self._c_obj)
        return value
    
    def __GetAttributeReferenceElement(self,i):
        value = AttributeReference()
        GetUploadAddressesRequest_GetAttributeReference = self.lib.GetUploadAddressesRequest_GetAttributeReference
        GetUploadAddressesRequest_GetAttributeReference.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        GetUploadAddressesRequest_GetAttributeReference(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetAttributeReferences(self):
         n = self.__GetNumberOfAttributeReferences();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetAttributeReferenceElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


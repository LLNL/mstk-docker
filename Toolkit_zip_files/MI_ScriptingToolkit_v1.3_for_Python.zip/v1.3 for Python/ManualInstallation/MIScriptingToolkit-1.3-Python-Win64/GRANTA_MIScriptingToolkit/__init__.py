import sys
import platform 
supported = False
try:
    supported_interpreter = False
    ver = sys.version_info
    if ver.major == 2 and ver.minor >= 7:
        supported_interpreter = True
    elif ver.major == 3 and ver.minor >=4:
        supported_interpreter = True
        
    supported_arch = ("64" in platform.architecture()[0])
    supported = supported_interpreter and supported_arch
    
except:
    pass
if not supported:
    raise EnvironmentError("This Python interpreter is not supported. Supported Python interpreters are versions 2.7 and 3.x [x>=4] built for 64-bit processors.")


"""The MI:Scripting Toolkit enables users to analyze and transform the materials data in your GRANTA MI system from within Python.
Data can be extracted based on known record lists or on user-supplied criteria, and the results of the analysis can be written back to the GRANTA MI database with full traceability. 
The toolkit supports the manipulation of the following GRANTA MI data types:
* Numerical (Point, Range, Integer)
* Text (Short Text, Long Text, Discrete)
* Functional (Float Functional, Discrete Functional)
* Media (File, Hyperlink)
* Other (Logical, Date)

A set of examples are included in the Examples/ directory.

To create a connection to a GRANTA MI Server create a ref:py:class:GRANTA_MISession object.
"""

__all__ = [
'GRANTA_Constants',
'GRANTA_Exception',
'GRANTA_ServiceLayerError',
'GRANTA_Logging',
'GRANTA_MISession',
'MIEntityReference',
'MISession',
'StringUtils',
'AttributeAddress',
'AttributeDetail',
'AttributeExporterParameters',
'AttributeMetaAttributes',
'AttributeReference',
'AttributeValue',
'BetweenDateTimesSearchValue',
'BetweenSearchValue',
'BrowseService',
'Constraint',
'Constraints',
'ContainsAllSearchValue',
'ContainsAnySearchValue',
'ContainsSearchValue',
'CriteriaSearch',
'DataExportService',
'DataImportService',
'DateDataType',
'DiscreteDataType',
'DiscreteValue',
'DoesNotContainSearchValue',
'DoesNotExistSearchValue',
'EngineeringDataService',
'ExactlySearchValue',
'ExistsSearchValue',
'Exporter',
'ExporterParameter',
'ExporterPopulation',
'ExportersForRecord',
'ExportersForRecordsRequest',
'ExportersForRecordsResponse',
'ExporterTransform',
'ExportRecordDataRequest',
'ExportRecordDataResponse',
'FileDataType',
'FloatFunctionalGraph',
'FloatFunctionalGriddedDataType',
'FloatFunctionalPointValue',
'FloatFunctionalRangeValue',
'FloatFunctionalSeriesDataType',
'FloatFunctionalSeriesGraph',
'FloatFunctionalValues',
'GetAttributeDetailsRequest',
'GetAttributeDetailsResponse',
'GetAttributeParametersRequest',
'GetAttributeParametersResponse',
'GetAvailableExportersRequest',
'GetAvailableExportersResponse',
'GetChildNodes',
'GetChildNodesResponse',
'GetDatabasesResponse',
'GetExporterParametersRequest',
'GetExporterParametersResponse',
'GetLinkedRecordsRequest',
'GetLinkedRecordsResponse',
'GetMetaAttributesRequest',
'GetMetaAttributesResponse',
'GetParameterDetailsRequest',
'GetParameterDetailsResponse',
'GetRecordAttributesByRefRequest',
'GetRecordAttributesByRefResponse',
'GetRecordAttributesRequest',
'GetRecordAttributesResponse',
'GetRecordLinkGroups',
'GetRecordLinkGroupsResponse',
'GetRecordVersionsRequest',
'GetRecordVersionsResponse',
'GetRootNode',
'GetRootNodeResponse',
'GetSubsetsRequest',
'GetSubsetsResponse',
'GetTables',
'GetTablesResponse',
'GetTreeRecordsRequest',
'GetTreeRecordsResponse',
'GetUnitSystems',
'GetUnitSystemsResponse',
'GetUploadAddressesRequest',
'GetUploadAddressesResponse',
'GraphDomain',
'GreaterThanSearchValue',
'HighEndSearchValue',
'HyperlinkDataType',
'ImportAttributeValue',
'ImportRecord',
'IntegerDataType',
'LessThanSearchValue',
'LinkAllCombinations',
'LinkedRecordsDataType',
'LinkRecords',
'ListDataType',
'ListItem',
'LogicalDataType',
'LongTextDataType',
'LowEndSearchValue',
'MIDatabase',
'MIParameterValue',
'ModifyRecordLinksRequest',
'ModifyRecordLinksResponse',
'NamedAttribute',
'NamedRecord',
'NamedSubset',
'NamedTargetedSourceRecord',
'NotatedTargetedSourceRecord',
'NotatedTargetRecord',
'ParameterDetail',
'ParameterDomain',
'ParameterInformation',
'ParameterReference',
'ParameterReferenceAndValue',
'ParameterReferencesAndValues',
'Parameters',
'ParameterValue',
'PartialTableReference',
'PointDataType',
'PointValueWithParameters',
'RangeDataType',
'RecordAttribute',
'RecordData',
'RecordExporterParameters',
'RecordFilter',
'RecordLinkChanges',
'RecordLinkGroup',
'RecordLinkGroupDetail',
'RecordLinkGroupReference',
'RecordLinkModifications',
'RecordNameSearchRequest',
'RecordReference',
'RecordSearchCriterion',
'RecordVersionState',
'RecordWithAttributeAddresses',
'RevisionInfo',
'SearchResult',
'SearchService',
'Series',
'ServiceLayerResponse',
'SetRecordAttributesRequest',
'SetRecordAttributesResponse',
'ShortTextDataType',
'SimpleTextSearch',
'SimpleTextSearchResponse',
'SourceRecord',
'SubsetDetail',
'SubsetReference',
'TableDetail',
'TableReference',
'TabularColumn',
'TabularColumnContainsSearchValue',
'TabularColumnDetail',
'TabularDataCell',
'TabularDataRow',
'TabularDataType',
'TargetedSourceRecord',
'TreeRecord',
'UnitConversionContext',
'UnitInformation',
'UnittedParameterValue',
'UnlinkAllRecords',
'UnlinkRecords',
'XYData',
'XYPoint',
'XYRange'
]

#Import modules
from GRANTA_MIScriptingToolkit._version import __version__
from GRANTA_MIScriptingToolkit.GRANTA_Constants import GRANTA_Constants
from GRANTA_MIScriptingToolkit.GRANTA_Exceptions import GRANTA_Exception
from GRANTA_MIScriptingToolkit.GRANTA_Exceptions import GRANTA_ServiceLayerError
from GRANTA_MIScriptingToolkit.GRANTA_Logging import GRANTA_Logging
from GRANTA_MIScriptingToolkit.GRANTA_MISession import GRANTA_MISession
from GRANTA_MIScriptingToolkit.MIEntityReference import MIEntityReference
from GRANTA_MIScriptingToolkit.MISession import MISession
from GRANTA_MIScriptingToolkit.StringUtils import StringUtils
from GRANTA_MIScriptingToolkit.AttributeAddress import AttributeAddress
from GRANTA_MIScriptingToolkit.AttributeDetail import AttributeDetail
from GRANTA_MIScriptingToolkit.AttributeExporterParameters import AttributeExporterParameters
from GRANTA_MIScriptingToolkit.AttributeMetaAttributes import AttributeMetaAttributes
from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference
from GRANTA_MIScriptingToolkit.AttributeValue import AttributeValue
from GRANTA_MIScriptingToolkit.BetweenDateTimesSearchValue import BetweenDateTimesSearchValue
from GRANTA_MIScriptingToolkit.BetweenSearchValue import BetweenSearchValue
from GRANTA_MIScriptingToolkit.BrowseService import BrowseService
from GRANTA_MIScriptingToolkit.Constraint import Constraint
from GRANTA_MIScriptingToolkit.Constraints import Constraints
from GRANTA_MIScriptingToolkit.ContainsAllSearchValue import ContainsAllSearchValue
from GRANTA_MIScriptingToolkit.ContainsAnySearchValue import ContainsAnySearchValue
from GRANTA_MIScriptingToolkit.ContainsSearchValue import ContainsSearchValue
from GRANTA_MIScriptingToolkit.CriteriaSearch import CriteriaSearch
from GRANTA_MIScriptingToolkit.DataExportService import DataExportService
from GRANTA_MIScriptingToolkit.DataImportService import DataImportService
from GRANTA_MIScriptingToolkit.DateDataType import DateDataType
from GRANTA_MIScriptingToolkit.DiscreteDataType import DiscreteDataType
from GRANTA_MIScriptingToolkit.DiscreteValue import DiscreteValue
from GRANTA_MIScriptingToolkit.DoesNotContainSearchValue import DoesNotContainSearchValue
from GRANTA_MIScriptingToolkit.DoesNotExistSearchValue import DoesNotExistSearchValue
from GRANTA_MIScriptingToolkit.EngineeringDataService import EngineeringDataService
from GRANTA_MIScriptingToolkit.ExactlySearchValue import ExactlySearchValue
from GRANTA_MIScriptingToolkit.ExistsSearchValue import ExistsSearchValue
from GRANTA_MIScriptingToolkit.Exporter import Exporter
from GRANTA_MIScriptingToolkit.ExporterParameter import ExporterParameter
from GRANTA_MIScriptingToolkit.ExporterPopulation import ExporterPopulation
from GRANTA_MIScriptingToolkit.ExportersForRecord import ExportersForRecord
from GRANTA_MIScriptingToolkit.ExportersForRecordsRequest import ExportersForRecordsRequest
from GRANTA_MIScriptingToolkit.ExportersForRecordsResponse import ExportersForRecordsResponse
from GRANTA_MIScriptingToolkit.ExporterTransform import ExporterTransform
from GRANTA_MIScriptingToolkit.ExportRecordDataRequest import ExportRecordDataRequest
from GRANTA_MIScriptingToolkit.ExportRecordDataResponse import ExportRecordDataResponse
from GRANTA_MIScriptingToolkit.FileDataType import FileDataType
from GRANTA_MIScriptingToolkit.FloatFunctionalGraph import FloatFunctionalGraph
from GRANTA_MIScriptingToolkit.FloatFunctionalGriddedDataType import FloatFunctionalGriddedDataType
from GRANTA_MIScriptingToolkit.FloatFunctionalPointValue import FloatFunctionalPointValue
from GRANTA_MIScriptingToolkit.FloatFunctionalRangeValue import FloatFunctionalRangeValue
from GRANTA_MIScriptingToolkit.FloatFunctionalSeriesDataType import FloatFunctionalSeriesDataType
from GRANTA_MIScriptingToolkit.FloatFunctionalSeriesGraph import FloatFunctionalSeriesGraph
from GRANTA_MIScriptingToolkit.FloatFunctionalValues import FloatFunctionalValues
from GRANTA_MIScriptingToolkit.GetAttributeDetailsRequest import GetAttributeDetailsRequest
from GRANTA_MIScriptingToolkit.GetAttributeDetailsResponse import GetAttributeDetailsResponse
from GRANTA_MIScriptingToolkit.GetAttributeParametersRequest import GetAttributeParametersRequest
from GRANTA_MIScriptingToolkit.GetAttributeParametersResponse import GetAttributeParametersResponse
from GRANTA_MIScriptingToolkit.GetAvailableExportersRequest import GetAvailableExportersRequest
from GRANTA_MIScriptingToolkit.GetAvailableExportersResponse import GetAvailableExportersResponse
from GRANTA_MIScriptingToolkit.GetChildNodes import GetChildNodes
from GRANTA_MIScriptingToolkit.GetChildNodesResponse import GetChildNodesResponse
from GRANTA_MIScriptingToolkit.GetDatabasesResponse import GetDatabasesResponse
from GRANTA_MIScriptingToolkit.GetExporterParametersRequest import GetExporterParametersRequest
from GRANTA_MIScriptingToolkit.GetExporterParametersResponse import GetExporterParametersResponse
from GRANTA_MIScriptingToolkit.GetLinkedRecordsRequest import GetLinkedRecordsRequest
from GRANTA_MIScriptingToolkit.GetLinkedRecordsResponse import GetLinkedRecordsResponse
from GRANTA_MIScriptingToolkit.GetMetaAttributesRequest import GetMetaAttributesRequest
from GRANTA_MIScriptingToolkit.GetMetaAttributesResponse import GetMetaAttributesResponse
from GRANTA_MIScriptingToolkit.GetParameterDetailsRequest import GetParameterDetailsRequest
from GRANTA_MIScriptingToolkit.GetParameterDetailsResponse import GetParameterDetailsResponse
from GRANTA_MIScriptingToolkit.GetRecordAttributesByRefRequest import GetRecordAttributesByRefRequest
from GRANTA_MIScriptingToolkit.GetRecordAttributesByRefResponse import GetRecordAttributesByRefResponse
from GRANTA_MIScriptingToolkit.GetRecordAttributesRequest import GetRecordAttributesRequest
from GRANTA_MIScriptingToolkit.GetRecordAttributesResponse import GetRecordAttributesResponse
from GRANTA_MIScriptingToolkit.GetRecordLinkGroups import GetRecordLinkGroups
from GRANTA_MIScriptingToolkit.GetRecordLinkGroupsResponse import GetRecordLinkGroupsResponse
from GRANTA_MIScriptingToolkit.GetRecordVersionsRequest import GetRecordVersionsRequest
from GRANTA_MIScriptingToolkit.GetRecordVersionsResponse import GetRecordVersionsResponse
from GRANTA_MIScriptingToolkit.GetRootNode import GetRootNode
from GRANTA_MIScriptingToolkit.GetRootNodeResponse import GetRootNodeResponse
from GRANTA_MIScriptingToolkit.GetSubsetsRequest import GetSubsetsRequest
from GRANTA_MIScriptingToolkit.GetSubsetsResponse import GetSubsetsResponse
from GRANTA_MIScriptingToolkit.GetTables import GetTables
from GRANTA_MIScriptingToolkit.GetTablesResponse import GetTablesResponse
from GRANTA_MIScriptingToolkit.GetTreeRecordsRequest import GetTreeRecordsRequest
from GRANTA_MIScriptingToolkit.GetTreeRecordsResponse import GetTreeRecordsResponse
from GRANTA_MIScriptingToolkit.GetUnitSystems import GetUnitSystems
from GRANTA_MIScriptingToolkit.GetUnitSystemsResponse import GetUnitSystemsResponse
from GRANTA_MIScriptingToolkit.GetUploadAddressesRequest import GetUploadAddressesRequest
from GRANTA_MIScriptingToolkit.GetUploadAddressesResponse import GetUploadAddressesResponse
from GRANTA_MIScriptingToolkit.GraphDomain import GraphDomain
from GRANTA_MIScriptingToolkit.GreaterThanSearchValue import GreaterThanSearchValue
from GRANTA_MIScriptingToolkit.HighEndSearchValue import HighEndSearchValue
from GRANTA_MIScriptingToolkit.HyperlinkDataType import HyperlinkDataType
from GRANTA_MIScriptingToolkit.ImportAttributeValue import ImportAttributeValue
from GRANTA_MIScriptingToolkit.ImportRecord import ImportRecord
from GRANTA_MIScriptingToolkit.IntegerDataType import IntegerDataType
from GRANTA_MIScriptingToolkit.LessThanSearchValue import LessThanSearchValue
from GRANTA_MIScriptingToolkit.LinkAllCombinations import LinkAllCombinations
from GRANTA_MIScriptingToolkit.LinkedRecordsDataType import LinkedRecordsDataType
from GRANTA_MIScriptingToolkit.LinkRecords import LinkRecords
from GRANTA_MIScriptingToolkit.ListDataType import ListDataType
from GRANTA_MIScriptingToolkit.ListItem import ListItem
from GRANTA_MIScriptingToolkit.LogicalDataType import LogicalDataType
from GRANTA_MIScriptingToolkit.LongTextDataType import LongTextDataType
from GRANTA_MIScriptingToolkit.LowEndSearchValue import LowEndSearchValue
from GRANTA_MIScriptingToolkit.MIDatabase import MIDatabase
from GRANTA_MIScriptingToolkit.MIParameterValue import MIParameterValue
from GRANTA_MIScriptingToolkit.ModifyRecordLinksRequest import ModifyRecordLinksRequest
from GRANTA_MIScriptingToolkit.ModifyRecordLinksResponse import ModifyRecordLinksResponse
from GRANTA_MIScriptingToolkit.NamedAttribute import NamedAttribute
from GRANTA_MIScriptingToolkit.NamedRecord import NamedRecord
from GRANTA_MIScriptingToolkit.NamedSubset import NamedSubset
from GRANTA_MIScriptingToolkit.NamedTargetedSourceRecord import NamedTargetedSourceRecord
from GRANTA_MIScriptingToolkit.NotatedTargetedSourceRecord import NotatedTargetedSourceRecord
from GRANTA_MIScriptingToolkit.NotatedTargetRecord import NotatedTargetRecord
from GRANTA_MIScriptingToolkit.ParameterDetail import ParameterDetail
from GRANTA_MIScriptingToolkit.ParameterDomain import ParameterDomain
from GRANTA_MIScriptingToolkit.ParameterInformation import ParameterInformation
from GRANTA_MIScriptingToolkit.ParameterReference import ParameterReference
from GRANTA_MIScriptingToolkit.ParameterReferenceAndValue import ParameterReferenceAndValue
from GRANTA_MIScriptingToolkit.ParameterReferencesAndValues import ParameterReferencesAndValues
from GRANTA_MIScriptingToolkit.Parameters import Parameters
from GRANTA_MIScriptingToolkit.ParameterValue import ParameterValue
from GRANTA_MIScriptingToolkit.PartialTableReference import PartialTableReference
from GRANTA_MIScriptingToolkit.PointDataType import PointDataType
from GRANTA_MIScriptingToolkit.PointValueWithParameters import PointValueWithParameters
from GRANTA_MIScriptingToolkit.RangeDataType import RangeDataType
from GRANTA_MIScriptingToolkit.RecordAttribute import RecordAttribute
from GRANTA_MIScriptingToolkit.RecordData import RecordData
from GRANTA_MIScriptingToolkit.RecordExporterParameters import RecordExporterParameters
from GRANTA_MIScriptingToolkit.RecordFilter import RecordFilter
from GRANTA_MIScriptingToolkit.RecordLinkChanges import RecordLinkChanges
from GRANTA_MIScriptingToolkit.RecordLinkGroup import RecordLinkGroup
from GRANTA_MIScriptingToolkit.RecordLinkGroupDetail import RecordLinkGroupDetail
from GRANTA_MIScriptingToolkit.RecordLinkGroupReference import RecordLinkGroupReference
from GRANTA_MIScriptingToolkit.RecordLinkModifications import RecordLinkModifications
from GRANTA_MIScriptingToolkit.RecordNameSearchRequest import RecordNameSearchRequest
from GRANTA_MIScriptingToolkit.RecordReference import RecordReference
from GRANTA_MIScriptingToolkit.RecordSearchCriterion import RecordSearchCriterion
from GRANTA_MIScriptingToolkit.RecordVersionState import RecordVersionState
from GRANTA_MIScriptingToolkit.RecordWithAttributeAddresses import RecordWithAttributeAddresses
from GRANTA_MIScriptingToolkit.RevisionInfo import RevisionInfo
from GRANTA_MIScriptingToolkit.SearchResult import SearchResult
from GRANTA_MIScriptingToolkit.SearchService import SearchService
from GRANTA_MIScriptingToolkit.Series import Series
from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse
from GRANTA_MIScriptingToolkit.SetRecordAttributesRequest import SetRecordAttributesRequest
from GRANTA_MIScriptingToolkit.SetRecordAttributesResponse import SetRecordAttributesResponse
from GRANTA_MIScriptingToolkit.ShortTextDataType import ShortTextDataType
from GRANTA_MIScriptingToolkit.SimpleTextSearch import SimpleTextSearch
from GRANTA_MIScriptingToolkit.SimpleTextSearchResponse import SimpleTextSearchResponse
from GRANTA_MIScriptingToolkit.SourceRecord import SourceRecord
from GRANTA_MIScriptingToolkit.SubsetDetail import SubsetDetail
from GRANTA_MIScriptingToolkit.SubsetReference import SubsetReference
from GRANTA_MIScriptingToolkit.TableDetail import TableDetail
from GRANTA_MIScriptingToolkit.TableReference import TableReference
from GRANTA_MIScriptingToolkit.TabularColumn import TabularColumn
from GRANTA_MIScriptingToolkit.TabularColumnContainsSearchValue import TabularColumnContainsSearchValue
from GRANTA_MIScriptingToolkit.TabularColumnDetail import TabularColumnDetail
from GRANTA_MIScriptingToolkit.TabularDataCell import TabularDataCell
from GRANTA_MIScriptingToolkit.TabularDataRow import TabularDataRow
from GRANTA_MIScriptingToolkit.TabularDataType import TabularDataType
from GRANTA_MIScriptingToolkit.TargetedSourceRecord import TargetedSourceRecord
from GRANTA_MIScriptingToolkit.TreeRecord import TreeRecord
from GRANTA_MIScriptingToolkit.UnitConversionContext import UnitConversionContext
from GRANTA_MIScriptingToolkit.UnitInformation import UnitInformation
from GRANTA_MIScriptingToolkit.UnittedParameterValue import UnittedParameterValue
from GRANTA_MIScriptingToolkit.UnlinkAllRecords import UnlinkAllRecords
from GRANTA_MIScriptingToolkit.UnlinkRecords import UnlinkRecords
from GRANTA_MIScriptingToolkit.XYData import XYData
from GRANTA_MIScriptingToolkit.XYPoint import XYPoint
from GRANTA_MIScriptingToolkit.XYRange import XYRange
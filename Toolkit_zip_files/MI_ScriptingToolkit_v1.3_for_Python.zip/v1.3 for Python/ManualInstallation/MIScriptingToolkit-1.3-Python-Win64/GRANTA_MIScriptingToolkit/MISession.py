from ctypes import POINTER, pointer
from ctypes import c_void_p, c_char_p, c_int, c_bool, string_at, byref
from GRANTA_MIScriptingToolkit import GRANTA_libs
from GRANTA_MIScriptingToolkit.GRANTA_Exceptions import GRANTA_Exception
from GRANTA_MIScriptingToolkit.StringUtils import EnsureEncoded

class MISession(object):
    """
        A connection to a GRANTA MI Server. Don't create this class directly instead see :py:mod:`GRANTA_MISession <GRANTA_MIScriptingToolkit.GRANTA_MISession>`
    
        Arguments:
           * url - url of your GRANTA MI:ServiceLayer installation
    """
    def __init__(self, url="", verbosity=1):
        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        MISession_Create = self.lib.MISession_Create
        MISession_Create.argtypes = [c_char_p, c_int]
        MISession_Create.restype = POINTER(c_void_p)
        self.c_obj = MISession_Create(url.encode('ascii'), verbosity)

        MISession_IdentifyAsPython = self.lib.MISession_IdentifyAsPython
        MISession_IdentifyAsPython.argtypes = [c_void_p]
        MISession_IdentifyAsPython(self.c_obj)
    
    def __del__(self):
        try:
           MISession_Destroy = self.lib.MISession_Destroy
           MISession_Destroy.argtypes = [POINTER(c_void_p)]
           MISession_Destroy(pointer(self.c_obj))
        except:
           pass
    
    
    def __SetInterfaceVersion(self, value):
        MISession_SetInterfaceVersion = self.lib.MISession_SetInterfaceVersion 
        MISession_SetInterfaceVersion.argtypes = [POINTER(c_void_p), c_char_p]
        MISession_SetInterfaceVersion(self.c_obj, value)

    def __SetActAsReadUser(self, value):
        fn = self.lib.MISession_SetActAsReadUser 
        fn.argtypes = [POINTER(c_void_p), c_bool]
        fn(self.c_obj, value)

    def __GetActAsReadUser(self):
        fn = self.lib.MISession_GetActAsReadUser
        fn.argtypes = [POINTER(c_void_p)]
        fn.restype = c_bool
        value = fn(self.c_obj)
        return value
        
    def ConnectionIsValid(self):
        """ Returns a tuple of (bool, string). The first element is whether or not requests can succeed, and the second is a description of the outcome of the test. """
        fn = self.lib.MISession_TestConnection
        fn.argtypes = [POINTER(c_void_p), POINTER(POINTER(c_void_p))]
        fn.restype = c_bool
        msg = POINTER(c_void_p)()
        value = fn(self.c_obj, byref(msg))
        msg = string_at(msg)
        msg = msg.decode("utf-8")
        return value,msg
        
    def TestConnection(self):
        """ Raises an exception if a request to the GRANTA MI Service Layer does not respond or responds with an error. """
        success, message = self.ConnectionIsValid()
        if not success:
            raise GRANTA_Exception("TestConnection", "Connection test failed: {0}.".format(message))        

    def UseAutoLogon(self):
        """ If called, this session will use Windows credentials (of the current principal) to authenticate to the GRANTA MI Service Layer. """
        fn = self.lib.MISession_UseAutoLogon
        fn.argtypes = [POINTER(c_void_p)]
        fn(self.c_obj)
        self.TestConnection()

    def SetCredentials(self, domain, username, password):
        """    
        Arguments:
           * username - your GRANTA MI username
           * password - your GRANTA MI password
           * domain - your GRANTA MI user domain
       
        """
        fn = self.lib.MISession_SetCredentials
        fn.argtypes = [POINTER(c_void_p), c_char_p, c_char_p, c_char_p]
        fn(self.c_obj, EnsureEncoded(domain), EnsureEncoded(username), EnsureEncoded(password))
        self.TestConnection()

    @property
    def actAsReadUser(self):
        """Property name is of type bool. If set to True, this session will perform operations as if it were a read user, even if the session authenticated as a higher privileged role.""" 
        self._actAsReadUser = self.__GetActAsReadUser()
        return self._actAsReadUser

    @actAsReadUser.setter
    def actAsReadUser(self, value):
        """Property actAsReadUser is of type bool. If set to True, this session will perform operations as if it were a read user, even if the session authenticated as a higher privileged role.""" 
        if not isinstance(value, bool):
            raise GRANTA_Exception('actAsReadUser','actAsReadUser: Invalid type name must be of type bool')
        self.__SetActAsReadUser(value)
        self._actAsReadUser = value
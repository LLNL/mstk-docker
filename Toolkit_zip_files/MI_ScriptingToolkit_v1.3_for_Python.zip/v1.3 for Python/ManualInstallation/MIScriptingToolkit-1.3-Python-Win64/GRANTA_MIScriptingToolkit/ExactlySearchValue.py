# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs



class ExactlySearchValue(object):
    """ExactlySearchValue. Search criterion to search for integer values which exactly match the specifed search value.
Applies to integer attributes only.
    
        Arguments:
                * value - type int


    """
    
    def __init__(self, value=None, isOwner=True):
        """

        Arguments:
                * value - type int

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            ExactlySearchValue_Create = self.lib.ExactlySearchValue_Create
            ExactlySearchValue_Create.restype = POINTER(c_void_p)
            self.c_obj = ExactlySearchValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if value is not None:
            self.value = value


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            ExactlySearchValue_Destroy = self.lib.ExactlySearchValue_Destroy
            ExactlySearchValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            ExactlySearchValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def value(self):
        """Property value is of type int. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('value','value: Invalid type value must be of type int')
        self.__SetValue(value)
        self._value = value

    def __GetValue(self):
        ExactlySearchValue_GetValue = self.lib.ExactlySearchValue_GetValue
        ExactlySearchValue_GetValue.argtypes = [POINTER(c_void_p)]
        ExactlySearchValue_GetValue.restype = c_int
        value = ExactlySearchValue_GetValue(self._c_obj)
        return value
    
    def __SetValue(self, value):

        ExactlySearchValue_SetValue = self.lib.ExactlySearchValue_SetValue 
        ExactlySearchValue_SetValue.argtypes = [POINTER(c_void_p), c_int]
        ExactlySearchValue_SetValue(self._c_obj, value)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


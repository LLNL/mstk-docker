# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.RevisionInfo import RevisionInfo


class MIParameterValue(object):
    """MIParameterValue. A named value of a Parameter in a GRANTA MI Database.
    
        Arguments:
                * revisionInfo - type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`
                * value - type float
                * valueName - type str


    """
    
    def __init__(self, revisionInfo=None, value=None, valueName=None, isOwner=True):
        """

        Arguments:
                * revisionInfo - type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`
                * value - type float
                * valueName - type str

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            MIParameterValue_Create = self.lib.MIParameterValue_Create
            MIParameterValue_Create.restype = POINTER(c_void_p)
            self.c_obj = MIParameterValue_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if revisionInfo is not None:
            self.revisionInfo = revisionInfo
        if value is not None:
            self.value = value
        if valueName is not None:
            self.valueName = valueName


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            MIParameterValue_Destroy = self.lib.MIParameterValue_Destroy
            MIParameterValue_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            MIParameterValue_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def revisionInfo(self):
        """Property revisionInfo is of type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`. """ 
        self._revisionInfo = self.__GetRevisionInfo()
        return self._revisionInfo

    @revisionInfo.setter
    def revisionInfo(self, value):
        if not isinstance(value, RevisionInfo):
            raise GRANTA_Exception('revisionInfo','revisionInfo: Invalid type revisionInfo must be of type RevisionInfo')
        self.__SetRevisionInfo(value)
        self._revisionInfo = value

    @property
    def value(self):
        """Property value is of type float. """ 
        self._value = self.__GetValue()
        return self._value

    @value.setter
    def value(self, value):
        if not isinstance(value, float):
            raise GRANTA_Exception('value','value: Invalid type value must be of type float')
        self.__SetValue(value)
        self._value = value

    @property
    def valueName(self):
        """Property valueName is of type str. """ 
        self._valueName = self.__GetValueName()
        return self._valueName

    @valueName.setter
    def valueName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('valueName','valueName: Invalid type valueName must be of type str')
        self.__SetValueName(value)
        self._valueName = value

    def __GetValue(self):
        MIParameterValue_GetValue = self.lib.MIParameterValue_GetValue
        MIParameterValue_GetValue.argtypes = [POINTER(c_void_p)]
        MIParameterValue_GetValue.restype = c_double
        value = MIParameterValue_GetValue(self._c_obj)
        return value
    
    def __SetValue(self, value):

        MIParameterValue_SetValue = self.lib.MIParameterValue_SetValue 
        MIParameterValue_SetValue.argtypes = [POINTER(c_void_p), c_double]
        MIParameterValue_SetValue(self._c_obj, value)

    def __GetValueName(self):
        MIParameterValue_GetValueName = self.lib.MIParameterValue_GetValueName
        MIParameterValue_GetValueName.argtypes = [POINTER(c_void_p)]
        MIParameterValue_GetValueName.restype = POINTER(c_void_p)
        value = MIParameterValue_GetValueName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetValueName(self, value):

        MIParameterValue_SetValueName = self.lib.MIParameterValue_SetValueName 
        MIParameterValue_SetValueName.argtypes = [POINTER(c_void_p), c_char_p]
        MIParameterValue_SetValueName(self._c_obj, EnsureEncoded(value))

    def __GetRevisionInfo(self):
        _revisionInfo = RevisionInfo()
        MIParameterValue_GetRevisionInfo = self.lib.MIParameterValue_GetRevisionInfo
        MIParameterValue_GetRevisionInfo.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        MIParameterValue_GetRevisionInfo(self._c_obj, (_revisionInfo.c_obj))
        
        return _revisionInfo
        
    def __SetRevisionInfo(self, value):

        MIParameterValue_SetRevisionInfo = self.lib.MIParameterValue_SetRevisionInfo 
        MIParameterValue_SetRevisionInfo.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        MIParameterValue_SetRevisionInfo(self._c_obj, value.c_obj)

    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


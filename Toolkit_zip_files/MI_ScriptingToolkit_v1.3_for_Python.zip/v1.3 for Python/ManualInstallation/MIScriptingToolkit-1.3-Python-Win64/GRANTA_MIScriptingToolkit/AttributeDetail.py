# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.AttributeReference import AttributeReference
from GRANTA_MIScriptingToolkit.TabularColumnDetail import TabularColumnDetail
from GRANTA_MIScriptingToolkit.RevisionInfo import RevisionInfo
from GRANTA_MIScriptingToolkit.NamedAttribute import NamedAttribute


class AttributeDetail(object):
    """AttributeDetail. Detailed meta-information about an attribute in a GRANTA MI database.
Does not include values of the attribute. For requests, the name, and type are required. 
    
        Arguments:
                * identity - type int
                * about - type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`
                * name - type str
                * axisName - type str
                * attribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * revisionInfo - type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`
                * chartable - type bool
                * isMeta - type bool
                * defaultThreshold - type str
                * discreteValues - type list of str objects
                * databaseUnit - type str
                * isSearchable - type bool
                * isMultiValued - type bool
                * type - type str
                * order - type int
                * columns - type list of :py:mod:`TabularColumnDetail <GRANTA_MIScriptingToolkit.TabularColumnDetail>` objects


    """
    
    def __init__(self, identity=None, about=None, name=None, axisName=None, attribute=None, revisionInfo=None, chartable=None, isMeta=None, defaultThreshold=None, discreteValues=None, databaseUnit=None, isSearchable=None, isMultiValued=None, type=None, order=None, columns=None, isOwner=True):
        """

        Arguments:
                * identity - type int
                * about - type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`
                * name - type str
                * axisName - type str
                * attribute - type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`
                * revisionInfo - type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`
                * chartable - type bool
                * isMeta - type bool
                * defaultThreshold - type str
                * discreteValues - type list of str objects
                * databaseUnit - type str
                * isSearchable - type bool
                * isMultiValued - type bool
                * type - type str
                * order - type int
                * columns - type list of :py:mod:`TabularColumnDetail <GRANTA_MIScriptingToolkit.TabularColumnDetail>` objects

 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        if isOwner:
            AttributeDetail_Create = self.lib.AttributeDetail_Create
            AttributeDetail_Create.restype = POINTER(c_void_p)
            self.c_obj = AttributeDetail_Create()
        else:
            self.c_obj = POINTER(c_void_p)()
            self._parent = None
        self._isOwner = isOwner
        
        if identity is not None:
            self.identity = identity
        if about is not None:
            self.about = about
        if name is not None:
            self.name = name
        if axisName is not None:
            self.axisName = axisName
        if attribute is not None:
            self.attribute = attribute
        if revisionInfo is not None:
            self.revisionInfo = revisionInfo
        if chartable is not None:
            self.chartable = chartable
        if isMeta is not None:
            self.isMeta = isMeta
        if defaultThreshold is not None:
            self.defaultThreshold = defaultThreshold
        if discreteValues is not None:
            self.discreteValues = discreteValues
        if databaseUnit is not None:
            self.databaseUnit = databaseUnit
        if isSearchable is not None:
            self.isSearchable = isSearchable
        if isMultiValued is not None:
            self.isMultiValued = isMultiValued
        if type is not None:
            self.type = type
        if order is not None:
            self.order = order
        if columns is not None:
            self.columns = columns


    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            AttributeDetail_Destroy = self.lib.AttributeDetail_Destroy
            AttributeDetail_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            AttributeDetail_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def identity(self):
        """Property identity is of type int. """ 
        self._identity = self.__GetIdentity()
        return self._identity

    @identity.setter
    def identity(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('identity','identity: Invalid type identity must be of type int')
        
        self._identity = value

    @property
    def about(self):
        """Property about is of type :py:mod:`NamedAttribute <GRANTA_MIScriptingToolkit.NamedAttribute>`. Only populated if 'isMeta' is True.""" 
        self._about = self.__GetAbout()
        return self._about

    @about.setter
    def about(self, value):
        if not isinstance(value, NamedAttribute):
            raise GRANTA_Exception('about','about: Invalid type about must be of type NamedAttribute')
        
        self._about = value

    @property
    def name(self):
        """Property name is of type str. """ 
        self._name = self.__GetName()
        return self._name

    @name.setter
    def name(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('name','name: Invalid type name must be of type str')
        self.__SetName(value)
        self._name = value

    @property
    def axisName(self):
        """Property axisName is of type str. """ 
        self._axisName = self.__GetAxisName()
        return self._axisName

    @axisName.setter
    def axisName(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('axisName','axisName: Invalid type axisName must be of type str')
        
        self._axisName = value

    @property
    def attribute(self):
        """Property attribute is of type :py:mod:`AttributeReference <GRANTA_MIScriptingToolkit.AttributeReference>`. """ 
        self._attribute = self.__GetAttribute()
        return self._attribute

    @attribute.setter
    def attribute(self, value):
        if not isinstance(value, AttributeReference):
            raise GRANTA_Exception('attribute','attribute: Invalid type attribute must be of type AttributeReference')
        self.__SetAttribute(value)
        self._attribute = value

    @property
    def revisionInfo(self):
        """Property revisionInfo is of type :py:mod:`RevisionInfo <GRANTA_MIScriptingToolkit.RevisionInfo>`. """ 
        self._revisionInfo = self.__GetRevisionInfo()
        return self._revisionInfo

    @revisionInfo.setter
    def revisionInfo(self, value):
        if not isinstance(value, RevisionInfo):
            raise GRANTA_Exception('revisionInfo','revisionInfo: Invalid type revisionInfo must be of type RevisionInfo')
        
        self._revisionInfo = value

    @property
    def chartable(self):
        """Property chartable is of type bool. """ 
        self._chartable = self.__GetChartable()
        return self._chartable

    @chartable.setter
    def chartable(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('chartable','chartable: Invalid type chartable must be of type bool')
        
        self._chartable = value

    @property
    def isMeta(self):
        """Property isMeta is of type bool. If this is True, the 'about' property may have additional information about the related parent attribute.""" 
        self._isMeta = self.__GetIsMeta()
        return self._isMeta

    @isMeta.setter
    def isMeta(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('isMeta','isMeta: Invalid type isMeta must be of type bool')
        
        self._isMeta = value

    @property
    def defaultThreshold(self):
        """Property defaultThreshold is of type str. """ 
        self._defaultThreshold = self.__GetDefaultThreshold()
        return self._defaultThreshold

    @defaultThreshold.setter
    def defaultThreshold(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('defaultThreshold','defaultThreshold: Invalid type defaultThreshold must be of type str')
        
        self._defaultThreshold = value

    @property
    def discreteValues(self):
        """Property discreteValues is a list of str objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._discreteValues = self.__GetDiscreteValues()
        except:
            pass
        return self._discreteValues

    @discreteValues.setter
    def discreteValues(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('discreteValues','discreteValues: Invalid type discreteValues must be a list of str')
        
        self._discreteValues = value

    @property
    def databaseUnit(self):
        """Property databaseUnit is of type str. """ 
        self._databaseUnit = self.__GetDatabaseUnit()
        return self._databaseUnit

    @databaseUnit.setter
    def databaseUnit(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('databaseUnit','databaseUnit: Invalid type databaseUnit must be of type str')
        
        self._databaseUnit = value

    @property
    def isSearchable(self):
        """Property isSearchable is of type bool. """ 
        self._isSearchable = self.__GetIsSearchable()
        return self._isSearchable

    @isSearchable.setter
    def isSearchable(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('isSearchable','isSearchable: Invalid type isSearchable must be of type bool')
        
        self._isSearchable = value

    @property
    def isMultiValued(self):
        """Property isMultiValued is of type bool. """ 
        self._isMultiValued = self.__GetIsMultiValued()
        return self._isMultiValued

    @isMultiValued.setter
    def isMultiValued(self, value):
        if not isinstance(value, bool):
            raise GRANTA_Exception('isMultiValued','isMultiValued: Invalid type isMultiValued must be of type bool')
        
        self._isMultiValued = value

    @property
    def type(self):
        """Property type is of type str. """ 
        self._type = self.__GetType()
        return self._type

    @type.setter
    def type(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('type','type: Invalid type type must be of type str')
        self.__SetType(value)
        self._type = value

    @property
    def order(self):
        """Property order is of type int. """ 
        self._order = self.__GetOrder()
        return self._order

    @order.setter
    def order(self, value):
        if not isinstance(value, int):
            raise GRANTA_Exception('order','order: Invalid type order must be of type int')
        
        self._order = value

    @property
    def columns(self):
        """Property columns is a list of :py:mod:`TabularColumnDetail <GRANTA_MIScriptingToolkit.TabularColumnDetail>` objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._columns = self.__GetColumns()
        except:
            pass
        return self._columns

    @columns.setter
    def columns(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('columns','columns: Invalid type columns must be a list of TabularColumnDetail')
        
        self._columns = value

    def __GetAttribute(self):
        _attributeReference = AttributeReference()
        AttributeDetail_GetAttribute = self.lib.AttributeDetail_GetAttribute
        AttributeDetail_GetAttribute.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeDetail_GetAttribute(self._c_obj, (_attributeReference.c_obj))
        
        return _attributeReference
        
    def __SetAttribute(self, value):

        AttributeDetail_SetAttribute = self.lib.AttributeDetail_SetAttribute 
        AttributeDetail_SetAttribute.argtypes = [POINTER(c_void_p), POINTER(c_void_p)]
        AttributeDetail_SetAttribute(self._c_obj, value.c_obj)

    def __GetName(self):
        AttributeDetail_GetName = self.lib.AttributeDetail_GetName
        AttributeDetail_GetName.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetName.restype = POINTER(c_void_p)
        value = AttributeDetail_GetName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetName(self, value):

        AttributeDetail_SetName = self.lib.AttributeDetail_SetName 
        AttributeDetail_SetName.argtypes = [POINTER(c_void_p), c_char_p]
        AttributeDetail_SetName(self._c_obj, EnsureEncoded(value))

    def __GetType(self):
        AttributeDetail_GetType = self.lib.AttributeDetail_GetType
        AttributeDetail_GetType.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetType.restype = POINTER(c_void_p)
        value = AttributeDetail_GetType(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __SetType(self, value):

        AttributeDetail_SetType = self.lib.AttributeDetail_SetType 
        AttributeDetail_SetType.argtypes = [POINTER(c_void_p), c_char_p]
        AttributeDetail_SetType(self._c_obj, EnsureEncoded(value))

    def __GetIsSearchable(self):
        AttributeDetail_GetIsSearchable = self.lib.AttributeDetail_GetIsSearchable
        AttributeDetail_GetIsSearchable.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetIsSearchable.restype = c_bool
        value = AttributeDetail_GetIsSearchable(self._c_obj)
        return value
    
    def __GetIsMultiValued(self):
        AttributeDetail_GetIsMultiValued = self.lib.AttributeDetail_GetIsMultiValued
        AttributeDetail_GetIsMultiValued.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetIsMultiValued.restype = c_bool
        value = AttributeDetail_GetIsMultiValued(self._c_obj)
        return value
    
    def __GetOrder(self):
        AttributeDetail_GetOrder = self.lib.AttributeDetail_GetOrder
        AttributeDetail_GetOrder.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetOrder.restype = c_int
        value = AttributeDetail_GetOrder(self._c_obj)
        return value
    
    def __GetDefaultThreshold(self):
        AttributeDetail_GetDefaultThreshold = self.lib.AttributeDetail_GetDefaultThreshold
        AttributeDetail_GetDefaultThreshold.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetDefaultThreshold.restype = POINTER(c_void_p)
        value = AttributeDetail_GetDefaultThreshold(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetDatabaseUnit(self):
        AttributeDetail_GetDatabaseUnit = self.lib.AttributeDetail_GetDatabaseUnit
        AttributeDetail_GetDatabaseUnit.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetDatabaseUnit.restype = POINTER(c_void_p)
        value = AttributeDetail_GetDatabaseUnit(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetNumberOfDiscreteValues(self):
        AttributeDetail_GetNumberOfDiscreteValues = self.lib.AttributeDetail_GetNumberOfDiscreteValues
        AttributeDetail_GetNumberOfDiscreteValues.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetNumberOfDiscreteValues.restype = c_int
        value = AttributeDetail_GetNumberOfDiscreteValues(self._c_obj)
        return value
    
    def __GetDiscreteValueElement(self,i):
        AttributeDetail_GetDiscreteValue = self.lib.AttributeDetail_GetDiscreteValue
        AttributeDetail_GetDiscreteValue.argtypes = [POINTER(c_void_p), c_int]
        AttributeDetail_GetDiscreteValue.restype = POINTER(c_void_p)
        value = AttributeDetail_GetDiscreteValue(self._c_obj, i)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
    
    def __GetDiscreteValues(self):
         n = self.__GetNumberOfDiscreteValues();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetDiscreteValueElement(i))
         return temp
    
    def __GetAxisName(self):
        AttributeDetail_GetAxisName = self.lib.AttributeDetail_GetAxisName
        AttributeDetail_GetAxisName.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetAxisName.restype = POINTER(c_void_p)
        value = AttributeDetail_GetAxisName(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetNumberOfColumns(self):
        AttributeDetail_GetNumberOfColumns = self.lib.AttributeDetail_GetNumberOfColumns
        AttributeDetail_GetNumberOfColumns.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetNumberOfColumns.restype = c_int
        value = AttributeDetail_GetNumberOfColumns(self._c_obj)
        return value
    
    def __GetColumnElement(self,i):
        value = TabularColumnDetail()
        AttributeDetail_GetColumn = self.lib.AttributeDetail_GetColumn
        AttributeDetail_GetColumn.argtypes = [POINTER(c_void_p), (POINTER(c_void_p)), c_int]
        AttributeDetail_GetColumn(self._c_obj, value.c_obj, i)
        
        return value
    
    def __GetColumns(self):
         n = self.__GetNumberOfColumns();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetColumnElement(i))
         return temp
    
    def __GetIdentity(self):
        AttributeDetail_GetIdentity = self.lib.AttributeDetail_GetIdentity
        AttributeDetail_GetIdentity.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetIdentity.restype = c_int
        value = AttributeDetail_GetIdentity(self._c_obj)
        return value
    
    def __GetRevisionInfo(self):
        _revisionInfo = RevisionInfo()
        AttributeDetail_GetRevisionInfo = self.lib.AttributeDetail_GetRevisionInfo
        AttributeDetail_GetRevisionInfo.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeDetail_GetRevisionInfo(self._c_obj, (_revisionInfo.c_obj))
        
        return _revisionInfo
        
    def __GetChartable(self):
        AttributeDetail_GetChartable = self.lib.AttributeDetail_GetChartable
        AttributeDetail_GetChartable.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetChartable.restype = c_bool
        value = AttributeDetail_GetChartable(self._c_obj)
        return value
    
    def __GetIsMeta(self):
        AttributeDetail_GetIsMeta = self.lib.AttributeDetail_GetIsMeta
        AttributeDetail_GetIsMeta.argtypes = [POINTER(c_void_p)]
        AttributeDetail_GetIsMeta.restype = c_bool
        value = AttributeDetail_GetIsMeta(self._c_obj)
        return value
    
    def __GetAbout(self):
        _namedAttribute = NamedAttribute()
        AttributeDetail_GetAbout = self.lib.AttributeDetail_GetAbout
        AttributeDetail_GetAbout.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        AttributeDetail_GetAbout(self._c_obj, (_namedAttribute.c_obj))
        
        return _namedAttribute
        
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value


# This file was automatically generated

from ctypes import POINTER, pointer, string_at, byref
from ctypes import c_void_p, c_int, c_char_p, c_bool, c_double
from .GRANTA_Logging import GRANTA_Logging
from .GRANTA_Exceptions import GRANTA_Exception
from .StringUtils import StringUtils, EnsureEncoded, Defs
import sys

from GRANTA_MIScriptingToolkit import GRANTA_libs

from GRANTA_MIScriptingToolkit.ServiceLayerResponse import ServiceLayerResponse


class GetUnitSystemsResponse(object):
    """GetUnitSystemsResponse. The ouput of a GetUnitSystems requests. 
Contains an array of unit systems for the specified database.
    
        Arguments:
            c_obj - ctypes.POINTER to a GetUnitSystemsResponse object.

    """
    
    def __init__(self, c_obj):
        """

        Arguments:
            c_obj - ctypes.POINTER to a GetUnitSystemsResponse object.
 
        """

        self.lib = GRANTA_libs.MIServiceLayerCAPILib
        self.c_obj = c_obj
        self._isOwner = True

    def __del__(self):
        if not hasattr(self, "_isOwner"):
            return
        if not self._isOwner:
            self._parent = None
            return
        try:
            GetUnitSystemsResponse_Destroy = self.lib.GetUnitSystemsResponse_Destroy
            GetUnitSystemsResponse_Destroy.argtypes = [POINTER(POINTER(c_void_p))]
            GetUnitSystemsResponse_Destroy(pointer(self._c_obj))
        except:
            pass
    
    @property
    def serviceLayerResponse(self):
        """Property serviceLayerResponse is of type :py:mod:`ServiceLayerResponse <GRANTA_MIScriptingToolkit.ServiceLayerResponse>`. """ 
        self._serviceLayerResponse = self.__GetServiceLayerResponse()
        return self._serviceLayerResponse

    @serviceLayerResponse.setter
    def serviceLayerResponse(self, value):
        if not isinstance(value, ServiceLayerResponse):
            raise GRANTA_Exception('serviceLayerResponse','serviceLayerResponse: Invalid type serviceLayerResponse must be of type ServiceLayerResponse')
        
        self._serviceLayerResponse = value

    @property
    def DBKey(self):
        """Property DBKey is of type str. """ 
        self._DBKey = self.__GetDBKey()
        return self._DBKey

    @DBKey.setter
    def DBKey(self, value):
        if not isinstance(value, Defs.string_types):
            raise GRANTA_Exception('DBKey','DBKey: Invalid type DBKey must be of type str')
        
        self._DBKey = value

    @property
    def unitSystems(self):
        """Property unitSystems is a list of str objects.  
        Warning: Do not attempt to edit or append to the returned value.
        """ 
        try:
            self._unitSystems = self.__GetUnitSystems()
        except:
            pass
        return self._unitSystems

    @unitSystems.setter
    def unitSystems(self, value):
        if not isinstance(value, list):
            raise GRANTA_Exception('unitSystems','unitSystems: Invalid type unitSystems must be a list of str')
        
        self._unitSystems = value

    def __GetDBKey(self):
        GetUnitSystemsResponse_GetDBKey = self.lib.GetUnitSystemsResponse_GetDBKey
        GetUnitSystemsResponse_GetDBKey.argtypes = [POINTER(c_void_p)]
        GetUnitSystemsResponse_GetDBKey.restype = POINTER(c_void_p)
        value = GetUnitSystemsResponse_GetDBKey(self._c_obj)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
        
    def __GetServiceLayerResponse(self):
        _serviceLayerResponse = ServiceLayerResponse()
        GetUnitSystemsResponse_GetServiceLayerResponse = self.lib.GetUnitSystemsResponse_GetServiceLayerResponse
        GetUnitSystemsResponse_GetServiceLayerResponse.argtypes = [POINTER(c_void_p), (POINTER(c_void_p))]
        GetUnitSystemsResponse_GetServiceLayerResponse(self._c_obj, (_serviceLayerResponse.c_obj))
        
        return _serviceLayerResponse
        
    def __GetNumberOfUnitSystems(self):
        GetUnitSystemsResponse_GetNumberOfUnitSystems = self.lib.GetUnitSystemsResponse_GetNumberOfUnitSystems
        GetUnitSystemsResponse_GetNumberOfUnitSystems.argtypes = [POINTER(c_void_p)]
        GetUnitSystemsResponse_GetNumberOfUnitSystems.restype = c_int
        value = GetUnitSystemsResponse_GetNumberOfUnitSystems(self._c_obj)
        return value
    
    def __GetUnitSystemElement(self,i):
        GetUnitSystemsResponse_GetUnitSystem = self.lib.GetUnitSystemsResponse_GetUnitSystem
        GetUnitSystemsResponse_GetUnitSystem.argtypes = [POINTER(c_void_p), c_int]
        GetUnitSystemsResponse_GetUnitSystem.restype = POINTER(c_void_p)
        value = GetUnitSystemsResponse_GetUnitSystem(self._c_obj, i)
        strValue = string_at(value)
        StringUtils().delete(value)
        return strValue.decode('utf-8')
    
    def __GetUnitSystems(self):
         n = self.__GetNumberOfUnitSystems();
         temp = []
         for i in range(0,n):
             temp.append(self.__GetUnitSystemElement(i))
         return temp
    
    @property
    def c_obj(self):
        """Pointer to the underlying C-object"""
        return self._c_obj

    @c_obj.setter
    def c_obj(self, value):
        self._c_obj = value

